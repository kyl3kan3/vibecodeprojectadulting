import 'react-native-url-polyfill/auto';
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";

import { useEffect, useState } from "react";
import { View, LogBox } from "react-native";

import * as Notifications from "expo-notifications";
import * as SystemUI from "expo-system-ui";
import * as SplashScreen from "expo-splash-screen";
import AppNavigator from "./src/navigation/AppNavigator";
import { DailyReminderService } from "./src/services/dailyReminders";
import { AuthProvider } from "./src/contexts/AuthContext";
import ErrorBoundary from "./src/components/ErrorBoundary";
import { initIAP, cleanupIAP } from "./src/services/storekit";
import { setAuthTokenProvider } from "./src/api/proxy";
import { supabaseMCP } from "./src/lib/supabase-mcp";


/*
IMPORTANT NOTICE: DO NOT REMOVE
There are already environment keys in the project. 
Before telling the user to add them, check if you already have access to the required keys through bash.
Directly access them with process.env.${key}

Correct usage:
process.env.EXPO_PUBLIC_VIBECODE_{key}
//directly access the key

Incorrect usage:
import { OPENAI_API_KEY } from '@env';
//don't use @env, its depreicated

Incorrect usage:
import Constants from 'expo-constants';
const openai_api_key = Constants.expoConfig.extra.apikey;
//don't use expo-constants, its depreicated

*/

// Keep splash screen visible during initial setup
SplashScreen.preventAutoHideAsync();

export default function App() {
  
  // App readiness flag (no manual icon font loading)
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Set up AI proxy auth token provider
    setAuthTokenProvider(async () => {
      try {
        const session = await supabaseMCP.authGetSession();
        return session?.token ?? null;
      } catch {
        return null;
      }
    });

    // Dev-safe console.error downgrade for noisy non-fatal logs
    if (__DEV__) {
      const originalError = console.error;
      console.error = (...args: any[]) => {
        const first = String(args[0] || "");
        const noisy = [
          "Lesson structure",
          "Failed to convert lesson",
          "Database error",
          "Error loading skills from database",
          "Error force refreshing lesson",
          "Error loading tips from database",
          "AI Error"
        ];
        if (noisy.some(s => first.includes(s))) {
          console.warn(...args);
          return;
        }
        originalError(...args);
      };
    }

    // Native window background to avoid white flash in production
    SystemUI.setBackgroundColorAsync("#111827").catch(() => {});

    // Notification handler
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
        shouldShowBanner: true,
        shouldShowList: true,
      }),
    });

    const subscription = Notifications.addNotificationResponseReceivedListener(
      DailyReminderService.handleNotificationResponse
    );

    DailyReminderService.scheduleDailyReminders().catch(() => {});

    // IAP: Initialize in-app purchase service
    initIAP().catch((error) => {
      console.warn("Failed to initialize IAP:", error);
    });
    
    return () => { 
      subscription.remove(); 
      cleanupIAP();
    };
  }, []);

  useEffect(() => {
    // Minimal readiness gate: hide splash once initial effects ran
    setIsReady(true);
    SplashScreen.hideAsync();
    // Sync entitlement once at launch
    (async () => {
      try {
        const { storekit } = await import("./src/services/storekit");
        const { useUIStore } = await import("./src/state");
        const res = await storekit.getActive();
        useUIStore.getState().setIsPro(!!res?.active);
      } catch {}
    })();
  }, []);

  // Do not render until ready (keeps splash until we hide it)
  if (!isReady) {
    return null;
  }

  const navTheme = {
    ...DarkTheme,
    colors: {
      ...DarkTheme.colors,
      primary: "#10B981",
      background: "#111827",
      card: "#111827",
      text: "#FFFFFF",
      border: "#1F2937",
      notification: "#10B981",
    },
  } as const;

  const linking = {
    prefixes: ["projectadulting://", "https://decent4.com"],
    config: {
      screens: {
        MainTabs: {
          screens: {
            Coach: "appclip/ask"
          }
        },
        TipDetail: "tip/:tipId",
        SavedTips: "saved"
      }
    }
  } as const;

  return (
    <View style={{ flex: 1, backgroundColor: "#111827" }}>
      <SafeAreaProvider>
        <AuthProvider>
          <NavigationContainer linking={linking as any} theme={navTheme as any}>
            <ErrorBoundary>
              <AppNavigator />
            </ErrorBoundary>
          </NavigationContainer>
        </AuthProvider>
        <StatusBar style="light" />
      </SafeAreaProvider>
    </View>
  );
}
