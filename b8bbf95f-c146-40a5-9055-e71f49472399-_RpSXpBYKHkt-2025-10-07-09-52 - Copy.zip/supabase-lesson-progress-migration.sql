-- Migration: Add user_lesson_progress table for cloud storage of lesson progress
-- This allows users to sync progress across devices and prevents data loss

-- Create user_lesson_progress table
CREATE TABLE IF NOT EXISTS user_lesson_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  skill_id TEXT NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  completed_steps TEXT[] DEFAULT '{}',
  step_results JSONB DEFAULT '{}',
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  notes TEXT,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()),
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  UNIQUE(user_id, skill_id)
);

-- Enable Row Level Security (RLS)
ALTER TABLE user_lesson_progress ENABLE ROW LEVEL SECURITY;

-- Create policies for user_lesson_progress table
CREATE POLICY "Users can view own lesson progress" 
  ON user_lesson_progress FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own lesson progress" 
  ON user_lesson_progress FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own lesson progress" 
  ON user_lesson_progress FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own lesson progress" 
  ON user_lesson_progress FOR DELETE 
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS user_lesson_progress_user_id_idx ON user_lesson_progress(user_id);
CREATE INDEX IF NOT EXISTS user_lesson_progress_skill_id_idx ON user_lesson_progress(skill_id);
CREATE INDEX IF NOT EXISTS user_lesson_progress_completed_idx ON user_lesson_progress(completed);
CREATE INDEX IF NOT EXISTS user_lesson_progress_updated_at_idx ON user_lesson_progress(updated_at DESC);

-- Create trigger for updated_at
CREATE TRIGGER user_lesson_progress_updated_at
  BEFORE UPDATE ON user_lesson_progress
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

-- Create composite index for user+skill queries (most common query pattern)
CREATE INDEX IF NOT EXISTS user_lesson_progress_user_skill_idx ON user_lesson_progress(user_id, skill_id);

-- Add comment for documentation
COMMENT ON TABLE user_lesson_progress IS 'Stores user progress for lessons/skills with cloud sync support';
COMMENT ON COLUMN user_lesson_progress.step_results IS 'JSONB containing detailed step results including checklist items, timers, etc';
COMMENT ON COLUMN user_lesson_progress.completed_steps IS 'Array of step IDs that have been completed';
