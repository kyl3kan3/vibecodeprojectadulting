import React, { createContext, useContext, useEffect, useState } from "react";
import { AppState } from "react-native";
import { supabaseMCP } from "../lib/supabase-mcp";
import { useProgressStore, useUIStore, useTipsStore } from "../state";
import { useAuthStore, shouldValidateSession } from "../state/auth-store";
import { authSecurityManager } from "../utils/auth-security";
import { storekit } from "../services/storekit";
import { sessionMonitor } from "../utils/session-monitor";
import { sessionRecovery } from "../utils/session-recovery";
import { migrateStoreData } from "../state/data-migration";
import { sessionAnalytics, trackLogin, trackLogout } from "../utils/session-analytics";
import { sessionSecurity, initializeSessionSecurity } from "../utils/session-security";
import { getDisplayName } from "../utils/profile-display";

const ADMIN_EMAILS = (process.env.EXPO_PUBLIC_ADMIN_EMAILS || "kyl3kan3@gmail.com")
  .split(/[\,\s]+/)
  .map((e: string) => e.trim().toLowerCase())
  .filter(Boolean);

const isAdminEmail = (email?: string | null) => !!email && ADMIN_EMAILS.includes(email.toLowerCase());

// Proxy session types
export type Session = { token: string } | null;
export type User = { id: string; email?: string | null } | null;
export type Profile = {
  id: string;
  email: string;
  full_name?: string | null;
  avatar_url?: string | null;
  username?: string | null;
  created_at?: string;
  updated_at?: string;
} | null;

interface AuthContextType {
  user: User;
  profile: Profile;
  session: Session;
  loading: boolean;
  signIn: (email: string, password: string, rememberMe?: boolean) => Promise<{ error: any }>; 
  signUp: (email: string, password: string, fullName?: string) => Promise<{ error: any }>; 
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<NonNullable<Profile>>) => Promise<{ error: any }>; 
  refreshSession: () => Promise<void>;
  sessionHealth: { isHealthy: boolean; issues: string[] } | null;
  recoverSession: () => Promise<boolean>;
  getAnalyticsSummary: () => { currentSession: string; totalEvents: number; recentActivity: string; healthScore: number };
  getSecurityStatus: () => { isSecure: boolean; riskScore: number; activeThreats: number; lastValidation: number; recommendations: string[] };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User>(null);
  const [profile, setProfile] = useState<Profile>(null);
  const [session, setSession] = useState<Session>(null);
  const [loading, setLoading] = useState(true);
  const [sessionHealth, setSessionHealth] = useState<{ isHealthy: boolean; issues: string[] } | null>(null);
  
  const authStore = useAuthStore();

  useEffect(() => {
    // One-time init
    storekit.init();

    // Initialize app (migrate data, but DON'T load from database yet)
    (async () => {
      try {
        // Migrate data from old unified-store to new stores (one-time)
        await migrateStoreData();
        
        // NOTE: Don't load skills/tips here - they require auth token
        // They will be loaded after successful session restoration
        if (__DEV__) console.log('[AuthContext] Data migration complete, waiting for auth...');
      } catch (e) { if (__DEV__) console.warn("App initialization error", e); }
    })();

    // Hybrid session restoration (memory + optional persistence)
    (async () => {
      // Ensure loading is set to false after max 10 seconds no matter what
      const loadingTimeout = setTimeout(() => {
        if (__DEV__) console.warn('[AuthContext] ⚠️ Loading timeout reached - forcing loading=false');
        setLoading(false);
      }, 10000);

      try {
        if (__DEV__) console.log('[AuthContext] Starting session restoration...');
        
        // Wait for auth store hydration
        if (!authStore.hydrated) {
          if (__DEV__) console.log('[AuthContext] Waiting for auth store hydration...');
          // Wait up to 2 seconds for hydration
          let attempts = 0;
          while (!authStore.hydrated && attempts < 20) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
          }
        }
        
        // Check if we should auto-restore from persistent storage
        const shouldRestore = authStore.shouldAutoRestore();
        if (__DEV__) console.log('[AuthContext] shouldAutoRestore():', shouldRestore, {
          rememberMe: authStore.rememberMe,
          hasToken: !!authStore.token,
          hasUser: !!authStore.user,
          isExpired: authStore.isExpired()
        });
        
        if (shouldRestore) {
          if (__DEV__) console.log('[AuthContext] Attempting to restore from persistent storage');
          
          const persistedToken = authStore.token;
          const persistedUser = authStore.user;
          
          if (persistedToken && persistedUser) {
            try {
              // Try to refresh the token first to ensure it's valid
              let activeToken = persistedToken;
              let activeUser = persistedUser;
              
              if (__DEV__) console.log('[AuthContext] Attempting to refresh token before restoration...');
              
              // Set the old token temporarily so refresh can use it
              supabaseMCP.setToken(persistedToken);
              (global as any).__AUTH_USER__ = persistedUser;
              const persistedRefreshToken = authStore.refreshToken;
              if (persistedRefreshToken) {
                (global as any).__REFRESH_TOKEN__ = persistedRefreshToken;
              }
              
              try {
                // Try to refresh the session
                const refreshResult = await supabaseMCP.authRefreshSession();
                if (refreshResult?.token && refreshResult?.user) {
                  if (__DEV__) console.log('[AuthContext] ✅ Token refreshed successfully');
                  activeToken = refreshResult.token;
                  activeUser = refreshResult.user;
                  
                  // Update auth store with new token
                  authStore.setAuth(
                    activeToken, 
                    activeUser, 
                    true, 
                    refreshResult.refreshToken || persistedRefreshToken
                  );
                } else {
                  if (__DEV__) console.log('[AuthContext] ⚠️ Token refresh returned invalid data, using stored token');
                }
              } catch (refreshError: any) {
                if (__DEV__) console.warn('[AuthContext] ⚠️ Token refresh failed, using stored token:', refreshError.message);
                // Continue with the stored token - it might still be valid
                // If it's truly invalid, we'll fail on first API call and user can re-login
              }
              
              // Set final tokens in memory
              supabaseMCP.setToken(activeToken);
              (global as any).__AUTH_USER__ = activeUser;
              
              if (__DEV__) console.log('[AuthContext] Token and user restored to memory:', {
                hasToken: !!activeToken,
                userId: activeUser.id,
                email: activeUser.email,
                wasRefreshed: activeToken !== persistedToken
              });
              
              // CRITICAL: Set session and user state BEFORE afterLogin
              setSession({ token: activeToken });
              setUser(activeUser);
              
              // Wait a tick for state to propagate
              await new Promise(resolve => setTimeout(resolve, 50));
              
              if (__DEV__) console.log('[AuthContext] Session state updated:', {
                hasSession: true,
                hasUser: true,
                userId: persistedUser.id,
                email: persistedUser.email
              });
              
              authStore.updateLastValidated();
              authSecurityManager.resetFailureCount();
              
              // CRITICAL: Mark auth as completed so AppNavigator knows user has authenticated
              try { 
                useUIStore.getState().setAuthCompleted(true); 
                if (__DEV__) console.log('[AuthContext] Set authCompleted=true in UI store');
              } catch {}
              
              // Now run afterLogin to load profile (catch errors so they don't break restoration)
              // TEMPORARY: Skip afterLogin to prevent loading hangs - data will be loaded on-demand
              try {
                // Only load profile, skip skills/tips/progress sync for now
                if (__DEV__) console.log('[AuthContext] Loading profile only (skipping skills/tips/progress)...');
                await loadProfile(activeUser.id);
                
                // Set UI store flags
                try { useUIStore.getState().setAuthCompleted(true); } catch {}
                try {
                  const store = useUIStore.getState();
                  if (!store.userProfile) {
                    store.ensureLocalProfile();
                  }
                  (store as any).setAuthUser?.({ id: activeUser.id, email: activeUser.email || null });
                } catch {}
                
                if (__DEV__) console.log('[AuthContext] ✅ Profile loaded');
              } catch (afterLoginError: any) {
                // Don't let afterLogin errors break the session restoration
                if (__DEV__) console.warn('[AuthContext] ⚠️ Profile load failed, but session is restored:', afterLoginError?.message || afterLoginError);
              }
              
              if (__DEV__) console.log('[AuthContext] ✅ Session restoration complete - user should be logged in');
            } catch (restoreError: any) {
              if (__DEV__) console.error('[AuthContext] ❌ Session restoration failed:', restoreError);
              // Don't clear auth on error during restoration - just log it
            }
          } else {
            if (__DEV__) console.log('[AuthContext] ❌ No persisted token or user found in storage');
          }
        } else {
          // Try memory-only session restore (legacy behavior)
          if (__DEV__) console.log('[AuthContext] Attempting memory-only session restore');
          
          const s = await supabaseMCP.authGetSession();
          const u = (s as any)?.user || null;
          
          if (s?.token && u) {
            if (__DEV__) console.log('[AuthContext] Memory session restored successfully');
            setSession({ token: s.token });
            setUser(u);
            await afterLogin(u);
          } else {
            if (__DEV__) console.log('[AuthContext] No valid session found - user needs to sign in');
            setSession(null);
            setUser(null);
          }
        }
      } catch (e) {
        if (__DEV__) console.warn("[AuthContext] Session restoration error (not clearing auth):", e);
        // Don't automatically clear auth on errors - the stored data might still be valid
        // Just set loading to false and let the user try to use the app
        // If the token is truly invalid, they'll get errors on first API call
      } finally {
        clearTimeout(loadingTimeout);
        setLoading(false);
        // Debug: Log final state before navigation decisions are made
        if (__DEV__) {
          setTimeout(() => {
            if (__DEV__) console.log('[AuthContext] Final state after restoration:', {
              hasUser: !!user,
              hasSession: !!session,
              userId: user?.id,
              email: user?.email
            });
          }, 100);
        }
        if (__DEV__) console.log('[AuthContext] Session restoration complete, loading=false');
      }
    })();
}, []);

  // Initialize session monitoring when auth context mounts
  useEffect(() => {
    // Start session monitoring
    sessionMonitor.start();
    
    // Initialize session security
    initializeSessionSecurity();
    
    // Listen to session health changes
    const unsubscribe = sessionMonitor.onHealthChange((health) => {
      setSessionHealth({
        isHealthy: health.isHealthy,
        issues: health.issues
      });
    });

    return () => {
      unsubscribe();
      sessionMonitor.stop();
      sessionSecurity.cleanup();
    };
  }, []);

  // App state monitoring for session validation
  useEffect(() => {
    const handleAppStateChange = async (nextAppState: string) => {
      if (nextAppState === 'active' && user && authStore.rememberMe) {
        // Check if session needs validation (24h+ since last validation)
        if (shouldValidateSession()) {
          if (__DEV__) console.log('[AuthContext] App became active - validating persistent session');
          
          try {
            // Perform security validation first
            const securityValidation = await authSecurityManager.validateSessionSecurity();
            
            if (securityValidation.shouldClearAuth) {
              if (__DEV__) console.log('[AuthContext] Security validation failed - signing out');
              await signOut();
              return;
            }
            
            const s = await supabaseMCP.authGetSession();
            const u = (s as any)?.user || null;
            
            if (s?.token && u && u.id === user.id) {
              // Session is still valid
              authStore.updateLastValidated();
              authSecurityManager.resetFailureCount();
              if (__DEV__) console.log('[AuthContext] Session validation successful');
            } else {
              // Session is invalid - sign out user
              if (__DEV__) console.log('[AuthContext] Session validation failed - signing out');
              authSecurityManager.recordValidationFailure('Periodic validation failed');
              await signOut();
            }
          } catch (error: any) {
            if (__DEV__) console.warn('[AuthContext] Session validation error:', error);
            authSecurityManager.recordValidationFailure(`Validation error: ${error.message}`);
            // On validation error, sign out to be safe
            await signOut();
          }
        }
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);
    
    return () => {
      subscription?.remove();
    };
  }, [user, authStore.rememberMe]);

  // Start proxy session monitoring if we have persistent auth
  useEffect(() => {
    if (user && authStore.rememberMe) {
      // Session monitoring removed - proxy session monitor was unused and deleted
      if (__DEV__) {
        if (__DEV__) console.log('[Auth] User session restored:', user.email);
      }
    }
  }, [user, authStore.rememberMe]);

  // Security and cleanup initialization
  useEffect(() => {
    // Perform auto-cleanup on startup
    authSecurityManager.performAutoCleanup().then(result => {
      if (result.cleaned && __DEV__) {
        if (__DEV__) console.log('[AuthContext] Auto-cleanup performed on startup:', result.reason);
      }
    }).catch(error => {
      if (__DEV__) {
        if (__DEV__) console.warn('[AuthContext] Auto-cleanup error:', error);
      }
    });

    // Set up periodic security checks (every 30 minutes)
    const securityInterval = setInterval(async () => {
      if (authStore.rememberMe && user) {
        const result = await authSecurityManager.performAutoCleanup();
        if (result.cleaned) {
          if (__DEV__) {
            if (__DEV__) console.log('[AuthContext] Periodic security cleanup triggered:', result.reason);
          }
          // Force sign out if security cleanup was performed
          await signOut();
        }
      }
    }, 30 * 60 * 1000); // 30 minutes

    return () => {
      clearInterval(securityInterval);
    };
  }, [user, authStore.rememberMe]);

  const afterLogin = async (u: NonNullable<User>) => {
    await loadProfile(u.id);
    
    // Load skills and tips from database (now that we have auth token)
    try {
      const { useLessonsStore } = await import('../state/lessons-store');
      const { useTipsStore } = await import('../state');
      
      if (__DEV__) console.log('[AuthContext] Loading skills and tips from database...');
      await useLessonsStore.getState().loadSkillsFromDatabase();
      await useTipsStore.getState().loadTipsFromDatabase();
      if (__DEV__) console.log('[AuthContext] ✅ Skills and tips loaded');
    } catch (error) {
      if (__DEV__) console.warn('[AuthContext] Failed to load skills/tips:', error);
    }
    
    // Load lesson progress from cloud and merge with local
    try {
      const { useLessonsStore } = await import('../state/lessons-store');
      const store = useLessonsStore.getState();
      
      // First, load any existing cloud progress
      await store.loadProgressFromCloud();
      
      // Then, upload any local progress that isn't in the cloud yet
      // This ensures we don't lose any progress made offline
      const localProgress = store.skillProgress;
      if (Object.keys(localProgress).length > 0) {
        if (__DEV__) console.log('📤 Uploading local progress to cloud...');
        await store.uploadLocalProgressToCloud();
      }
    } catch (error) {
      // Silently fail - don't block login if progress sync fails
      if (__DEV__) console.warn('Progress sync failed (non-critical):', error);
    }
    
    try {
      const store = useUIStore.getState();
      if (!store.userProfile) {
        const displayName = u.email ? (u.email.split("@")[0] || "Friend") : "Friend";
        store.ensureLocalProfile();
      }
      // Mirror auth user for services
      (store as any).setAuthUser?.({ id: u.id, email: u.email || null });
    } catch {}

    try {
      const store = useUIStore.getState();
      if (isAdminEmail(u.email || null)) {
        store.setIsAdmin(true);
        store.setIsPro(true);
      } else {
        store.setIsAdmin(false);
        const { active } = await storekit.getActive();
        store.setIsPro(active);
      }
    } catch {}
  };

  const loadProfile = async (userId: string) => {
    try {
      // Load profile from database
      const res = await supabaseMCP.query("profiles", { select: "*", filters: [{ column: "id", op: "eq", value: userId }], limit: 1 });
      const row = res?.data?.[0] || null;
      setProfile(row);
      
      // Sync to UI store if we have profile data
      if (row) {
        const uiStore = useUIStore.getState();
        const name = getDisplayName(row, user, uiStore.userProfile);
        useUIStore.setState({
          userProfile: {
            ...uiStore.userProfile,
            id: row.id,
            name: name,
          } as any,
          user: {
            ...uiStore.user,
            id: row.id,
            name: name,
          } as any
        });
        if (__DEV__) console.log('✅ [AuthContext] Synced profile to UI store:', { 
          name, 
          username: row.username, 
          fullName: row.full_name,
          email: row.email 
        });
      }
      
      // Load streak from database
      const streakRes = await supabaseMCP.query("user_streaks", { 
        select: "*", 
        filters: [{ column: "user_id", op: "eq", value: userId }], 
        limit: 1 
      });
      const streak = streakRes?.data?.[0] || null;
      
      // Sync to progress store if we have streak data
      if (streak) {
        const progressStore = useProgressStore.getState();
        useProgressStore.setState({
          userProgress: {
            ...progressStore.userProgress,
            streak: streak.current_streak || 0,
            streakDays: streak.current_streak || 0,
            longestStreak: streak.longest_streak || 0,
          } as any
        });
        if (__DEV__) console.log('✅ [AuthContext] Synced streak to progress store:', { 
          current: streak.current_streak,
          longest: streak.longest_streak
        });
      }
    } catch (e) {
      if (__DEV__) console.warn("Profile load failed", e);
    }
  };

  const signIn = async (email: string, password: string, rememberMe: boolean = false) => {
    try {
      const resp = await supabaseMCP.authSignIn(email, password);
      const token = resp?.token as string | undefined;
      const refreshToken = resp?.refreshToken as string | undefined;
      const u = resp?.user as any;
      if (!token || !u) {
        return { error: { message: "Missing session token" } } as any;
      }
      
      // Store in memory (always)
      supabaseMCP.setToken(token);
      (global as any).__AUTH_USER__ = u;
      if (refreshToken) {
        (global as any).__REFRESH_TOKEN__ = refreshToken;
      }
      setSession({ token });
      setUser(u);
      
      // Store persistently if remember me is enabled
      if (rememberMe) {
        if (__DEV__) console.log('[AuthContext] Storing session persistently (rememberMe=true)');
        authStore.setAuth(token, { id: u.id, email: u.email }, true, refreshToken);
      } else {
        if (__DEV__) console.log('[AuthContext] Using memory-only session (rememberMe=false)');
        // Ensure no persistent data exists
        authStore.clearAuth();
      }
      
      try { useUIStore.getState().setAuthCompleted(true); } catch {}
      await afterLogin(u);
      
      // Track successful login
      trackLogin(u?.id);
      
      return { error: null };
    } catch (error: any) {
      return { error: { message: error?.message || "Sign in failed" } } as any;
    }
  };

  const signUp = async (email: string, password: string, fullName?: string) => {
    try {
      const resp = await supabaseMCP.authSignUp(email, password, fullName);
      const token = resp?.token as string | undefined;
      const u = resp?.user as any;
      if (token && u) {
        // Store in memory only - no persistent storage
        supabaseMCP.setToken(token);
        (global as any).__AUTH_USER__ = u;
        setSession({ token });
        setUser(u);
        try {
          const store = useUIStore.getState();
          store.setAuthCompleted(true);
          if (u?.id) store.setJustSignedUpUserId(u.id);
        } catch {}
        await afterLogin(u);
      }
      return { error: null }; // When email confirmation required, token may be null
    } catch (error: any) {
      return { error: { message: error?.message || "Sign up failed" } } as any;
    }
  };

  const signOut = async () => {
    const currentUserId = user?.id;
    
    try {
      await supabaseMCP.authSignOut().catch(() => {});
    } finally {
      // Clear all session data (memory + persistent)
      authStore.clearAuth();
      supabaseMCP.setToken(null);
      (global as any).__AUTH_USER__ = null;
      setSession(null);
      setUser(null);
      setProfile(null);
      // NOTE: User progress should persist - NOT resetting on sign-out
      // try { useProgressStore.getState().resetUserData(); } catch {}
      
      // Track logout
      trackLogout(currentUserId);
      
      if (__DEV__) console.log('[AuthContext] Complete sign out - cleared all session data');
    }
  };

  const updateProfile = async (updates: Partial<NonNullable<Profile>>) => {
    if (!user) return { error: new Error("No user logged in") };
    try {
      const payload = { id: user.id, email: user.email || "", ...updates, updated_at: new Date().toISOString() } as any;
      await supabaseMCP.update("profiles", payload);
      setProfile(prev => prev ? { ...prev, ...updates } : ({ id: user.id, email: user.email || "" } as any));
      return { error: null };
    } catch (error) {
      return { error } as any;
    }
  };

  const refreshSession = async () => {
    if (__DEV__) console.log('[AuthContext] Manual session refresh requested');
    try {
      // Check current memory state
      const s = await supabaseMCP.authGetSession();
      const u = (s as any)?.user || null;
      
      if (__DEV__) console.log('[AuthContext] Refresh - memory state check:', {
        hasSession: !!s,
        hasToken: !!s?.token,
        hasUser: !!u,
        userId: u?.id,
        userEmail: u?.email
      });
      
      if (s?.token && u) {
        setSession({ token: s.token });
        setUser(u);
        if (__DEV__) console.log('[AuthContext] Session refresh successful - updating profile');
        await loadProfile(u.id);
      } else {
        if (__DEV__) console.log('[AuthContext] Session refresh failed - clearing state');
        // Clear invalid session state
        supabaseMCP.setToken(null);
        (global as any).__AUTH_USER__ = null;
        setSession(null);
        setUser(null);
        setProfile(null);
      }
    } catch (e) {
      if (__DEV__) console.warn("[AuthContext] Session refresh failed", e);
      // Clear session state on any error during refresh
      supabaseMCP.setToken(null);
      (global as any).__AUTH_USER__ = null;
      setSession(null);
      setUser(null);
      setProfile(null);
    }
  };

  const recoverSession = async (): Promise<boolean> => {
    if (__DEV__) console.log('[AuthContext] Manual session recovery requested');
    try {
      const success = await sessionRecovery.attemptRecovery('manual_auth_context');
      if (success) {
        // Refresh our local state after successful recovery
        await refreshSession();
      }
      return success;
    } catch (error) {
      if (__DEV__) console.warn('[AuthContext] Session recovery failed:', error);
      return false;
    }
  };

  const getAnalyticsSummary = () => {
    return sessionAnalytics.getSummary();
  };

  const getSecurityStatus = () => {
    return sessionSecurity.getSecurityStatus();
  };

  const value: AuthContextType = {
    user,
    profile,
    session,
    loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
    refreshSession,
    sessionHealth,
    recoverSession,
    getAnalyticsSummary,
    getSecurityStatus,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
