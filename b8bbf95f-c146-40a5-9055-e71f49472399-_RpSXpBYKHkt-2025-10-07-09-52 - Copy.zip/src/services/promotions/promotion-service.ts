/**
 * Promotion Service
 * Manages promotional features like free Pro skill trials
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { useUIStore } from '../../state/ui-store';

const STORAGE_KEY = 'promotions';

export interface PromotionStatus {
  freeTrialSkillUsed: boolean;
  freeTrialSkillId: string | null;
  freeTrialSkillUnlockedAt: string | null;
}

/**
 * Check if user has used their free Pro skill trial
 */
export async function hasUsedFreeTrialSkill(): Promise<boolean> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (!stored) return false;
    
    const status: PromotionStatus = JSON.parse(stored);
    return status.freeTrialSkillUsed || false;
  } catch (error) {
    if (__DEV__) console.error('[Promotion] Error checking trial status:', error);
    return false;
  }
}

/**
 * Get the free trial skill ID if one was unlocked
 */
export async function getFreeTrialSkillId(): Promise<string | null> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    
    const status: PromotionStatus = JSON.parse(stored);
    return status.freeTrialSkillId;
  } catch (error) {
    if (__DEV__) console.error('[Promotion] Error getting trial skill:', error);
    return null;
  }
}

/**
 * Unlock one Pro skill for free trial
 */
export async function unlockFreeTrialSkill(skillId: string): Promise<{ success: boolean; error?: string }> {
  try {
    // Check if already used
    const hasUsed = await hasUsedFreeTrialSkill();
    if (hasUsed) {
      return { success: false, error: 'Free trial already used' };
    }

    // Check if user is already Pro
    const isPro = useUIStore.getState().isPro;
    if (isPro) {
      return { success: false, error: 'Already have Pro access' };
    }

    // Store the unlocked skill
    const status: PromotionStatus = {
      freeTrialSkillUsed: true,
      freeTrialSkillId: skillId,
      freeTrialSkillUnlockedAt: new Date().toISOString()
    };

    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(status));

    // Add to free unlocked skills list
    const currentLimits = useUIStore.getState().freeLimits;
    const unlockedSkills = [...(currentLimits.unlockedSkillIds || []), skillId];
    
    useUIStore.setState({
      freeLimits: {
        ...currentLimits,
        unlockedSkillIds: unlockedSkills
      }
    });

    if (__DEV__) console.log('[Promotion] Unlocked free trial skill:', skillId);
    
    return { success: true };
  } catch (error: any) {
    if (__DEV__) console.error('[Promotion] Error unlocking trial skill:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Check if a specific skill is the free trial skill
 */
export async function isFreeTrialSkill(skillId: string): Promise<boolean> {
  const trialSkillId = await getFreeTrialSkillId();
  return trialSkillId === skillId;
}

/**
 * Reset free trial (for testing or support purposes)
 */
export async function resetFreeTrial(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
    
    // Remove from free unlocked skills
    const currentLimits = useUIStore.getState().freeLimits;
    useUIStore.setState({
      freeLimits: {
        ...currentLimits,
        unlockedSkillIds: []
      }
    });

    if (__DEV__) console.log('[Promotion] Reset free trial');
  } catch (error) {
    if (__DEV__) console.error('[Promotion] Error resetting trial:', error);
  }
}

/**
 * Get promotion status
 */
export async function getPromotionStatus(): Promise<PromotionStatus> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (!stored) {
      return {
        freeTrialSkillUsed: false,
        freeTrialSkillId: null,
        freeTrialSkillUnlockedAt: null
      };
    }
    
    return JSON.parse(stored);
  } catch (error) {
    if (__DEV__) console.error('[Promotion] Error getting status:', error);
    return {
      freeTrialSkillUsed: false,
      freeTrialSkillId: null,
      freeTrialSkillUnlockedAt: null
    };
  }
}

export const promotions = {
  hasUsedFreeTrial: hasUsedFreeTrialSkill,
  getFreeTrialSkill: getFreeTrialSkillId,
  unlockFreeTrial: unlockFreeTrialSkill,
  isFreeTrialSkill,
  resetFreeTrial,
  getStatus: getPromotionStatus
};
