/**
 * Analytics Service
 * Tracks paywall impressions, conversions, and user behavior
 */

import { supabaseMCP } from '../../lib/supabase-mcp';

export type AnalyticsEvent =
  | 'paywall_shown'
  | 'paywall_dismissed'
  | 'paywall_upgrade_tapped'
  | 'subscription_purchase_initiated'
  | 'subscription_purchase_completed'
  | 'subscription_purchase_failed'
  | 'subscription_restored'
  | 'free_skill_completed'
  | 'locked_skill_tapped'
  | 'ai_limit_reached'
  | 'ai_message_sent'
  | 'skill_preview_viewed';

export interface AnalyticsEventData {
  event: AnalyticsEvent;
  userId?: string;
  timestamp: string;
  properties?: Record<string, any>;
  sessionId?: string;
}

/**
 * Track analytics event to Supabase
 */
export async function trackEvent(
  event: AnalyticsEvent,
  properties?: Record<string, any>
): Promise<void> {
  try {
    // Get user ID if available
    const userId = await getCurrentUserId();

    if (__DEV__) {
      console.log('[Analytics]', event, properties);
    }

    // Store in Supabase
    await supabaseMCP.update('analytics_events', {
      user_id: userId,
      event_name: event,
      event_properties: properties || {},
      session_id: getSessionId(),
      created_at: new Date().toISOString()
    }, {});

  } catch (error) {
    // Don't throw - analytics shouldn't break the app
    if (__DEV__) console.error('[Analytics] Error tracking event:', error);
  }
}

/**
 * Track paywall shown
 */
export async function trackPaywallShown(source: string, skillId?: string): Promise<void> {
  await trackEvent('paywall_shown', {
    source, // 'skill_detail', 'ai_limit', 'catalog', etc.
    skillId,
    isPro: await getIsPro()
  });
}

/**
 * Track paywall dismissed
 */
export async function trackPaywallDismissed(source: string, timeSpent: number): Promise<void> {
  await trackEvent('paywall_dismissed', {
    source,
    timeSpentMs: timeSpent
  });
}

/**
 * Track upgrade button tap
 */
export async function trackUpgradeTapped(source: string, skillId?: string): Promise<void> {
  await trackEvent('paywall_upgrade_tapped', {
    source,
    skillId
  });
}

/**
 * Track subscription purchase flow
 */
export async function trackPurchaseInitiated(productId: string): Promise<void> {
  await trackEvent('subscription_purchase_initiated', {
    productId
  });
}

export async function trackPurchaseCompleted(productId: string, price?: string): Promise<void> {
  await trackEvent('subscription_purchase_completed', {
    productId,
    price
  });
}

export async function trackPurchaseFailed(productId: string, error: string): Promise<void> {
  await trackEvent('subscription_purchase_failed', {
    productId,
    error
  });
}

/**
 * Track skill interactions
 */
export async function trackLockedSkillTapped(skillId: string, skillTitle: string): Promise<void> {
  await trackEvent('locked_skill_tapped', {
    skillId,
    skillTitle
  });
}

export async function trackFreeSkillCompleted(skillId: string, skillTitle: string): Promise<void> {
  await trackEvent('free_skill_completed', {
    skillId,
    skillTitle
  });
}

export async function trackSkillPreviewViewed(skillId: string, skillTitle: string): Promise<void> {
  await trackEvent('skill_preview_viewed', {
    skillId,
    skillTitle
  });
}

/**
 * Track AI usage
 */
export async function trackAIMessageSent(messageCount: number, remaining: number): Promise<void> {
  await trackEvent('ai_message_sent', {
    messageCount,
    remaining,
    isPro: await getIsPro()
  });
}

export async function trackAILimitReached(source: string): Promise<void> {
  await trackEvent('ai_limit_reached', {
    source
  });
}

/**
 * Get conversion funnel metrics
 */
export async function getConversionMetrics(userId: string): Promise<{
  paywallImpressions: number;
  upgradeTaps: number;
  purchaseAttempts: number;
  successfulPurchases: number;
  conversionRate: number;
} | null> {
  try {
    const { data, error } = await supabaseMCP.query('analytics_events', {
      select: 'event_name',
      filters: [{ column: 'user_id', op: 'eq', value: userId }]
    });

    if (error || !data) return null;

    const paywallImpressions = data.filter((e: any) => e.event_name === 'paywall_shown').length;
    const upgradeTaps = data.filter((e: any) => e.event_name === 'paywall_upgrade_tapped').length;
    const purchaseAttempts = data.filter((e: any) => e.event_name === 'subscription_purchase_initiated').length;
    const successfulPurchases = data.filter((e: any) => e.event_name === 'subscription_purchase_completed').length;

    const conversionRate = paywallImpressions > 0 
      ? (successfulPurchases / paywallImpressions) * 100 
      : 0;

    return {
      paywallImpressions,
      upgradeTaps,
      purchaseAttempts,
      successfulPurchases,
      conversionRate
    };
  } catch (error) {
    if (__DEV__) console.error('[Analytics] Error getting metrics:', error);
    return null;
  }
}

/**
 * Helper functions
 */
async function getCurrentUserId(): Promise<string | undefined> {
  try {
    const { useAuth } = await import('../../contexts/AuthContext');
    const { user } = useAuth();
    return user?.id;
  } catch {
    return undefined;
  }
}

async function getIsPro(): Promise<boolean> {
  try {
    const { useUIStore } = await import('../../state/ui-store');
    return useUIStore.getState().isPro;
  } catch {
    return false;
  }
}

let sessionId: string | null = null;
function getSessionId(): string {
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
  return sessionId;
}

export const analytics = {
  track: trackEvent,
  paywall: {
    shown: trackPaywallShown,
    dismissed: trackPaywallDismissed,
    upgradeTapped: trackUpgradeTapped
  },
  purchase: {
    initiated: trackPurchaseInitiated,
    completed: trackPurchaseCompleted,
    failed: trackPurchaseFailed
  },
  skill: {
    lockedTapped: trackLockedSkillTapped,
    freeCompleted: trackFreeSkillCompleted,
    previewViewed: trackSkillPreviewViewed
  },
  ai: {
    messageSent: trackAIMessageSent,
    limitReached: trackAILimitReached
  },
  metrics: {
    getConversion: getConversionMetrics
  }
};
