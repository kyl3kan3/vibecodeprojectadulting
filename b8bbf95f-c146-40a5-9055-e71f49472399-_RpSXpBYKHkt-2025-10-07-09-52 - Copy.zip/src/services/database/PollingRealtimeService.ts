import { supabaseMCP } from '../../lib/supabase-mcp';

export type DatabaseChangeEvent = 'INSERT' | 'UPDATE' | 'DELETE';

export interface ProgressChangePayload {
  eventType: DatabaseChangeEvent;
  new: any;
  old: any;
  table: string;
}

export interface StreakChangePayload {
  eventType: DatabaseChangeEvent;
  new: any;
  old: any;
  table: string;
}

export interface ProfileChangePayload {
  eventType: DatabaseChangeEvent;
  new: any;
  old: any;
  table: string;
}

export type SubscriptionCallback<T> = (payload: T) => void;

const DEFAULT_INTERVAL_MS = 15000;

export class PollingRealtimeService { 
  subscribeToAllUserData(
    userId: string,
    callbacks: {
      onProgressChange?: SubscriptionCallback<ProgressChangePayload>;
      onStreakChange?: SubscriptionCallback<StreakChangePayload>;
      onProfileChange?: SubscriptionCallback<ProfileChangePayload>;
    },
    intervalMs?: number
  ): () => void {
    const unsubs: Array<() => void> = [];
    if (callbacks.onProgressChange) {
      unsubs.push(this.subscribeToUserProgress(userId, callbacks.onProgressChange, intervalMs));
    }
    if (callbacks.onStreakChange) {
      unsubs.push(this.subscribeToUserStreak(userId, callbacks.onStreakChange, intervalMs));
    }
    if (callbacks.onProfileChange) {
      unsubs.push(this.subscribeToProfile(userId, callbacks.onProfileChange, intervalMs));
    }
    return () => unsubs.forEach((fn) => fn());
  }
  private timers = new Map<string, any>();
  private snapshots = new Map<string, any[]>();

  private startPolling(key: string, fn: () => Promise<void>, intervalMs = DEFAULT_INTERVAL_MS) {
    if (this.timers.has(key)) return () => this.stop(key);
    const tick = async () => { try { await fn(); } catch {} };
    // Run immediately and then on interval
    tick();
    const handle = setInterval(tick, intervalMs);
    this.timers.set(key, handle);
    return () => this.stop(key);
  }

  private stop(key: string) {
    const handle = this.timers.get(key);
    if (handle) clearInterval(handle);
    this.timers.delete(key);
    this.snapshots.delete(key);
  }

  unsubscribeAll() {
    Array.from(this.timers.keys()).forEach((k) => this.stop(k));
  }

  subscribeToUserProgress(userId: string, callback: SubscriptionCallback<ProgressChangePayload>, intervalMs?: number) {
    const key = `user_progress:${userId}`;
    return this.startPolling(key, async () => {
      const res = await supabaseMCP.query('user_progress', {
        select: '*',
        filters: [{ column: 'user_id', op: 'eq', value: userId }],
        order: { column: 'completed_at', direction: 'asc' }
      });
      const next = res?.data || [];
      const prev = this.snapshots.get(key) || [];
      // Diff simple by id
      const byIdPrev = new Map(prev.map((r: any) => [r.id, r]));
      const byIdNext = new Map(next.map((r: any) => [r.id, r]));

      // Inserts/updates
      next.forEach((row: any) => {
        const before = byIdPrev.get(row.id);
        if (!before) {
          callback({ eventType: 'INSERT', new: row, old: null, table: 'user_progress' });
        } else if (JSON.stringify(before) !== JSON.stringify(row)) {
          callback({ eventType: 'UPDATE', new: row, old: before, table: 'user_progress' });
        }
      });
      // Deletes
      prev.forEach((row: any) => {
        if (!byIdNext.has(row.id)) {
          callback({ eventType: 'DELETE', new: null, old: row, table: 'user_progress' });
        }
      });

      this.snapshots.set(key, next);
    }, intervalMs);
  }

  subscribeToUserStreak(userId: string, callback: SubscriptionCallback<StreakChangePayload>, intervalMs?: number) {
    const key = `user_streaks:${userId}`;
    return this.startPolling(key, async () => {
      const res = await supabaseMCP.query('user_streaks', {
        select: '*',
        filters: [{ column: 'user_id', op: 'eq', value: userId }]
      });
      const next = res?.data || [];
      const prev = this.snapshots.get(key) || [];
      const before = prev[0] || null;
      const after = next[0] || null;
      if (!before && after) callback({ eventType: 'INSERT', new: after, old: null, table: 'user_streaks' });
      else if (before && !after) callback({ eventType: 'DELETE', new: null, old: before, table: 'user_streaks' });
      else if (before && after && JSON.stringify(before) !== JSON.stringify(after)) callback({ eventType: 'UPDATE', new: after, old: before, table: 'user_streaks' });
      this.snapshots.set(key, next);
    }, intervalMs);
  }

  subscribeToProfile(userId: string, callback: SubscriptionCallback<ProfileChangePayload>, intervalMs?: number) {
    const key = `profiles:${userId}`;
    return this.startPolling(key, async () => {
      const res = await supabaseMCP.query('profiles', {
        select: '*',
        filters: [{ column: 'id', op: 'eq', value: userId }],
        limit: 1
      });
      const next = res?.data || [];
      const prev = this.snapshots.get(key) || [];
      const before = prev[0] || null;
      const after = next[0] || null;
      if (!before && after) callback({ eventType: 'INSERT', new: after, old: null, table: 'profiles' });
      else if (before && !after) callback({ eventType: 'DELETE', new: null, old: before, table: 'profiles' });
      else if (before && after && JSON.stringify(before) !== JSON.stringify(after)) callback({ eventType: 'UPDATE', new: after, old: before, table: 'profiles' });
      this.snapshots.set(key, next);
    }, intervalMs);
  }
}

export const pollingRealtimeService = new PollingRealtimeService();
