/**
 * LessonService
 * Centralizes all lesson data access with caching and error handling
 * Created during Phase 2 refactoring
 */

import { BaseService } from './BaseService';
import { DatabaseResult } from './errors';
import { supabaseMCP } from '../../lib/supabase-mcp';
import type { LifeSkill, SkillCategory, Resource } from '../../types/app';
import AsyncStorage from '@react-native-async-storage/async-storage';

// DatabaseLesson interface (matches database structure)
interface DatabaseLesson {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  estimated_time?: number;
  xp_reward?: number;
  tags?: string[];
  content?: {
    overview?: string;
    keyPoints?: string[];
    stepByStep?: any[];
    tips?: string[];
    resources?: any[];
    commonMistakes?: string[];
    stepResources?: Record<string, any[]>;
  };
  is_unlocked?: boolean;
  created_at: string;
}

// Cache configuration
const LESSON_CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes
const LESSON_METADATA_CACHE_KEY = 'lesson-metadata-cache';

interface LessonCache {
  lessons: LifeSkill[];
  timestamp: number;
}

interface LessonMetadataCache {
  ids: string[];
  categories: Record<string, string[]>;
  lastSync: number;
}

export interface LessonFilter {
  category?: SkillCategory;
  difficulty?: 'starter' | 'building' | 'mastery';
  tags?: string[];
  searchQuery?: string;
}

export class LessonService extends BaseService {
  private memoryCache: LessonCache | null = null;
  private conversionFunction: ((lesson: DatabaseLesson) => Promise<LifeSkill>) | null = null;

  /**
   * Set the conversion function (to avoid circular dependencies)
   * This should be called from the store initialization
   */
  setConversionFunction(fn: (lesson: DatabaseLesson) => Promise<LifeSkill>) {
    this.conversionFunction = fn;
  }

  /**
   * Get all lessons with caching
   */
  async getAllLessons(forceRefresh = false): Promise<DatabaseResult<LifeSkill[]>> {
    return this.withRetry(async () => {
      // Check memory cache first
      if (!forceRefresh && this.memoryCache && this.isCacheValid(this.memoryCache.timestamp)) {
        if (__DEV__) console.log('✅ [LessonService] Returning lessons from memory cache');
        return this.memoryCache.lessons;
      }

      if (__DEV__) console.log('📡 [LessonService] Fetching lessons from database...');
      
      const { data, error } = await supabaseMCP.query('lessons', {
        select: '*',
        order: { column: 'created_at', direction: 'asc' },
        limit: 1000
      });

      if (error) {
        throw new Error(`Failed to fetch lessons: ${error.message}`);
      }

      if (!data || data.length === 0) {
        if (__DEV__) console.warn('⚠️  [LessonService] No lessons found in database');
        return [];
      }

      if (__DEV__) console.log(`✅ [LessonService] Fetched ${data.length} lessons from database`);

      // Convert lessons using the conversion function if available
      let lessons: LifeSkill[];
      if (this.conversionFunction) {
        const dbLessons = data as DatabaseLesson[];
        const converted = await Promise.all(
          dbLessons.map(lesson => this.conversionFunction!(lesson).catch(err => {
            if (__DEV__) console.error(`Failed to convert lesson ${lesson.id}:`, err);
            return null;
          }))
        );
        lessons = converted.filter(Boolean) as LifeSkill[];
      } else {
        // Fallback: basic conversion without special processing
        lessons = (data as DatabaseLesson[]).map(lesson => this.basicConversion(lesson));
      }

      // Update memory cache
      this.memoryCache = {
        lessons,
        timestamp: Date.now()
      };

      // Cache metadata to AsyncStorage
      await this.cacheMetadata(lessons);

      return lessons;
    }, 'getAllLessons');
  }

  /**
   * Get a single lesson by ID
   */
  async getLessonById(id: string): Promise<DatabaseResult<LifeSkill | null>> {
    return this.withRetry(async () => {
      this.validateRequired({ id }, ['id']);

      // Check if it's in memory cache first
      if (this.memoryCache && this.isCacheValid(this.memoryCache.timestamp)) {
        const cached = this.memoryCache.lessons.find(l => l.id === id);
        if (cached) {
          if (__DEV__) console.log(`✅ [LessonService] Returning lesson ${id} from cache`);
          return cached;
        }
      }

      // Fetch from database
      const { data, error } = await supabaseMCP.query('lessons', {
        select: '*',
        filters: [{ column: 'id', op: 'eq', value: id }],
        limit: 1
      });

      if (error) {
        throw new Error(`Failed to fetch lesson: ${error.message}`);
      }

      if (!data || data.length === 0) {
        return null;
      }

      const dbLesson = data[0] as DatabaseLesson;
      
      // Convert lesson
      const lesson = this.conversionFunction 
        ? await this.conversionFunction(dbLesson)
        : this.basicConversion(dbLesson);

      return lesson;
    }, 'getLessonById');
  }

  /**
   * Get lessons by category
   */
  async getLessonsByCategory(category: SkillCategory): Promise<DatabaseResult<LifeSkill[]>> {
    return this.withRetry(async () => {
      // Try memory cache first
      if (this.memoryCache && this.isCacheValid(this.memoryCache.timestamp)) {
        const filtered = this.memoryCache.lessons.filter(l => l.category === category);
        if (__DEV__) console.log(`✅ [LessonService] Returning ${filtered.length} lessons for category ${category} from cache`);
        return filtered;
      }

      // Fetch from database
      const { data, error } = await supabaseMCP.query('lessons', {
        select: '*',
        filters: [{ column: 'category', op: 'eq', value: category }],
        order: { column: 'created_at', direction: 'asc' }
      });

      if (error) {
        throw new Error(`Failed to fetch lessons by category: ${error.message}`);
      }

      const dbLessons = (data || []) as DatabaseLesson[];
      const lessons = this.conversionFunction
        ? await Promise.all(dbLessons.map(l => this.conversionFunction!(l)))
        : dbLessons.map(l => this.basicConversion(l));

      return lessons;
    }, 'getLessonsByCategory');
  }

  /**
   * Search lessons by title or description
   */
  async searchLessons(query: string): Promise<DatabaseResult<LifeSkill[]>> {
    return this.withRetry(async () => {
      if (!query.trim()) {
        return [];
      }

      // Search in memory cache if available
      if (this.memoryCache && this.isCacheValid(this.memoryCache.timestamp)) {
        const lowerQuery = query.toLowerCase();
        const filtered = this.memoryCache.lessons.filter(l => 
          l.title.toLowerCase().includes(lowerQuery) ||
          l.description.toLowerCase().includes(lowerQuery) ||
          l.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
        );
        if (__DEV__) console.log(`✅ [LessonService] Found ${filtered.length} lessons matching "${query}" in cache`);
        return filtered;
      }

      // Fetch all and filter (could be optimized with DB text search)
      const allLessons = await this.getAllLessons();
      if (!allLessons.success || !allLessons.data) {
        return [];
      }

      const lowerQuery = query.toLowerCase();
      return allLessons.data.filter(l => 
        l.title.toLowerCase().includes(lowerQuery) ||
        l.description.toLowerCase().includes(lowerQuery) ||
        l.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
      );
    }, 'searchLessons');
  }

  /**
   * Get multiple lessons by IDs (batch operation)
   */
  async getBatchLessons(ids: string[]): Promise<DatabaseResult<LifeSkill[]>> {
    return this.withRetry(async () => {
      if (ids.length === 0) {
        return [];
      }

      // Check cache first
      if (this.memoryCache && this.isCacheValid(this.memoryCache.timestamp)) {
        const cached = this.memoryCache.lessons.filter(l => ids.includes(l.id));
        if (cached.length === ids.length) {
          if (__DEV__) console.log(`✅ [LessonService] Returning ${cached.length} lessons from cache`);
          return cached;
        }
      }

      // Fetch from database
      const { data, error } = await supabaseMCP.query('lessons', {
        select: '*',
        filters: [{ column: 'id', op: 'in', value: ids }]
      });

      if (error) {
        throw new Error(`Failed to fetch batch lessons: ${error.message}`);
      }

      const dbLessons = (data || []) as DatabaseLesson[];
      const lessons = this.conversionFunction
        ? await Promise.all(dbLessons.map(l => this.conversionFunction!(l)))
        : dbLessons.map(l => this.basicConversion(l));

      return lessons;
    }, 'getBatchLessons');
  }

  /**
   * Invalidate cache and force refresh
   */
  async refreshLessons(): Promise<DatabaseResult<LifeSkill[]>> {
    if (__DEV__) console.log('🔄 [LessonService] Invalidating cache and refreshing lessons...');
    this.memoryCache = null;
    return this.getAllLessons(true);
  }

  /**
   * Clear all caches
   */
  async clearCache(): Promise<void> {
    this.memoryCache = null;
    try {
      await AsyncStorage.removeItem(LESSON_METADATA_CACHE_KEY);
      if (__DEV__) console.log('✅ [LessonService] Cache cleared');
    } catch (error) {
      if (__DEV__) console.warn('Failed to clear AsyncStorage cache:', error);
    }
  }

  // === PRIVATE HELPER METHODS ===

  private isCacheValid(timestamp: number): boolean {
    return Date.now() - timestamp < LESSON_CACHE_TTL_MS;
  }

  private async cacheMetadata(lessons: LifeSkill[]): Promise<void> {
    try {
      const metadata: LessonMetadataCache = {
        ids: lessons.map(l => l.id),
        categories: lessons.reduce((acc, lesson) => {
          if (!acc[lesson.category]) acc[lesson.category] = [];
          acc[lesson.category].push(lesson.id);
          return acc;
        }, {} as Record<string, string[]>),
        lastSync: Date.now()
      };

      await AsyncStorage.setItem(LESSON_METADATA_CACHE_KEY, JSON.stringify(metadata));
    } catch (error) {
      if (__DEV__) console.warn('Failed to cache lesson metadata:', error);
    }
  }

  private basicConversion(lesson: DatabaseLesson): LifeSkill {
    return {
      id: lesson.id,
      title: lesson.title,
      description: lesson.description,
      category: lesson.category as SkillCategory,
      difficulty: (lesson.difficulty || 'starter') as 'starter' | 'building' | 'mastery',
      estimatedTime: lesson.estimated_time || 30,
      xpReward: lesson.xp_reward || 50,
      tags: lesson.tags || [],
      content: {
        overview: lesson.content?.overview || lesson.description,
        keyPoints: lesson.content?.keyPoints || [],
        stepByStep: lesson.content?.stepByStep || [],
        tips: lesson.content?.tips || [],
        resources: lesson.content?.resources || [],
        commonMistakes: lesson.content?.commonMistakes || [],
        stepResources: lesson.content?.stepResources || {}
      }
    };
  }
}

// Singleton instance
export const lessonService = new LessonService();
