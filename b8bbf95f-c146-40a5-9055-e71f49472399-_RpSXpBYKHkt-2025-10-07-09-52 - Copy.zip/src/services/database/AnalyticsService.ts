import { BaseService } from "./BaseService";
import { DatabaseResult } from "./errors";
import { TipCategory } from "../../types/adulting";
import { supabaseMCP } from "../../lib/supabase-mcp";

export interface ProgressInsights {
  completionRate: {
    daily: number;
    weekly: number;
    monthly: number;
  };
  categoryInsights: {
    category: TipCategory;
    completed: number;
    averageDifficulty: number;
    lastCompleted: string | null;
  }[];
  streakInsights: {
    currentStreak: number;
    longestStreak: number;
    averageStreakLength: number;
    streakBreaks: number;
  };
  timeInsights: {
    mostProductiveDay: string;
    mostProductiveHour: number;
    completionsByDayOfWeek: Record<string, number>;
    completionsByHour: Record<string, number>;
  };
  difficultyInsights: {
    averageRating: number;
    difficultyDistribution: Record<string, number>;
    improvementTrend: "improving" | "stable" | "declining";
  };
  goals: {
    suggestedDailyTarget: number;
    daysToComplete100Tips: number;
    projectedStreakGrowth: number;
  };
}

export interface CompletionTrend {
  date: string;
  count: number;
  cumulativeCount: number;
  movingAverage: number;
}

export interface CategoryStats {
  category: TipCategory;
  completed: number;
  percentage: number;
  averageDifficulty: number;
  firstCompleted: string | null;
  lastCompleted: string | null;
  completionRate: number;
}

export class AnalyticsService extends BaseService {
  async getProgressInsights(): Promise<DatabaseResult<ProgressInsights>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();

      const progressRes = await supabaseMCP.query("user_progress", {
        select: "*",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
        order: { column: "completed_at", direction: "asc" },
      });
      const progress = (progressRes?.data || []) as Array<{ completed_at: string; difficulty_rating: number | null }>;

      const streakRes = await supabaseMCP.query("user_streaks", {
        select: "*",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
        limit: 1,
      });
      const streak = (streakRes?.data || [])[0] as any;

      const now = new Date();
      const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const dailyCompletions = progress.filter((p) => new Date(p.completed_at) >= dayAgo).length;
      const weeklyCompletions = progress.filter((p) => new Date(p.completed_at) >= weekAgo).length;
      const monthlyCompletions = progress.filter((p) => new Date(p.completed_at) >= monthAgo).length;

      const categoryInsights: ProgressInsights["categoryInsights"] = [];

      const streakInsights = {
        currentStreak: streak?.current_streak || 0,
        longestStreak: streak?.longest_streak || 0,
        averageStreakLength: this.calculateAverageStreakLength(progress as any[]),
        streakBreaks: this.calculateStreakBreaks(progress as any[]),
      };

      const timeInsights = this.calculateTimeInsights(progress as any[]);
      const difficultyInsights = this.calculateDifficultyInsights(progress as any[]);
      const goals = this.calculateGoals(progress as any[]);

      return {
        completionRate: { daily: dailyCompletions, weekly: weeklyCompletions, monthly: monthlyCompletions },
        categoryInsights,
        streakInsights,
        timeInsights,
        difficultyInsights,
        goals,
      };
    }, "getProgressInsights");
  }

  async getCompletionTrends(days: number = 30): Promise<DatabaseResult<CompletionTrend[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days + 1);

      const res = await supabaseMCP.query("user_progress", {
        select: "completed_at",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "completed_at", op: "gte", value: startDate.toISOString() },
        ],
        order: { column: "completed_at", direction: "asc" },
      });

      const progress = (res?.data || []) as Array<{ completed_at: string }>;

      const dailyCounts = new Map<string, number>();
      for (let i = 0; i < days; i++) {
        const date = new Date(startDate);
        date.setDate(startDate.getDate() + i);
        const dateStr = date.toISOString().split("T")[0];
        dailyCounts.set(dateStr, 0);
      }

      progress.forEach((p) => {
        const dateStr = p.completed_at.split("T")[0];
        dailyCounts.set(dateStr, (dailyCounts.get(dateStr) || 0) + 1);
      });

      const trends: CompletionTrend[] = [];
      let cumulativeCount = 0;
      const counts = Array.from(dailyCounts.values());
      dailyCounts.forEach((count, date) => {
        cumulativeCount += count;
        const index = trends.length;
        const start = Math.max(0, index - 6);
        const relevantCounts = counts.slice(start, index + 1);
        const movingAverage = relevantCounts.reduce((sum, c) => sum + c, 0) / relevantCounts.length;
        trends.push({ date, count, cumulativeCount, movingAverage: Math.round(movingAverage * 100) / 100 });
      });

      return trends;
    }, "getCompletionTrends");
  }

  async getCategoryStats(): Promise<DatabaseResult<CategoryStats[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      // Touch progress to assert DB availability via proxy
      await supabaseMCP.query("user_progress", { select: "id", filters: [{ column: "user_id", op: "eq", value: user.id }], limit: 1 });
      const categoryStats: CategoryStats[] = [];
      return categoryStats;
    }, "getCategoryStats");
  }

  async exportAnalytics(): Promise<DatabaseResult<{ insights: ProgressInsights; trends: CompletionTrend[]; rawData: any[] }>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const [insightsResult, trendsResult, rawDataResult] = await Promise.all([
        this.getProgressInsights(),
        this.getCompletionTrends(90),
        supabaseMCP.query("user_progress", { select: "*", filters: [{ column: "user_id", op: "eq", value: user.id }] }),
      ]);
      if (!insightsResult.success) throw insightsResult.error;
      if (!trendsResult.success) throw trendsResult.error;
      return { insights: insightsResult.data!, trends: trendsResult.data!, rawData: (rawDataResult?.data || []) as any[] };
    }, "exportAnalytics");
  }

  async getPerformanceMetrics(): Promise<DatabaseResult<{ totalUsers: number; totalCompletions: number; averageCompletionsPerUser: number; mostActiveUsers: { user_id: string; completions: number }[]; completionsByDate: { date: string; completions: number }[] }>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_progress", { select: "completed_at", filters: [{ column: "user_id", op: "eq", value: user.id }] });
      const progress = (res?.data || []) as Array<{ completed_at: string }>;
      const totalCompletions = progress.length;
      return { totalUsers: 1, totalCompletions, averageCompletionsPerUser: totalCompletions, mostActiveUsers: [{ user_id: user.id, completions: totalCompletions }], completionsByDate: [] };
    }, "getPerformanceMetrics");
  }

  private calculateAverageStreakLength(progress: any[]): number {
    if (progress.length === 0) return 0;
    const streaks: number[] = [];
    let currentStreak = 1;
    let lastDate = new Date(progress[0]?.completed_at);
    for (let i = 1; i < progress.length; i++) {
      const currentDate = new Date(progress[i].completed_at);
      const daysDiff = Math.floor((currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff === 1) currentStreak++;
      else if (daysDiff > 1) { streaks.push(currentStreak); currentStreak = 1; }
      lastDate = currentDate;
    }
    if (currentStreak > 0) streaks.push(currentStreak);
    return streaks.length > 0 ? streaks.reduce((sum, s) => sum + s, 0) / streaks.length : 0;
  }

  private calculateStreakBreaks(progress: any[]): number {
    if (progress.length < 2) return 0;
    let breaks = 0;
    let lastDate = new Date(progress[0]?.completed_at);
    for (let i = 1; i < progress.length; i++) {
      const currentDate = new Date(progress[i].completed_at);
      const daysDiff = Math.floor((currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDiff > 1) breaks++;
      lastDate = currentDate;
    }
    return breaks;
  }

  private calculateTimeInsights(progress: any[]): ProgressInsights["timeInsights"] {
    if (progress.length === 0) {
      return { mostProductiveDay: "Monday", mostProductiveHour: 9, completionsByDayOfWeek: {}, completionsByHour: {} };
    }
    const dayOfWeekCounts: Record<string, number> = { Sunday: 0, Monday: 0, Tuesday: 0, Wednesday: 0, Thursday: 0, Friday: 0, Saturday: 0 };
    const hourCounts: Record<string, number> = {};
    progress.forEach((p) => {
      const date = new Date(p.completed_at);
      const dayName = date.toLocaleDateString("en-US", { weekday: "long" });
      const hour = date.getHours();
      dayOfWeekCounts[dayName]++;
      hourCounts[hour.toString()] = (hourCounts[hour.toString()] || 0) + 1;
    });
    const mostProductiveDay = Object.entries(dayOfWeekCounts).reduce((max, [day, count]) => (count > max.count ? { day, count } : max), { day: "Monday", count: 0 }).day;
    const mostProductiveHour = Object.entries(hourCounts).reduce((max, [hour, count]) => (count > max.count ? { hour: parseInt(hour), count } : max), { hour: 9, count: 0 }).hour;
    return { mostProductiveDay, mostProductiveHour, completionsByDayOfWeek: dayOfWeekCounts, completionsByHour: hourCounts };
  }

  private calculateDifficultyInsights(progress: any[]): ProgressInsights["difficultyInsights"] {
    const ratingsOnly = progress.filter((p) => p.difficulty_rating !== null);
    if (ratingsOnly.length === 0) return { averageRating: 0, difficultyDistribution: {}, improvementTrend: "stable" };
    const averageRating = ratingsOnly.reduce((sum, p) => sum + p.difficulty_rating, 0) / ratingsOnly.length;
    const difficultyDistribution: Record<string, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    ratingsOnly.forEach((p) => { difficultyDistribution[p.difficulty_rating.toString()]++; });
    const mid = Math.floor(ratingsOnly.length / 2);
    const recentAvg = ratingsOnly.slice(mid).reduce((sum, p) => sum + p.difficulty_rating, 0) / (ratingsOnly.length - mid);
    const olderAvg = ratingsOnly.slice(0, mid).reduce((sum, p) => sum + p.difficulty_rating, 0) / mid;
    let improvementTrend: "improving" | "stable" | "declining" = "stable";
    if (recentAvg > olderAvg + 0.2) improvementTrend = "improving";
    else if (recentAvg < olderAvg - 0.2) improvementTrend = "declining";
    return { averageRating: Math.round(averageRating * 100) / 100, difficultyDistribution, improvementTrend };
  }

  private calculateGoals(progress: any[]): ProgressInsights["goals"] {
    const totalDays = progress.length > 0 ? Math.ceil((new Date().getTime() - new Date(progress[0].completed_at).getTime()) / (1000 * 60 * 60 * 24)) : 1;
    const completionsPerDay = progress.length / totalDays;
    const suggestedDailyTarget = Math.max(1, Math.ceil(completionsPerDay * 1.2));
    const daysToComplete100Tips = completionsPerDay > 0 ? Math.ceil((100 - progress.length) / completionsPerDay) : 365;
    const projectedStreakGrowth = Math.min(30, Math.ceil(completionsPerDay * 7));
    return { suggestedDailyTarget, daysToComplete100Tips: Math.max(0, daysToComplete100Tips), projectedStreakGrowth };
  }
}
