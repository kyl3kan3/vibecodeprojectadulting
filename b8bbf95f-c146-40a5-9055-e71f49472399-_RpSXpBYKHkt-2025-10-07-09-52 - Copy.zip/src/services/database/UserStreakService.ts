import { BaseService } from "./BaseService";
import { DatabaseResult, createSuccessResult } from "./errors";
import type { Database } from "../../types/db";
import { supabaseMCP } from "../../lib/supabase-mcp";

// Types
type UserStreakRow = Database["public"]["Tables"]["user_streaks"]["Row"];
type UserStreakInsert = Database["public"]["Tables"]["user_streaks"]["Insert"];
type UserStreakUpdate = Database["public"]["Tables"]["user_streaks"]["Update"];

export interface StreakStats {
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: string;
  streakStartDate: string | null;
  isActiveToday: boolean;
  daysUntilBreak: number;
}

export interface StreakHistory {
  date: string;
  streakLength: number;
  tipCount: number;
  isStreakDay: boolean;
}

export class UserStreakService extends BaseService {
  async getUserStreak(): Promise<DatabaseResult<UserStreakRow | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_streaks", {
        select: "*",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
        limit: 1,
      });
      const row = (res?.data || [])[0] || null;
      return row as UserStreakRow | null;
    }, "getUserStreak");
  }

  async initializeStreak(): Promise<DatabaseResult<UserStreakRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const streakData: UserStreakInsert = {
        user_id: user.id,
        current_streak: 0,
        longest_streak: 0,
        last_activity_date: new Date().toISOString(),
      } as any;
      const res = await supabaseMCP.update("user_streaks", streakData, {
        onConflict: "user_id"
      });
      const row = (res?.data || [])[0] as UserStreakRow;
      return row;
    }, "initializeStreak");
  }

  async updateStreakAfterCompletion(): Promise<DatabaseResult<UserStreakRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();

      // Current streak
      const current = await this.getUserStreak();

      // Progress today
      const today = new Date().toISOString().split("T")[0];
      const progressRes = await supabaseMCP.query("user_progress", {
        select: "id,completed_at",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "completed_at", op: "gte", value: `${today}T00:00:00.000Z` },
          { column: "completed_at", op: "lt", value: `${today}T23:59:59.999Z` },
        ],
      });
      const hasProgressToday = ((progressRes?.data || []) as any[]).length > 0;

      if (!current.success || !current.data) {
        if (hasProgressToday) {
          const r = await this.initializeStreakWithProgress();
          if (!r.success) throw r.error;
          return r.data!;
        }
        const r = await this.initializeStreak();
        if (!r.success) throw r.error;
        return r.data!;
      }

      const streak = current.data as UserStreakRow;
      const lastActivityDate = new Date(streak.last_activity_date);
      const todayDate = new Date();
      const yesterday = new Date();
      yesterday.setDate(todayDate.getDate() - 1);

      const lastActivityDateStr = lastActivityDate.toISOString().split("T")[0];
      const todayStr = todayDate.toISOString().split("T")[0];
      const yesterdayStr = yesterday.toISOString().split("T")[0];

      let newCurrentStreak = streak.current_streak;
      if (hasProgressToday) {
        if (lastActivityDateStr === yesterdayStr) newCurrentStreak = streak.current_streak + 1;
        else if (lastActivityDateStr === todayStr) newCurrentStreak = streak.current_streak;
        else newCurrentStreak = 1;
      } else {
        return streak;
      }

      const newLongestStreak = Math.max(newCurrentStreak, streak.longest_streak);
      const updateData: UserStreakUpdate = {
        current_streak: newCurrentStreak,
        longest_streak: newLongestStreak,
        last_activity_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      } as any;

      const res = await supabaseMCP.update("user_streaks", { id: streak.id, user_id: user.id, ...updateData }, {
        onConflict: "user_id"
      });
      const row = (res?.data || [])[0] as UserStreakRow;
      return row;
    }, "updateStreakAfterCompletion");
  }

  async checkAndResetStreak(): Promise<DatabaseResult<UserStreakRow | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const streakRes = await this.getUserStreak();
      if (!streakRes.success || !streakRes.data) return null;

      const streak = streakRes.data as UserStreakRow;
      const lastActivityDate = new Date(streak.last_activity_date);
      const now = new Date();
      const yesterday = new Date();
      yesterday.setDate(now.getDate() - 1);

      const lastActivityDateStr = lastActivityDate.toISOString().split("T")[0];
      const yesterdayStr = yesterday.toISOString().split("T")[0];
      const todayStr = now.toISOString().split("T")[0];

      const daysDifference = Math.floor((now.getTime() - lastActivityDate.getTime()) / (1000 * 60 * 60 * 24));
      if (daysDifference > 1 && lastActivityDateStr !== yesterdayStr && lastActivityDateStr !== todayStr) {
        const todayProgress = await supabaseMCP.query("user_progress", {
          select: "id",
          filters: [
            { column: "user_id", op: "eq", value: user.id },
            { column: "completed_at", op: "gte", value: `${todayStr}T00:00:00.000Z` },
            { column: "completed_at", op: "lt", value: `${todayStr}T23:59:59.999Z` },
          ],
          limit: 1,
        });
        const hasProgressToday = ((todayProgress?.data || []) as any[]).length > 0;
        if (!hasProgressToday) {
          const res = await supabaseMCP.update("user_streaks", {
            id: streak.id,
            user_id: user.id,
            current_streak: 0,
            last_activity_date: now.toISOString(),
            updated_at: now.toISOString(),
          }, {
            onConflict: "user_id"
          });
          const row = (res?.data || [])[0] as UserStreakRow;
          return row;
        }
      }
      return streak;
    }, "checkAndResetStreak");
  }

  async getStreakStats(): Promise<DatabaseResult<StreakStats>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const streakRes = await this.getUserStreak();
      const streak = streakRes.data as UserStreakRow | null;
      if (!streak) {
        return {
          currentStreak: 0,
          longestStreak: 0,
          lastActivityDate: new Date().toISOString(),
          streakStartDate: null,
          isActiveToday: false,
          daysUntilBreak: 0,
        };
      }

      const today = new Date().toISOString().split("T")[0];
      const todayProg = await supabaseMCP.query("user_progress", {
        select: "id",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "completed_at", op: "gte", value: `${today}T00:00:00.000Z` },
          { column: "completed_at", op: "lt", value: `${today}T23:59:59.999Z` },
        ],
        limit: 1,
      });
      const isActiveToday = ((todayProg?.data || []) as any[]).length > 0;

      let streakStartDate: string | null = null;
      if (streak.current_streak > 0) {
        const startDate = new Date(streak.last_activity_date);
        startDate.setDate(startDate.getDate() - streak.current_streak + 1);
        streakStartDate = startDate.toISOString();
      }

      const lastActivityDate = new Date(streak.last_activity_date);
      const now = new Date();
      const timeDiff = now.getTime() - lastActivityDate.getTime();
      const daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
      const daysUntilBreak = Math.max(0, 1 - daysDiff);

      return {
        currentStreak: streak.current_streak,
        longestStreak: streak.longest_streak,
        lastActivityDate: streak.last_activity_date,
        streakStartDate,
        isActiveToday,
        daysUntilBreak,
      };
    }, "getStreakStats");
  }

  async getStreakHistory(days: number = 30): Promise<DatabaseResult<StreakHistory[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days + 1);

      const res = await supabaseMCP.query("user_progress", {
        select: "completed_at",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "completed_at", op: "gte", value: startDate.toISOString() },
        ],
        order: { column: "completed_at", direction: "asc" },
      });
      const progressData = (res?.data || []) as Array<{ completed_at: string }>;

      const progressByDate = new Map<string, number>();
      progressData.forEach((p) => {
        const ds = p.completed_at.split("T")[0];
        progressByDate.set(ds, (progressByDate.get(ds) || 0) + 1);
      });

      const history: StreakHistory[] = [];
      let currentStreakLength = 0;
      for (let i = 0; i < days; i++) {
        const d = new Date(startDate);
        d.setDate(startDate.getDate() + i);
        const ds = d.toISOString().split("T")[0];
        const tipCount = progressByDate.get(ds) || 0;
        const isStreakDay = tipCount > 0;
        currentStreakLength = isStreakDay ? currentStreakLength + 1 : 0;
        history.push({ date: ds, streakLength: currentStreakLength, tipCount, isStreakDay });
      }

      return history;
    }, "getStreakHistory");
  }

  async resetStreak(): Promise<DatabaseResult<UserStreakRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.update("user_streaks", {
        user_id: user.id,
        current_streak: 0,
        last_activity_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }, {
        onConflict: "user_id"
      });
      const row = (res?.data || [])[0] as UserStreakRow;
      return row;
    }, "resetStreak");
  }

  private async initializeStreakWithProgress(): Promise<DatabaseResult<UserStreakRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.update("user_streaks", {
        user_id: user.id,
        current_streak: 1,
        longest_streak: 1,
        last_activity_date: new Date().toISOString(),
      }, {
        onConflict: "user_id"
      });
      const row = (res?.data || [])[0] as UserStreakRow;
      return row;
    }, "initializeStreakWithProgress");
  }
}
