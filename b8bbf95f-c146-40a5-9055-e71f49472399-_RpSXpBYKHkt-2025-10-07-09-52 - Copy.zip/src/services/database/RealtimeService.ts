// Thin shim that re-exports the polling-based realtime service
export type {
  DatabaseChangeEvent,
  ProgressChangePayload,
  StreakChangePayload,
  ProfileChangePayload,
  SubscriptionCallback,
} from './PollingRealtimeService';

export { PollingRealtimeService as RealtimeService, pollingRealtimeService as realtimeService } from './PollingRealtimeService';