/**
 * LessonService Tests
 * Test lesson loading, caching, and error handling
 */

import { LessonService } from '../LessonService';
import { mockDatabaseSuccess, mockDatabaseError, mockLesson } from '../../../utils/testUtils';

// Mock supabaseMCP
jest.mock('../../../lib/supabase-mcp', () => ({
  supabaseMCP: {
    query: jest.fn(),
  },
}));

describe('LessonService', () => {
  let service: LessonService;

  beforeEach(() => {
    service = new LessonService();
    jest.clearAllMocks();
  });

  describe('getAllLessons', () => {
    it('should load lessons from database', async () => {
      const mockData = [mockLesson];
      const { supabaseMCP } = require('../../../lib/supabase-mcp');
      supabaseMCP.query.mockResolvedValue({ data: mockData, error: null });

      const result = await service.getAllLessons();

      expect(result.success).toBe(true);
      expect(result.data).toEqual(mockData);
      expect(supabaseMCP.query).toHaveBeenCalledWith(
        'lessons',
        expect.objectContaining({ select: '*' })
      );
    });

    it('should use cache on second call', async () => {
      const mockData = [mockLesson];
      const { supabaseMCP } = require('../../../lib/supabase-mcp');
      supabaseMCP.query.mockResolvedValue({ data: mockData, error: null });

      // First call - should hit database
      await service.getAllLessons();
      expect(supabaseMCP.query).toHaveBeenCalledTimes(1);

      // Second call - should use cache
      await service.getAllLessons();
      expect(supabaseMCP.query).toHaveBeenCalledTimes(1); // Still 1, used cache
    });

    it('should handle database errors gracefully', async () => {
      const { supabaseMCP } = require('../../../lib/supabase-mcp');
      supabaseMCP.query.mockResolvedValue({ 
        data: null, 
        error: { message: 'Database error' } 
      });

      const result = await service.getAllLessons();

      expect(result.success).toBe(false);
      expect(result.error).toBeDefined();
    });
  });

  describe('getLessonById', () => {
    it('should fetch a single lesson by ID', async () => {
      const { supabaseMCP } = require('../../../lib/supabase-mcp');
      supabaseMCP.query.mockResolvedValue({ data: [mockLesson], error: null });

      const result = await service.getLessonById('test-lesson-1');

      expect(result.success).toBe(true);
      expect(result.data?.id).toBe('test-lesson-1');
    });
  });

  describe('clearCache', () => {
    it('should clear the lesson cache', async () => {
      await service.clearCache();
      // Cache should be cleared (tested by checking next call hits DB)
    });
  });
});
