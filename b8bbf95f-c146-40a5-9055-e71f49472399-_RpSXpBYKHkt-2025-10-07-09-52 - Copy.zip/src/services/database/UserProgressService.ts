import { BaseService } from "./BaseService";
import { DatabaseResult } from "./errors";
import type { Database } from "../../types/db";
import { supabaseMCP } from "../../lib/supabase-mcp";

// Types
type UserProgressRow = Database["public"]["Tables"]["user_progress"]["Row"];
type UserProgressInsert = Database["public"]["Tables"]["user_progress"]["Insert"];

export interface ProgressStats {
  totalCompleted: number;
  completedToday: number;
  completedThisWeek: number;
  completedThisMonth: number;
  categoryCounts: Record<string, number>;
  difficultyBreakdown: Record<string, number>;
  averageDifficulty: number;
}

export interface ProgressFilter {
  category?: string;
  difficulty?: string;
  dateFrom?: string;
  dateTo?: string;
  limit?: number;
  offset?: number;
}

export class UserProgressService extends BaseService {
  async markTipComplete(
    tipId: string,
    difficultyRating?: number,
    notes?: string
  ): Promise<DatabaseResult<UserProgressRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      this.validateRequired({ tipId }, ["tipId"]);
      if (difficultyRating && (difficultyRating < 1 || difficultyRating > 5)) {
        throw new Error("Difficulty rating must be between 1 and 5");
      }

      // Prevent duplicates
      const existing = await this.getTipProgress(tipId);
      if (existing.success && existing.data) {
        throw new Error("Tip already completed");
      }

      const progressData: UserProgressInsert = {
        user_id: user.id,
        tip_id: tipId,
        completed_at: new Date().toISOString(),
        difficulty_rating: difficultyRating || null,
        notes: notes || null,
      } as any;

      const upsert = await supabaseMCP.update("user_progress", progressData, {
        onConflict: "user_id,tip_id"
      });
      const row = (upsert?.data || [])[0] as UserProgressRow;
      return row;
    }, "markTipComplete");
  }

  async getTipProgress(tipId: string): Promise<DatabaseResult<UserProgressRow | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_progress", {
        select: "*",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "tip_id", op: "eq", value: tipId },
        ],
        limit: 1,
      });
      const row = (res?.data || [])[0] || null;
      return row as UserProgressRow | null;
    }, "getTipProgress");
  }

  async getProgressHistory(filter: ProgressFilter = {}): Promise<DatabaseResult<{ data: UserProgressRow[]; totalCount: number; hasMore: boolean }>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();

      // Build filters
      const filters: Array<{ column: string; op: string; value: any }> = [
        { column: "user_id", op: "eq", value: user.id },
      ];
      if (filter.dateFrom) filters.push({ column: "completed_at", op: "gte", value: filter.dateFrom });
      if (filter.dateTo) filters.push({ column: "completed_at", op: "lte", value: filter.dateTo });

      const limit = filter.limit || 20;
      const offset = filter.offset || 0;

      const res = await supabaseMCP.query("user_progress", {
        select: "*",
        filters,
        order: { column: "completed_at", direction: "desc" },
        limit,
        offset,
      });

      const rows = (res?.data || []) as UserProgressRow[];
      const hasMore = rows.length === limit; // heuristic
      return { data: rows, totalCount: rows.length, hasMore };
    }, "getProgressHistory");
  }

  async getProgressStats(): Promise<DatabaseResult<ProgressStats>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_progress", {
        select: "*",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
      });
      const progress = (res?.data || []) as Array<{
        completed_at: string;
        difficulty_rating: number | null;
      }>;

      const now = new Date();
      const today = now.toISOString().split("T")[0];
      const weekStartDate = new Date(now);
      weekStartDate.setDate(now.getDate() - now.getDay());
      const weekStart = weekStartDate.toISOString().split("T")[0];
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];

      const totalCompleted = progress.length;
      const completedToday = progress.filter((p) => p.completed_at.split("T")[0] === today).length;
      const completedThisWeek = progress.filter((p) => p.completed_at.split("T")[0] >= weekStart).length;
      const completedThisMonth = progress.filter((p) => p.completed_at.split("T")[0] >= monthStart).length;

      const categoryCounts: Record<string, number> = {};
      const difficultyBreakdown: Record<string, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 } as any;

      let totalRating = 0;
      let ratedCount = 0;
      progress.forEach((p) => {
        if (p.difficulty_rating) {
          const key = String(p.difficulty_rating);
          difficultyBreakdown[key] = (difficultyBreakdown[key] || 0) + 1;
          totalRating += p.difficulty_rating;
          ratedCount += 1;
        }
      });

      const averageDifficulty = ratedCount > 0 ? totalRating / ratedCount : 0;
      return {
        totalCompleted,
        completedToday,
        completedThisWeek,
        completedThisMonth,
        categoryCounts,
        difficultyBreakdown,
        averageDifficulty,
      };
    }, "getProgressStats");
  }

  async getCompletionTrends(days: number = 30): Promise<DatabaseResult<Array<{ date: string; count: number }>>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const res = await supabaseMCP.query("user_progress", {
        select: "completed_at",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "completed_at", op: "gte", value: startDate.toISOString() },
        ],
        order: { column: "completed_at", direction: "asc" },
      });
      const data = (res?.data || []) as Array<{ completed_at: string }>;

      const trendsMap = new Map<string, number>();
      for (let i = 0; i < days; i++) {
        const d = new Date();
        d.setDate(d.getDate() - days + i + 1);
        const ds = d.toISOString().split("T")[0];
        trendsMap.set(ds, 0);
      }
      data.forEach((row) => {
        const ds = row.completed_at.split("T")[0];
        trendsMap.set(ds, (trendsMap.get(ds) || 0) + 1);
      });
      const trends = Array.from(trendsMap.entries()).map(([date, count]) => ({ date, count }));
      return trends;
    }, "getCompletionTrends");
  }

  async getCompletedTipIds(): Promise<DatabaseResult<string[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_progress", {
        select: "tip_id",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
      });
      const ids = ((res?.data || []) as Array<{ tip_id: string }>).map((p) => p.tip_id);
      return ids;
    }, "getCompletedTipIds");
  }

  async updateProgress(
    progressId: string,
    updates: { notes?: string; difficulty_rating?: number }
  ): Promise<DatabaseResult<UserProgressRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      if (
        updates.difficulty_rating &&
        (updates.difficulty_rating < 1 || updates.difficulty_rating > 5)
      ) {
        throw new Error("Difficulty rating must be between 1 and 5");
      }
      const res = await supabaseMCP.update("user_progress", {
        id: progressId,
        user_id: user.id,
        ...updates,
      });
      const row = (res?.data || [])[0] as UserProgressRow;
      return row;
    }, "updateProgress");
  }

  async deleteProgress(progressId: string): Promise<DatabaseResult<boolean>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      await supabaseMCP.delete("user_progress", [
        { column: "id", op: "eq", value: progressId },
        { column: "user_id", op: "eq", value: user.id },
      ]);
      return true;
    }, "deleteProgress");
  }

  async markMultipleTipsComplete(
    tipIds: string[],
    notes?: string
  ): Promise<DatabaseResult<UserProgressRow[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      if (tipIds.length === 0) throw new Error("No tip IDs provided");

      const existingRes = await supabaseMCP.query("user_progress", {
        select: "tip_id",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          // The proxy may not support `in` filter; fetch all and filter client-side
        ],
      });
      const existingSet = new Set(((existingRes?.data || []) as Array<{ tip_id: string }>).map((r) => r.tip_id));
      const newTipIds = tipIds.filter((id) => !existingSet.has(id));
      if (newTipIds.length === 0) throw new Error("All tips are already completed");

      const payloads: UserProgressInsert[] = newTipIds.map((tipId) => ({
        user_id: user.id,
        tip_id: tipId,
        completed_at: new Date().toISOString(),
        difficulty_rating: null,
        notes: notes || null,
      })) as any;

      const res = await supabaseMCP.update("user_progress", payloads, {
        onConflict: "user_id,tip_id"
      });
      const rows = (res?.data || []) as UserProgressRow[];
      return rows;
    }, "markMultipleTipsComplete");
  }
}
