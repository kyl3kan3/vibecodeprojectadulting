/**
 * LessonProgressService
 * Handles cloud storage and sync of lesson/skill progress to Supabase
 */

import { BaseService } from "./BaseService";
import { DatabaseResult } from "./errors";
import { supabaseMCP } from "../../lib/supabase-mcp";
import type { SkillProgress } from "../../types/app";

export interface LessonProgressRow {
  id: string;
  user_id: string;
  skill_id: string;
  completed: boolean;
  completed_steps: string[];
  step_results: Record<string, any>;
  rating: number | null;
  notes: string | null;
  started_at: string;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface LessonProgressInsert {
  user_id: string;
  skill_id: string;
  completed?: boolean;
  completed_steps?: string[];
  step_results?: Record<string, any>;
  rating?: number | null;
  notes?: string | null;
  started_at?: string;
  completed_at?: string | null;
}

export class LessonProgressService extends BaseService {
  /**
   * Save or update lesson progress to Supabase
   * Handles duplicate key errors gracefully (data already synced)
   */
  async saveProgress(
    skillId: string,
    progress: SkillProgress
  ): Promise<DatabaseResult<LessonProgressRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      this.validateRequired({ skillId }, ["skillId"]);

      const progressData: any = {
        user_id: user.id,
        skill_id: skillId,
        completed: !!progress.completedAt || false,
        completed_steps: progress.completedSteps || [],
        step_results: progress.stepResults || {},
        rating: progress.rating || null,
        notes: progress.notes || null,
        started_at: progress.startedAt || new Date().toISOString(),
        completed_at: progress.completedAt || null,
      };

      try {
        if (__DEV__) console.log('[LessonProgress] Syncing progress to cloud...');
        
        // Upsert with onConflict to handle duplicate (user_id, skill_id) pairs
        const result = await supabaseMCP.update("user_lesson_progress", progressData, {
          onConflict: "user_id,skill_id"
        });
        
        const row = (result?.data || [])[0] as LessonProgressRow;
        if (__DEV__) console.log('[LessonProgress] ✅ Sync successful');
        return row;
        
      } catch (error: any) {
        // Check if it's a duplicate key error
        const errorMsg = error?.message || '';
        const isDuplicateError = errorMsg.includes('duplicate key') || 
                                 errorMsg.includes('unique constraint') ||
                                 errorMsg.includes('user_lesson_progress_user_id_skill_id');
        
        if (isDuplicateError) {
          // Duplicate key means data is already in cloud - fetch and return it
          if (__DEV__) console.log('[LessonProgress] ⚠️ Duplicate key (data already synced), fetching existing...');
          const existing = await this.getProgress(skillId);
          
          if (existing.success && existing.data) {
            if (__DEV__) console.log('[LessonProgress] ✅ Returned existing record');
            return existing.data;
          }
        }
        
        // For other errors, re-throw
        throw error;
      }
    }, "saveProgress");
  }

  /**
   * Get progress for a specific lesson
   */
  async getProgress(skillId: string): Promise<DatabaseResult<LessonProgressRow | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_lesson_progress", {
        select: "*",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "skill_id", op: "eq", value: skillId },
        ],
        limit: 1,
      });
      const row = (res?.data || [])[0] || null;
      return row as LessonProgressRow | null;
    }, "getProgress");
  }

  /**
   * Get all lesson progress for current user
   */
  async getAllProgress(): Promise<DatabaseResult<LessonProgressRow[]>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("user_lesson_progress", {
        select: "*",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
        order: { column: "updated_at", direction: "desc" },
      });
      const rows = (res?.data || []) as LessonProgressRow[];
      
      return rows;
    }, "getAllProgress");
  }

  /**
   * Mark a lesson as completed
   */
  async markCompleted(
    skillId: string,
    rating?: number,
    notes?: string
  ): Promise<DatabaseResult<LessonProgressRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      
      // Get existing progress first
      const existing = await this.getProgress(skillId);
      
      const progressData: LessonProgressInsert = {
        user_id: user.id,
        skill_id: skillId,
        completed: true,
        completed_at: new Date().toISOString(),
        rating: rating || null,
        notes: notes || null,
        // Preserve existing data
        ...(existing.success && existing.data ? {
          completed_steps: existing.data.completed_steps,
          step_results: existing.data.step_results,
          started_at: existing.data.started_at,
        } : {}),
      };

      const result = await supabaseMCP.update("user_lesson_progress", progressData, {
        onConflict: "user_id,skill_id"
      });
      const row = (result?.data || [])[0] as LessonProgressRow;
      
      return row;
    }, "markCompleted");
  }

  /**
   * Update step progress within a lesson
   */
  async updateStepProgress(
    skillId: string,
    stepId: string,
    stepResult: any
  ): Promise<DatabaseResult<LessonProgressRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      
      // Get existing progress
      const existing = await this.getProgress(skillId);
      
      const existingStepResults = existing.success && existing.data 
        ? existing.data.step_results 
        : {};
      
      const existingCompletedSteps = existing.success && existing.data 
        ? existing.data.completed_steps 
        : [];

      // Update step results
      const updatedStepResults = {
        ...existingStepResults,
        [stepId]: {
          ...existingStepResults[stepId],
          ...stepResult,
        },
      };

      // Add to completed steps if not already there
      const updatedCompletedSteps = existingCompletedSteps.includes(stepId)
        ? existingCompletedSteps
        : [...existingCompletedSteps, stepId];

      const progressData: LessonProgressInsert = {
        user_id: user.id,
        skill_id: skillId,
        step_results: updatedStepResults,
        completed_steps: updatedCompletedSteps,
        started_at: existing.success && existing.data 
          ? existing.data.started_at 
          : new Date().toISOString(),
      };

      const result = await supabaseMCP.update("user_lesson_progress", progressData, {
        onConflict: "user_id,skill_id"
      });
      const row = (result?.data || [])[0] as LessonProgressRow;
      
      return row;
    }, "updateStepProgress");
  }

  /**
   * Delete progress for a specific lesson
   */
  async deleteProgress(skillId: string): Promise<DatabaseResult<void>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      
      await supabaseMCP.query("user_lesson_progress", {
        select: "*",
        filters: [
          { column: "user_id", op: "eq", value: user.id },
          { column: "skill_id", op: "eq", value: skillId },
        ],
        limit: 1,
      });
      
      // Note: supabaseMCP doesn't have a delete method, so we'll mark as deleted
      // or implement soft delete. For now, we'll just update to reset progress
      const resetData: LessonProgressInsert = {
        user_id: user.id,
        skill_id: skillId,
        completed: false,
        completed_steps: [],
        step_results: {},
        rating: null,
        notes: null,
        completed_at: null,
      };
      
      await supabaseMCP.update("user_lesson_progress", resetData, {
        onConflict: "user_id,skill_id"
      });
    }, "deleteProgress");
  }

  /**
   * Batch upload multiple lesson progress records
   * Useful for migrating local data to cloud
   */
  async batchUpload(
    progressRecords: Array<{ skillId: string; progress: SkillProgress }>
  ): Promise<DatabaseResult<{ succeeded: number; failed: number; errors: string[] }>> {
    return this.withRetry(async () => {
      let succeeded = 0;
      let failed = 0;
      const errors: string[] = [];

      for (const record of progressRecords) {
        try {
          await this.saveProgress(record.skillId, record.progress);
          succeeded++;
        } catch (error: any) {
          failed++;
          errors.push(`${record.skillId}: ${error.message}`);
          // Only log individual failures in dev mode
          if (__DEV__) console.warn(`[Upload failed] ${record.skillId}`);
        }
      }

      if (__DEV__ && failed > 0) {
        if (__DEV__) console.log(`📤 Batch upload: ${succeeded}/${progressRecords.length} succeeded`);
      }

      return { succeeded, failed, errors };
    }, "batchUpload");
  }

  /**
   * Convert cloud progress to local SkillProgress format
   */
  static toSkillProgress(row: LessonProgressRow): SkillProgress & { completed?: boolean } {
    return {
      skillId: row.skill_id,
      completedSteps: row.completed_steps || [],
      timeSpent: 0, // Not tracked currently
      startedAt: row.started_at,
      completedAt: row.completed_at || undefined,
      rating: row.rating || undefined,
      notes: row.notes || undefined,
      stepResults: row.step_results || {},
    };
  }

  /**
   * Get summary statistics for user's lesson progress
   */
  async getProgressStats(): Promise<DatabaseResult<{
    totalLessons: number;
    completedLessons: number;
    inProgressLessons: number;
    totalStepsCompleted: number;
    averageRating: number;
  }>> {
    return this.withRetry(async () => {
      const allProgress = await this.getAllProgress();
      
      if (!allProgress.success || !allProgress.data) {
        throw new Error("Failed to fetch progress");
      }

      const rows = allProgress.data;
      const totalLessons = rows.length;
      const completedLessons = rows.filter(r => r.completed).length;
      const inProgressLessons = rows.filter(r => !r.completed && r.completed_steps.length > 0).length;
      const totalStepsCompleted = rows.reduce((sum, r) => sum + r.completed_steps.length, 0);
      const ratingsSum = rows.reduce((sum, r) => sum + (r.rating || 0), 0);
      const ratingsCount = rows.filter(r => r.rating).length;
      const averageRating = ratingsCount > 0 ? ratingsSum / ratingsCount : 0;

      return {
        totalLessons,
        completedLessons,
        inProgressLessons,
        totalStepsCompleted,
        averageRating,
      };
    }, "getProgressStats");
  }
}

// Export singleton instance
export const lessonProgressService = new LessonProgressService();
