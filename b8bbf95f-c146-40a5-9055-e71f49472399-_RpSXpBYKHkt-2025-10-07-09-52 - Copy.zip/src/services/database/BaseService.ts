import { supabaseMCP } from '../../lib/supabase-mcp';
import { DatabaseError, DatabaseResult, createSuccessResult, createErrorResult } from './errors';

// Configuration for retry logic
export interface RetryConfig {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxAttempts: 3,
  baseDelayMs: 1000,
  maxDelayMs: 10000,
  backoffMultiplier: 2,
};

export abstract class BaseService {
  protected retryConfig: RetryConfig;

  constructor(retryConfig: RetryConfig = DEFAULT_RETRY_CONFIG) {
    this.retryConfig = retryConfig;
  }

  // Generic retry wrapper with exponential backoff
  protected async withRetry<T>(
    operation: () => Promise<T>,
    operationName: string,
    customRetryConfig?: Partial<RetryConfig>
  ): Promise<DatabaseResult<T>> {
    const config = { ...this.retryConfig, ...customRetryConfig };
    let lastError: DatabaseError;

    for (let attempt = 1; attempt <= config.maxAttempts; attempt++) {
      try {
        const result = await operation();
        return createSuccessResult(result);
      } catch (error: any) {
        lastError = DatabaseError.fromSupabaseError(error);
        
        // Only log errors on final attempt or in dev mode for retryable errors
        if (!lastError.retryable || attempt === config.maxAttempts) {
          if (__DEV__) {
            if (__DEV__) console.warn(`[Database] ${operationName} failed (attempt ${attempt}/${config.maxAttempts}):`, lastError.message);
          }
          break;
        }

        // Calculate delay with exponential backoff
        const delay = Math.min(
          config.baseDelayMs * Math.pow(config.backoffMultiplier, attempt - 1),
          config.maxDelayMs
        );

        // Add jitter to prevent thundering herd
        const jitteredDelay = delay + Math.random() * 1000;

        if (__DEV__) {
          if (__DEV__) console.log(`[Database] Retrying ${operationName} in ${Math.round(jitteredDelay)}ms...`);
        }
        await this.sleep(jitteredDelay);
      }
    }

    return createErrorResult<T>(lastError!);
  }

  // Helper method to check if user is authenticated via memory session
  protected async getCurrentUser() {
    try {
      const session = await supabaseMCP.authGetSession();
      const user = (session as any)?.user;
      
      if (!user?.id) {
        throw new DatabaseError('Please sign in to continue', DatabaseError.fromSupabaseError(null).code, null, false);
      }
      
      return { id: user.id, email: user.email || null };
      
    } catch (error: any) {
      // If it's already a DatabaseError, re-throw it
      if (error instanceof DatabaseError) {
        throw error;
      }
      
      if (error.message?.includes('401') || error.message?.includes('403')) {
        throw new DatabaseError('Session expired - please sign in again', DatabaseError.fromSupabaseError(error).code, null, false);
      }
      
      throw new DatabaseError('Authentication check failed - please try again', DatabaseError.fromSupabaseError(error).code, null, false);
    }
  }

  // Helper method to validate required fields
  protected validateRequired(fields: Record<string, any>, fieldNames: string[]): void {
    const missing = fieldNames.filter(field => 
      fields[field] === undefined || fields[field] === null || fields[field] === ''
    );

    if (missing.length > 0) {
      throw new DatabaseError(
        `Missing required fields: ${missing.join(', ')}`,
        DatabaseError.fromSupabaseError(null).code,
        null,
        false
      );
    }
  }

  // Helper method to create optimistic updates
  protected createOptimisticUpdate<T>(
    currentData: T[],
    newItem: T,
    idField: keyof T = 'id' as keyof T
  ): T[] {
    // Check if item already exists
    const existingIndex = currentData.findIndex(item => item[idField] === newItem[idField]);
    
    if (existingIndex >= 0) {
      // Update existing item
      const updated = [...currentData];
      updated[existingIndex] = newItem;
      return updated;
    } else {
      // Add new item
      return [newItem, ...currentData];
    }
  }

  // Helper method for pagination
  protected async paginate<T>(
    query: any,
    page: number = 1,
    pageSize: number = 20
  ): Promise<{ data: T[]; hasMore: boolean; totalCount?: number }> {
    const start = (page - 1) * pageSize;
    const end = start + pageSize - 1;

    const { data, error, count } = await query
      .range(start, end)
      .select('*', { count: 'exact' });

    if (error) {
      throw DatabaseError.fromSupabaseError(error);
    }

    return {
      data: data || [],
      hasMore: data?.length === pageSize,
      totalCount: count || undefined,
    };
  }

  // Helper method to handle database transactions
  protected async withTransaction<T>(
    operations: Array<() => Promise<any>>
  ): Promise<DatabaseResult<T[]>> {
    try {
      const results = [];
      
      // Execute all operations
      for (const operation of operations) {
        const result = await operation();
        results.push(result);
      }
      
      return createSuccessResult(results);
    } catch (error: any) {
      // In a real transaction, we'd rollback here
      // Supabase doesn't support client-side transactions yet
      if (__DEV__) console.error('Transaction failed:', error);
      return createErrorResult(DatabaseError.fromSupabaseError(error));
    }
  }

  // Performance monitoring helper
  protected async measurePerformance<T>(
    operation: () => Promise<T>,
    operationName: string
  ): Promise<T> {
    const startTime = Date.now();
    
    try {
      const result = await operation();
      const duration = Date.now() - startTime;
      
      // Log slow queries (>500ms)
      if (duration > 500) {
        if (__DEV__) console.warn(`Slow database operation detected:`, {
          operation: operationName,
          duration: `${duration}ms`,
          timestamp: new Date().toISOString(),
        });
      }
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      if (__DEV__) console.error(`Database operation failed:`, {
        operation: operationName,
        duration: `${duration}ms`,
        error,
        timestamp: new Date().toISOString(),
      });
      throw error;
    }
  }

  // Helper to create database health check
  protected async healthCheck(): Promise<DatabaseResult<{ status: 'healthy' | 'unhealthy'; latency: number }>> {
    const startTime = Date.now();
    
    try {
      // Simple query to test connection via proxy
      await supabaseMCP.query('profiles', { select: 'id', limit: 1 });
      const latency = Date.now() - startTime;
      
      return createSuccessResult({
        status: 'healthy' as const,
        latency,
      });
    } catch (error: any) {
      const latency = Date.now() - startTime;
      
      return createSuccessResult({
        status: 'unhealthy' as const,
        latency,
      });
    }
  }

  // Utility sleep function
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}