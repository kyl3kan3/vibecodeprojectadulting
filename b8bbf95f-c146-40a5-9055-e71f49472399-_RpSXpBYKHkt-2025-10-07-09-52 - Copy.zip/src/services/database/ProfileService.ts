import { BaseService } from "./BaseService";
import { DatabaseResult, createSuccessResult } from "./errors";
import type { Database } from "../../types/db";
import { supabaseMCP } from "../../lib/supabase-mcp";

// Types derived from legacy Database types (for compatibility)
type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];
type ProfileInsert = Database["public"]["Tables"]["profiles"]["Insert"];
type ProfileUpdate = Database["public"]["Tables"]["profiles"]["Update"];

export interface ProfileWithStats extends ProfileRow {
  stats?: {
    totalTipsCompleted: number;
    currentStreak: number;
    longestStreak: number;
    joinedDaysAgo: number;
    favoriteCategories: string[];
  };
}

export class ProfileService extends BaseService {
  // Get user profile
  async getProfile(): Promise<DatabaseResult<ProfileRow | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const res = await supabaseMCP.query("profiles", {
        select: "*",
        filters: [{ column: "id", op: "eq", value: user.id }],
        limit: 1,
      });
      const row = (res?.data || [])[0] || null;
      return row as ProfileRow | null;
    }, "getProfile");
  }

  // Get profile with statistics
  async getProfileWithStats(): Promise<DatabaseResult<ProfileWithStats | null>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();

      // Base profile
      const profileRes = await supabaseMCP.query("profiles", {
        select: "*",
        filters: [{ column: "id", op: "eq", value: user.id }],
        limit: 1,
      });
      const profile = (profileRes?.data || [])[0] as ProfileRow | undefined;
      if (!profile) return null;

      // Progress stats
      const progressRes = await supabaseMCP.query("user_progress", {
        select: "tip_id,completed_at",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
      });

      // Streak stats
      const streakRes = await supabaseMCP.query("user_streaks", {
        select: "current_streak,longest_streak",
        filters: [{ column: "user_id", op: "eq", value: user.id }],
        limit: 1,
      });

      const totalTipsCompleted = (progressRes?.data || []).length;
      const currentStreak = (streakRes?.data?.[0]?.current_streak as number) || 0;
      const longestStreak = (streakRes?.data?.[0]?.longest_streak as number) || 0;

      const joinedDate = new Date(profile.created_at);
      const now = new Date();
      const joinedDaysAgo = Math.floor((now.getTime() - joinedDate.getTime()) / (1000 * 60 * 60 * 24));

      const profileWithStats: ProfileWithStats = {
        ...(profile as any),
        stats: {
          totalTipsCompleted,
          currentStreak,
          longestStreak,
          joinedDaysAgo,
          favoriteCategories: [],
        },
      };

      return profileWithStats;
    }, "getProfileWithStats");
  }

  // Update user profile
  async updateProfile(updates: ProfileUpdate): Promise<DatabaseResult<ProfileRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();

      if (updates.email && !this.isValidEmail(updates.email)) {
        throw new Error("Invalid email format");
      }
      if (updates.username && !this.isValidUsername(updates.username)) {
        throw new Error("Username must be 3-20 characters and contain only letters, numbers, and underscores");
      }

      // Check unique username
      if (updates.username) {
        const exists = await supabaseMCP.query("profiles", {
          select: "id",
          filters: [
            { column: "username", op: "eq", value: updates.username },
            { column: "id", op: "neq", value: user.id } as any,
          ],
          limit: 1,
        }).catch(() => null);
        if (exists?.data?.[0]) {
          throw new Error("Username is already taken");
        }
      }

      const payload: ProfileUpdate = {
        ...updates,
        id: user.id,
        updated_at: new Date().toISOString(),
      };

      // Use proxy for authenticated write operations
      const upsert = await supabaseMCP.update("profiles", payload, { onConflict: "id" });
      const row = (upsert?.data || [])[0] as ProfileRow;
      return row;
    }, "updateProfile");
  }

  // Upload and update avatar (not available via proxy)
  async uploadAvatar(_avatarFile: File | Blob, _fileName: string): Promise<DatabaseResult<string>> {
    return this.withRetry(async () => {
      throw new Error("Avatar uploads are unavailable in this build");
    }, "uploadAvatar");
  }

  // Delete avatar (not available via proxy)
  async deleteAvatar(): Promise<DatabaseResult<boolean>> {
    return this.withRetry(async () => {
      // Best-effort profile field clear
      const user = await this.getCurrentUser();
      await supabaseMCP.update("profiles", { id: user.id, avatar_url: null, updated_at: new Date().toISOString() });
      return true;
    }, "deleteAvatar");
  }

  // Create initial profile (called after signup)
  async createProfile(email: string, fullName?: string): Promise<DatabaseResult<ProfileRow>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const profileData: ProfileInsert = {
        id: user.id,
        email,
        full_name: fullName || null,
        username: null,
        avatar_url: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      } as any;
      const res = await supabaseMCP.update("profiles", profileData, { onConflict: "id" });
      const row = (res?.data || [])[0] as ProfileRow;
      return row;
    }, "createProfile");
  }

  // Delete user profile and all associated data
  async deleteProfile(): Promise<DatabaseResult<boolean>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      await supabaseMCP.delete("profiles", [{ column: "id", op: "eq", value: user.id }]);
      // Note: Auth account deletion is handled server-side (webhook/support)
      return true;
    }, "deleteProfile");
  }

  // Check if username exists
  async isUsernameAvailable(username: string): Promise<DatabaseResult<boolean>> {
    return this.withRetry(async () => {
      if (!this.isValidUsername(username)) return false;
      const res = await supabaseMCP.query("profiles", {
        select: "id",
        filters: [{ column: "username", op: "eq", value: username }],
        limit: 1,
      });
      return !res?.data?.[0];
    }, "isUsernameAvailable");
  }

  // Check username availability with suggestions
  async checkUsernameAvailability(username: string): Promise<DatabaseResult<{ available: boolean; suggestion?: string }>> {
    return this.withRetry(async () => {
      if (!this.isValidUsername(username)) {
        return { available: false, suggestion: undefined };
      }

      const res = await supabaseMCP.query("profiles", {
        select: "id",
        filters: [{ column: "username", op: "eq", value: username }],
        limit: 1,
      });

      const available = !res?.data?.[0];
      let suggestion: string | undefined;

      if (!available) {
        // Generate suggestions by appending numbers
        const random = Math.floor(Math.random() * 999);
        suggestion = `${username}${random}`;
      }

      return { available, suggestion };
    }, "checkUsernameAvailability");
  }

  // Export user data (for GDPR compliance)
  async exportUserData(): Promise<DatabaseResult<{ profile: ProfileRow; progress: any[]; streaks: any[] }>> {
    return this.withRetry(async () => {
      const user = await this.getCurrentUser();
      const [profileRes, progressRes, streakRes] = await Promise.all([
        supabaseMCP.query("profiles", { select: "*", filters: [{ column: "id", op: "eq", value: user.id }], limit: 1 }),
        supabaseMCP.query("user_progress", { select: "*", filters: [{ column: "user_id", op: "eq", value: user.id }] }),
        supabaseMCP.query("user_streaks", { select: "*", filters: [{ column: "user_id", op: "eq", value: user.id }] }),
      ]);
      const profile = (profileRes?.data || [])[0] as ProfileRow;
      const progress = progressRes?.data || [];
      const streaks = streakRes?.data || [];
      return { profile, progress, streaks };
    }, "exportUserData");
  }

  // Private validation helpers
  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidUsername(username: string): boolean {
    if (!username || username.length < 3 || username.length > 20) return false;
    const usernameRegex = /^[a-zA-Z0-9_]+$/;
    return usernameRegex.test(username);
  }
}
