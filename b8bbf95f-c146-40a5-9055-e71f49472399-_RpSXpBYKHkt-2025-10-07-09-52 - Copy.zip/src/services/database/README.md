# Database Services Documentation

This directory contains comprehensive database services for the ProjectAdulting React Native app, built on top of Supabase.

## Architecture

### Services Overview

1. **BaseService** - Foundation class with error handling, retry logic, and common utilities
2. **UserProgressService** - Manages tip completion tracking and progress statistics
3. **UserStreakService** - Handles streak calculations and streak-related operations
4. **ProfileService** - User profile management including avatar uploads
5. **AnalyticsService** - Progress insights, trends, and analytics
6. **RealtimeService** - Real-time database subscriptions and live updates

### Error Handling

All services use a comprehensive error handling system with:
- Custom error types (`DatabaseError`)
- Automatic retry logic with exponential backoff
- Circuit breaker pattern for resilience
- User-friendly error messages

### Performance Features

- Query result caching with TTL
- Optimistic updates for better UX
- Performance monitoring and slow query detection
- Connection pooling and health checks
- Batch operations for bulk updates

## Usage Examples

### Basic Progress Tracking

```typescript
import { userProgressService } from '../services/database';

// Mark tip as complete
const result = await userProgressService.markTipComplete(
  'tip-001', 
  4, // difficulty rating
  'This was helpful!'
);

if (result.success) {
  console.log('Tip completed:', result.data);
} else {
  console.error('Error:', result.error?.message);
}
```

### Streak Management

```typescript
import { userStreakService } from '../services/database';

// Get current streak stats
const streakStats = await userStreakService.getStreakStats();

if (streakStats.success) {
  const { currentStreak, longestStreak, isActiveToday } = streakStats.data!;
  console.log(`Current streak: ${currentStreak} days`);
}
```

### Real-time Updates

```typescript
import { realtimeService } from '../services/database';

// Subscribe to progress changes
const unsubscribe = realtimeService.subscribeToUserProgress(
  userId,
  (payload) => {
    console.log('Progress updated:', payload);
    // Update UI accordingly
  }
);

// Clean up when component unmounts
return unsubscribe;
```

### Profile Management

```typescript
import { profileService } from '../services/database';

// Update user profile
const result = await profileService.updateProfile({
  username: 'newusername',
  full_name: 'John Doe',
});

// Upload avatar
const avatarResult = await profileService.uploadAvatar(
  avatarFile,
  'avatar.jpg'
);
```

### Analytics and Insights

```typescript
import { analyticsService } from '../services/database';

// Get comprehensive insights
const insights = await analyticsService.getProgressInsights();

if (insights.success) {
  const {
    completionRate,
    streakInsights,
    timeInsights,
    goals
  } = insights.data!;
  
  console.log('Daily completion rate:', completionRate.daily);
  console.log('Suggested daily target:', goals.suggestedDailyTarget);
}
```

## Enhanced useSupabaseProgress Hook

The hook has been completely rewritten to use the new services:

```typescript
import { useSupabaseProgress } from '../hooks/useSupabaseProgress';

function MyComponent() {
  const {
    userProgress,
    userStreak,
    progressStats,
    streakStats,
    loading,
    error,
    markTipComplete,
    markMultipleTipsComplete,
    resetStreak,
    exportProgress,
  } = useSupabaseProgress();

  // Real-time updates are handled automatically
  // Optimistic updates provide immediate UI feedback
  // Comprehensive error handling with retry logic
}
```

## Key Features

### 1. Robust Error Handling
- Automatic retry with exponential backoff
- Circuit breaker pattern
- User-friendly error messages
- Comprehensive error logging

### 2. Real-time Capabilities
- Live progress updates
- Streak counter updates
- Profile synchronization
- Automatic reconnection handling

### 3. Performance Optimization
- Intelligent caching with TTL
- Optimistic updates
- Query optimization
- Slow query detection

### 4. Data Integrity
- Row Level Security (RLS) policies
- Input validation and sanitization
- Transaction-like operations
- Conflict resolution

### 5. Analytics and Insights
- Progress trends and patterns
- Streak analysis
- Category completion stats
- Goal suggestions and projections

## Database Schema

The services work with these main tables:

```sql
-- User profiles
profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT NOT NULL,
  username TEXT UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);

-- Progress tracking
user_progress (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  tip_id TEXT NOT NULL,
  completed_at TIMESTAMP,
  difficulty_rating INTEGER CHECK (1-5),
  notes TEXT,
  created_at TIMESTAMP
);

-- Streak management
user_streaks (
  id UUID PRIMARY KEY,
  user_id UUID UNIQUE REFERENCES auth.users(id),
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_activity_date TIMESTAMP,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

## Testing

To test the database services:

1. Set up a test Supabase project
2. Run the schema creation scripts
3. Use the BaseService test patterns:

```typescript
// Mock data and test operations
const testService = new TestService();
const result = await testService.testOperation();

// Verify results
expect(result.success).toBe(true);
expect(result.data).toBeDefined();
```

## Security Considerations

1. **Row Level Security**: All tables have RLS enabled
2. **Input Validation**: All inputs are validated and sanitized
3. **Rate Limiting**: Built-in rate limiting for sensitive operations
4. **Error Sanitization**: Error messages don't expose sensitive data
5. **Audit Logging**: Important operations are logged for monitoring

## Performance Tips

1. **Use Batch Operations**: For multiple updates, use batch methods
2. **Enable Caching**: Results are cached automatically with appropriate TTL
3. **Optimize Queries**: Services use optimized queries with proper indexing
4. **Monitor Performance**: Slow queries are automatically detected and logged
5. **Use Real-time Wisely**: Subscribe only to necessary data changes

## Migration and Deployment

1. Execute `supabase-schema.sql` in your Supabase dashboard
2. Verify RLS policies are active
3. Test authentication and basic operations
4. Monitor performance and error rates
5. Set up backup and recovery procedures

This database infrastructure provides a solid foundation for the ProjectAdulting app with enterprise-grade features like real-time updates, comprehensive analytics, robust error handling, and performance optimization.