// Database error types for comprehensive error handling

export enum DatabaseErrorCode {
  NETWORK_ERROR = 'NETWORK_ERROR',
  AUTH_ERROR = 'AUTH_ERROR',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  CONSTRAINT_ERROR = 'CONSTRAINT_ERROR',
  NOT_FOUND = 'NOT_FOUND',
  DUPLICATE_ERROR = 'DUPLICATE_ERROR',
  PERMISSION_DENIED = 'PERMISSION_DENIED',
  TIMEOUT_ERROR = 'TIMEOUT_ERROR',
  UNKNOWN_ERROR = 'UNKNOWN_ERROR',
}

export class DatabaseError extends Error {
  public readonly code: DatabaseErrorCode;
  public readonly originalError?: any;
  public readonly retryable: boolean;
  public readonly timestamp: Date;

  constructor(
    message: string,
    code: DatabaseErrorCode,
    originalError?: any,
    retryable: boolean = false
  ) {
    super(message);
    this.name = 'DatabaseError';
    this.code = code;
    this.originalError = originalError;
    this.retryable = retryable;
    this.timestamp = new Date();
  }

  static fromSupabaseError(error: any): DatabaseError {
    if (!error) {
      return new DatabaseError('Unknown error occurred', DatabaseErrorCode.UNKNOWN_ERROR);
    }

    // Network/connection errors
    if (error.message?.includes('fetch') || error.code === 'NETWORK_ERROR') {
      return new DatabaseError(
        'Network connection failed. Please check your internet connection.',
        DatabaseErrorCode.NETWORK_ERROR,
        error,
        true
      );
    }

    // Authentication errors
    if (error.code === 'PGRST301' || error.message?.includes('JWT')) {
      return new DatabaseError(
        'Authentication failed. Please sign in again.',
        DatabaseErrorCode.AUTH_ERROR,
        error,
        false
      );
    }

    // Row Level Security / Permission errors
    if (error.code === 'PGRST116' || error.message?.includes('policy')) {
      return new DatabaseError(
        'Access denied. You do not have permission to perform this action.',
        DatabaseErrorCode.PERMISSION_DENIED,
        error,
        false
      );
    }

    // Validation/constraint errors
    if (error.code?.startsWith('23') || error.message?.includes('violates')) {
      return new DatabaseError(
        'Data validation failed. Please check your input.',
        DatabaseErrorCode.CONSTRAINT_ERROR,
        error,
        false
      );
    }

    // Duplicate key errors
    if (error.code === '23505' || error.message?.includes('duplicate')) {
      return new DatabaseError(
        'This record already exists.',
        DatabaseErrorCode.DUPLICATE_ERROR,
        error,
        false
      );
    }

    // Not found errors
    if (error.code === 'PGRST116' || error.message?.includes('not found')) {
      return new DatabaseError(
        'The requested data was not found.',
        DatabaseErrorCode.NOT_FOUND,
        error,
        false
      );
    }

    // Timeout errors
    if (error.message?.includes('timeout') || error.code === 'ETIMEDOUT') {
      return new DatabaseError(
        'Request timed out. Please try again.',
        DatabaseErrorCode.TIMEOUT_ERROR,
        error,
        true
      );
    }

    // Default to unknown error
    return new DatabaseError(
      error.message || 'An unexpected error occurred',
      DatabaseErrorCode.UNKNOWN_ERROR,
      error,
      true
    );
  }
}

export interface DatabaseResult<T> {
  data: T | null;
  error: DatabaseError | null;
  success: boolean;
}

export function createSuccessResult<T>(data: T): DatabaseResult<T> {
  return {
    data,
    error: null,
    success: true,
  };
}

export function createErrorResult<T>(error: DatabaseError): DatabaseResult<T> {
  return {
    data: null,
    error,
    success: false,
  };
}