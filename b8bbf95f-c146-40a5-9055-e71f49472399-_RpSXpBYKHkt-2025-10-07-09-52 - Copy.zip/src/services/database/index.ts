// Database services index - centralized access to all database services

export { BaseService } from './BaseService';
export { UserProgressService } from './UserProgressService';
export { UserStreakService } from './UserStreakService';
export { ProfileService } from './ProfileService';
export { AnalyticsService } from './AnalyticsService';
export { LessonService } from './LessonService';
export { ResourceService } from './ResourceService';
export { LessonProgressService } from './LessonProgressService';
// Realtime switched to polling-based service
export { PollingRealtimeService as RealtimeService, pollingRealtimeService as realtimeService } from './PollingRealtimeService';

export {
  DatabaseError,
  DatabaseErrorCode,
  DatabaseResult,
  createSuccessResult,
  createErrorResult,
} from './errors';

export type {
  ProgressStats,
  ProgressFilter,
} from './UserProgressService';

export type {
  StreakStats,
  StreakHistory,
} from './UserStreakService';

export type {
  ProfileWithStats,
} from './ProfileService';

export type {
  ProgressInsights,
  CompletionTrend,
  CategoryStats,
} from './AnalyticsService';

export type {
  DatabaseChangeEvent,
  ProgressChangePayload,
  StreakChangePayload,
  ProfileChangePayload,
  SubscriptionCallback,
} from './RealtimeService';

export type {
  LessonProgressRow,
  LessonProgressInsert,
} from './LessonProgressService';

// Import classes for instance creation
import { UserProgressService } from './UserProgressService';
import { UserStreakService } from './UserStreakService';
import { ProfileService } from './ProfileService';
import { AnalyticsService } from './AnalyticsService';
import { LessonService } from './LessonService';
import { ResourceService } from './ResourceService';
import { LessonProgressService } from './LessonProgressService';

// Service instances for easy access
export const userProgressService = new UserProgressService();
export const userStreakService = new UserStreakService();
export const profileService = new ProfileService();
export const analyticsService = new AnalyticsService();
export const lessonService = new LessonService();
export const resourceService = new ResourceService();
export const lessonProgressService = new LessonProgressService();