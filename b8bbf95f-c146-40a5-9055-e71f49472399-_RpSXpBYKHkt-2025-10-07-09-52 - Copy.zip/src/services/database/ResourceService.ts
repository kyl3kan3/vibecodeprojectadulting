/**
 * ResourceService
 * Manages AI-generated resources and caching for substep research
 * Created during Phase 2 refactoring
 */

import { BaseService } from './BaseService';
import { DatabaseResult } from './errors';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Resource } from '../../types/app';

const RESOURCE_CACHE_PREFIX = 'ai-resource-cache-';
const RESOURCE_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

interface CachedResource {
  content: any;
  timestamp: number;
  lessonId: string;
  stepId: string;
}

export class ResourceService extends BaseService {
  /**
   * Get resources for a specific lesson step
   * First checks cache, then database stepResources
   */
  async getResourcesForStep(
    lessonId: string,
    stepId: string
  ): Promise<DatabaseResult<Resource[]>> {
    return this.withRetry(async () => {
      this.validateRequired({ lessonId, stepId }, ['lessonId', 'stepId']);

      // Check cache first
      const cached = await this.getResourceCache(lessonId, stepId);
      if (cached.success && cached.data) {
        if (__DEV__) console.log(`✅ [ResourceService] Returning cached resources for ${lessonId}/${stepId}`);
        return cached.data;
      }

      if (__DEV__) console.log(`📡 [ResourceService] No cache found for ${lessonId}/${stepId}`);
      // Return empty array - resources will be generated on-demand by AI
      return [];
    }, 'getResourcesForStep');
  }

  /**
   * Cache AI-generated resource for a substep
   */
  async cacheAIGeneratedResource(
    lessonId: string,
    stepId: string,
    substepId: string,
    content: any
  ): Promise<DatabaseResult<boolean>> {
    return this.withRetry(async () => {
      this.validateRequired({ lessonId, stepId, substepId }, ['lessonId', 'stepId', 'substepId']);

      const cacheKey = this.getCacheKey(lessonId, stepId, substepId);
      const cacheData: CachedResource = {
        content,
        timestamp: Date.now(),
        lessonId,
        stepId
      };

      try {
        await AsyncStorage.setItem(cacheKey, JSON.stringify(cacheData));
        if (__DEV__) console.log(`✅ [ResourceService] Cached AI resource for ${lessonId}/${stepId}/${substepId}`);
        return true;
      } catch (error) {
        if (__DEV__) console.error('Failed to cache AI resource:', error);
        throw new Error('Failed to cache resource');
      }
    }, 'cacheAIGeneratedResource');
  }

  /**
   * Get cached resource for a substep
   */
  async getResourceCache(
    lessonId: string,
    stepId: string,
    substepId?: string
  ): Promise<DatabaseResult<any | null>> {
    return this.withRetry(async () => {
      const cacheKey = substepId 
        ? this.getCacheKey(lessonId, stepId, substepId)
        : this.getCacheKey(lessonId, stepId);

      try {
        const cached = await AsyncStorage.getItem(cacheKey);
        if (!cached) {
          return null;
        }

        const cacheData: CachedResource = JSON.parse(cached);
        
        // Check if cache is still valid
        if (Date.now() - cacheData.timestamp > RESOURCE_CACHE_TTL_MS) {
          if (__DEV__) console.log(`⚠️  [ResourceService] Cache expired for ${cacheKey}`);
          await AsyncStorage.removeItem(cacheKey);
          return null;
        }

        return cacheData.content;
      } catch (error) {
        if (__DEV__) console.warn('Failed to get resource cache:', error);
        return null;
      }
    }, 'getResourceCache');
  }

  /**
   * Clear all resource caches
   */
  async clearResourceCache(): Promise<DatabaseResult<number>> {
    return this.withRetry(async () => {
      try {
        const keys = await AsyncStorage.getAllKeys();
        const resourceKeys = keys.filter(key => key.startsWith(RESOURCE_CACHE_PREFIX));
        
        if (resourceKeys.length > 0) {
          await AsyncStorage.multiRemove(resourceKeys);
          if (__DEV__) console.log(`✅ [ResourceService] Cleared ${resourceKeys.length} cached resources`);
        }
        
        return resourceKeys.length;
      } catch (error) {
        if (__DEV__) console.error('Failed to clear resource cache:', error);
        throw new Error('Failed to clear cache');
      }
    }, 'clearResourceCache');
  }

  /**
   * Clear cache for a specific lesson
   */
  async clearLessonCache(lessonId: string): Promise<DatabaseResult<number>> {
    return this.withRetry(async () => {
      try {
        const keys = await AsyncStorage.getAllKeys();
        const lessonKeys = keys.filter(key => key.includes(`-${lessonId}-`));
        
        if (lessonKeys.length > 0) {
          await AsyncStorage.multiRemove(lessonKeys);
          if (__DEV__) console.log(`✅ [ResourceService] Cleared ${lessonKeys.length} resources for lesson ${lessonId}`);
        }
        
        return lessonKeys.length;
      } catch (error) {
        if (__DEV__) console.error('Failed to clear lesson cache:', error);
        throw new Error('Failed to clear lesson cache');
      }
    }, 'clearLessonCache');
  }

  /**
   * Get cache statistics
   */
  async getCacheStats(): Promise<DatabaseResult<{ total: number; sizeBytes: number }>> {
    return this.withRetry(async () => {
      try {
        const keys = await AsyncStorage.getAllKeys();
        const resourceKeys = keys.filter(key => key.startsWith(RESOURCE_CACHE_PREFIX));
        
        let totalSize = 0;
        for (const key of resourceKeys) {
          const value = await AsyncStorage.getItem(key);
          if (value) {
            totalSize += value.length;
          }
        }

        return {
          total: resourceKeys.length,
          sizeBytes: totalSize
        };
      } catch (error) {
        if (__DEV__) console.error('Failed to get cache stats:', error);
        return { total: 0, sizeBytes: 0 };
      }
    }, 'getCacheStats');
  }

  // === PRIVATE HELPERS ===

  private getCacheKey(lessonId: string, stepId: string, substepId?: string): string {
    return substepId
      ? `${RESOURCE_CACHE_PREFIX}${lessonId}-${stepId}-${substepId}`
      : `${RESOURCE_CACHE_PREFIX}${lessonId}-${stepId}`;
  }
}

// Singleton instance
export const resourceService = new ResourceService();
