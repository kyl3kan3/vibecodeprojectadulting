/**
 * Subscription Service
 * Handles server-side subscription verification and management
 */

import { supabaseMCP } from '../../lib/supabase-mcp';
import { useUIStore } from '../../state/ui-store';
import * as RNIap from 'react-native-iap';
import { Platform } from 'react-native';

export interface SubscriptionStatus {
  isActive: boolean;
  expiresAt: string | null;
  productId: string | null;
  platform: 'ios' | 'android' | 'web' | null;
  lastVerified: string;
}

export interface SubscriptionVerification {
  success: boolean;
  isActive: boolean;
  expiresAt: string | null;
  error?: string;
}

/**
 * Verify subscription with Apple/Google servers via Supabase
 * Note: This requires a Supabase function to be created
 */
export async function verifySubscriptionWithServer(
  userId: string,
  receiptData?: string
): Promise<SubscriptionVerification> {
  try {
    if (__DEV__) console.log('[SubscriptionService] Verifying subscription for user:', userId);

    // TODO: Implement Supabase RPC function 'verify_subscription'
    // For now, return local verification
    if (__DEV__) console.warn('[SubscriptionService] Server verification not yet implemented');
    
    return {
      success: true,
      isActive: useUIStore.getState().isPro,
      expiresAt: null
    };
  } catch (error: any) {
    if (__DEV__) console.error('[SubscriptionService] Verification exception:', error);
    return {
      success: false,
      isActive: false,
      expiresAt: null,
      error: error.message
    };
  }
}

/**
 * Get subscription status from Supabase (cached server-side)
 */
export async function getSubscriptionStatus(userId: string): Promise<SubscriptionStatus | null> {
  try {
    const { data, error } = await supabaseMCP.query('user_subscriptions', {
      select: 'is_active, expires_at, product_id, platform, last_verified',
      filters: [{ column: 'user_id', op: 'eq', value: userId }],
      limit: 1
    });

    if (error || !data || !data.length) {
      if (__DEV__) console.log('[SubscriptionService] No subscription found for user');
      return null;
    }

    const record = data[0];
    return {
      isActive: record.is_active,
      expiresAt: record.expires_at,
      productId: record.product_id,
      platform: record.platform,
      lastVerified: record.last_verified
    };
  } catch (error) {
    if (__DEV__) console.error('[SubscriptionService] Error getting status:', error);
    return null;
  }
}

/**
 * Update subscription status in Supabase
 */
export async function updateSubscriptionStatus(
  userId: string,
  status: Partial<SubscriptionStatus>
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabaseMCP.update('user_subscriptions', {
      user_id: userId,
      is_active: status.isActive ?? false,
      expires_at: status.expiresAt,
      product_id: status.productId,
      platform: status.platform || Platform.OS,
      last_verified: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }, {
      onConflict: 'user_id'
    });

    if (error) {
      if (__DEV__) console.error('[SubscriptionService] Update error:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error: any) {
    if (__DEV__) console.error('[SubscriptionService] Update exception:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Sync local Pro status with server (for analytics/tracking)
 * Call this on app launch and after purchases
 * NOTE: This syncs StoreKit status to database - it does NOT override StoreKit
 * StoreKit remains the source of truth for subscription status
 */
export async function syncSubscriptionStatus(userId: string): Promise<boolean> {
  try {
    if (__DEV__) console.log('[SubscriptionService] Syncing subscription status to database...');

    // Get current Pro status from StoreKit (source of truth)
    const { storekit } = await import('../storekit');
    const { active: storekitActive } = await storekit.getActive();
    
    if (__DEV__) console.log('[SubscriptionService] StoreKit Pro status:', storekitActive);

    // Get server status (for tracking/analytics)
    const serverStatus = await getSubscriptionStatus(userId);

    // StoreKit is always the source of truth
    const isActive = storekitActive;

    // Update database to match StoreKit status (for analytics purposes)
    if (!serverStatus || serverStatus.isActive !== isActive) {
      if (__DEV__) console.log(`[SubscriptionService] Updating database: ${serverStatus?.isActive} → ${isActive}`);
      await updateSubscriptionStatus(userId, {
        isActive,
        expiresAt: serverStatus?.expiresAt || null,
        productId: serverStatus?.productId || 'apple_subscription',
        platform: 'ios'
      });
    }

    return isActive;
  } catch (error) {
    if (__DEV__) console.error('[SubscriptionService] Sync error:', error);
    // On error, keep local state from StoreKit
    return useUIStore.getState().isPro;
  }
}

/**
 * Verify and update subscription after purchase (syncs to database only)
 * NOTE: StoreKit already handles setting isPro - this just records to database
 */
export async function verifyAndUpdateSubscription(userId: string): Promise<boolean> {
  try {
    if (__DEV__) console.log('[SubscriptionService] Recording subscription to database...');

    // Get available purchases from device
    if (!RNIap || typeof RNIap.getAvailablePurchases !== 'function') {
      if (__DEV__) console.warn('[SubscriptionService] IAP not available');
      return false;
    }

    const purchases = await RNIap.getAvailablePurchases();
    
    if (!purchases || purchases.length === 0) {
      if (__DEV__) console.log('[SubscriptionService] No active purchases found');
      
      // Record to database only - don't touch isPro (StoreKit handles that)
      await updateSubscriptionStatus(userId, {
        isActive: false,
        expiresAt: null,
        productId: null
      });
      
      return false;
    }

    // Get most recent purchase
    const latestPurchase = purchases[0];
    if (__DEV__) console.log('[SubscriptionService] Found purchase:', latestPurchase.productId);

    // For iOS, verify receipt with server
    if (Platform.OS === 'ios') {
      const receiptData = latestPurchase.transactionReceipt;
      const verification = await verifySubscriptionWithServer(userId, receiptData);
      
      if (verification.success && verification.isActive) {
        // Record to database only - StoreKit already set isPro
        await updateSubscriptionStatus(userId, {
          isActive: true,
          expiresAt: verification.expiresAt,
          productId: latestPurchase.productId,
          platform: 'ios'
        });
        
        return true;
      }
    } else {
      // For Android or other platforms
      await updateSubscriptionStatus(userId, {
        isActive: true,
        expiresAt: null, // Android handles expiration
        productId: latestPurchase.productId,
        platform: 'android'
      });
      
      return true;
    }

    return false;
  } catch (error) {
    if (__DEV__) console.error('[SubscriptionService] Verify and update error:', error);
    return false;
  }
}

/**
 * Handle subscription expiration (syncs to database only)
 * NOTE: StoreKit will automatically handle local isPro status
 */
export async function handleSubscriptionExpiration(userId: string): Promise<void> {
  try {
    if (__DEV__) console.log('[SubscriptionService] Recording subscription expiration to database');

    // Update server status only
    await updateSubscriptionStatus(userId, {
      isActive: false,
      expiresAt: new Date().toISOString()
    });

    // StoreKit will handle local isPro status automatically on next check

    // Could trigger notification or email here
    if (__DEV__) console.log('[SubscriptionService] Subscription marked as expired in database');
  } catch (error) {
    if (__DEV__) console.error('[SubscriptionService] Expiration handling error:', error);
  }
}

export const subscriptionService = {
  verify: verifySubscriptionWithServer,
  getStatus: getSubscriptionStatus,
  updateStatus: updateSubscriptionStatus,
  sync: syncSubscriptionStatus,
  verifyAndUpdate: verifyAndUpdateSubscription,
  handleExpiration: handleSubscriptionExpiration
};
