/**
 * Referral Service
 * Manages referral codes, tracking, and rewards
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabaseMCP } from '../../lib/supabase-mcp';
import { useUIStore } from '../../state/ui-store';
import * as Sharing from 'expo-sharing';

const STORAGE_KEY = 'referral_data';

export interface ReferralData {
  referralCode: string;
  referredBy: string | null;
  referralsCount: number;
  rewardsEarned: number;
  referralCredits: number; // Days of Pro access earned
}

export interface ReferralReward {
  type: 'pro_days' | 'free_skill' | 'ai_credits';
  value: number;
  description: string;
}

/**
 * Generate a unique referral code for user
 */
export async function generateReferralCode(userId: string): Promise<string> {
  try {
    // Check if user already has a code
    const existing = await getReferralData(userId);
    if (existing?.referralCode) {
      return existing.referralCode;
    }

    // Generate new code (6 characters: first 3 letters of ID + 3 random)
    const code = userId.substring(0, 3).toUpperCase() + 
                 Math.random().toString(36).substring(2, 5).toUpperCase();

    // Store in database
    await supabaseMCP.update('referral_codes', {
      user_id: userId,
      code,
      created_at: new Date().toISOString()
    }, {
      onConflict: 'user_id'
    });

    // Store locally
    const data: ReferralData = {
      referralCode: code,
      referredBy: null,
      referralsCount: 0,
      rewardsEarned: 0,
      referralCredits: 0
    };
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));

    return code;
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error generating code:', error);
    // Fallback code
    return userId.substring(0, 6).toUpperCase();
  }
}

/**
 * Apply a referral code (when new user signs up)
 */
export async function applyReferralCode(
  newUserId: string,
  referralCode: string
): Promise<{ success: boolean; reward?: ReferralReward; error?: string }> {
  try {
    // Validate code exists
    const { data: codeData, error: codeError } = await supabaseMCP.query('referral_codes', {
      select: 'user_id',
      filters: [{ column: 'code', op: 'eq', value: referralCode.toUpperCase() }],
      limit: 1
    });

    if (codeError || !codeData || !codeData.length) {
      return { success: false, error: 'Invalid referral code' };
    }

    const referrerId = codeData[0].user_id;

    // Can't refer yourself
    if (referrerId === newUserId) {
      return { success: false, error: 'Cannot use your own referral code' };
    }

    // Record the referral
    await supabaseMCP.update('referrals', {
      referrer_id: referrerId,
      referred_id: newUserId,
      code_used: referralCode.toUpperCase(),
      created_at: new Date().toISOString(),
      status: 'pending' // Becomes 'active' when referred user completes first lesson
    }, {});

    // Grant reward to new user (3 days Pro trial)
    const reward: ReferralReward = {
      type: 'pro_days',
      value: 3,
      description: 'Get 3 days of Pro access for using a referral code!'
    };

    // Store locally
    const data: ReferralData = {
      referralCode: await generateReferralCode(newUserId),
      referredBy: referrerId,
      referralsCount: 0,
      rewardsEarned: 1,
      referralCredits: 3
    };
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data));

    // Grant Pro access
    await grantProAccess(newUserId, 3);

    return { success: true, reward };
  } catch (error: any) {
    if (__DEV__) console.error('[Referral] Error applying code:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Grant Pro access for specified days
 */
async function grantProAccess(userId: string, days: number): Promise<void> {
  try {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);

    // Update subscription status
    await supabaseMCP.update('user_subscriptions', {
      user_id: userId,
      is_active: true,
      expires_at: expiresAt.toISOString(),
      product_id: 'referral_trial',
      platform: 'referral',
      last_verified: new Date().toISOString()
    }, {
      onConflict: 'user_id'
    });

    // Update local state
    useUIStore.getState().setIsPro(true);

    if (__DEV__) console.log(`[Referral] Granted ${days} days Pro access`);
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error granting Pro access:', error);
  }
}

/**
 * Complete a referral (when referred user completes first lesson)
 */
export async function completeReferral(userId: string): Promise<void> {
  try {
    const data = await getReferralData(userId);
    if (!data?.referredBy) return;

    // Update referral status
    await supabaseMCP.update('referrals', {
      status: 'completed',
      completed_at: new Date().toISOString()
    }, {});

    // Grant reward to referrer (7 days Pro)
    await grantReferrerReward(data.referredBy);

    if (__DEV__) console.log('[Referral] Referral completed, referrer rewarded');
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error completing referral:', error);
  }
}

/**
 * Grant reward to referrer
 */
async function grantReferrerReward(referrerId: string): Promise<void> {
  try {
    // Grant 7 days Pro access
    await grantProAccess(referrerId, 7);

    // Update referrer's stats
    const referrerData = await getReferralData(referrerId);
    if (referrerData) {
      referrerData.referralsCount += 1;
      referrerData.rewardsEarned += 1;
      referrerData.referralCredits += 7;
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(referrerData));
    }

    if (__DEV__) console.log('[Referral] Granted reward to referrer:', referrerId);
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error granting referrer reward:', error);
  }
}

/**
 * Get referral data for user
 */
export async function getReferralData(userId: string): Promise<ReferralData | null> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }

    // Try to fetch from database
    const { data, error } = await supabaseMCP.query('referral_codes', {
      select: 'code',
      filters: [{ column: 'user_id', op: 'eq', value: userId }],
      limit: 1
    });

    if (!error && data && data.length > 0) {
      return {
        referralCode: data[0].code,
        referredBy: null,
        referralsCount: 0,
        rewardsEarned: 0,
        referralCredits: 0
      };
    }

    return null;
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error getting data:', error);
    return null;
  }
}

/**
 * Get referral stats
 */
export async function getReferralStats(userId: string): Promise<{
  totalReferrals: number;
  activeReferrals: number;
  pendingReferrals: number;
  totalRewards: number;
} | null> {
  try {
    const { data, error } = await supabaseMCP.query('referrals', {
      select: 'status',
      filters: [{ column: 'referrer_id', op: 'eq', value: userId }]
    });

    if (error || !data) return null;

    const totalReferrals = data.length;
    const activeReferrals = data.filter((r: any) => r.status === 'completed').length;
    const pendingReferrals = data.filter((r: any) => r.status === 'pending').length;
    const totalRewards = activeReferrals * 7; // 7 days per completed referral

    return {
      totalReferrals,
      activeReferrals,
      pendingReferrals,
      totalRewards
    };
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error getting stats:', error);
    return null;
  }
}

/**
 * Share referral code
 */
export async function shareReferralCode(userId: string): Promise<void> {
  try {
    const code = await generateReferralCode(userId);
    const message = `Join me on Adulting Coach! Use my referral code ${code} to get 3 days of Pro access for free. 🎉\n\nLearn essential life skills and get AI coaching.\n\nDownload: [App Store Link]`;

    if (await Sharing.isAvailableAsync()) {
      // Create a simple text share
      // Note: In production, create a proper shareable link
      await Sharing.shareAsync('data:text/plain;base64,' + btoa(message));
    }
  } catch (error) {
    if (__DEV__) console.error('[Referral] Error sharing code:', error);
  }
}

export const referral = {
  generateCode: generateReferralCode,
  applyCode: applyReferralCode,
  completeReferral,
  getData: getReferralData,
  getStats: getReferralStats,
  share: shareReferralCode
};
