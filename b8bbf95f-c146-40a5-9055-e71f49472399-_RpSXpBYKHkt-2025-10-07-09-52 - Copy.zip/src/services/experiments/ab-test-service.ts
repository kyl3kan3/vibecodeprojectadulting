/**
 * A/B Testing Service
 * Manages feature flags and experiments for conversion optimization
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabaseMCP } from '../../lib/supabase-mcp';

export type ExperimentVariant = 'control' | 'variant_a' | 'variant_b' | 'variant_c';

export interface Experiment {
  id: string;
  name: string;
  description: string;
  active: boolean;
  variants: {
    name: ExperimentVariant;
    weight: number; // 0-100 percentage
    config: Record<string, any>;
  }[];
}

export interface UserExperiment {
  experimentId: string;
  variant: ExperimentVariant;
  assignedAt: string;
}

const STORAGE_KEY = 'ab_tests_assignments';

/**
 * Get user's assigned variant for an experiment
 */
export async function getVariant(
  experimentId: string,
  userId?: string
): Promise<ExperimentVariant> {
  try {
    // Check if user already has an assignment
    const existing = await getStoredAssignment(experimentId);
    if (existing) {
      return existing.variant;
    }

    // Get experiment configuration
    const experiment = await getExperiment(experimentId);
    if (!experiment || !experiment.active) {
      return 'control';
    }

    // Assign variant based on weights
    const variant = assignVariant(experiment, userId);
    
    // Store assignment
    await storeAssignment(experimentId, variant);
    
    // Track assignment in analytics
    await trackAssignment(experimentId, variant, userId);

    return variant;
  } catch (error) {
    if (__DEV__) console.error('[ABTest] Error getting variant:', error);
    return 'control';
  }
}

/**
 * Get experiment configuration from Supabase
 */
async function getExperiment(experimentId: string): Promise<Experiment | null> {
  try {
    const { data, error } = await supabaseMCP.query('experiments', {
      select: '*',
      filters: [
        { column: 'id', op: 'eq', value: experimentId },
        { column: 'active', op: 'eq', value: true }
      ],
      limit: 1
    });

    if (error || !data || !data.length) {
      return null;
    }

    return data[0] as Experiment;
  } catch (error) {
    if (__DEV__) console.error('[ABTest] Error fetching experiment:', error);
    return null;
  }
}

/**
 * Assign variant based on weights and user ID
 */
function assignVariant(experiment: Experiment, userId?: string): ExperimentVariant {
  // Use user ID for consistent assignment (same user always gets same variant)
  const seed = userId 
    ? hashString(userId + experiment.id)
    : Math.random() * 100;

  let cumulativeWeight = 0;
  for (const variant of experiment.variants) {
    cumulativeWeight += variant.weight;
    if (seed < cumulativeWeight) {
      return variant.name;
    }
  }

  return experiment.variants[0]?.name || 'control';
}

/**
 * Simple string hash for consistent assignment
 */
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash % 100);
}

/**
 * Store assignment in AsyncStorage
 */
async function storeAssignment(experimentId: string, variant: ExperimentVariant): Promise<void> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    const assignments: Record<string, UserExperiment> = stored ? JSON.parse(stored) : {};
    
    assignments[experimentId] = {
      experimentId,
      variant,
      assignedAt: new Date().toISOString()
    };
    
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(assignments));
  } catch (error) {
    if (__DEV__) console.error('[ABTest] Error storing assignment:', error);
  }
}

/**
 * Get stored assignment from AsyncStorage
 */
async function getStoredAssignment(experimentId: string): Promise<UserExperiment | null> {
  try {
    const stored = await AsyncStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    
    const assignments: Record<string, UserExperiment> = JSON.parse(stored);
    return assignments[experimentId] || null;
  } catch (error) {
    if (__DEV__) console.error('[ABTest] Error getting stored assignment:', error);
    return null;
  }
}

/**
 * Track assignment in Supabase for analytics
 */
async function trackAssignment(
  experimentId: string,
  variant: ExperimentVariant,
  userId?: string
): Promise<void> {
  try {
    await supabaseMCP.update('experiment_assignments', {
      user_id: userId,
      experiment_id: experimentId,
      variant,
      assigned_at: new Date().toISOString()
    }, {});
  } catch (error) {
    // Don't throw - analytics shouldn't break the app
    if (__DEV__) console.error('[ABTest] Error tracking assignment:', error);
  }
}

/**
 * Pre-configured experiments
 */
export const Experiments = {
  FREE_SKILL_COUNT: 'free_skill_count',
  AI_MESSAGE_LIMIT: 'ai_message_limit',
  PAYWALL_DESIGN: 'paywall_design',
  TRIAL_OFFER: 'trial_offer'
};

/**
 * Get free skill count based on experiment
 */
export async function getFreeSkillCount(userId?: string): Promise<number> {
  const variant = await getVariant(Experiments.FREE_SKILL_COUNT, userId);
  
  switch (variant) {
    case 'control':
      return 3; // 3 starter skills per category (default)
    case 'variant_a':
      return 5; // 5 starter skills per category (more generous)
    case 'variant_b':
      return 2; // 2 starter skills per category (more restrictive)
    case 'variant_c':
      return 10; // 10 starter skills per category (very generous)
    default:
      return 3;
  }
}

/**
 * Get AI message limit based on experiment
 */
export async function getAIMessageLimit(userId?: string): Promise<number> {
  const variant = await getVariant(Experiments.AI_MESSAGE_LIMIT, userId);
  
  switch (variant) {
    case 'control':
      return 3; // 3 messages per day (default)
    case 'variant_a':
      return 5; // 5 messages per day
    case 'variant_b':
      return 1; // 1 message per day
    case 'variant_c':
      return 10; // 10 messages per day
    default:
      return 3;
  }
}

/**
 * Track experiment conversion
 */
export async function trackConversion(
  experimentId: string,
  userId?: string,
  conversionValue?: number
): Promise<void> {
  try {
    const assignment = await getStoredAssignment(experimentId);
    if (!assignment) return;

    await supabaseMCP.update('experiment_conversions', {
      user_id: userId,
      experiment_id: experimentId,
      variant: assignment.variant,
      conversion_value: conversionValue,
      converted_at: new Date().toISOString()
    }, {});
  } catch (error) {
    if (__DEV__) console.error('[ABTest] Error tracking conversion:', error);
  }
}

export const abTest = {
  getVariant,
  getFreeSkillCount,
  getAIMessageLimit,
  trackConversion,
  experiments: Experiments
};
