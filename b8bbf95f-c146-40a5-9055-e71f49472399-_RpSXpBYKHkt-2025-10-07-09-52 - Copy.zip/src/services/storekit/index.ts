// src/services/storekit/index.ts
import { Platform, Linking } from "react-native";
import * as RNIap from "react-native-iap";
import { useUIStore } from "../../state";

export type SKProduct = {
  id: string;
  productId: string;
  title: string;
  description?: string;
  priceString?: string;
  subscriptionPeriod?: string;
};

const getConfiguredIds = (): string[] => {
  const raw = process.env.EXPO_PUBLIC_IAP_PRODUCT_IDS || "";
  if (__DEV__) console.log("getConfiguredIds: Raw product IDs from env:", raw);
  const ids = raw.split(/[\s,]+/).map((s: string) => s.trim()).filter(Boolean);
  if (__DEV__) console.log("getConfiguredIds: Parsed product IDs:", ids);
  return ids;
};

let purchaseUpdateSub: any | null = null;
let purchaseErrorSub: any | null = null;

export type PurchaseState =
  | "idle"
  | "loading"
  | "purchased"
  | "restored"
  | "deferred"
  | "error";

export async function initIAP() {
  try {
    if (!RNIap || typeof RNIap.initConnection !== "function") {
      if (__DEV__) console.warn("react-native-iap library not properly loaded");
      return false;
    }

    if (Platform.OS === "web") {
      if (__DEV__) console.warn("IAP not supported on web platform");
      return false;
    }

    const ready = await RNIap.initConnection();
    if (!ready) {
      if (__DEV__) console.warn("IAP initConnection returned false");
      return false;
    }

    // Recommended: flush pending (Android helper guarded)
    try { await RNIap.flushFailedPurchasesCachedAsPendingAndroid?.(); } catch {}

    if (!purchaseUpdateSub) {
      purchaseUpdateSub = RNIap.purchaseUpdatedListener(async (purchase) => {
        try {
          await RNIap.finishTransaction({ purchase, isConsumable: false });
          try { useUIStore.getState().setIsPro(true); } catch {}
        } catch (err) {
          if (__DEV__) console.warn("finishTransaction error", err);
        }
      });
    }

    if (!purchaseErrorSub) {
      purchaseErrorSub = RNIap.purchaseErrorListener((err) => {
        if (__DEV__) console.warn("purchaseErrorListener", err);
      });
    }

    return true;
  } catch (e) {
    if (__DEV__) console.warn("IAP init error", e);
    return false;
  }
}

export function cleanupIAP() {
  purchaseUpdateSub?.remove();
  purchaseErrorSub?.remove();
  purchaseUpdateSub = null;
  purchaseErrorSub = null;
  try { RNIap.endConnection(); } catch {}
}

export function isIAPAvailable(): boolean {
  return !!(
    RNIap &&
    typeof RNIap.initConnection === "function" &&
    typeof RNIap.getSubscriptions === "function" &&
    typeof RNIap.requestSubscription === "function"
  );
}

export function getIAPStatus(): {
  available: boolean;
  initialized: boolean;
  hasListeners: boolean;
} {
  return {
    available: isIAPAvailable(),
    initialized: !!(purchaseUpdateSub && purchaseErrorSub),
    hasListeners: !!(purchaseUpdateSub && purchaseErrorSub),
  };
}

export async function getProducts(): Promise<SKProduct[]> {
  try {
    // Check if RNIap is available and properly initialized
    if (!RNIap) {
      if (__DEV__) console.warn("getProducts: RNIap is not available");
      return [];
    }
    
    if (typeof RNIap.getSubscriptions !== "function") {
      if (__DEV__) console.warn("getProducts: getSubscriptions function is not available");
      return [];
    }
    
    // Check if IAP is properly initialized by attempting to initialize
    // Since we can't reliably check connection state, we'll try to initialize if needed
    try {
      if (__DEV__) console.warn("getProducts: Ensuring IAP is initialized...");
      const initialized = await initIAP();
      if (!initialized) {
        if (__DEV__) console.warn("getProducts: Failed to initialize IAP");
        return [];
      }
    } catch (initError) {
      if (__DEV__) console.warn("getProducts: Error initializing IAP:", initError);
      return [];
    }
    
    const skus = getConfiguredIds();
    if (!skus.length) {
      if (__DEV__) console.warn("getProducts: No SKUs configured");
      return [];
    }
    
    if (__DEV__) console.log("getProducts: Fetching subscriptions for SKUs:", skus);
    const subs = await RNIap.getSubscriptions({ skus });
    
    if (!subs) {
      if (__DEV__) console.warn("getProducts: getSubscriptions returned null/undefined");
      return [];
    }
    
    if (!Array.isArray(subs)) {
      if (__DEV__) console.warn("getProducts: getSubscriptions did not return an array:", typeof subs);
      return [];
    }
    
    const products = subs.map((p: any) => ({
      id: p.productId || p.productIdentifier || p.sku,
      productId: p.productId || p.productIdentifier || p.sku,
      title: p.title || 'Unknown Product',
      description: p.description || '',
      priceString: p.priceString || p.localizedPrice || p.displayPrice || 'Price unavailable',
      subscriptionPeriod: (p.subscriptionPeriod || p.subscriptionPeriodAndroid || p.subscriptionPeriodUnitAndroid || p.subscriptionPeriodNumberIOS || p.subscriptionPeriodUnitIOS),
    }));
    
    if (__DEV__) console.log("getProducts: Successfully fetched", products.length, "products");
    return products;
  } catch (e) {
    if (__DEV__) console.error("getProducts error:", e);
    return [];
  }
}

export async function getProduct() {
  const list = await getProducts();
  const first = list[0];
  if (!first) return null as any;
  return {
    ...first,
    localizedPrice: first.priceString,
  } as any;
}

export async function purchase(productId?: string): Promise<PurchaseState> {
  try {
    if (!RNIap || typeof RNIap.requestSubscription !== "function") return "error";
    const sku = productId || getConfiguredIds()[0];
    if (!sku) throw new Error("No product id configured");
    await RNIap.requestSubscription({ sku });
    return "purchased";
  } catch (e: any) {
    if (e?.code === "E_USER_CANCELLED") return "idle";
    if (e?.code === "E_DEFERRED_PAYMENT") return "deferred";
    if (__DEV__) console.warn("purchase error", e);
    return "error";
  }
}

export async function restore(): Promise<PurchaseState> {
  try {
    if (!RNIap || typeof RNIap.getAvailablePurchases !== "function") return "error";
    const restored = await RNIap.getAvailablePurchases();
    return restored?.length ? "restored" : "idle";
  } catch (e) {
    if (__DEV__) console.warn("restore error", e);
    return "error";
  }
}

export function manageSubscriptionsUrl() {
  return "itms-apps://apps.apple.com/account/subscriptions";
}

// Lightweight facade used by diagnostics and UI flows
export const storekit = {
  init: initIAP,
  getProducts,
  getConfiguredIds,
  async getActive() {
    try {
      // Local entitlement flag for this build; replace with server check in production
      const active = !!useUIStore.getState().isPro;
      return { active } as { active: boolean };
    } catch {
      return { active: false } as { active: boolean };
    }
  },
  purchase,
  restore,
  openManageSubscriptions() {
    try { return Linking.openURL(manageSubscriptionsUrl()); } catch { return Promise.resolve(); }
  }
};
