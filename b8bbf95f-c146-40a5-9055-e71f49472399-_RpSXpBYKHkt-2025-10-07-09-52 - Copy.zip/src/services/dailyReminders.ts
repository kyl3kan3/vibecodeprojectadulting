import * as Notifications from 'expo-notifications';
import { useUIStore, useProgressStore } from '../state';
import { SkillCategory } from '../types/app';

// Daily reminder messages by category
const dailyMessages = {
  money_mastery: [
    "💰 Check your spending from yesterday - small habits lead to big savings!",
    "🏦 Quick tip: Set up automatic savings today, even if it's just $5!",
    "📊 Take 2 minutes to review your budget - you've got this!",
    "💳 Before any purchase today, ask: 'Do I need this or want this?'",
    "🎯 Your future self will thank you for the money decisions you make today!"
  ],
  career_growth: [
    "🚀 Take 10 minutes to update your LinkedIn profile or resume today!",
    "📈 What's one skill you can practice for 15 minutes today?",
    "🤝 Reach out to one person in your professional network today!",
    "📚 Read one article about your industry to stay current!",
    "💼 Set a small career goal for this week - you're building your future!"
  ],
  home_life: [
    "🏠 Spend 10 minutes organizing one small area of your space today!",
    "🧹 A little cleaning now prevents a big mess later - tackle one room!",
    "🔧 Check one item on your home maintenance list today!",
    "📦 Declutter 5 items you no longer need - donate or toss them!",
    "✨ A tidy space leads to a clear mind - start with your bed!"
  ],
  health_wellness: [
    "💪 Your body is your home for life - move it for 20 minutes today!",
    "🥗 Fuel your body with one healthy meal choice today!",
    "💧 Drink more water today - your body will thank you!",
    "😴 Good sleep tonight starts with good choices today!",
    "🧘 Take 5 deep breaths right now - you deserve this moment of calm!"
  ],
  relationships: [
    "💌 Send a thoughtful message to someone you care about today!",
    "👂 Practice active listening in one conversation today!",
    "🤗 Show appreciation to someone who's been there for you!",
    "💬 Have one meaningful conversation today - put the phone down!",
    "❤️ Remember: healthy relationships require effort from both sides!"
  ],
  personal_growth: [
    "🌱 What's one thing you learned about yourself recently?",
    "📖 Read or listen to something that challenges your perspective!",
    "🎯 Set one small goal for today and celebrate when you achieve it!",
    "🪞 Practice self-compassion today - you're doing better than you think!",
    "🌟 Step out of your comfort zone in one small way today!"
  ],
  tech_savvy: [
    "🔐 Update your passwords and check your security settings today!",
    "📱 Clean up your phone - delete apps you don't use anymore!",
    "💾 Back up your important files and photos today!",
    "🚫 Practice digital wellness - take breaks from screens!",
    "⚡ Learn one new tech skill or shortcut today!"
  ],
  life_admin: [
    "📋 Tackle one item on your adulting to-do list today!",
    "🗂️ Organize one important document or file today!",
    "📅 Check your calendar and prepare for the week ahead!",
    "💡 Pay one bill or check one account - stay on top of your responsibilities!",
    "📝 Write down one thing you need to remember - don't trust it to memory!"
  ]
};

// General motivational messages for variety
const generalMessages = [
  "🌟 You're building the life you want, one small step at a time!",
  "🎯 Every adult skill you learn is an investment in your independence!",
  "💪 You're more capable than you realize - keep pushing forward!",
  "🧩 Each day is another piece of the puzzle that is your adult life!",
  "🚀 Small daily actions create massive long-term results!",
  "✨ Your future self is cheering you on - make them proud today!",
  "🎪 Adulting is a skill, not a talent - you can learn and improve!",
  "🌈 Every challenge you face is making you stronger and more resilient!"
];

export interface DailyReminderContent {
  title: string;
  body: string;
  category?: SkillCategory;
}

export class DailyReminderService {
  /**
   * Get a personalized daily reminder based on user preferences
   */
  static getDailyReminderContent(userProfile?: any): DailyReminderContent {
    // Get user profile from parameter or store
    const profile = userProfile || useUIStore.getState().userProfile;
    
    if (!profile) {
      return this.getGeneralReminder();
    }

    // Get user's focus areas and preferences
    const focusAreas = profile.preferences?.focusAreas || [];
    const categoryPreferences = profile.preferences?.categoryPreferences || [];
    
    // Filter to high priority categories
    const highPriorityCategories = categoryPreferences
      .filter((pref: any) => pref.isEnabled && pref.priority === 'high')
      .map((pref: any) => pref.category);
    
    // Choose category based on priorities
    let targetCategory: SkillCategory | null = null;
    
    if (highPriorityCategories.length > 0) {
      // Prioritize high-priority categories
      targetCategory = highPriorityCategories[Math.floor(Math.random() * highPriorityCategories.length)];
    } else if (focusAreas.length > 0) {
      // Fall back to any focus areas
      targetCategory = focusAreas[Math.floor(Math.random() * focusAreas.length)];
    }
    
    if (targetCategory && dailyMessages[targetCategory]) {
      const messages = dailyMessages[targetCategory];
      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      
      return {
        title: '🎯 Ready to grow today?',
        body: randomMessage,
        category: targetCategory
      };
    }
    
    return this.getGeneralReminder();
  }

  /**
   * Get a general motivational reminder
   */
  static getGeneralReminder(): DailyReminderContent {
    const randomMessage = generalMessages[Math.floor(Math.random() * generalMessages.length)];
    
    return {
      title: '🌟 Your daily adulting boost!',
      body: randomMessage
    };
  }

  /**
   * Build weekly digest summary content
   */
  static buildWeeklyDigest(userProfile?: any): DailyReminderContent {
    const profile = userProfile || useUIStore.getState().userProfile;
    const adulting = useProgressStore.getState();
    const history = adulting.userProgress.completedTipHistory || [];

    // Last 7 days
    const today = new Date();
    let tipTotal = 0;
    let todoTotal = 0;
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const dayStr = d.toISOString().split('T')[0];
      tipTotal += history.filter(h => h.completedAt?.startsWith(dayStr)).length;
      todoTotal += adulting.userProgress.todoItems.filter(t => t.completed && t.completedAt && t.completedAt.startsWith(dayStr)).length;
    }

    const streak = profile?.streak || 0;
    const title = '📈 Your week at a glance';
    const body = `Tips completed: ${tipTotal} • Todos done: ${todoTotal} • Streak: ${streak} days. Keep it going!`;
    return { title, body };
  }

  /**
   * Schedule weekly digest
   */
  static async scheduleWeeklyDigest(userProfile?: any): Promise<void> {
    const profile = userProfile || useUIStore.getState().userProfile;
    if (!profile) return;
    const prefs = profile.preferences || {};
    if (!prefs.weeklyDigestEnabled) return;

    const day = typeof prefs.weeklyDigestDay === 'number' ? prefs.weeklyDigestDay : 0; // Sunday default
    const time = prefs.weeklyDigestTime || '09:00';
    const [hours, minutes] = time.split(':').map(Number);

    const content = this.buildWeeklyDigest(profile);
    await Notifications.scheduleNotificationAsync({
      content: {
        title: content.title,
        body: content.body,
        sound: 'default',
        data: { type: 'weekly_digest', timestamp: Date.now() }
      },
      trigger: {
        weekday: day === 0 ? 7 : day,
        hour: hours,
        minute: minutes,
        repeats: true,
      } as any,
    });
  }

  /**
   * Test weekly digest in ~2s
   */
  static async sendWeeklyDigestTest(userProfile?: any): Promise<void> {
    const content = this.buildWeeklyDigest(userProfile);
    await Notifications.scheduleNotificationAsync({
      content: {
        title: content.title,
        body: content.body,
        sound: 'default',
      },
      trigger: { type: 'timeInterval', seconds: 2 } as any,
    });
  }

  /**
   * Schedule daily reminders based on user preferences
   */
  static async scheduleDailyReminders(userProfile?: any): Promise<void> {
    const profile = userProfile || useUIStore.getState().userProfile;
    
    if (!profile?.preferences?.notificationsEnabled) {
      await Notifications.cancelAllScheduledNotificationsAsync();
      return;
    }

    const reminderTime = profile.preferences.reminderTime || '19:00';
    const reminderDays = profile.preferences.reminderDays || [1, 2, 3, 4, 5];
    
    // Cancel existing notifications
    await Notifications.cancelAllScheduledNotificationsAsync();
    
    const [hours, minutes] = reminderTime.split(':').map(Number);

    // Schedule for each selected day
    for (const dayOfWeek of reminderDays) {
      // Get varied content for different days
      const content = this.getDailyReminderContent(profile);
      
      await Notifications.scheduleNotificationAsync({
        content: {
          title: content.title,
          body: content.body,
          sound: 'default',
          data: {
            type: 'daily_reminder',
            category: content.category,
            timestamp: Date.now()
          }
        },
        trigger: {
          weekday: dayOfWeek === 0 ? 7 : dayOfWeek,
          hour: hours,
          minute: minutes,
          repeats: true,
        } as any,
      });
    }
  }

  /**
   * Get streak-based motivational message
   */
  static getStreakMessage(streak: number): string {
    if (streak === 0) {
      return "🌟 Start your adulting journey today - every expert was once a beginner!";
    } else if (streak < 7) {
      return `🔥 ${streak} day streak! You're building momentum - keep it going!`;
    } else if (streak < 30) {
      return `💪 ${streak} days strong! You're developing real habits now!`;
    } else {
      return `🏆 ${streak} day streak! You're an adulting champion - incredible consistency!`;
    }
  }

  /**
   * Handle notification tap - open app to relevant section
   */
  static handleNotificationResponse(response: Notifications.NotificationResponse): void {
    const data = response.notification.request.content.data;
    
    if (data?.type === 'daily_reminder') {
      // Could navigate to specific category or daily challenge
      // For now, just update the user's streak
      const store = useProgressStore.getState();
      store.updateStreak();
    }
  }

  /**
   * Test notification (for development/testing)
   */
  static async sendTestNotification(userProfile?: any): Promise<void> {
    const content = this.getDailyReminderContent(userProfile);
    
    await Notifications.scheduleNotificationAsync({
      content: {
        title: content.title,
        body: content.body,
        sound: 'default',
      },
      trigger: {
        type: 'timeInterval',
        seconds: 2,
      } as any,
    });
  }
}