/**
 * Enhanced Session Status Component
 * 
 * Advanced session status display with detailed information, controls, and real-time updates
 */

import React, { useState, useEffect } from "react";
import { View, Text, Pressable, Animated, Modal } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../contexts/AuthContext";
import { 
  getSessionDebugInfo, 
  getSessionUptime, 
  getCurrentSessionState,
  performHealthCheck 
} from "../utils/session-utils";
import { sessionPerformance } from "../utils/session-performance";

interface Props {
  position?: 'top' | 'bottom' | 'floating';
  showDetails?: boolean;
  onPress?: () => void;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

export default function EnhancedSessionStatus({ 
  position = 'top', 
  showDetails = true,
  onPress,
  autoRefresh = true,
  refreshInterval = 5000
}: Props) {
  const { user, sessionHealth, recoverSession, getAnalyticsSummary } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<any>(null);
  const [lastUpdate, setLastUpdate] = useState(Date.now());
  const [pulseAnim] = useState(new Animated.Value(1));
  const [isRecovering, setIsRecovering] = useState(false);

  // Auto-refresh session information
  useEffect(() => {
    const updateSessionInfo = () => {
      const debugInfo = getSessionDebugInfo();
      const analytics = getAnalyticsSummary();
      const sessionState = getCurrentSessionState();
      const performance = sessionPerformance.getCurrentMetrics();
      
      setSessionInfo({
        debugInfo,
        analytics,
        sessionState,
        performance,
        uptime: getSessionUptime(),
        timestamp: Date.now()
      });
      setLastUpdate(Date.now());
    };

    // Initial update
    updateSessionInfo();

    // Set up auto-refresh
    if (autoRefresh) {
      const interval = setInterval(updateSessionInfo, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [autoRefresh, refreshInterval]);

  // Pulse animation for updates
  useEffect(() => {
    Animated.sequence([
      Animated.timing(pulseAnim, {
        toValue: 1.1,
        duration: 150,
        useNativeDriver: true
      }),
      Animated.timing(pulseAnim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true
      })
    ]).start();
  }, [lastUpdate, pulseAnim]);

  const handleRecovery = async () => {
    if (isRecovering) return;
    
    setIsRecovering(true);
    try {
      await recoverSession();
    } finally {
      setIsRecovering(false);
    }
  };

  const handlePress = () => {
    if (onPress) {
      onPress();
    } else {
      setShowModal(true);
    }
  };

  const getStatusInfo = () => {
    if (isRecovering) {
      return {
        color: '#F59E0B',
        bgColor: '#FEF3C7',
        icon: 'refresh' as const,
        status: 'Recovering',
        priority: 'medium' as const
      };
    }

    if (!sessionHealth) {
      return {
        color: '#6B7280',
        bgColor: '#F3F4F6',
        icon: 'help-circle' as const,
        status: 'Unknown',
        priority: 'low' as const
      };
    }

    if (sessionHealth.isHealthy) {
      return {
        color: '#10B981',
        bgColor: '#D1FAE5',
        icon: 'checkmark-circle' as const,
        status: 'Healthy',
        priority: 'low' as const
      };
    }

    return {
      color: '#EF4444',
      bgColor: '#FEE2E2',
      icon: 'alert-circle' as const,
      status: `${sessionHealth.issues.length} Issues`,
      priority: 'high' as const
    };
  };

  const statusInfo = getStatusInfo();
  const positionStyles = {
    top: 'top-16',
    bottom: 'bottom-20',
    floating: 'top-1/2 -translate-y-1/2'
  };

  return (
    <>
      <View className={`absolute left-4 right-4 z-50 ${positionStyles[position]}`}>
        <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
          <Pressable
            onPress={handlePress}
            className="rounded-2xl border shadow-lg overflow-hidden"
            style={{ 
              backgroundColor: statusInfo.bgColor,
              borderColor: statusInfo.color + '40'
            }}
          >
            {/* Main Status Bar */}
            <View className="flex-row items-center justify-between p-3">
              <View className="flex-row items-center flex-1">
                <Ionicons 
                  name={statusInfo.icon} 
                  size={20} 
                  color={statusInfo.color} 
                />
                
                <View className="ml-3 flex-1">
                  <Text 
                    className="font-bold text-sm"
                    style={{ color: statusInfo.color }}
                  >
                    Session {statusInfo.status}
                  </Text>
                  
                  {showDetails && user && (
                    <Text 
                      className="text-xs mt-1"
                      style={{ color: statusInfo.color + 'CC' }}
                    >
                      {user.email} • Uptime: {sessionInfo?.uptime || 'N/A'}
                    </Text>
                  )}
                </View>
              </View>

              {/* Quick Actions */}
              <View className="flex-row items-center space-x-2">
                {sessionInfo?.analytics && (
                  <View 
                    className="px-2 py-1 rounded-full"
                    style={{ backgroundColor: statusInfo.color + '20' }}
                  >
                    <Text 
                      className="text-xs font-bold"
                      style={{ color: statusInfo.color }}
                    >
                      {sessionInfo.analytics.totalEvents}
                    </Text>
                  </View>
                )}
                
                <Ionicons 
                  name="chevron-down" 
                  size={16} 
                  color={statusInfo.color} 
                />
              </View>
            </View>

            {/* Detailed Info Bar (when expanded) */}
            {showDetails && sessionInfo && (
              <View 
                className="border-t px-3 py-2"
                style={{ 
                  borderTopColor: statusInfo.color + '20',
                  backgroundColor: statusInfo.color + '10'
                }}
              >
                <View className="flex-row justify-between items-center">
                  <Text 
                    className="text-xs"
                    style={{ color: statusInfo.color + 'DD' }}
                  >
                    Health: {sessionInfo.performance?.efficiency?.healthCheckSuccess || 0}%
                  </Text>
                  
                  <Text 
                    className="text-xs"
                    style={{ color: statusInfo.color + 'DD' }}
                  >
                    Events: {sessionInfo.analytics?.totalEvents || 0}
                  </Text>
                  
                  <Text 
                    className="text-xs"
                    style={{ color: statusInfo.color + 'DD' }}
                  >
                    Score: {sessionInfo.analytics?.healthScore || 0}%
                  </Text>
                  
                  <Text 
                    className="text-xs"
                    style={{ color: statusInfo.color + 'DD' }}
                  >
                    Updated: {Math.round((Date.now() - lastUpdate) / 1000)}s ago
                  </Text>
                </View>
              </View>
            )}
          </Pressable>
        </Animated.View>
      </View>

      {/* Detailed Modal */}
      <Modal
        visible={showModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowModal(false)}
      >
        <View className="flex-1 bg-gray-900">
          {/* Header */}
          <View className="flex-row items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
            <Text className="text-lg font-bold text-white">Session Details</Text>
            <Pressable
              onPress={() => setShowModal(false)}
              className="p-2 rounded-lg bg-gray-700"
            >
              <Ionicons name="close" size={20} color="#D1D5DB" />
            </Pressable>
          </View>

          {/* Content */}
          <View className="flex-1 p-4">
            {/* Current Status */}
            <View className="bg-gray-800 rounded-lg p-4 mb-4 border border-gray-700">
              <Text className="font-semibold text-white mb-3">Current Status</Text>
              
              <View className="flex-row items-center mb-2">
                <Ionicons name={statusInfo.icon} size={24} color={statusInfo.color} />
                <Text className="ml-2 font-medium" style={{ color: statusInfo.color }}>
                  {statusInfo.status}
                </Text>
              </View>
              
              {user && (
                <View className="space-y-1">
                  <Text className="text-sm text-gray-300">
                    <Text className="font-medium">User:</Text> {user.email}
                  </Text>
                  <Text className="text-sm text-gray-300">
                    <Text className="font-medium">ID:</Text> {user.id.substring(0, 16)}...
                  </Text>
                  <Text className="text-sm text-gray-300">
                    <Text className="font-medium">Session Uptime:</Text> {sessionInfo?.uptime || 'N/A'}
                  </Text>
                </View>
              )}
            </View>

            {/* Analytics Summary */}
            {sessionInfo?.analytics && (
              <View className="bg-gray-800 rounded-lg p-4 mb-4 border border-gray-700">
                <Text className="font-semibold text-white mb-3">Analytics Summary</Text>
                
                <View className="grid grid-cols-2 gap-4">
                  <View>
                    <Text className="text-sm font-medium text-gray-400">Total Events</Text>
                    <Text className="text-lg font-bold text-blue-400">
                      {sessionInfo.analytics.totalEvents}
                    </Text>
                  </View>
                  
                  <View>
                    <Text className="text-sm font-medium text-gray-400">Health Score</Text>
                    <Text className="text-lg font-bold text-green-400">
                      {sessionInfo.analytics.healthScore}%
                    </Text>
                  </View>
                  
                  <View>
                    <Text className="text-sm font-medium text-gray-400">Current Session</Text>
                    <Text className="text-sm text-gray-300">
                      {sessionInfo.analytics.currentSession}
                    </Text>
                  </View>
                  
                  <View>
                    <Text className="text-sm font-medium text-gray-400">Recent Activity</Text>
                    <Text className="text-sm text-gray-300" numberOfLines={2}>
                      {sessionInfo.analytics.recentActivity}
                    </Text>
                  </View>
                </View>
              </View>
            )}

            {/* Performance Metrics */}
            {sessionInfo?.performance && (
              <View className="bg-white rounded-lg p-4 mb-4 border border-gray-200">
                <Text className="font-semibold text-gray-800 mb-3">Performance Metrics</Text>
                
                <View className="space-y-2">
                  <View className="flex-row justify-between">
                    <Text className="text-sm text-gray-600">Memory Events</Text>
                    <Text className="text-sm font-medium text-gray-800">
                      {sessionInfo.performance.memoryUsage?.eventsCount || 0}
                    </Text>
                  </View>
                  
                  <View className="flex-row justify-between">
                    <Text className="text-sm text-gray-600">Active Listeners</Text>
                    <Text className="text-sm font-medium text-gray-800">
                      {sessionInfo.performance.memoryUsage?.listenersCount || 0}
                    </Text>
                  </View>
                  
                  <View className="flex-row justify-between">
                    <Text className="text-sm text-gray-600">Health Check Success</Text>
                    <Text className="text-sm font-medium text-green-600">
                      {sessionInfo.performance.efficiency?.healthCheckSuccess || 0}%
                    </Text>
                  </View>
                  
                  <View className="flex-row justify-between">
                    <Text className="text-sm text-gray-600">Recovery Success Rate</Text>
                    <Text className="text-sm font-medium text-green-600">
                      {sessionInfo.performance.efficiency?.recoverySuccessRate || 0}%
                    </Text>
                  </View>
                </View>
              </View>
            )}

            {/* Action Buttons */}
            <View className="space-y-3">
              <Pressable
                onPress={handleRecovery}
                disabled={isRecovering}
                className={`p-4 rounded-lg flex-row items-center justify-center ${
                  isRecovering ? 'bg-gray-300' : 'bg-blue-500'
                }`}
              >
                <Ionicons 
                  name={isRecovering ? 'refresh' : 'medical'} 
                  size={20} 
                  color="white" 
                />
                <Text className="text-white font-semibold ml-2">
                  {isRecovering ? 'Recovering...' : 'Manual Recovery'}
                </Text>
              </Pressable>

              <Pressable
                onPress={async () => {
                  await performHealthCheck();
                  // Refresh session info after health check
                  const debugInfo = getSessionDebugInfo();
                  const analytics = getAnalyticsSummary();
                  const sessionState = getCurrentSessionState();
                  const performance = sessionPerformance.getCurrentMetrics();
                  
                  setSessionInfo({
                    debugInfo,
                    analytics,
                    sessionState,
                    performance,
                    uptime: getSessionUptime(),
                    timestamp: Date.now()
                  });
                }}
                className="p-4 rounded-lg bg-green-500 flex-row items-center justify-center"
              >
                <Ionicons name="pulse" size={20} color="white" />
                <Text className="text-white font-semibold ml-2">
                  Run Health Check
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}