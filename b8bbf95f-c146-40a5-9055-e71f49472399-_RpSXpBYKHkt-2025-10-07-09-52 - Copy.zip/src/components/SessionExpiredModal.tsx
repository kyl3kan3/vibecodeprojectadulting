import React from "react";
import { View, Text, Pressable, Modal } from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface Props {
  visible: boolean;
  onSignIn: () => void;
  onDismiss?: () => void;
}

export default function SessionExpiredModal({ visible, onSignIn, onDismiss }: Props) {
  return (
    <Modal 
      visible={visible} 
      animationType="fade" 
      transparent 
      onRequestClose={onDismiss}
    >
      <View className="flex-1 bg-black/50 justify-center items-center px-6">
        <View className="bg-gray-800 rounded-3xl p-6 w-full max-w-sm border border-gray-700">
          <View className="items-center mb-4">
            <View className="w-16 h-16 bg-orange-600/20 rounded-full items-center justify-center mb-3">
              <Ionicons name="time-outline" size={32} color="#EA580C" />
            </View>
            <Text className="text-white text-xl font-bold text-center">
              Session Expired
            </Text>
          </View>
          
          <Text className="text-gray-300 text-center mb-6 leading-6">
            Your session has expired for security. Please sign in again to continue using the app.
          </Text>
          
          <View className="space-y-3">
            <Pressable 
              onPress={onSignIn}
              className="bg-emerald-600 py-4 rounded-2xl active:bg-emerald-700"
            >
              <Text className="text-white font-bold text-center text-lg">
                Sign In Again
              </Text>
            </Pressable>
            
            {onDismiss && (
              <Pressable 
                onPress={onDismiss}
                className="py-3 rounded-2xl active:bg-gray-700/50"
              >
                <Text className="text-gray-400 font-semibold text-center">
                  Dismiss
                </Text>
              </Pressable>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}