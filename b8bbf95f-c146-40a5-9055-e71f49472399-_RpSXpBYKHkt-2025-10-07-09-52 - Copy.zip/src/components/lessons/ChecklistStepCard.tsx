import React, { useState, useCallback, useMemo } from 'react';
import { View, Text, Pressable, Linking, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLessonsStore } from '../../state';
import SubstepResearchModal from '../SubstepResearchModal';
import { Resource } from '../../types/app';

interface Props {
  skillId: string;
  stepId: string;
  title: string;
  description?: string;
  items: { id: string; text: string }[];
  stepIndex?: number;
  totalSteps?: number;
  lessonTitle?: string;
  lessonCategory?: string;
  stepResources?: Resource[];
}

const ChecklistStepCard = React.memo(function ChecklistStepCard({ 
  skillId, 
  stepId, 
  title, 
  description, 
  items, 
  stepIndex, 
  totalSteps, 
  lessonTitle = '', 
  lessonCategory = '',
  stepResources = []
}: Props) {
  // Use a more specific selector to ensure re-renders on changes
  const toggleChecklistItem = useLessonsStore((state) => state.toggleChecklistItem);
  const res = useLessonsStore((state) => 
    state.skillProgress?.[skillId]?.stepResults?.[stepId]?.checklist as Record<string, boolean> | undefined
  );
  const done = React.useMemo(() => (res ? Object.values(res).filter(Boolean).length : 0), [res]);
  const total = items.length;
  
  // Debug logging
  React.useEffect(() => {
    if (__DEV__) {
      if (__DEV__) console.log(`[ChecklistStepCard] ${stepId} - ${done}/${total} completed`, res);
    }
  }, [stepId, done, total, res]);
  
  const [researchModalVisible, setResearchModalVisible] = useState(false);
  const [selectedSubstep, setSelectedSubstep] = useState<{ id: string; text: string } | null>(null);
  
  const handleResearchSubstep = useCallback((item: { id: string; text: string }) => {
    setSelectedSubstep(item);
    setResearchModalVisible(true);
  }, []);

  const handleResourcePress = useCallback(async (resource: Resource) => {
    try {
      if (__DEV__) console.log('Resource pressed:', resource);
      if (__DEV__) console.log('Resource URL:', resource.url);
      if (__DEV__) console.log('Resource searchTopic:', resource.searchTopic);
      
      if (resource.url) {
        // Check if URL is valid
        const url = resource.url.startsWith('http') ? resource.url : `https://${resource.url}`;
        if (__DEV__) console.log('Opening URL:', url);
        
        try {
          const canOpen = await Linking.canOpenURL(url);
          if (__DEV__) console.log('Can open URL:', canOpen);
          
          if (canOpen) {
            await Linking.openURL(url);
          } else {
            throw new Error('Cannot open URL');
          }
        } catch (urlError) {
          // URL failed, fallback to Google search with resource title
          if (__DEV__) console.log('URL failed, falling back to search:', urlError);
          Alert.alert(
            'Link Unavailable',
            `The direct link is not working. Would you like to search for "${resource.title}" instead?`,
            [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Search Google',
                onPress: async () => {
                  const searchQuery = encodeURIComponent(resource.title);
                  const searchUrl = `https://www.google.com/search?q=${searchQuery}`;
                  await Linking.openURL(searchUrl);
                }
              }
            ]
          );
        }
      } else if (resource.searchTopic) {
        // Automatically open search based on resource type
        const searchQuery = encodeURIComponent(resource.searchTopic);
        let searchUrl: string;
        
        // Use YouTube for videos, Google for everything else
        if (resource.type === 'video') {
          searchUrl = `https://www.youtube.com/results?search_query=${searchQuery}`;
        } else {
          searchUrl = `https://www.google.com/search?q=${searchQuery}`;
        }
        
        if (__DEV__) console.log('Opening search:', searchUrl);
        await Linking.openURL(searchUrl);
      } else {
        // Show detailed content based on resource type
        let detailedContent = resource.description;
        
        if (resource.title.includes('Step-by-Step Guide')) {
          detailedContent = `📋 ${resource.description}\n\n✅ Break down the task into smaller steps\n✅ Set specific deadlines for each step\n✅ Track your progress daily\n✅ Celebrate small wins along the way\n✅ Ask for help if you get stuck`;
        } else if (resource.title.includes('Progress Checklist')) {
          detailedContent = `📝 ${resource.description}\n\n□ Set your goal clearly\n□ Break it into actionable steps\n□ Set deadlines for each step\n□ Track daily progress\n□ Review and adjust weekly\n□ Celebrate milestones\n□ Learn from setbacks`;
        } else if (resource.title.includes('Emergency Fund Calculator')) {
          detailedContent = `💰 ${resource.description}\n\n📊 Calculation Formula:\n• 3-6 months of expenses = Emergency Fund Goal\n• Monthly expenses × 3 = Minimum target\n• Monthly expenses × 6 = Ideal target\n\n💡 Tips:\n• Start with $1,000 if you are just beginning\n• Automate monthly transfers\n• Keep in high-yield savings account\n• Do not touch unless it is a true emergency`;
        } else if (resource.title.includes('Budget Template')) {
          detailedContent = `📊 ${resource.description}\n\n📋 Budget Categories:\n• Housing (25-30%)\n• Food (10-15%)\n• Transportation (10-15%)\n• Utilities (5-10%)\n• Insurance (10-15%)\n• Savings (20%)\n• Entertainment (5-10%)\n\n💡 Track every expense for 30 days to see where your money really goes!`;
        }
        
        Alert.alert(resource.title, detailedContent);
      }
    } catch (error) {
      if (__DEV__) console.error('Error opening resource:', error);
      Alert.alert('Error', 'Could not open this resource: ' + (error as Error).message);
    }
  }, []);

  return (
    <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700">
      <Text className="text-white text-lg font-bold mb-3">{stepIndex && totalSteps ? `Step ${stepIndex} of ${totalSteps}: ${title}` : title}</Text>
      {description && (
        <Text className="text-gray-300 text-base mb-4">{description}</Text>
      )}
      <View className="space-y-3">
        {items.map(it => (
          <View key={it.id} className="flex-row items-center">
            <Pressable onPress={() => toggleChecklistItem(skillId, stepId, it.id)} className="flex-1 flex-row items-center">
              <View className={res?.[it.id] ? "w-6 h-6 rounded-full bg-emerald-500 items-center justify-center" : "w-6 h-6 rounded-full border border-gray-600 bg-gray-900 items-center justify-center"}>
                {res?.[it.id] && <View className="w-2 h-2 rounded-full bg-white" />}
              </View>
              <Text className="ml-3 flex-1 text-gray-200">{it.text}</Text>
            </Pressable>
            <Pressable 
              onPress={() => handleResearchSubstep(it)}
              className="ml-2 w-8 h-8 items-center justify-center bg-purple-600 rounded-full"
            >
              <Ionicons name="sparkles" size={16} color="#FFFFFF" />
            </Pressable>
          </View>
        ))}
      </View>
      <View className="mt-4">
        <Text className="text-gray-400 text-sm">{done}/{total} completed</Text>
      </View>
      
      {/* Step Resources */}
      {stepResources && stepResources.length > 0 && (
        <View className="mt-4 pt-4 border-t border-gray-700">
          <Text className="text-gray-300 text-sm font-semibold mb-2">Resources for this step:</Text>
          <View className="space-y-2">
            {stepResources.map((resource, index) => (
              <Pressable
                key={index}
                onPress={() => handleResourcePress(resource)}
                className={`flex-row items-center p-3 rounded-xl ${
                  resource.url ? 'bg-blue-600' : 
                  resource.searchTopic && resource.type === 'video' ? 'bg-red-600' : 
                  resource.searchTopic ? 'bg-purple-600' : 
                  'bg-gray-700'
                }`}
              >
                <Ionicons 
                  name={
                    resource.type === 'link' || resource.type === 'article' ? 'link' : 
                    resource.type === 'video' ? 'logo-youtube' :
                    resource.type === 'tool' ? 'hammer' : 
                    resource.type === 'template' ? 'document-text' : 
                    'calculator'
                  } 
                  size={20} 
                  color="#FFFFFF"
                />
                <View className="flex-1 ml-3">
                  <Text className="text-sm font-semibold text-white">
                    {resource.title}
                  </Text>
                  <Text className="text-xs text-white opacity-80 mt-0.5" numberOfLines={1}>
                    {resource.url ? '🔗 Direct Link' : 
                     resource.searchTopic && resource.type === 'video' ? '▶️ Search YouTube' : 
                     resource.searchTopic ? '🔍 Search Google' : 
                     resource.description}
                  </Text>
                </View>
                <Ionicons 
                  name="chevron-forward" 
                  size={18} 
                  color="#FFFFFF" 
                />
              </Pressable>
            ))}
          </View>
        </View>
      )}
      
      {/* AI Research Modal */}
      {selectedSubstep && (
        <SubstepResearchModal
          visible={researchModalVisible}
          onClose={() => {
            setResearchModalVisible(false);
            setSelectedSubstep(null);
          }}
          lessonTitle={lessonTitle}
          lessonCategory={lessonCategory}
          stepTitle={title}
          substepText={selectedSubstep.text}
        />
      )}
    </View>
  );
});

export default ChecklistStepCard;
