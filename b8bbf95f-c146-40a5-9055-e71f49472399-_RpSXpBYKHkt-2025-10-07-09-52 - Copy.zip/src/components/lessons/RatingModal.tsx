import React from 'react';
import { Modal, View, Text, Pressable } from 'react-native';

interface Props {
  visible: boolean;
  onRate: (stars: number) => void;
  onClose: () => void;
}

export default function RatingModal({ visible, onRate, onClose }: Props) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View className="flex-1 bg-black/60 items-center justify-center px-6">
        <View className="bg-gray-800 rounded-3xl p-6 w-full border border-gray-700">
          <Text className="text-white text-xl font-bold mb-2">Rate this lesson</Text>
          <View className="flex-row items-center justify-between mt-2">
            {[1,2,3,4,5].map(n => (
               <Pressable key={n} onPress={() => onRate(n)} className="px-3 py-2 rounded-2xl bg-gray-700">
                 <Text className="text-gray-200 font-semibold">{n} ★</Text>
              </Pressable>
            ))}
          </View>
          <Pressable onPress={onClose} className="mt-4 px-4 py-2 rounded-2xl bg-emerald-600 self-end">
            <Text className="text-gray-900 font-bold">Done</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
