import React, { useState, useEffect } from 'react';
import { View, Text, Modal, Pressable, ScrollView, Linking, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { generateSubstepResearch, SubstepResearchResult } from '../api/ai-substep-research';

interface Props {
  visible: boolean;
  onClose: () => void;
  lessonTitle: string;
  lessonCategory: string;
  stepTitle: string;
  substepText: string;
}

export default function SubstepResearchModal({ 
  visible, 
  onClose, 
  lessonTitle, 
  lessonCategory, 
  stepTitle, 
  substepText 
}: Props) {
  const [loading, setLoading] = useState(true);
  const [research, setResearch] = useState<SubstepResearchResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (visible) {
      loadResearch();
    }
  }, [visible, substepText]);

  const loadResearch = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await generateSubstepResearch(
        lessonTitle,
        lessonCategory,
        stepTitle,
        substepText
      );
      setResearch(result);
    } catch (err) {
      setError('Failed to load research. Please try again.');
      if (__DEV__) console.error('Research error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchResource = async (searchQuery: string) => {
    try {
      const url = `https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`;
      await Linking.openURL(url);
    } catch (err) {
      if (__DEV__) console.error('Error opening search:', err);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-gray-900">
        {/* Header */}
        <View className="bg-gray-800 border-b border-gray-700 px-6 pt-16 pb-4">
          <View className="flex-row items-center justify-between">
            <View className="flex-1 mr-4">
              <Text className="text-blue-400 text-sm font-semibold mb-1">AI Research</Text>
              <Text className="text-white text-lg font-bold" numberOfLines={2}>
                {substepText}
              </Text>
            </View>
            <Pressable onPress={onClose} className="w-10 h-10 items-center justify-center">
              <Ionicons name="close" size={28} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>

        {/* Content */}
        <ScrollView className="flex-1 px-6 py-6">
          {loading ? (
            <View className="items-center justify-center py-20">
              <ActivityIndicator size="large" color="#3B82F6" />
              <Text className="text-gray-400 mt-4">Generating personalized guidance...</Text>
            </View>
          ) : error ? (
            <View className="items-center justify-center py-20">
              <Ionicons name="alert-circle" size={64} color="#EF4444" />
              <Text className="text-red-400 mt-4 text-center">{error}</Text>
              <Pressable 
                onPress={loadResearch} 
                className="mt-6 bg-blue-600 px-6 py-3 rounded-xl"
              >
                <Text className="text-white font-semibold">Try Again</Text>
              </Pressable>
            </View>
          ) : research ? (
            <View className="space-y-6">
              {/* Explanation */}
              <View className="bg-blue-600 rounded-2xl p-5">
                <View className="flex-row items-center mb-3">
                  <Ionicons name="bulb" size={24} color="#FFFFFF" />
                  <Text className="text-white text-lg font-bold ml-2">What This Means</Text>
                </View>
                <Text className="text-white text-base leading-relaxed">
                  {research.explanation}
                </Text>
                {research.estimatedTime && (
                  <View className="flex-row items-center mt-3 pt-3 border-t border-blue-500">
                    <Ionicons name="time-outline" size={18} color="#FFFFFF" />
                    <Text className="text-white ml-2 font-semibold">
                      Estimated time: {research.estimatedTime}
                    </Text>
                  </View>
                )}
              </View>

              {/* Tips */}
              <View className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
                <View className="flex-row items-center mb-4">
                  <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                  <Text className="text-white text-lg font-bold ml-2">Pro Tips</Text>
                </View>
                {research.tips.map((tip, index) => (
                  <View key={index} className="flex-row items-start mb-3">
                    <View className="w-2 h-2 rounded-full bg-emerald-500 mt-2 mr-3" />
                    <Text className="flex-1 text-gray-300 leading-relaxed">{tip}</Text>
                  </View>
                ))}
              </View>

              {/* Common Mistakes */}
              <View className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
                <View className="flex-row items-center mb-4">
                  <Ionicons name="warning" size={24} color="#F59E0B" />
                  <Text className="text-white text-lg font-bold ml-2">Avoid These Mistakes</Text>
                </View>
                {research.commonMistakes.map((mistake, index) => (
                  <View key={index} className="flex-row items-start mb-3">
                    <View className="w-2 h-2 rounded-full bg-amber-500 mt-2 mr-3" />
                    <Text className="flex-1 text-gray-300 leading-relaxed">{mistake}</Text>
                  </View>
                ))}
              </View>

              {/* Resources */}
              <View className="bg-gray-800 rounded-2xl p-5 border border-gray-700">
                <View className="flex-row items-center mb-4">
                  <Ionicons name="search" size={24} color="#8B5CF6" />
                  <Text className="text-white text-lg font-bold ml-2">Learn More</Text>
                </View>
                {research.resources.map((resource, index) => (
                  <Pressable
                    key={index}
                    onPress={() => handleSearchResource(resource.searchQuery)}
                    className="bg-purple-600 rounded-xl p-4 mb-3"
                  >
                    <Text className="text-white font-semibold text-base mb-1">
                      {resource.title}
                    </Text>
                    <Text className="text-white opacity-80 text-sm mb-2">
                      {resource.description}
                    </Text>
                    <View className="flex-row items-center">
                      <Ionicons name="search-outline" size={16} color="#FFFFFF" />
                      <Text className="text-white text-xs ml-1 opacity-70">
                        Search: {resource.searchQuery}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </View>
            </View>
          ) : null}

          {/* Bottom padding */}
          <View className="h-8" />
        </ScrollView>
      </View>
    </Modal>
  );
}
