import React from "react";
import { View, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function ProgressShareCard({
  streakDays,
  completedTips,
  totalTips,
}: {
  streakDays: number;
  completedTips: number;
  totalTips: number;
}) {
  const pct = totalTips > 0 ? Math.round((completedTips / totalTips) * 100) : 0;
  return (
    <View className="w-[320px] h-[320px] bg-gray-900 rounded-3xl items-center justify-center border border-gray-700">
      <View className="items-center">
        <View className="w-20 h-20 bg-emerald-500 rounded-2xl items-center justify-center">
          <Ionicons name="trophy" size={36} color="#111827" />
        </View>
        <Text className="text-white text-xl font-black mt-4">My Adulting Progress</Text>
        <Text className="text-emerald-400 mt-2 font-bold">🔥 {streakDays} day streak</Text>
        <Text className="text-gray-300 mt-1">✅ {completedTips}/{totalTips} tips • {pct}%</Text>
        <Text className="text-gray-500 mt-6 text-xs">Project Adulting</Text>
      </View>
    </View>
  );
}
