import React, { useState, useEffect } from "react";
import { View, Text, Pressable, Animated } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../contexts/AuthContext";
import { sessionMonitor, SessionAlert } from "../utils/session-monitor";
import { sessionRecovery } from "../utils/session-recovery";

interface Props {
  position?: 'top' | 'bottom';
  showDetails?: boolean;
  onPress?: () => void;
}

export default function SessionStatusIndicator({ 
  position = 'top', 
  showDetails = false, 
  onPress 
}: Props) {
  const { sessionHealth, recoverSession } = useAuth();
  const [recentAlerts, setRecentAlerts] = useState<SessionAlert[]>([]);
  const [isRecovering, setIsRecovering] = useState(false);
  const [pulseAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    // Listen to alerts for recent notifications
    const unsubscribe = sessionMonitor.onAlert((alert) => {
      setRecentAlerts(prev => [alert, ...prev.slice(0, 4)]); // Keep last 5 alerts
      
      // Pulse animation for new alerts
      Animated.sequence([
        Animated.timing(pulseAnim, { 
          toValue: 1.2, 
          duration: 200, 
          useNativeDriver: true 
        }),
        Animated.timing(pulseAnim, { 
          toValue: 1, 
          duration: 200, 
          useNativeDriver: true 
        })
      ]).start();
    });

    // Check recovery status
    const checkRecoveryStatus = () => {
      setIsRecovering(sessionRecovery.isRecoveryInProgress());
    };
    
    const recoveryInterval = setInterval(checkRecoveryStatus, 1000);

    return () => {
      unsubscribe();
      clearInterval(recoveryInterval);
    };
  }, [pulseAnim]);

  const handleRecovery = async () => {
    if (isRecovering) return;
    
    try {
      await recoverSession();
      if (__DEV__) console.log('[SessionStatusIndicator] Manual recovery completed');
    } catch (error) {
      if (__DEV__) console.warn('[SessionStatusIndicator] Manual recovery failed:', error);
    }
  };

  const getStatusInfo = () => {
    if (isRecovering) {
      return {
        color: '#F59E0B',
        icon: 'refresh' as const,
        text: 'Recovering...',
        bgColor: '#FEF3C7'
      };
    }

    if (!sessionHealth) {
      return {
        color: '#6B7280',
        icon: 'help-circle' as const,
        text: 'Unknown',
        bgColor: '#F3F4F6'
      };
    }

    if (sessionHealth.isHealthy) {
      return {
        color: '#10B981',
        icon: 'checkmark-circle' as const,
        text: 'Healthy',
        bgColor: '#D1FAE5'
      };
    }

    return {
      color: '#EF4444',
      icon: 'alert-circle' as const,
      text: `${sessionHealth.issues.length} Issues`,
      bgColor: '#FEE2E2'
    };
  };

  const status = getStatusInfo();
  const hasRecentAlerts = recentAlerts.length > 0;

  return (
    <View className={`absolute left-4 right-4 z-50 ${position === 'top' ? 'top-16' : 'bottom-20'}`}>
      <Animated.View 
        style={{ 
          transform: [{ scale: pulseAnim }],
          opacity: sessionHealth === null ? 0.7 : 1
        }}
      >
        <Pressable
          onPress={onPress || handleRecovery}
          className="flex-row items-center justify-between p-3 rounded-2xl border shadow-lg"
          style={{ 
            backgroundColor: status.bgColor,
            borderColor: status.color + '40'
          }}
        >
          <View className="flex-row items-center flex-1">
            <Ionicons 
              name={status.icon} 
              size={20} 
              color={status.color} 
            />
            
            <View className="ml-3 flex-1">
              <Text 
                className="font-bold text-sm"
                style={{ color: status.color }}
              >
                Session {status.text}
              </Text>
              
              {showDetails && sessionHealth && !sessionHealth.isHealthy && (
                <Text 
                  className="text-xs mt-1"
                  style={{ color: status.color + 'CC' }}
                  numberOfLines={2}
                >
                  {sessionHealth.issues.slice(0, 2).join(', ')}
                  {sessionHealth.issues.length > 2 && '...'}
                </Text>
              )}
              
              {showDetails && hasRecentAlerts && (
                <Text 
                  className="text-xs mt-1"
                  style={{ color: status.color + 'CC' }}
                >
                  {recentAlerts[0].message}
                </Text>
              )}
            </View>
          </View>

          {hasRecentAlerts && (
            <View 
              className="w-6 h-6 rounded-full items-center justify-center ml-2"
              style={{ backgroundColor: status.color }}
            >
              <Text className="text-white text-xs font-bold">
                {recentAlerts.length}
              </Text>
            </View>
          )}

          {isRecovering && (
            <Animated.View
              style={{
                transform: [{
                  rotate: pulseAnim.interpolate({
                    inputRange: [1, 1.2],
                    outputRange: ['0deg', '360deg']
                  })
                }]
              }}
            >
              <Ionicons 
                name="refresh" 
                size={16} 
                color={status.color}
                className="ml-2"
              />
            </Animated.View>
          )}
        </Pressable>
      </Animated.View>
    </View>
  );
}