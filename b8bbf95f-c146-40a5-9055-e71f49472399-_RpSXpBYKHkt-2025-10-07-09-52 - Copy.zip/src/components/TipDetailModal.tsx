import React from 'react';
import { View, Text, ScrollView, Pressable, Modal, TextInput, Image, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { AdultingTip } from '../types/adulting';
import { useTipsStore, useProgressStore } from '../state';
import { cn } from '../utils/cn';
import { shareTip } from '../utils/sharing';

interface TipDetailModalProps {
  tip: AdultingTip | null;
  isVisible: boolean;
  onClose: () => void;
}

const categoryColors: Record<string, string> = {
  finances: 'bg-green-100 text-green-800 border-green-200',
  health_insurance: 'bg-blue-100 text-blue-800 border-blue-200',
  cooking: 'bg-orange-100 text-orange-800 border-orange-200',
  laundry: 'bg-purple-100 text-purple-800 border-purple-200',
  taxes: 'bg-red-100 text-red-800 border-red-200',
  housing: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  career: 'bg-gray-100 text-gray-800 border-gray-200',
  legal: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  maintenance: 'bg-pink-100 text-pink-800 border-pink-200',
  social: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  career_work: 'bg-gray-100 text-gray-800 border-gray-200',
  relationships: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-200',
  daily_living: 'bg-emerald-100 text-emerald-800 border-emerald-200',
};

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career: 'Career',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social',
};

const difficultyColors = {
  beginner: 'bg-green-100 text-green-700',
  intermediate: 'bg-yellow-100 text-yellow-700',
  advanced: 'bg-red-100 text-red-700',
};

export default function TipDetailModal({ tip, isVisible, onClose }: TipDetailModalProps) {
  const { 
    markTipCompleted, 
    toggleTipBookmark,
    getTipsByCategory,
    setTipRating,
    setTipNote,
    removeTipPhoto,
  } = useTipsStore();
  const {
    addTodoItem, 
    addGoal,
    userProgress
  } = useProgressStore();

  const [noteText, setNoteText] = React.useState<string>("");
  const [noteSaved, setNoteSaved] = React.useState<boolean>(false);

  React.useEffect(() => {
    if (tip) {
      const existing = (userProgress.tipNotes && userProgress.tipNotes[tip.id]) || "";
      setNoteText(existing);
      setNoteSaved(false);
    }
  }, [tip?.id]);

  React.useEffect(() => {
    if (!tip) return;
    const handler = setTimeout(() => {
      setTipNote(tip.id, noteText);
      setNoteSaved(true);
      setTimeout(() => setNoteSaved(false), 1000);
    }, 500);
    return () => clearTimeout(handler);
  }, [noteText, tip?.id]);

  if (!tip) return null;

  const isCompleted = userProgress.completedTips.includes(tip.id);
  const isBookmarked = userProgress.bookmarkedTips.includes(tip.id);
  const relatedTips = getTipsByCategory(tip.category).filter(t => t.id !== tip.id).slice(0, 3);

  const handleMarkCompleted = () => {
    if (!isCompleted) {
      markTipCompleted(tip.id);
    }
  };

  const handleBookmark = () => {
    toggleTipBookmark(tip.id);
  };

  const handleAddActionToTodo = (action: string) => {
    addTodoItem({
      title: action,
      description: `From tip: ${tip.title}`,
      category: tip.category,
      completed: false,
    });
  };

  return (
    <Modal
      visible={isVisible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView className="flex-1 bg-white">
        {/* Header */}
        <View className="flex-row items-center justify-between p-4 border-b border-gray-100">
          <View className="flex-1">
            <Text className="text-lg font-semibold text-gray-900">Tip Details</Text>
          </View>
          <Pressable onPress={onClose} className="p-2">
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {/* Tip Header */}
          <View className="p-6">
            <View className="flex-row flex-wrap items-center mb-4">
              <View className={cn("px-3 py-1 rounded-full border mr-2 mb-2", categoryColors[tip.category])}>
                <Text className={cn("text-sm font-medium", categoryColors[tip.category])}>
                  {categoryLabels[tip.category]}
                </Text>
              </View>
              <View className={cn("px-3 py-1 rounded-full mr-2 mb-2", difficultyColors[tip.difficulty])}>
                <Text className={cn("text-sm font-medium capitalize", difficultyColors[tip.difficulty])}>
                  {tip.difficulty}
                </Text>
              </View>
              {tip.estimatedTime && (
                <View className="px-3 py-1 bg-gray-100 rounded-full mb-2">
                  <Text className="text-sm text-gray-700">⏱️ {tip.estimatedTime}</Text>
                </View>
              )}
            </View>

            <Text className="text-2xl font-bold text-gray-900 mb-4 leading-tight">
              {tip.title}
            </Text>

            <Text className="text-base text-gray-700 leading-relaxed mb-6">
              {tip.content?.overview || tip.description || 'No description available'}
            </Text>

            {/* Action Buttons */}
            <View className="flex-row space-x-3 mb-6">
              <Pressable
                onPress={handleMarkCompleted}
                disabled={isCompleted}
                accessibilityRole="button"
                accessibilityLabel={isCompleted ? "Tip completed" : "Mark tip complete"}
                className={cn(
                  "flex-1 flex-row items-center justify-center p-3 rounded-xl",
                  isCompleted 
                    ? "bg-green-100 border border-green-200" 
                    : "bg-blue-500"
                )}
              >
                <Ionicons 
                  name={isCompleted ? "checkmark-circle" : "checkmark-circle-outline"} 
                  size={18} 
                  color={isCompleted ? "#059669" : "#FFFFFF"} 
                />
                <Text className={cn(
                  "ml-2 font-semibold text-sm",
                  isCompleted ? "text-green-700" : "text-white"
                )}>
                  {isCompleted ? "Completed" : "Mark Complete"}
                </Text>
              </Pressable>

              <Pressable
                onPress={handleBookmark}
                accessibilityRole="button"
                accessibilityLabel={isBookmarked ? "Remove bookmark" : "Add bookmark"}
                className={cn(
                  "px-4 py-3 rounded-xl border",
                  isBookmarked 
                    ? "bg-blue-50 border-blue-200" 
                    : "bg-white border-gray-200"
                )}
              >
                <Ionicons 
                  name={isBookmarked ? "bookmark" : "bookmark-outline"} 
                  size={18} 
                  color={isBookmarked ? "#007AFF" : "#6B7280"} 
                />
              </Pressable>

              <Pressable
                onPress={() => shareTip(tip)}
                accessibilityRole="button"
                accessibilityLabel="Share tip"
                className="px-4 py-3 rounded-xl border bg-white border-gray-200"
              >
                <Ionicons name="share-social-outline" size={18} color="#6B7280" />
              </Pressable>
            </View>

            {/* Rating */}
            <View className="mb-6">
              <Text className="text-base font-semibold text-gray-900 mb-2">Rate this tip</Text>
              <View className="flex-row items-center">
                {[1,2,3,4,5].map(n => (
                  <Pressable
                    key={n}
                    onPress={() => setTipRating(tip.id, n)}
                    accessibilityRole="button"
                    accessibilityLabel={`Rate ${n} star`}
                    className="mr-2"
                  >
                    <Ionicons
                      name={(userProgress.tipRatings[tip.id] || 0) >= n ? "star" : "star-outline"}
                      size={20}
                      color="#F59E0B"
                    />
                  </Pressable>
                ))}
                {userProgress.tipRatings[tip.id] ? (
                  <Text className="ml-2 text-gray-600 text-sm">{userProgress.tipRatings[tip.id]} / 5</Text>
                ) : null}
              </View>
            </View>
          </View>


            {/* Notes */}
            <View className="px-6 pb-6">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="text-xl font-bold text-gray-900">Your Notes</Text>
                {noteSaved && (
                  <Text className="text-xs text-gray-500">Saved</Text>
                )}
              </View>
              <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <View className="bg-gray-50 border border-gray-100 rounded-xl p-3">
                  <TextInput
                    value={noteText}
                    onChangeText={setNoteText}
                    placeholder="Add a note about this tip..."
                    placeholderTextColor="#9CA3AF"
                    multiline
                    maxLength={500}
                    className="text-gray-800 min-h-[80px]"
                    accessibilityLabel="Your note about this tip"
                  />
                </View>
              </KeyboardAvoidingView>
              <View className="flex-row mt-2">
                <Pressable onPress={async () => {
                  try {
                    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsMultipleSelection: false, quality: 0.7 });
                    if (!res.canceled && res.assets && res.assets[0]?.uri) {
                      useTipsStore.getState().addTipPhoto(tip.id, res.assets[0].uri);
                    }
                  } catch {}
                }} className="px-3 py-2 bg-gray-100 rounded-lg border border-gray-200">
                  <Text className="text-gray-700 text-sm">Add photo</Text>
                </Pressable>
              </View>
              {/* Thumbnails */}
              <View className="flex-row mt-2 flex-wrap">
                {((userProgress.tipPhotos && userProgress.tipPhotos[tip.id]) || []).map((uri: string, i: number) => (
                  <View key={i} className="w-16 h-16 bg-gray-100 rounded-lg mr-2 mb-2 overflow-hidden">
                    <Image source={{ uri }} style={{ width: '100%', height: '100%' }} />
                    <Pressable
                      onPress={() => removeTipPhoto(tip.id, uri)}
                      accessibilityLabel="Remove photo"
                      className="absolute -top-1 -right-1 w-6 h-6 rounded-full items-center justify-center bg-white border border-gray-300"
                    >
                      <Ionicons name="close" size={12} color="#6B7280" />
                    </Pressable>
                  </View>
                ))}
              </View>
            </View>


            {/* Related Tips */}
            {relatedTips.length > 0 && (
              <View className="px-6 pb-8">
                <Text className="text-xl font-bold text-gray-900 mb-4">More in {categoryLabels[tip.category]}</Text>
                <View className="space-y-3">
                  {relatedTips.map((relatedTip) => {
                    const isRelatedCompleted = userProgress.completedTips.includes(relatedTip.id);
                    return (
                      <View
                        key={relatedTip.id}
                        className="bg-white border border-gray-200 rounded-xl p-4"
                      >
                        <View className="flex-row items-start justify-between">
                          <View className="flex-1">
                            <Text className="font-semibold text-gray-900 mb-1">
                              {relatedTip.title}
                            </Text>
                            <Text className="text-sm text-gray-600 leading-relaxed" numberOfLines={2}>
                              {relatedTip.description}
                            </Text>
                            <View className="flex-row items-center mt-2">
                              <Text className="text-xs text-gray-500 capitalize mr-2">
                                {relatedTip.difficulty}
                              </Text>
                              {relatedTip.estimatedTime && (
                                <Text className="text-xs text-gray-500">
                                  • {relatedTip.estimatedTime}
                                </Text>
                              )}
                            </View>
                          </View>
                          {isRelatedCompleted && (
                            <Ionicons name="checkmark-circle" size={20} color="#059669" />
                          )}
                        </View>
                      </View>
                    );
                  })}
                </View>
                <Pressable onPress={() => (require('@react-navigation/native').useNavigation as any)().navigate('ResourceExplorer', { q: tip.title })} className="mt-4 bg-gray-100 border border-gray-200 rounded-xl p-3 items-center">
                  <Text className="text-gray-800 font-medium">Explore trusted resources</Text>
                </Pressable>
              </View>
            )}
          </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}