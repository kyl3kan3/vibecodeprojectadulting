/**
 * Stack Component
 * Flexbox container with consistent spacing
 */

import React from 'react';
import { View } from 'react-native';
import { cn } from '../../utils/cn';

export interface StackProps {
  children: React.ReactNode;
  direction?: 'vertical' | 'horizontal';
  spacing?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  align?: 'start' | 'center' | 'end' | 'stretch';
  justify?: 'start' | 'center' | 'end' | 'between' | 'around';
  className?: string;
}

const spacingStyles: Record<NonNullable<StackProps['spacing']>, string> = {
  none: 'gap-0',
  xs: 'gap-1',
  sm: 'gap-2',
  md: 'gap-4',
  lg: 'gap-6',
  xl: 'gap-8',
};

const alignStyles: Record<NonNullable<StackProps['align']>, string> = {
  start: 'items-start',
  center: 'items-center',
  end: 'items-end',
  stretch: 'items-stretch',
};

const justifyStyles: Record<NonNullable<StackProps['justify']>, string> = {
  start: 'justify-start',
  center: 'justify-center',
  end: 'justify-end',
  between: 'justify-between',
  around: 'justify-around',
};

export const Stack: React.FC<StackProps> = ({
  children,
  direction = 'vertical',
  spacing = 'md',
  align,
  justify,
  className,
}) => {
  return (
    <View
      className={cn(
        direction === 'vertical' ? 'flex-col' : 'flex-row',
        spacingStyles[spacing],
        align && alignStyles[align],
        justify && justifyStyles[justify],
        className
      )}
    >
      {children}
    </View>
  );
};
