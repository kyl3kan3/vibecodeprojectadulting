/**
 * Container Component
 * Content wrapper with consistent width and padding
 */

import React from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { cn } from '../../utils/cn';

export interface ContainerProps {
  children: React.ReactNode;
  useSafeArea?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  className?: string;
}

const paddingStyles: Record<NonNullable<ContainerProps['padding']>, string> = {
  none: '',
  sm: 'px-4',
  md: 'px-6',
  lg: 'px-8',
};

export const Container: React.FC<ContainerProps> = ({
  children,
  useSafeArea = true,
  padding = 'md',
  className,
}) => {
  const Wrapper = useSafeArea ? SafeAreaView : View;
  
  return (
    <Wrapper className={cn('flex-1', paddingStyles[padding], className)}>
      {children}
    </Wrapper>
  );
};
