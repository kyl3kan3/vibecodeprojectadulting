import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Modal, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { TodoItem } from '../types/adulting';
import { useProgressStore } from '../state';
import { cn } from '../utils/cn';

interface TodoDetailModalProps {
  todo: TodoItem | null;
  isVisible: boolean;
  onClose: () => void;
}

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career_work: 'Career & Work',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social',
  credit: 'Credit',
  fitness: 'Fitness',
  mental_health: 'Mental Health',
  healthcare: 'Healthcare',
  relationships: 'Relationships',
  education: 'Education',
  personal_care: 'Personal Care',
  safety: 'Safety',
  transportation: 'Transportation',
  technology: 'Technology',
  nutrition: 'Nutrition',
  shopping: 'Shopping',
  time_management: 'Time Management',
  communication: 'Communication',
  organization: 'Organization',
  goal_setting: 'Goal Setting',
  networking: 'Networking',
  side_hustles: 'Side Hustles',
  insurance: 'Insurance',
  investing: 'Investing',
  daily_living: 'Daily Living',
  personal_development: 'Personal Development',
  consumer_rights: 'Consumer Rights',
  travel: 'Travel',
  environment: 'Environment',
};

const categoryIcons: Record<string, string> = {
  finances: 'card',
  health_insurance: 'medical',
  cooking: 'restaurant',
  laundry: 'shirt',
  taxes: 'document-text',
  housing: 'home',
  career_work: 'briefcase',
  legal: 'library',
  maintenance: 'construct',
  social: 'people',
  credit: 'card',
  fitness: 'fitness',
  mental_health: 'heart',
  healthcare: 'medical',
  relationships: 'people',
  education: 'school',
  personal_care: 'body',
  safety: 'shield',
  transportation: 'car',
  technology: 'laptop',
  nutrition: 'nutrition',
  shopping: 'bag',
  time_management: 'time',
  communication: 'chatbubbles',
  organization: 'folder',
  goal_setting: 'flag',
  networking: 'people-circle',
  side_hustles: 'cash',
  insurance: 'shield-checkmark',
  investing: 'trending-up',
  daily_living: 'home',
  personal_development: 'person',
  consumer_rights: 'shield',
  travel: 'airplane',
  environment: 'leaf',
};

const categoryColors: Record<string, string> = {
  finances: '#10B981',
  health_insurance: '#3B82F6',
  cooking: '#F59E0B',
  laundry: '#8B5CF6',
  taxes: '#EF4444',
  housing: '#06B6D4',
  career_work: '#6366F1',
  legal: '#84CC16',
  maintenance: '#F97316',
  social: '#EC4899',
  credit: '#7C3AED',
  fitness: '#EF4444',
  mental_health: '#06B6D4',
  healthcare: '#10B981',
  relationships: '#F59E0B',
  education: '#3B82F6',
  personal_care: '#8B5CF6',
  safety: '#EF4444',
  transportation: '#6366F1',
  technology: '#84CC16',
  nutrition: '#F97316',
  shopping: '#EC4899',
  time_management: '#10B981',
  communication: '#3B82F6',
  organization: '#F59E0B',
  goal_setting: '#8B5CF6',
  networking: '#EF4444',
  side_hustles: '#06B6D4',
  insurance: '#6366F1',
  investing: '#84CC16',
  daily_living: '#F97316',
  personal_development: '#EC4899',
  consumer_rights: '#10B981',
  travel: '#3B82F6',
  environment: '#F59E0B',
};

export default function TodoDetailModal({ todo, isVisible, onClose }: TodoDetailModalProps) {
  const { toggleTodoCompleted, deleteTodoItem } = useProgressStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedDescription, setEditedDescription] = useState('');

  if (!todo) return null;

  const categoryColor = categoryColors[todo.category] || '#6B7280';

  const handleEdit = () => {
    setEditedTitle(todo.title);
    setEditedDescription(todo.description || '');
    setIsEditing(true);
  };

  const handleSave = () => {
    Alert.alert('Feature Coming Soon', 'Todo editing will be available in a future update!');
    setIsEditing(false);
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Todo',
      'Are you sure you want to delete this todo item?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: () => {
            deleteTodoItem(todo.id);
            onClose();
          }
        }
      ]
    );
  };

  const handleToggleCompleted = () => {
    toggleTodoCompleted(todo.id);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityLevel = () => {
    const createdDate = new Date(todo.createdAt);
    const daysSinceCreated = Math.floor((Date.now() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysSinceCreated > 7) return { level: 'High', color: '#EF4444' };
    if (daysSinceCreated > 3) return { level: 'Medium', color: '#F59E0B' };
    return { level: 'Normal', color: '#10B981' };
  };

  const priority = getPriorityLevel();

  return (
    <Modal
      visible={isVisible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView className="flex-1 bg-gray-900">
        {/* Header */}
        <View className="flex-row items-center justify-between p-6 border-b border-gray-700">
          <View className="flex-1">
            <Text className="text-gray-400 text-sm font-medium mb-1">
              Todo Details
            </Text>
            <Text className="text-white text-xl font-black">
              {categoryLabels[todo.category] || 'Todo'}
            </Text>
          </View>
          <View className="flex-row items-center space-x-2">
            {!isEditing && (
              <Pressable 
                onPress={handleEdit}
                className="w-12 h-12 bg-gray-800 rounded-full items-center justify-center border border-gray-700"
              >
                <Ionicons name="pencil" size={20} color="#FFFFFF" />
              </Pressable>
            )}
            <Pressable 
              onPress={onClose}
              className="w-12 h-12 bg-gray-800 rounded-full items-center justify-center border border-gray-700"
            >
              <Ionicons name="close" size={20} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          <View className="p-6">
            {/* Status and Category Card */}
            <View className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center">
                  <Pressable 
                    onPress={handleToggleCompleted}
                    className="mr-4"
                  >
                    <Ionicons 
                      name={todo.completed ? "checkmark-circle" : "ellipse-outline"} 
                      size={32} 
                      color={todo.completed ? "#10B981" : "#9CA3AF"} 
                    />
                  </Pressable>
                  <View>
                    <View className="flex-row items-center mb-2">
                      <View 
                        className="w-10 h-10 rounded-2xl items-center justify-center mr-3"
                        style={{ backgroundColor: categoryColor }}
                      >
                        <Ionicons 
                          name={categoryIcons[todo.category] as any} 
                          size={20} 
                          color="white" 
                        />
                      </View>
                      <Text className="text-white font-bold">
                        {categoryLabels[todo.category]}
                      </Text>
                    </View>
                    <View 
                      className="px-3 py-1 rounded-full"
                      style={{ backgroundColor: `${priority.color}20` }}
                    >
                      <Text 
                        className="text-xs font-bold"
                        style={{ color: priority.color }}
                      >
                        {priority.level} Priority
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </View>

            {/* Title */}
            {isEditing ? (
              <View className="mb-6">
                <Text className="text-gray-300 text-sm font-bold mb-3">TITLE</Text>
                <TextInput
                  value={editedTitle}
                  onChangeText={setEditedTitle}
                  className="bg-gray-800 border border-gray-700 rounded-2xl p-4 text-white"
                  placeholder="Enter todo title..."
                  placeholderTextColor="#9CA3AF"
                />
              </View>
            ) : (
              <View className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
                <Text className="text-gray-300 text-sm font-bold mb-3">TITLE</Text>
                <Text className={cn(
                  "text-xl font-bold leading-tight",
                  todo.completed ? "text-gray-500 line-through" : "text-white"
                )}>
                  {todo.title}
                </Text>
              </View>
            )}

            {/* Description */}
            {(todo.description || isEditing) && (
              <View className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
                <Text className="text-gray-300 text-sm font-bold mb-3">DESCRIPTION</Text>
                {isEditing ? (
                  <TextInput
                    value={editedDescription}
                    onChangeText={setEditedDescription}
                    multiline
                    numberOfLines={4}
                    className="bg-gray-700 border border-gray-600 rounded-2xl p-4 text-white"
                    placeholder="Enter description..."
                    placeholderTextColor="#9CA3AF"
                    textAlignVertical="top"
                  />
                ) : (
                  <Text className="text-white leading-relaxed">
                    {todo.description || 'No description provided'}
                  </Text>
                )}
              </View>
            )}

            {/* Edit Actions */}
            {isEditing && (
              <View className="flex-row space-x-3 mb-6">
                <Pressable
                  onPress={handleSave}
                  className="flex-1 rounded-2xl p-4"
                  style={{ backgroundColor: categoryColor }}
                >
                  <Text className="text-white font-bold text-center">Save Changes</Text>
                </Pressable>
                <Pressable
                  onPress={() => setIsEditing(false)}
                  className="px-6 py-4 border border-gray-600 bg-gray-700 rounded-2xl"
                >
                  <Text className="text-white font-bold">Cancel</Text>
                </Pressable>
              </View>
            )}

            {/* Metadata */}
            <View className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
              <Text className="text-gray-300 text-sm font-bold mb-4">DETAILS</Text>
              
              <View className="space-y-4">
                <View className="flex-row justify-between">
                  <Text className="text-gray-400">Status</Text>
                  <Text className={cn(
                    "font-bold",
                    todo.completed ? "text-green-400" : "text-orange-400"
                  )}>
                    {todo.completed ? "Completed" : "Pending"}
                  </Text>
                </View>

                <View className="flex-row justify-between">
                  <Text className="text-gray-400">Created</Text>
                  <Text className="text-white">{formatDate(todo.createdAt)}</Text>
                </View>

                <View className="flex-row justify-between">
                  <Text className="text-gray-400">Category</Text>
                  <Text className="text-white">{categoryLabels[todo.category]}</Text>
                </View>

                {todo.dueDate && (
                  <View className="flex-row justify-between">
                    <Text className="text-gray-400">Due Date</Text>
                    <Text className="text-white">{formatDate(todo.dueDate)}</Text>
                  </View>
                )}
              </View>
            </View>

            {/* Completion Status */}
            {!todo.completed && (
              <View className="bg-blue-600 rounded-3xl p-6 mb-6">
                <View className="flex-row items-center mb-3">
                  <View className="w-12 h-12 bg-blue-500 rounded-2xl items-center justify-center mr-4">
                    <Ionicons name="information-circle" size={24} color="white" />
                  </View>
                  <Text className="text-white font-bold text-lg">Quick Action</Text>
                </View>
                <Text className="text-blue-100 leading-relaxed">
                  Tap the circle above to mark this todo as completed when you're done!
                </Text>
              </View>
            )}

            {/* Action Buttons */}
            <View className="space-y-3">
              <Pressable
                onPress={handleToggleCompleted}
                className={cn(
                  "flex-row items-center justify-center p-4 rounded-3xl",
                  todo.completed 
                    ? "bg-orange-500" 
                    : "bg-green-500"
                )}
              >
                <Ionicons 
                  name={todo.completed ? "refresh" : "checkmark-circle"} 
                  size={24} 
                  color="#FFFFFF" 
                />
                <Text className="text-white font-bold ml-3 text-lg">
                  {todo.completed ? "Mark as Pending" : "Mark as Completed"}
                </Text>
              </Pressable>

              <Pressable
                onPress={handleDelete}
                className="flex-row items-center justify-center p-4 border-2 border-red-500 bg-gray-800 rounded-3xl"
              >
                <Ionicons name="trash-outline" size={24} color="#EF4444" />
                <Text className="text-red-500 font-bold ml-3 text-lg">Delete Todo</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}