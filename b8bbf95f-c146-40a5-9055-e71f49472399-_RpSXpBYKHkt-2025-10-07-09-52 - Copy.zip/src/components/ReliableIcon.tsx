import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface ReliableIconProps {
  name: keyof typeof Ionicons.glyphMap;
  size: number;
  color: string;
  fallbackNames?: (keyof typeof Ionicons.glyphMap)[];
  testId?: string;
}

/**
 * ReliableIcon component with fallback options for icon rendering issues
 * Tries multiple icon names if the primary one fails to render correctly
 */
export const ReliableIcon: React.FC<ReliableIconProps> = ({
  name,
  size,
  color,
  fallbackNames = [],
  testId
}) => {
  const [currentIconIndex, setCurrentIconIndex] = useState(0);
  const [hasError, setHasError] = useState(false);

  // Create array of icon names to try (primary + fallbacks)
  const iconNames = [name, ...fallbackNames];
  const currentIconName = iconNames[currentIconIndex];

  const handleIconError = () => {
    if (__DEV__) console.log(`[ReliableIcon] Icon "${currentIconName}" failed to render, trying fallback...`);
    
    if (currentIconIndex < iconNames.length - 1) {
      setCurrentIconIndex(prev => prev + 1);
    } else {
      if (__DEV__) console.error(`[ReliableIcon] All icon options failed: ${iconNames.join(', ')}`);
      setHasError(true);
    }
  };

  // If all icons failed, show a text fallback
  if (hasError) {
    return (
      <View 
        style={{ 
          width: size, 
          height: size, 
          justifyContent: 'center', 
          alignItems: 'center',
          backgroundColor: color + '20',
          borderRadius: size / 4
        }}
        testID={testId}
      >
        <Text style={{ color, fontSize: size * 0.6, fontWeight: 'bold' }}>×</Text>
      </View>
    );
  }

  try {
    return (
      <Ionicons 
        name={currentIconName} 
        size={size} 
        color={color}
        onError={handleIconError}
        testID={testId}
      />
    );
  } catch (error) {
    if (__DEV__) console.error(`[ReliableIcon] Error rendering icon "${currentIconName}":`, error);
    handleIconError();
    return null;
  }
};

/**
 * Predefined reliable close icon with multiple fallback options
 * Optimized for different platforms and use cases
 */
export const ReliableCloseIcon: React.FC<{
  size?: number;
  color?: string;
  testId?: string;
  variant?: 'default' | 'outline' | 'circle' | 'minimal';
}> = ({ 
  size = 24, 
  color = '#DC2626',
  testId = 'close-icon',
  variant = 'default'
}) => {
  // Different fallback strategies based on variant
  const getFallbackNames = (): (keyof typeof Ionicons.glyphMap)[] => {
    switch (variant) {
      case 'outline':
        return ['close-outline', 'close', 'remove-outline', 'stop-outline'];
      case 'circle':
        return ['close-circle', 'close-circle-outline', 'close', 'stop-circle'];
      case 'minimal':
        return ['remove', 'close', 'stop', 'ban'];
      default:
        return [
          'close-outline',  // Most reliable outline version
          'close-circle-outline',  // Circle outline fallback
          'remove-outline',  // Alternative outline
          'stop-outline',    // Stop sign outline
          'close',          // Original close
          'remove',         // Simple remove
          'stop'            // Final fallback
        ];
    }
  };

  return (
    <ReliableIcon
      name={variant === 'outline' ? 'close-outline' : 'close'}
      size={size}
      color={color}
      fallbackNames={getFallbackNames()}
      testId={testId}
    />
  );
};

/**
 * Icon validation utility
 * Checks if an icon name exists in the Ionicons glyph map
 */
export const validateIconName = (iconName: string): boolean => {
  try {
    return iconName in Ionicons.glyphMap;
  } catch (error) {
    if (__DEV__) console.warn(`[ReliableIcon] Error validating icon "${iconName}":`, error);
    return false;
  }
};

/**
 * Icon testing utility
 * Tests multiple icon names and returns the first valid one
 */
export const findValidIcon = (iconNames: string[]): keyof typeof Ionicons.glyphMap | null => {
  for (const iconName of iconNames) {
    if (validateIconName(iconName)) {
      return iconName as keyof typeof Ionicons.glyphMap;
    }
  }
  return null;
};

/**
 * Debug component to test icon rendering
 * Only shown in development mode
 */
export const IconDebugger: React.FC<{
  iconNames: string[];
  size?: number;
  color?: string;
}> = ({ iconNames, size = 24, color = '#000000' }) => {
  if (!__DEV__) return null;

  return (
    <View style={{ padding: 10, backgroundColor: '#f0f0f0', margin: 5, borderRadius: 8 }}>
      <Text style={{ fontSize: 14, fontWeight: 'bold', marginBottom: 10 }}>Icon Test Results:</Text>
      {iconNames.map((iconName, index) => {
        const isValid = validateIconName(iconName);
        return (
          <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
            <Text style={{ 
              fontSize: 12, 
              marginRight: 10, 
              color: isValid ? 'green' : 'red',
              fontWeight: isValid ? 'bold' : 'normal'
            }}>
              {iconName}: {isValid ? '✓' : '✗'}
            </Text>
            {isValid && (
              <Ionicons 
                name={iconName as keyof typeof Ionicons.glyphMap} 
                size={size} 
                color={color} 
              />
            )}
          </View>
        );
      })}
    </View>
  );
};

/**
 * Close icon tester component
 * Tests all close icon variants in development
 */
export const CloseIconTester: React.FC = () => {
  if (!__DEV__) return null;

  const closeIconNames = [
    'close',
    'close-outline', 
    'close-circle',
    'close-circle-outline',
    'remove',
    'remove-outline',
    'stop',
    'stop-outline',
    'ban',
    'ban-outline'
  ];

  return (
    <View style={{ padding: 20, backgroundColor: '#fff', margin: 10, borderRadius: 12 }}>
      <Text style={{ fontSize: 16, fontWeight: 'bold', marginBottom: 15 }}>
        Close Icon Compatibility Test
      </Text>
      <IconDebugger iconNames={closeIconNames} size={24} color="#DC2626" />
      <Text style={{ fontSize: 12, color: '#666', marginTop: 10 }}>
        Valid icons will show ✓ and render properly. Invalid icons show ✗.
      </Text>
    </View>
  );
};