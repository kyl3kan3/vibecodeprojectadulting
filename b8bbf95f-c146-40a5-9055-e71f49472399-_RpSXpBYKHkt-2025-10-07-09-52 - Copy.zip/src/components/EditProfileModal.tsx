import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Modal,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';
import { profileService } from '../services/database';
import { validateUsername, sanitizeUsername } from '../utils/profile-display';

interface EditProfileModalProps {
  visible: boolean;
  onClose: () => void;
  onSave: () => void;
}

export default function EditProfileModal({ visible, onClose, onSave }: EditProfileModalProps) {
  const { profile, updateProfile } = useAuth();
  
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [checkTimeout, setCheckTimeout] = useState<NodeJS.Timeout | null>(null);

  // Initialize with current profile data
  useEffect(() => {
    if (visible && profile) {
      setUsername(profile.username || '');
      setFullName(profile.full_name || '');
      setUsernameAvailable(null);
      setUsernameError(null);
      setSaveError(null);
    }
  }, [visible, profile]);

  // Debounced username availability check
  useEffect(() => {
    // Clear any existing timeout
    if (checkTimeout) {
      clearTimeout(checkTimeout);
    }

    // Don't check if empty or same as current username
    if (!username || username === profile?.username) {
      setCheckingUsername(false);
      setUsernameAvailable(null);
      setUsernameError(null);
      return;
    }

    // Validate format first
    const validation = validateUsername(username);
    if (!validation.valid) {
      setUsernameError(validation.error || 'Invalid username');
      setUsernameAvailable(false);
      setCheckingUsername(false);
      return;
    }

    // Set checking state
    setCheckingUsername(true);
    setUsernameError(null);

    // Debounce the API call
    const timeout = setTimeout(async () => {
      try {
        const result = await profileService.checkUsernameAvailability(username);
        if (result.success && result.data) {
          setUsernameAvailable(result.data.available);
          if (!result.data.available) {
            setUsernameError(`Username taken. Try ${result.data.suggestion}`);
          } else {
            setUsernameError(null);
          }
        }
      } catch (error: any) {
        setUsernameError('Could not check availability');
        setUsernameAvailable(null);
      } finally {
        setCheckingUsername(false);
      }
    }, 500);

    setCheckTimeout(timeout);

    return () => {
      if (timeout) clearTimeout(timeout);
    };
  }, [username, profile?.username]);

  const handleUsernameChange = (text: string) => {
    // Sanitize input
    const sanitized = sanitizeUsername(text);
    setUsername(sanitized);
  };

  const handleSave = async () => {
    setSaveError(null);
    setLoading(true);

    try {
      // Validate username if changed
      if (username && username !== profile?.username) {
        if (usernameAvailable === false) {
          setSaveError('Please choose an available username');
          setLoading(false);
          return;
        }

        const validation = validateUsername(username);
        if (!validation.valid) {
          setSaveError(validation.error || 'Invalid username');
          setLoading(false);
          return;
        }
      }

      // Prepare updates
      const updates: any = {};
      if (username !== profile?.username) {
        updates.username = username || null;
      }
      if (fullName !== profile?.full_name) {
        updates.full_name = fullName || null;
      }

      // Only update if there are changes
      if (Object.keys(updates).length === 0) {
        onClose();
        return;
      }

      // Update profile
      const { error } = await updateProfile(updates);
      
      if (error) {
        setSaveError(error.message || 'Failed to update profile');
        setLoading(false);
        return;
      }

      // Success - close modal and trigger refresh
      onSave();
      onClose();
    } catch (error: any) {
      setSaveError(error.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={onClose}
    >
      <SafeAreaView className="flex-1 bg-gray-900">
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          className="flex-1"
        >
          <ScrollView className="flex-1" keyboardShouldPersistTaps="handled">
            {/* Header */}
            <View className="px-6 py-4 border-b border-gray-800 flex-row items-center justify-between">
              <View className="flex-row items-center">
                <View className="w-10 h-10 bg-emerald-500 rounded-2xl items-center justify-center mr-3">
                  <Ionicons name="create-outline" size={20} color="#111827" />
                </View>
                <Text className="text-white text-2xl font-black">Edit Profile</Text>
              </View>
              <Pressable onPress={onClose} hitSlop={8}>
                <Ionicons name="close" size={28} color="#9CA3AF" />
              </Pressable>
            </View>

            {/* Form */}
            <View className="px-6 py-6">
              {/* Full Name */}
              <View className="mb-6">
                <Text className="text-gray-400 font-medium mb-2">Full Name</Text>
                <TextInput
                  value={fullName}
                  onChangeText={setFullName}
                  placeholder="Enter your full name"
                  placeholderTextColor="#6B7280"
                  className="w-full px-4 py-3 border border-gray-700 rounded-2xl text-white bg-gray-800"
                  autoCapitalize="words"
                  autoComplete="name"
                  editable={!loading}
                />
                <Text className="text-gray-500 text-xs mt-2">
                  This is how others will see your name
                </Text>
              </View>

              {/* Username */}
              <View className="mb-6">
                <Text className="text-gray-400 font-medium mb-2">Username</Text>
                <View className="relative">
                  <View className="flex-row items-center border border-gray-700 rounded-2xl bg-gray-800">
                    <Text className="text-gray-400 pl-4 text-lg">@</Text>
                    <TextInput
                      value={username}
                      onChangeText={handleUsernameChange}
                      placeholder="username"
                      placeholderTextColor="#6B7280"
                      className="flex-1 px-2 py-3 text-white"
                      autoCapitalize="none"
                      autoCorrect={false}
                      autoComplete="username"
                      editable={!loading}
                    />
                    {checkingUsername && (
                      <View className="pr-4">
                        <ActivityIndicator size="small" color="#10B981" />
                      </View>
                    )}
                    {!checkingUsername && username && username !== profile?.username && (
                      <View className="pr-4">
                        {usernameAvailable === true && (
                          <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                        )}
                        {usernameAvailable === false && (
                          <Ionicons name="close-circle" size={24} color="#EF4444" />
                        )}
                      </View>
                    )}
                  </View>
                </View>
                
                {usernameError && (
                  <Text className="text-red-400 text-xs mt-2">{usernameError}</Text>
                )}
                
                <Text className="text-gray-500 text-xs mt-2">
                  3-20 characters, letters, numbers, and underscores only
                </Text>
              </View>

              {/* Error Message */}
              {saveError && (
                <View className="bg-red-500/10 border border-red-600 rounded-2xl p-4 mb-6">
                  <Text className="text-red-400">{saveError}</Text>
                </View>
              )}

              {/* Action Buttons */}
              <View className="flex-row space-x-3">
                <Pressable
                  onPress={onClose}
                  disabled={loading}
                  className="flex-1 bg-gray-800 border border-gray-700 rounded-2xl p-4 items-center"
                >
                  <Text className="text-white font-bold text-lg">Cancel</Text>
                </Pressable>

                <Pressable
                  onPress={handleSave}
                  disabled={loading || checkingUsername || (username !== profile?.username && usernameAvailable === false)}
                  className={`flex-1 rounded-2xl p-4 items-center ${
                    loading || checkingUsername || (username !== profile?.username && usernameAvailable === false)
                      ? 'bg-gray-700'
                      : 'bg-emerald-500'
                  }`}
                >
                  {loading ? (
                    <ActivityIndicator color="#111827" />
                  ) : (
                    <Text className="text-gray-900 font-bold text-lg">Save</Text>
                  )}
                </Pressable>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}
