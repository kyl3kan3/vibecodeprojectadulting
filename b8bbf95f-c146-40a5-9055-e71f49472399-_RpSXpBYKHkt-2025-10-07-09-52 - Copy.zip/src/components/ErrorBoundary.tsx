import React from "react";
import { View, Text, Pressable } from "react-native";

type Props = {
  children: React.ReactNode;
};

type State = { hasError: boolean };

export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: any, info: any) {
    // Intentionally no console output in production; UI handles messaging
  }

  handleReset = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <View style={{ flex: 1, backgroundColor: "#111827", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <Text style={{ color: "#FFFFFF", fontSize: 18, fontWeight: "700", marginBottom: 8 }}>Something went wrong</Text>
          <Text style={{ color: "#9CA3AF", textAlign: "center", marginBottom: 16 }}>Please try again. If the issue persists, update to the latest build.</Text>
          <Pressable onPress={this.handleReset} style={{ backgroundColor: "#10B981", borderRadius: 16, paddingVertical: 10, paddingHorizontal: 16 }}>
            <Text style={{ color: "#111827", fontWeight: "800" }}>Retry</Text>
          </Pressable>
        </View>
      );
    }
    return this.props.children as any;
  }
}
