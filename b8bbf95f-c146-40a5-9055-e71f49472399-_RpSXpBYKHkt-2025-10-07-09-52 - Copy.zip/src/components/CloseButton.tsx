import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { ReliableCloseIcon } from './ReliableIcon';
import { cn } from '../utils/cn';

interface CloseButtonProps {
  onPress: () => void;
  variant?: 'header' | 'primary' | 'emergency' | 'minimal';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  testId?: string;
  accessibilityLabel?: string;
  showText?: boolean;
  customText?: string;
}

/**
 * Consistent close button component with multiple variants
 * Ensures all close buttons have the same behavior and styling
 */
export const CloseButton: React.FC<CloseButtonProps> = ({
  onPress,
  variant = 'header',
  size = 'medium',
  disabled = false,
  testId,
  accessibilityLabel,
  showText = true,
  customText
}) => {
  // Size configurations
  const sizeConfig = {
    small: { iconSize: 20, padding: 8, textSize: 'text-sm' },
    medium: { iconSize: 24, padding: 12, textSize: 'text-base' },
    large: { iconSize: 28, padding: 16, textSize: 'text-lg' }
  };

  const config = sizeConfig[size];

  // Variant-specific styling
  const getVariantStyles = () => {
    switch (variant) {
      case 'header':
        return {
          container: 'flex-row items-center px-3 py-2 rounded-full bg-red-50 border border-red-200',
          iconColor: '#DC2626',
          textColor: 'text-red-600',
          iconVariant: 'outline' as const,
          text: customText || 'Close'
        };
      
      case 'primary':
        return {
          container: 'w-full bg-red-600 rounded-2xl py-4 items-center shadow-lg',
          iconColor: 'white',
          textColor: 'text-white',
          iconVariant: 'default' as const,
          text: customText || 'Close Resource'
        };
      
      case 'emergency':
        return {
          container: 'w-14 h-14 bg-red-600 rounded-full items-center justify-center shadow-lg border-2 border-white',
          iconColor: 'white',
          textColor: 'text-white',
          iconVariant: 'circle' as const,
          text: customText || 'Emergency Exit'
        };
      
      case 'minimal':
        return {
          container: 'w-10 h-10 rounded-full bg-gray-100 items-center justify-center',
          iconColor: '#6B7280',
          textColor: 'text-gray-600',
          iconVariant: 'minimal' as const,
          text: customText || 'Close'
        };
      
      default:
        return getVariantStyles(); // Fallback to header
    }
  };

  const styles = getVariantStyles();
  const isDisabled = disabled;

  // Accessibility label with fallback
  const finalAccessibilityLabel = accessibilityLabel || 
    `${styles.text} button` || 
    'Close button';

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      className={cn(
        styles.container,
        isDisabled && 'opacity-50'
      )}
      accessibilityLabel={finalAccessibilityLabel}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled }}
      testID={testId}
    >
      {variant === 'emergency' ? (
        // Emergency variant - icon only
        <ReliableCloseIcon
          size={config.iconSize}
          color={styles.iconColor}
          variant={styles.iconVariant}
          testId={`${testId}-icon`}
        />
      ) : (
        // Other variants - icon + optional text
        <View className="flex-row items-center">
          <ReliableCloseIcon
            size={config.iconSize}
            color={styles.iconColor}
            variant={styles.iconVariant}
            testId={`${testId}-icon`}
          />
          {showText && (
            <Text className={cn(
              styles.textColor,
              config.textSize,
              'font-semibold',
              variant === 'primary' ? 'font-bold' : '',
              variant !== 'minimal' ? 'ml-2' : 'ml-1'
            )}>
              {styles.text}
            </Text>
          )}
        </View>
      )}
    </Pressable>
  );
};

/**
 * Emergency close button with label
 * Includes both the button and emergency label
 */
export const EmergencyCloseButton: React.FC<{
  onPress: () => void;
  testId?: string;
}> = ({ onPress, testId }) => {
  return (
    <View className="items-center">
      <CloseButton
        onPress={onPress}
        variant="emergency"
        size="large"
        showText={false}
        testId={testId}
        accessibilityLabel="Emergency exit - force close"
      />
      <View className="absolute -bottom-8 bg-red-600 px-2 py-1 rounded">
        <Text className="text-white text-xs font-bold">Emergency Exit</Text>
      </View>
    </View>
  );
};