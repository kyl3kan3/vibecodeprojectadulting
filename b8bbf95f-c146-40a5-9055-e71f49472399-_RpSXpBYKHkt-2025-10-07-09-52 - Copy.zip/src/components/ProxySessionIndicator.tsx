import React, { useState, useEffect } from "react";
import { View, Text, Pressable, Animated } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { proxySessionMonitor, ProxySessionHealth } from "../utils/proxy-session-monitor";
import { proxySessionRecovery } from "../utils/proxy-session-recovery";

interface Props {
  position?: 'top' | 'bottom';
  showDetails?: boolean;
  onPress?: () => void;
  compact?: boolean;
}

export default function ProxySessionIndicator({ 
  position = 'top', 
  showDetails = false, 
  onPress,
  compact = false
}: Props) {
  const [health, setHealth] = useState<ProxySessionHealth | null>(null);
  const [isRecovering, setIsRecovering] = useState(false);
  const [pulseAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    // Subscribe to health updates
    const unsubscribe = proxySessionMonitor.onHealthChange((newHealth) => {
      setHealth(newHealth);
      
      // Pulse animation when health changes
      if (newHealth && (!health || newHealth.isHealthy !== health.isHealthy)) {
        Animated.sequence([
          Animated.timing(pulseAnim, { 
            toValue: 1.1, 
            duration: 150, 
            useNativeDriver: true 
          }),
          Animated.timing(pulseAnim, { 
            toValue: 1, 
            duration: 150, 
            useNativeDriver: true 
          })
        ]).start();
      }
    });

    // Start monitoring if not already started
    proxySessionMonitor.startMonitoring();

    // Check recovery status periodically
    const checkRecoveryStatus = () => {
      setIsRecovering(proxySessionRecovery.isRecoveryInProgress());
    };
    
    const recoveryInterval = setInterval(checkRecoveryStatus, 1000);

    return () => {
      unsubscribe();
      clearInterval(recoveryInterval);
    };
  }, [health, pulseAnim]);

  const handlePress = async () => {
    if (onPress) {
      onPress();
      return;
    }

    // Default action: attempt recovery if unhealthy
    if (health && !health.isHealthy && !isRecovering) {
      try {
        await proxySessionRecovery.attemptRecovery();
      } catch (error) {
        if (__DEV__) {
          if (__DEV__) console.warn('[ProxySessionIndicator] Recovery failed:', error);
        }
      }
    }
  };

  const getStatusInfo = () => {
    if (isRecovering) {
      return {
        color: '#F59E0B',
        icon: 'sync' as const,
        text: 'Recovering...',
        bgColor: '#FEF3C7',
        description: 'Attempting to restore connection'
      };
    }

    if (!health) {
      return {
        color: '#6B7280',
        icon: 'help-circle' as const,
        text: 'Unknown',
        bgColor: '#F3F4F6',
        description: 'Proxy status unknown'
      };
    }

    if (health.isHealthy && health.isConnected) {
      const latencyText = health.latency ? ` (${health.latency}ms)` : '';
      return {
        color: '#10B981',
        icon: 'checkmark-circle' as const,
        text: `Healthy${latencyText}`,
        bgColor: '#D1FAE5',
        description: `Success rate: ${health.successRate.toFixed(1)}%`
      };
    }

    if (health.isConnected && !health.isHealthy) {
      return {
        color: '#F59E0B',
        icon: 'warning' as const,
        text: `${health.errors.length} Issues`,
        bgColor: '#FEF3C7',
        description: 'Connected but experiencing errors'
      };
    }

    return {
      color: '#EF4444',
      icon: 'close-circle' as const,
      text: 'Disconnected',
      bgColor: '#FEE2E2',
      description: 'Cannot reach proxy server'
    };
  };

  const status = getStatusInfo();

  if (compact) {
    return (
      <Animated.View 
        style={{ 
          transform: [{ scale: pulseAnim }]
        }}
      >
        <Pressable
          onPress={handlePress}
          className="flex-row items-center px-2 py-1 rounded-lg"
          style={{ backgroundColor: status.bgColor }}
        >
          <Ionicons 
            name={status.icon} 
            size={16} 
            color={status.color} 
          />
          
          {!compact && (
            <Text 
              className="ml-1 text-xs font-medium"
              style={{ color: status.color }}
            >
              Proxy
            </Text>
          )}
          
          {isRecovering && (
            <Animated.View
              style={{
                marginLeft: 4,
                transform: [{
                  rotate: pulseAnim.interpolate({
                    inputRange: [1, 1.1],
                    outputRange: ['0deg', '360deg']
                  })
                }]
              }}
            >
              <Ionicons 
                name="sync" 
                size={12} 
                color={status.color}
              />
            </Animated.View>
          )}
        </Pressable>
      </Animated.View>
    );
  }

  return (
    <View className={`absolute left-4 right-4 z-50 ${position === 'top' ? 'top-20' : 'bottom-24'}`}>
      <Animated.View 
        style={{ 
          transform: [{ scale: pulseAnim }],
          opacity: health === null ? 0.7 : 1
        }}
      >
        <Pressable
          onPress={handlePress}
          className="flex-row items-center justify-between p-3 rounded-2xl border shadow-lg"
          style={{ 
            backgroundColor: status.bgColor,
            borderColor: status.color + '40'
          }}
        >
          <View className="flex-row items-center flex-1">
            <Ionicons 
              name={status.icon} 
              size={20} 
              color={status.color} 
            />
            
            <View className="ml-3 flex-1">
              <Text 
                className="font-bold text-sm"
                style={{ color: status.color }}
              >
                Proxy {status.text}
              </Text>
              
              {showDetails && (
                <Text 
                  className="text-xs mt-1"
                  style={{ color: status.color + 'CC' }}
                  numberOfLines={2}
                >
                  {status.description}
                </Text>
              )}
              
              {showDetails && health && health.errors.length > 0 && (
                <Text 
                  className="text-xs mt-1"
                  style={{ color: status.color + 'CC' }}
                  numberOfLines={1}
                >
                  Last error: {health.errors[0].message}
                </Text>
              )}
            </View>
          </View>

          {health && health.consecutiveFailures > 0 && (
            <View 
              className="w-6 h-6 rounded-full items-center justify-center ml-2"
              style={{ backgroundColor: status.color }}
            >
              <Text className="text-white text-xs font-bold">
                {health.consecutiveFailures}
              </Text>
            </View>
          )}

          {isRecovering && (
            <Animated.View
              style={{
                marginLeft: 8,
                transform: [{
                  rotate: pulseAnim.interpolate({
                    inputRange: [1, 1.1],
                    outputRange: ['0deg', '360deg']
                  })
                }]
              }}
            >
              <Ionicons 
                name="sync" 
                size={16} 
                color={status.color}
              />
            </Animated.View>
          )}
        </Pressable>
      </Animated.View>
    </View>
  );
}