/**
 * Card Component
 * Reusable container with consistent styling
 */

import React from 'react';
import { View, Pressable } from 'react-native';
import { cn } from '../../utils/cn';

export interface CardProps {
  children: React.ReactNode;
  onPress?: () => void;
  variant?: 'default' | 'outlined' | 'elevated';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  className?: string;
}

const variantStyles: Record<NonNullable<CardProps['variant']>, string> = {
  default: 'bg-gray-800 border-gray-700',
  outlined: 'bg-transparent border-gray-600',
  elevated: 'bg-gray-800 border-gray-700',
};

const paddingStyles: Record<NonNullable<CardProps['padding']>, string> = {
  none: '',
  sm: 'p-3',
  md: 'p-5',
  lg: 'p-6',
};

export const Card: React.FC<CardProps> = ({
  children,
  onPress,
  variant = 'default',
  padding = 'md',
  className,
}) => {
  const baseStyles = cn(
    'rounded-3xl border',
    variantStyles[variant],
    paddingStyles[padding],
    className
  );

  if (onPress) {
    return (
      <Pressable onPress={onPress} className={baseStyles}>
        {children}
      </Pressable>
    );
  }

  return <View className={baseStyles}>{children}</View>;
};
