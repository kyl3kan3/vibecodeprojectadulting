/**
 * Text Component
 * Typography system with semantic variants
 */

import React from 'react';
import { Text as RNText, TextProps as RNTextProps } from 'react-native';
import { cn } from '../../utils/cn';

export type TextVariant = 'h1' | 'h2' | 'h3' | 'h4' | 'body' | 'caption' | 'label';
export type TextColor = 'primary' | 'secondary' | 'muted' | 'error' | 'success' | 'warning';

export interface TextProps extends RNTextProps {
  variant?: TextVariant;
  color?: TextColor;
  weight?: 'normal' | 'medium' | 'semibold' | 'bold' | 'black';
  align?: 'left' | 'center' | 'right';
}

const variantStyles: Record<TextVariant, string> = {
  h1: 'text-3xl font-black',
  h2: 'text-2xl font-bold',
  h3: 'text-xl font-bold',
  h4: 'text-lg font-semibold',
  body: 'text-base',
  caption: 'text-sm',
  label: 'text-xs font-medium uppercase tracking-wide',
};

const colorStyles: Record<TextColor, string> = {
  primary: 'text-white',
  secondary: 'text-gray-300',
  muted: 'text-gray-400',
  error: 'text-red-400',
  success: 'text-green-400',
  warning: 'text-yellow-400',
};

const weightStyles: Record<NonNullable<TextProps['weight']>, string> = {
  normal: 'font-normal',
  medium: 'font-medium',
  semibold: 'font-semibold',
  bold: 'font-bold',
  black: 'font-black',
};

const alignStyles: Record<NonNullable<TextProps['align']>, string> = {
  left: 'text-left',
  center: 'text-center',
  right: 'text-right',
};

export const Text: React.FC<TextProps> = ({
  children,
  variant = 'body',
  color = 'primary',
  weight,
  align,
  className,
  ...props
}) => {
  return (
    <RNText
      className={cn(
        variantStyles[variant],
        colorStyles[color],
        weight && weightStyles[weight],
        align && alignStyles[align],
        className
      )}
      {...props}
    >
      {children}
    </RNText>
  );
};
