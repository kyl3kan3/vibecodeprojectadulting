/**
 * Button Component
 * Reusable button with multiple variants and sizes
 * Follows Apple HIG design principles
 */

import React from 'react';
import { Pressable, Text, ActivityIndicator, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../../utils/cn';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  children: React.ReactNode;
  onPress?: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  className?: string;
}

const variantStyles: Record<ButtonVariant, string> = {
  primary: 'bg-blue-600 border-blue-600',
  secondary: 'bg-gray-700 border-gray-600',
  outline: 'bg-transparent border-gray-600',
  ghost: 'bg-transparent border-transparent',
  danger: 'bg-red-600 border-red-600',
};

const textStyles: Record<ButtonVariant, string> = {
  primary: 'text-white',
  secondary: 'text-white',
  outline: 'text-gray-200',
  ghost: 'text-blue-400',
  danger: 'text-white',
};

const sizeStyles: Record<ButtonSize, { container: string; text: string; icon: number }> = {
  sm: { container: 'px-3 py-2', text: 'text-sm', icon: 16 },
  md: { container: 'px-4 py-3', text: 'text-base', icon: 20 },
  lg: { container: 'px-6 py-4', text: 'text-lg', icon: 24 },
};

export const Button: React.FC<ButtonProps> = ({
  children,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  className,
}) => {
  const sizeStyle = sizeStyles[size];
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={isDisabled ? undefined : onPress}
      disabled={isDisabled}
      className={cn(
        'border rounded-2xl items-center justify-center flex-row',
        variantStyles[variant],
        sizeStyle.container,
        fullWidth && 'w-full',
        isDisabled && 'opacity-50',
        className
      )}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'outline' || variant === 'ghost' ? '#60A5FA' : '#FFFFFF'} 
        />
      ) : (
        <View className="flex-row items-center">
          {icon && iconPosition === 'left' && (
            <Ionicons 
              name={icon} 
              size={sizeStyle.icon} 
              color={variant === 'outline' || variant === 'ghost' ? '#E5E7EB' : '#FFFFFF'}
              style={{ marginRight: 8 }}
            />
          )}
          <Text className={cn('font-semibold', textStyles[variant], sizeStyle.text)}>
            {children}
          </Text>
          {icon && iconPosition === 'right' && (
            <Ionicons 
              name={icon} 
              size={sizeStyle.icon} 
              color={variant === 'outline' || variant === 'ghost' ? '#E5E7EB' : '#FFFFFF'}
              style={{ marginLeft: 8 }}
            />
          )}
        </View>
      )}
    </Pressable>
  );
};
