/**
 * Input Component
 * Form input with validation states
 */

import React from 'react';
import { View, TextInput, Text, TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../../utils/cn';

export interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  helperText?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  success?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  helperText,
  icon,
  success,
  className,
  ...props
}) => {
  const hasError = !!error;
  
  return (
    <View className="mb-4">
      {label && (
        <Text className="text-gray-300 text-sm font-medium mb-2">{label}</Text>
      )}
      <View className="relative">
        {icon && (
          <View className="absolute left-4 top-0 bottom-0 justify-center z-10">
            <Ionicons 
              name={icon} 
              size={20} 
              color={hasError ? '#F87171' : success ? '#34D399' : '#9CA3AF'} 
            />
          </View>
        )}
        <TextInput
          className={cn(
            'bg-gray-800 border rounded-2xl px-4 py-3 text-white',
            icon && 'pl-12',
            hasError && 'border-red-500',
            success && 'border-green-500',
            !hasError && !success && 'border-gray-700',
            className
          )}
          placeholderTextColor="#6B7280"
          {...props}
        />
      </View>
      {error && (
        <Text className="text-red-400 text-sm mt-1">{error}</Text>
      )}
      {helperText && !error && (
        <Text className="text-gray-500 text-sm mt-1">{helperText}</Text>
      )}
    </View>
  );
};
