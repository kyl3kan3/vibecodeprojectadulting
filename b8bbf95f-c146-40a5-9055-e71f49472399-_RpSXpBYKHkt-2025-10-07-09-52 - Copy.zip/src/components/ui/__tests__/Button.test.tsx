/**
 * Button Component Tests
 * Test button variants, states, and interactions
 */

import React from 'react';
import { render, fireEvent } from '../../../utils/testUtils';
import { Button } from '../Button';

describe('Button', () => {
  it('should render correctly', () => {
    const { getByText } = render(<Button>Click Me</Button>);
    expect(getByText('Click Me')).toBeTruthy();
  });

  it('should call onPress when clicked', () => {
    const onPress = jest.fn();
    const { getByText } = render(<Button onPress={onPress}>Click Me</Button>);
    
    fireEvent.press(getByText('Click Me'));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  it('should not call onPress when disabled', () => {
    const onPress = jest.fn();
    const { getByText } = render(
      <Button onPress={onPress} disabled>Click Me</Button>
    );
    
    fireEvent.press(getByText('Click Me'));
    expect(onPress).not.toHaveBeenCalled();
  });

  it('should show loading state', () => {
    const { queryByText, UNSAFE_getByType } = render(
      <Button loading>Click Me</Button>
    );
    
    // Text should not be visible when loading
    expect(queryByText('Click Me')).toBeNull();
    // ActivityIndicator should be present
    expect(UNSAFE_getByType(require('react-native').ActivityIndicator)).toBeTruthy();
  });

  it('should render with icon', () => {
    const { getByText } = render(
      <Button icon="checkmark-circle">With Icon</Button>
    );
    
    expect(getByText('With Icon')).toBeTruthy();
  });

  it('should apply variant styles correctly', () => {
    const { getByText } = render(
      <Button variant="danger">Delete</Button>
    );
    
    expect(getByText('Delete')).toBeTruthy();
  });
});
