/**
 * EmptyState Component
 * Placeholder for empty data states
 */

import React from 'react';
import { View, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button } from './Button';

export interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = 'albums-outline',
  title,
  description,
  actionLabel,
  onAction,
}) => {
  return (
    <View className="flex-1 items-center justify-center px-8 py-12">
      <Ionicons name={icon} size={64} color="#6B7280" />
      <Text className="text-white text-xl font-bold mt-4 text-center">{title}</Text>
      {description && (
        <Text className="text-gray-400 text-center mt-2">{description}</Text>
      )}
      {actionLabel && onAction && (
        <View className="mt-6">
          <Button onPress={onAction} variant="primary">
            {actionLabel}
          </Button>
        </View>
      )}
    </View>
  );
};
