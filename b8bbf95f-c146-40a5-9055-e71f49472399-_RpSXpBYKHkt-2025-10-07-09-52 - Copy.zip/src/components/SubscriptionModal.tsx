import React from "react";
import { Modal, View, Text, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { storekit } from "../services/storekit";

interface Props {
  visible: boolean;
  onClose: () => void;
}

export default function SubscriptionModal({ visible, onClose }: Props) {
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View className="flex-1 bg-black/60">
        <SafeAreaView className="mt-auto bg-gray-900 rounded-t-3xl" style={{ maxHeight: "80%" }}>
          <View className="px-6 pt-5 pb-3 border-b border-gray-800 flex-row items-center justify-between">
            <View className="flex-row items-center">
              <View className="w-10 h-10 bg-emerald-500 rounded-2xl items-center justify-center mr-3">
                <Ionicons name="card-outline" size={20} color="#111827" />
              </View>
              <Text className="text-white text-xl font-black">Subscription</Text>
            </View>
            <Pressable onPress={onClose} className="px-3 py-1 rounded-2xl bg-gray-800 border border-gray-700">
              <Text className="text-white font-bold">Close</Text>
            </Pressable>
          </View>

          <View className="px-6 py-5">
            <Text className="text-white font-bold mb-2">This screen has moved</Text>
            <Text className="text-gray-400 mb-4">Subscriptions are now handled with Apple StoreKit. Please use the Manage Subscription sheet in Profile.</Text>
            <Pressable onPress={() => storekit.openManageSubscriptions()} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700 self-start">
              <Text className="text-white font-bold">Open Apple Subscriptions</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </View>
    </Modal>
  );
}
