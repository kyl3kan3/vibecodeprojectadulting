import React from "react";
import { View, ViewStyle, StyleProp } from "react-native";

export type SafeLinearGradientProps = {
  colors: (string | number)[];
  locations?: number[];
  start?: { x: number; y: number };
  end?: { x: number; y: number };
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
};

// Tries to use expo-linear-gradient if present; otherwise falls back to a solid color View
export const SafeLinearGradient: React.FC<SafeLinearGradientProps> = (props) => {
  let ExpoLG: any = null;
  try {
    // Use eval to avoid Metro static resolution when the module is not installed
    const req: any = (eval as any)("require");
    const mod = req && req("expo-linear-gradient");
    ExpoLG = mod && (mod.LinearGradient || mod.default?.LinearGradient);
  } catch {}

  if (ExpoLG) {
    const LG = ExpoLG as React.ComponentType<SafeLinearGradientProps>;
    return <LG {...props}>{props.children}</LG> as any;
  }

  const bg = Array.isArray(props.colors) && props.colors.length > 0 ? String(props.colors[0]) : "#10B981";
  return <View style={[props.style, { backgroundColor: bg }]}>{props.children}</View>;
};

export default SafeLinearGradient;
