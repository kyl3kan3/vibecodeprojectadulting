/**
 * Example: Cloud Storage Usage
 * 
 * This file demonstrates how to use the cloud storage service
 * for uploading photos, documents, and other files.
 */

import React, { useState } from 'react';
import { View, Text, Image, Pressable, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import {
  uploadFromUri,
  getFileUrl,
  deleteFile,
  generateUserFilePath,
} from '../api/cloud-storage';

interface UploadedFile {
  path: string;
  url: string | null;
  timestamp: number;
}

export function CloudStorageExample() {
  const [uploading, setUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  // Example: Upload a photo from camera or library
  const handlePickAndUploadImage = async () => {
    try {
      // Request permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera roll permissions are needed to upload photos.');
        return;
      }

      // Pick image
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (result.canceled) {
        return;
      }

      const imageUri = result.assets[0].uri;
      
      // Get user ID (from your auth context)
      const userId = (global as any).__AUTH_USER__?.id;
      if (!userId) {
        Alert.alert('Error', 'You must be signed in to upload files.');
        return;
      }

      setUploading(true);

      // Generate unique path for this user's photo
      const filePath = generateUserFilePath(userId, 'photos', 'jpg');

      // Upload to cloud storage via proxy
      const uploadResult = await uploadFromUri(imageUri, {
        bucket: 'user-content',
        path: filePath,
        contentType: 'image/jpeg',
        upsert: true,
      });

      if (uploadResult.success) {
        Alert.alert('Success', 'Photo uploaded successfully!');
        
        // Get download URL to display the image
        const downloadUrl = await getFileUrl('user-content', uploadResult.path, 3600);
        
        // Save to state
        setUploadedFiles(prev => [
          ...prev,
          {
            path: uploadResult.path,
            url: downloadUrl,
            timestamp: Date.now(),
          },
        ]);
      } else {
        Alert.alert('Upload Failed', uploadResult.error || 'Unknown error');
      }
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setUploading(false);
    }
  };

  // Example: Delete a file
  const handleDeleteFile = async (filePath: string) => {
    try {
      const result = await deleteFile('user-content', filePath);
      
      if (result.success) {
        Alert.alert('Success', 'File deleted successfully!');
        setUploadedFiles(prev => prev.filter(f => f.path !== filePath));
      } else {
        Alert.alert('Delete Failed', result.error || 'Unknown error');
      }
    } catch (error: any) {
      Alert.alert('Error', error.message);
    }
  };

  // Example: Refresh download URL (they expire after 5 minutes by default)
  const refreshDownloadUrl = async (filePath: string) => {
    try {
      const newUrl = await getFileUrl('user-content', filePath, 3600);
      
      if (newUrl) {
        setUploadedFiles(prev =>
          prev.map(f => (f.path === filePath ? { ...f, url: newUrl } : f))
        );
      }
    } catch (error: any) {
      if (__DEV__) console.error('Failed to refresh URL:', error);
    }
  };

  return (
    <View className="flex-1 bg-white p-4">
      <Text className="text-2xl font-bold mb-4">Cloud Storage Example</Text>

      {/* Upload Button */}
      <Pressable
        onPress={handlePickAndUploadImage}
        disabled={uploading}
        className="bg-blue-500 p-4 rounded-lg mb-4 items-center active:opacity-70"
      >
        <View className="flex-row items-center">
          <Ionicons name="cloud-upload" size={24} color="white" />
          <Text className="text-white font-semibold ml-2">
            {uploading ? 'Uploading...' : 'Upload Photo'}
          </Text>
        </View>
      </Pressable>

      {/* Uploaded Files Grid */}
      <Text className="text-lg font-semibold mb-2">Uploaded Files:</Text>
      
      {uploadedFiles.length === 0 ? (
        <View className="items-center justify-center py-8">
          <Ionicons name="cloud-offline-outline" size={48} color="#ccc" />
          <Text className="text-gray-400 mt-2">No files uploaded yet</Text>
        </View>
      ) : (
        <View className="flex-row flex-wrap">
          {uploadedFiles.map((file, index) => (
            <View key={index} className="w-1/2 p-2">
              <View className="bg-gray-100 rounded-lg overflow-hidden">
                {file.url ? (
                  <Pressable onPress={() => setSelectedImage(file.url)}>
                    <Image
                      source={{ uri: file.url }}
                      className="w-full h-40"
                      resizeMode="cover"
                    />
                  </Pressable>
                ) : (
                  <View className="w-full h-40 items-center justify-center bg-gray-200">
                    <Ionicons name="image-outline" size={48} color="#999" />
                    <Text className="text-gray-500 text-xs mt-2">Loading...</Text>
                  </View>
                )}
                
                <View className="p-2 flex-row justify-between">
                  <Pressable
                    onPress={() => refreshDownloadUrl(file.path)}
                    className="flex-1 items-center active:opacity-50"
                  >
                    <Ionicons name="refresh" size={20} color="#666" />
                  </Pressable>
                  
                  <Pressable
                    onPress={() => handleDeleteFile(file.path)}
                    className="flex-1 items-center active:opacity-50"
                  >
                    <Ionicons name="trash" size={20} color="#ef4444" />
                  </Pressable>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Full Screen Image Modal */}
      {selectedImage && (
        <Pressable
          onPress={() => setSelectedImage(null)}
          className="absolute inset-0 bg-black/90 items-center justify-center"
        >
          <Image
            source={{ uri: selectedImage }}
            className="w-full h-full"
            resizeMode="contain"
          />
          <Pressable
            onPress={() => setSelectedImage(null)}
            className="absolute top-12 right-4 bg-white/20 rounded-full p-2"
          >
            <Ionicons name="close" size={32} color="white" />
          </Pressable>
        </Pressable>
      )}
    </View>
  );
}

// ============================================
// Example: Upload Progress Share Card Image
// ============================================

export async function uploadProgressCardImage(
  cardImageUri: string,
  userId: string
): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    // Generate path
    const filePath = generateUserFilePath(userId, 'achievements', 'jpg');

    // Upload
    const result = await uploadFromUri(cardImageUri, {
      bucket: 'user-content',
      path: filePath,
      contentType: 'image/jpeg',
      upsert: true,
    });

    if (!result.success) {
      return { success: false, error: result.error };
    }

    // Get a long-lived URL for sharing (1 hour)
    const url = await getFileUrl('user-content', result.path, 3600);

    if (!url) {
      return { success: false, error: 'Failed to generate download URL' };
    }

    return { success: true, url };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// ============================================
// Example: Upload User Profile Photo
// ============================================

export async function uploadProfilePhoto(
  photoUri: string,
  userId: string
): Promise<{ success: boolean; path?: string; error?: string }> {
  try {
    // Always use same path for profile photo (upsert will replace old one)
    const filePath = `users/${userId}/avatars/profile.jpg`;

    const result = await uploadFromUri(photoUri, {
      bucket: 'avatars',
      path: filePath,
      contentType: 'image/jpeg',
      upsert: true, // Will replace existing profile photo
    });

    if (result.success) {
      return { success: true, path: result.path };
    } else {
      return { success: false, error: result.error };
    }
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// ============================================
// Example: Get User Profile Photo URL
// ============================================

export async function getProfilePhotoUrl(
  userId: string
): Promise<string | null> {
  try {
    const filePath = `users/${userId}/avatars/profile.jpg`;
    const url = await getFileUrl('avatars', filePath, 3600);
    return url;
  } catch (error) {
    if (__DEV__) console.error('Failed to get profile photo URL:', error);
    return null;
  }
}
