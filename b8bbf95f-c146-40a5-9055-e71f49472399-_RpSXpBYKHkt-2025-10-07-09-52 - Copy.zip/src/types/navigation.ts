import type { NavigationProp, CompositeNavigationProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';

export type RootStackParamList = {
  MainTabs: undefined;
  Onboarding: undefined;
  SkillDetail: { skillId: string };
  TipDetail: { tipId: string };
  Category: { category: string };
};

export type TabParamList = {
  Home: undefined;
  Learn: undefined;
  Progress: undefined;
  Coach: undefined;
  Profile: undefined;
};

export type RootStackNavigationProp = NativeStackNavigationProp<RootStackParamList>;
export type TabNavigationProp = BottomTabNavigationProp<TabParamList>;

export type HomeScreenNavigationProp = CompositeNavigationProp<
  TabNavigationProp,
  RootStackNavigationProp
>;