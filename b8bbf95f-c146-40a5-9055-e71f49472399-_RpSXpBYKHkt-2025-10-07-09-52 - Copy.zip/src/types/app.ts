// Core app types for the redesigned Adulting Coach

export interface LifeSkill {
  id: string;
  title: string;
  description: string;
  category: SkillCategory;
  difficulty: 'starter' | 'building' | 'mastery';
  estimatedTime: number; // minutes
  xpReward: number;
  prerequisites?: string[];
  content: SkillContent;
  tags: string[];
}

export interface SkillContent {
  overview: string;
  keyPoints: string[];
  stepByStep: SkillStep[];
  tips: string[];
  commonMistakes: string[];
  resources: Resource[];
  stepResources?: Record<string, Resource[]>;
}

export interface SkillStep {
  id: string;
  title: string;
  description: string;
  timeEstimate: number;
  isOptional?: boolean;
  type?: "read" | "checklist" | "timer" | "input" | "quiz";
  checklist?: { items: { id: string; text: string }[] };
  timer?: { seconds: number };
  input?: { placeholder: string; keyboard?: "default" | "number-pad" };
  quiz?: { question: string; choices: string[]; correctIndex: number; explanation?: string };
}

export interface Resource {
  type: 'link' | 'tool' | 'template' | 'calculator' | 'article' | 'video';
  title: string;
  url?: string;
  description: string;
  searchTopic?: string;
  relevanceScore?: number; // 0-100 relevance to the specific lesson
  source?: 'curated' | 'ai' | 'fallback';
}

export type SkillCategory = 
  | 'money_mastery'
  | 'health_wellness' 
  | 'home_life'
  | 'career_growth'
  | 'relationships'
  | 'personal_growth'
  | 'tech_savvy'
  | 'life_admin';

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  currentLevel: number;
  totalXP: number;
  streak: number;
  lastActiveDate: string;
  preferences: UserPreferences;
  completedSkills: string[];
  inProgressSkills: string[];
  savedSkills: string[];
  achievements: Achievement[];
  goals: PersonalGoal[];
}

export interface UserPreferences {
  focusAreas: SkillCategory[];
  learningStyle: 'visual' | 'reading' | 'hands_on';
  timeCommitment: 'light' | 'moderate' | 'intensive'; // 10, 20, 30+ min/day
  reminderTime: string;
  reminderDays: number[];
  notificationsEnabled: boolean;
  categoryPreferences: CategoryPreference[];
  aiTone?: 'friendly' | 'neutral' | 'formal';
  aiDepth?: 'brief' | 'detailed';
  safetyMode?: boolean;
  weeklyDigestEnabled?: boolean;
  weeklyDigestDay?: number; // 0-6, 0=Sun
  weeklyDigestTime?: string; // "HH:mm"
}

export interface CategoryPreference {
  category: SkillCategory;
  isEnabled: boolean;
  priority: 'high' | 'medium' | 'low';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  xpReward: number;
  unlockedAt?: string;
  isUnlocked: boolean;
}

export interface PersonalGoal {
  id: string;
  title: string;
  description: string;
  category: SkillCategory;
  targetDate: string;
  relatedSkills: string[];
  milestones: Milestone[];
  isCompleted: boolean;
  createdAt: string;
}

export interface Milestone {
  id: string;
  title: string;
  isCompleted: boolean;
  completedAt?: string;
}

export interface LearningPath {
  id: string;
  title: string;
  description: string;
  category: SkillCategory;
  skills: string[];
  estimatedWeeks: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export interface DailyChallenge {
  id: string;
  date: string;
  title: string;
  description: string;
  category: SkillCategory;
  xpReward: number;
  isCompleted: boolean;
  timeEstimate: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type: 'text' | 'skill_suggestion' | 'goal_creation';
  metadata?: any;
}

export interface SkillProgress {
  skillId: string;
  completedSteps: string[];
  timeSpent: number;
  startedAt: string;
  completedAt?: string;
  rating?: number;
  notes?: string;
  stepResults?: Record<string, StepResult>;
}

export type AiGateResult =
  | { ok: true }
  | { ok: false; reason: "quota" | "cooldown"; remainingMs: number };

export type StepResult = {
  status: 'pending' | 'in_progress' | 'done';
  checklist?: Record<string, boolean>;
  inputValue?: string;
  quiz?: { selectedIndex: number | null; correct: boolean | null };
  timer?: { startedAt?: string; durationSec: number; completed: boolean; completedAt?: string };
  completedItems?: string[];
  timerStartedAt?: string;
  timerDuration?: number;
  timerCompletedAt?: string;
};
