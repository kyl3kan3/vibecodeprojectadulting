/**
 * Utility Types
 * Common type patterns used across the application
 */

/**
 * Result of an async operation
 */
export type AsyncResult<T> = {
  data: T | null;
  error: Error | null;
  loading: boolean;
};

/**
 * Paginated API response
 */
export type PaginatedResponse<T> = {
  data: T[];
  page: number;
  pageSize: number;
  total: number;
  hasMore: boolean;
};

/**
 * Standard API response wrapper
 */
export type ApiResponse<T> = {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metadata?: {
    timestamp: string;
    requestId?: string;
  };
};

/**
 * Nullable type helper
 */
export type Nullable<T> = T | null;

/**
 * Optional fields helper
 */
export type PartialBy<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

/**
 * Required fields helper
 */
export type RequiredBy<T, K extends keyof T> = Omit<T, K> & Required<Pick<T, K>>;

/**
 * Deep partial helper
 */
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};
