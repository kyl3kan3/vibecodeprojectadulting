export interface AdultingTip {
  id: string;
  title: string;
  description: string;
  content: {
    overview: string;
    keyPoints: string[];
    stepByStep: any[];
    tips: string[];
    resources: any[];
    commonMistakes: string[];
  };
  category: TipCategory;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: number;
  tags: string[];
  isUnlocked: boolean;
  createdAt: string;
  isCompleted: boolean;
  isBookmarked: boolean;
  rating: number;
  note: string;
  photos: string[];
}

export type TipCategory = 
  | 'finances'
  | 'health_insurance'
  | 'cooking'
  | 'laundry'
  | 'taxes'
  | 'housing'
  | 'career'
  | 'career_work'
  | 'daily_living'
  | 'personal_development'
  | 'legal'
  | 'maintenance'
  | 'social'
  | 'transportation'
  | 'technology'
  | 'fitness'
  | 'mental_health'
  | 'healthcare'
  | 'relationships'
  | 'education'
  | 'personal_care'
  | 'safety'
  | 'travel'
  | 'environment'
  | 'consumer_rights'
  | 'time_management'
  | 'communication'
  | 'nutrition'
  | 'shopping'
  | 'organization'
  | 'goal_setting'
  | 'networking'
  | 'side_hustles'
  | 'credit'
  | 'insurance'
  | 'investing';

export interface Goal {
  id: string;
  title: string;
  description: string;
  category: TipCategory;
  source: 'ai_chat' | 'tip_action' | 'manual';
  sourceId?: string; // AI message ID or tip ID
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  createdAt: string;
  completedAt?: string;
}

export interface UserProgress {
  totalXP: number;
  totalTipsCompleted: number;
  completedTips: string[];
  bookmarkedTips: string[];
  todoItems: TodoItem[];
  goals: Goal[];
  streak: number;
  streakDays: number; // Alias for streak
  lastVisit: string;
  achievements: string[]; // Array of unlocked achievement IDs
  tipRatings: Record<string, number>; // tipId -> rating (1-5)
  tipNotes?: Record<string, string>; // tipId -> note text
  tipPhotos?: Record<string, string[]>; // tipId -> local image URIs
  completedTipHistory?: { tipId: string; completedAt: string }[]; // per-completion timestamps
  preferences: {
    categories: string[];
    difficulty: 'beginner' | 'intermediate' | 'advanced';
    notifications: boolean;
    reminderTime: string;
  };
}

export interface TodoItem {
  id: string;
  title: string;
  description?: string;
  category: TipCategory;
  completed: boolean;
  dueDate?: string;
  createdAt: string;
  completedAt?: string;
}

export interface DailyTipSchedule {
  date: string;
  tipId: string;
  completed: boolean;
}

export interface NotificationSettings {
  enabled: boolean;
  time: string; // Format: "HH:mm"
  days: number[]; // 0-6, where 0 is Sunday
}

export interface AppSettings {
  notifications: NotificationSettings;
  darkMode: boolean;
  onboardingCompleted: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface HowToGuide {
  id: string;
  title: string;
  description: string;
  category: TipCategory;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: string;
  steps: HowToStep[];
  prerequisites?: string[];
  tips?: string[];
}

export interface HowToStep {
  id: string;
  title: string;
  description: string;
  image?: string;
  warning?: string;
  tip?: string;
}