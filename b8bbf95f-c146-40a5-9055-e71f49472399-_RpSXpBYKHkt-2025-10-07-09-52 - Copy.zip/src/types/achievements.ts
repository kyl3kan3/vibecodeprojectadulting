export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  bgColor: string;
  requirement: number;
  type: 'tips_completed' | 'streak_days' | 'categories_mastered' | 'todos_completed' | 'special';
  unlocked: boolean;
  unlockedAt?: string;
}

export const achievements: Achievement[] = [
  // Tips Completed
  {
    id: 'first_tip',
    title: 'First Step',
    description: 'Complete your first adulting tip',
    icon: 'checkmark-circle',
    color: 'text-green-600',
    bgColor: 'bg-green-100',
    requirement: 1,
    type: 'tips_completed',
    unlocked: false,
  },
  {
    id: 'five_tips',
    title: 'Getting Started',
    description: 'Complete 5 adulting tips',
    icon: 'trophy',
    color: 'text-orange-600',
    bgColor: 'bg-orange-100',
    requirement: 5,
    type: 'tips_completed',
    unlocked: false,
  },
  {
    id: 'ten_tips',
    title: 'Building Momentum',
    description: 'Complete 10 adulting tips',
    icon: 'medal',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
    requirement: 10,
    type: 'tips_completed',
    unlocked: false,
  },
  {
    id: 'twenty_tips',
    title: 'Adulting Pro',
    description: 'Complete 20 adulting tips',
    icon: 'star',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-100',
    requirement: 20,
    type: 'tips_completed',
    unlocked: false,
  },

  // Streak Days
  {
    id: 'three_day_streak',
    title: 'Consistent Learner',
    description: 'Maintain a 3-day learning streak',
    icon: 'flame',
    color: 'text-red-600',
    bgColor: 'bg-red-100',
    requirement: 3,
    type: 'streak_days',
    unlocked: false,
  },
  {
    id: 'week_streak',
    title: 'Week Warrior',
    description: 'Maintain a 7-day learning streak',
    icon: 'calendar',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100',
    requirement: 7,
    type: 'streak_days',
    unlocked: false,
  },
  {
    id: 'month_streak',
    title: 'Dedication Master',
    description: 'Maintain a 30-day learning streak',
    icon: 'ribbon',
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-100',
    requirement: 30,
    type: 'streak_days',
    unlocked: false,
  },

  // Categories
  {
    id: 'finance_explorer',
    title: 'Finance Explorer',
    description: 'Complete all finance tips',
    icon: 'card',
    color: 'text-green-600',
    bgColor: 'bg-green-100',
    requirement: 2, // Number of finance tips
    type: 'categories_mastered',
    unlocked: false,
  },
  {
    id: 'cooking_chef',
    title: 'Kitchen Confident',
    description: 'Complete all cooking tips',
    icon: 'restaurant',
    color: 'text-orange-600',
    bgColor: 'bg-orange-100',
    requirement: 2, // Number of cooking tips
    type: 'categories_mastered',
    unlocked: false,
  },

  // Special Achievements
  {
    id: 'early_bird',
    title: 'Early Bird',
    description: 'Complete a tip before 8 AM',
    icon: 'sunny',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-100',
    requirement: 1,
    type: 'special',
    unlocked: false,
  },
  {
    id: 'night_owl',
    title: 'Night Owl',
    description: 'Complete a tip after 10 PM',
    icon: 'moon',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
    requirement: 1,
    type: 'special',
    unlocked: false,
  },
];