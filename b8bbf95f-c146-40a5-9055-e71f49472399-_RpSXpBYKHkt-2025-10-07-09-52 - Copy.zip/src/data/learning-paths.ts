import { TipCategory } from '../types/adulting';

export interface LearningPath {
  id: string;
  title: string;
  description: string;
  category: TipCategory;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: string;
  skillIds: string[];
  prerequisites?: string[];
  icon: string;
  color: string;
}

export const learningPaths: LearningPath[] = [
  // Beginner Paths
  {
    id: 'path-financial-basics',
    title: 'Financial Foundations',
    description: 'Master the basics of money management and budgeting',
    category: 'finances',
    difficulty: 'beginner',
    estimatedTime: '2 weeks',
    skillIds: [
      'basic-financial-literacy',
      'track-spending-for-one-month',
      'zero-based-budget-in-45-minutes',
      'three-account-money-flow',
      'build-emergency-fund-starter-1000',
      'create-a-budget-friendly-meal-plan',
      'negotiate-internet-bill-15-minutes'
    ],
    icon: '💰',
    color: '#10B981'
  },
  {
    id: 'path-cooking-essentials',
    title: 'Cooking Essentials',
    description: 'Learn fundamental cooking skills and meal planning',
    category: 'cooking',
    difficulty: 'beginner',
    estimatedTime: '3 weeks',
    skillIds: [
      'master-basic-cooking-techniques',
      'knife-skills-safe-fast-consistent',
      'cook-basic-sauces-from-scratch',
      'cook-healthy-breakfast-options',
      'cook-plant-based-meals',
      'make-coffee-shop-quality-at-home',
      'master-basic-bread-making',
      'cook-international-cuisine-basics'
    ],
    icon: '🍳',
    color: '#F59E0B'
  },
  {
    id: 'path-career-starter',
    title: 'Career Kickstart',
    description: 'Build professional skills and land your first job',
    category: 'career_work',
    difficulty: 'beginner',
    estimatedTime: '4 weeks',
    skillIds: [
      'create-a-personal-brand',
      'build-a-professional-network',
      'networking-basics-for-introverts',
      'cold-outreach-that-gets-replies',
      'prepare-behavioral-interview-star-method',
      'job-interview-prep'
    ],
    icon: '🚀',
    color: '#3B82F6'
  },
  {
    id: 'path-home-basics',
    title: 'Home Life Mastery',
    description: 'Essential skills for independent living',
    category: 'daily_living',
    difficulty: 'beginner',
    estimatedTime: '3 weeks',
    skillIds: [
      'create-a-simple-morning-routine',
      'apartment-cleaning-30-minute-reset',
      'create-a-home-office',
      'basic-sewing-repairs',
      'create-a-home-emergency-kit',
      'create-a-family-emergency-plan',
      'create-a-capsule-wardrobe',
      'create-a-minimalist-home'
    ],
    icon: '🏠',
    color: '#8B5CF6'
  },

  // Intermediate Paths  
  {
    id: 'path-investment-basics',
    title: 'Investment Journey',
    description: 'Start building wealth through smart investing',
    category: 'investing',
    difficulty: 'intermediate',
    estimatedTime: '6 weeks',
    skillIds: [
      'learn-basic-investing',
      'pick-first-low-cost-index-fund',
      'rollover-old-401k-checklist'
    ],
    prerequisites: ['path-financial-basics'],
    icon: '📈',
    color: '#06B6D4'
  },
  {
    id: 'path-professional-growth',
    title: 'Professional Excellence',
    description: 'Advance your career with leadership skills',
    category: 'career_work',
    difficulty: 'intermediate', 
    estimatedTime: '8 weeks',
    skillIds: [
      'handle-conflict-at-work',
      'learn-conflict-resolution-at-work',
      'create-a-personal-development-plan',
      'build-mental-resilience',
      'develop-a-growth-mindset',
      'develop-creative-problem-solving'
    ],
    prerequisites: ['path-career-starter'],
    icon: '👔',
    color: '#6366F1'
  },
  {
    id: 'path-wellness-routine',
    title: 'Complete Wellness',
    description: 'Build sustainable health and fitness habits',
    category: 'fitness',
    difficulty: 'intermediate',
    estimatedTime: '6 weeks',
    skillIds: [
      '20-minute-total-body-routine',
      'strengthen-your-core-in-10-minutes',
      'desk-mobility-10-minute-reset',
      'create-a-home-gym',
      'learn-basic-cycling-skills'
    ],
    icon: '💪',
    color: '#EF4444'
  },

  // Advanced Paths
  {
    id: 'path-wealth-building',
    title: 'Wealth Master',
    description: 'Advanced financial strategies for long-term wealth',
    category: 'investing',
    difficulty: 'advanced',
    estimatedTime: '12 weeks',
    skillIds: [
      'learn-basic-investing',
      'pick-first-low-cost-index-fund',
      'rollover-old-401k-checklist',
      'create-a-personal-finance-plan',
      'create-a-budget-for-major-purchase',
      'create-a-family-budget'
    ],
    prerequisites: ['path-investment-basics'],
    icon: '💎',
    color: '#7C3AED'
  },
  {
    id: 'path-leadership-mastery',
    title: 'Executive Leadership',
    description: 'Develop advanced leadership and strategic thinking',
    category: 'career_work',
    difficulty: 'advanced',
    estimatedTime: '10 weeks',
    skillIds: [
      'build-resilience-after-setbacks',
      'build-effective-study-habits',
      'develop-creative-problem-solving',
      'develop-creative-writing-skills',
      'create-a-personal-website',
      'create-a-vision-board'
    ],
    prerequisites: ['path-professional-growth'],
    icon: '👑',
    color: '#EC4899'
  }
];

export const getNextRecommendedPath = (completedSkills: string[], currentPaths: string[] = []): LearningPath | null => {
  // Find paths user hasn't started
  const availablePaths = learningPaths.filter(path => !(currentPaths || []).includes(path.id));
  
  // Check prerequisites
  const eligiblePaths = availablePaths.filter(path => {
    if (!path.prerequisites) return true;
    return (path.prerequisites || []).every(prereq => (currentPaths || []).includes(prereq));
  });
  
  // Prioritize beginner paths, then by completion potential
  return eligiblePaths.sort((a, b) => {
    const difficultyOrder = { beginner: 1, intermediate: 2, advanced: 3 };
    if (difficultyOrder[a.difficulty] !== difficultyOrder[b.difficulty]) {
      return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
    }
    
    // Then by how many skills user already has completed in this path
    const aCompleted = (a.skillIds || []).filter(id => (completedSkills || []).includes(id)).length;
    const bCompleted = (b.skillIds || []).filter(id => (completedSkills || []).includes(id)).length;
    return bCompleted - aCompleted;
  })[0] || null;
};