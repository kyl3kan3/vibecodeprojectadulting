import { HowToGuide } from "../types/adulting";

// Local static dataset for v1. Future versions can load from DB.
export const HOW_TO_GUIDES: HowToGuide[] = [
  {
    id: "renters-insurance",
    title: "How to Get Renters Insurance",
    description: "Protect your belongings and liability with an affordable renters insurance policy.",
    category: "housing" as any,
    difficulty: "beginner",
    estimatedTime: "30–45 min",
    prerequisites: [
      "Know your address and unit details",
      "Estimate the value of your belongings",
      "Have payment method ready"
    ],
    tips: [
      "Bundle with auto insurance to save",
      "Inventory high‑value items with photos",
      "Choose a deductible that fits your budget"
    ],
    steps: [
      {
        id: "ri-1",
        title: "Inventory Your Belongings",
        description: "List items you would want to replace (electronics, furniture, clothing) and estimate their value.",
        tip: "Snap a few photos to document ownership."
      },
      {
        id: "ri-2",
        title: "Check Your Building Requirements",
        description: "Some landlords require minimum liability coverage (often $100k). Confirm any requirements.",
        warning: "Policies with very low liability may not meet your lease requirements."
      },
      {
        id: "ri-3",
        title: "Get 2–3 Quotes",
        description: "Compare major insurers for personal property coverage, liability, deductible, and monthly price.",
        tip: "Look for discounts (bundling, safe home, loyalty)."
      },
      {
        id: "ri-4",
        title: "Choose Coverage & Deductible",
        description: "Aim for property coverage roughly matching your inventory value; pick a deductible you can afford."
      },
      {
        id: "ri-5",
        title: "Purchase and Set Start Date",
        description: "Complete checkout and set the policy to start before or on move‑in day."
      },
      {
        id: "ri-6",
        title: "Save Your Proof of Insurance",
        description: "Download your declarations page and share with your landlord if required."
      }
    ]
  },
  {
    id: "build-credit-zero",
    title: "How to Build Credit from Zero",
    description: "Establish a strong credit history safely and steadily as a beginner.",
    category: "credit" as any,
    difficulty: "beginner",
    estimatedTime: "2–4 weeks (setup)",
    prerequisites: ["SSN/ITIN", "Checking account"],
    tips: [
      "Payment history is the most important factor",
      "Keep utilization under 10% if possible",
      "Avoid unnecessary hard inquiries"
    ],
    steps: [
      { id: "bc-1", title: "Check Your File", description: "Create accounts at annualcreditreport.com and the three bureaus to see if a file already exists." },
      { id: "bc-2", title: "Open a Starter Product", description: "Get a secured card or become an authorized user with someone who has good habits." },
      { id: "bc-3", title: "Set Up Autopay", description: "Autopay minimums to avoid missed payments while you build routines." },
      { id: "bc-4", title: "Use for Small Purchases", description: "Put 1–2 small recurring bills on the card and pay in full monthly." },
      { id: "bc-5", title: "Keep Utilization Low", description: "Aim to report less than 10% of your limit each month." },
      { id: "bc-6", title: "Monitor Scores", description: "Track progress with free tools; expect meaningful movement over 3–6 months." },
      { id: "bc-7", title: "Graduate Products", description: "After ~6–12 months of on‑time history, request unsecured or better rewards products." }
    ]
  },
  {
    id: "file-first-taxes",
    title: "How to File Your First Tax Return",
    description: "Gather documents, choose a filing method, and submit your first return with confidence.",
    category: "taxes" as any,
    difficulty: "beginner",
    estimatedTime: "1–2 hours",
    prerequisites: ["W‑2 or 1099 forms", "Social Security Number"],
    tips: ["E‑file for faster refunds", "Keep PDFs of everything"],
    steps: [
      { id: "tx-1", title: "Collect Documents", description: "Get W‑2s, 1099s, interest statements, tuition forms, and last year’s return if any." },
      { id: "tx-2", title: "Create an IRS Account", description: "Optional but helpful to view transcripts and track refunds." },
      { id: "tx-3", title: "Choose Filing Method", description: "Use reputable software, a VITA site (free), or a paid preparer if complex." },
      { id: "tx-4", title: "Enter Information Carefully", description: "Follow prompts; double‑check names, SSN, and totals." },
      { id: "tx-5", title: "Claim Credits & Deductions", description: "Standard deduction vs itemizing; education and saver’s credits may apply." },
      { id: "tx-6", title: "Review & E‑file", description: "Fix errors and e‑file. Choose direct deposit for refunds." },
      { id: "tx-7", title: "Save a Copy", description: "Save a PDF of your return and confirmations in a safe folder." }
    ]
  },
  {
    id: "negotiate-first-salary",
    title: "How to Negotiate Your First Salary",
    description: "Research, prepare your case, and negotiate professionally to maximize your offer.",
    category: "career" as any,
    difficulty: "intermediate",
    estimatedTime: "60–90 min prep",
    prerequisites: ["Offer details", "Role responsibilities"],
    tips: ["Negotiate total comp, not just base", "Practice scripts aloud"],
    steps: [
      { id: "ns-1", title: "Research Market Rates", description: "Use multiple sources (Glassdoor, Levels, HR data) for your location and level." },
      { id: "ns-2", title: "Document Your Value", description: "List achievements, internships, projects, and measurable impact." },
      { id: "ns-3", title: "Plan Your Ask", description: "Define target and walk‑away numbers; include base, bonus, equity, and start date." },
      { id: "ns-4", title: "Practice Your Script", description: "Role‑play with a friend to build confidence and clarity." },
      { id: "ns-5", title: "Run the Conversation", description: "Be appreciative, specific, and data‑backed. Pause after you ask." },
      { id: "ns-6", title: "Evaluate Counter", description: "Compare to targets; ask clarifying questions; request time if needed." },
      { id: "ns-7", title: "Confirm in Writing", description: "Summarize the final agreement via email before signing." }
    ]
  },
  {
    id: "first-budget-setup",
    title: "How to Set Up Your First Budget",
    description: "Create a simple, realistic budget using the 50/30/20 approach and basic tracking.",
    category: "finances",
    difficulty: "beginner",
    estimatedTime: "45–60 min",
    prerequisites: ["List of income sources", "Recent bank statements"],
    tips: ["Automate transfers on payday", "Review monthly and adjust"],
    steps: [
      { id: "bd-1", title: "Calculate Monthly Income", description: "Use take‑home pay after taxes and deductions." },
      { id: "bd-2", title: "List Fixed Essentials", description: "Rent, utilities, transit, insurance; total these costs." },
      { id: "bd-3", title: "Set 50/30/20 Targets", description: "50% needs, 30% wants, 20% savings/debt as a starting point." },
      { id: "bd-4", title: "Pick a Tracking Method", description: "Spreadsheet, bank app, or budgeting app—keep it simple." },
      { id: "bd-5", title: "Automate Savings", description: "Set recurring transfers to savings or debt on payday." },
      { id: "bd-6", title: "Do Week 1 Review", description: "Check spending vs plan; adjust targets if unrealistic." },
      { id: "bd-7", title: "Monthly Tune‑Up", description: "Repeat reviews; celebrate wins and iterate." }
    ]
  },
  {
    id: "meal-prep-like-pro",
    title: "How to Meal Prep Like a Pro",
    description: "Plan, shop, cook, and store efficiently so you always have healthy meals ready.",
    category: "cooking",
    difficulty: "beginner",
    estimatedTime: "60–120 min",
    prerequisites: ["Pantry basics", "Food containers"],
    tips: ["Start with 2 recipes you enjoy", "Label and date your containers"],
    steps: [
      { id: "mp-1", title: "Pick 2–3 Recipes", description: "Choose simple dishes that share ingredients to save money." },
      { id: "mp-2", title: "Make a Shopping List", description: "Group by store section; check your pantry first." },
      { id: "mp-3", title: "Batch Cook", description: "Cook proteins, grains, and veggies in larger quantities." },
      { id: "mp-4", title: "Portion & Label", description: "Divide into containers; add dates and reheating notes." },
      { id: "mp-5", title: "Store Safely", description: "Cool quickly; refrigerate 3–4 days, freeze longer." },
      { id: "mp-6", title: "Plan Reheats", description: "Rotate meals; add fresh toppings to keep variety." },
      { id: "mp-7", title: "Weekly Review", description: "Note what worked; update your base recipes for next week." }
    ]
  }
];

export type { HowToGuide };
