/**
 * Authentication Security Utilities
 * 
 * Provides security measures for persistent authentication including:
 * - Session fingerprinting and validation
 * - Automatic cleanup of expired sessions
 * - Suspicious activity detection
 * - Security event logging
 */

import { useAuthStore, getSessionInfo } from '../state/auth-store';
import { supabaseMCP } from '../lib/supabase-mcp';

export interface SecurityEvent {
  timestamp: number;
  type: 'validation_failure' | 'session_expired' | 'suspicious_activity' | 'forced_logout';
  details: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface SecurityConfig {
  maxFailedValidations: number;
  suspiciousActivityThreshold: number;
  autoCleanupEnabled: boolean;
  securityLoggingEnabled: boolean;
}

class AuthSecurityManager {
  private securityEvents: SecurityEvent[] = [];
  private failureCount = 0;
  private maxEvents = 100;
  
  private config: SecurityConfig = {
    maxFailedValidations: 10, // Increased from 3 to 10 to be less aggressive
    suspiciousActivityThreshold: 20, // Increased from 5 to 20
    autoCleanupEnabled: true,
    securityLoggingEnabled: __DEV__
  };

  /**
   * Record a security event
   */
  recordSecurityEvent(event: Omit<SecurityEvent, 'timestamp'>) {
    const securityEvent: SecurityEvent = {
      ...event,
      timestamp: Date.now()
    };

    this.securityEvents.unshift(securityEvent);
    
    // Keep events within limit
    if (this.securityEvents.length > this.maxEvents) {
      this.securityEvents = this.securityEvents.slice(0, this.maxEvents);
    }

    if (this.config.securityLoggingEnabled) {
      if (__DEV__) console.log('[AuthSecurity] Security event recorded:', securityEvent);
    }

    // Handle critical events
    if (event.severity === 'critical') {
      this.handleCriticalEvent(securityEvent);
    }
  }

  /**
   * Validate session integrity and security
   */
  async validateSessionSecurity(): Promise<{
    isValid: boolean;
    issues: string[];
    shouldClearAuth: boolean;
  }> {
    const issues: string[] = [];
    let shouldClearAuth = false;

    try {
      const sessionInfo = getSessionInfo();
      
      // Check if session is expired
      if (sessionInfo.isExpired) {
        issues.push('Session has expired');
        shouldClearAuth = true;
        
        this.recordSecurityEvent({
          type: 'session_expired',
          details: `Session expired after ${sessionInfo.sessionAge}ms`,
          severity: 'medium'
        });
      }

      // Check for suspicious activity patterns
      const recentFailures = this.getRecentEvents('validation_failure', 3600000); // Last hour
      if (recentFailures.length >= this.config.suspiciousActivityThreshold) {
        issues.push('Suspicious validation failure pattern detected');
        shouldClearAuth = true;
        
        this.recordSecurityEvent({
          type: 'suspicious_activity',
          details: `${recentFailures.length} validation failures in the last hour`,
          severity: 'high'
        });
      }

      // Validate token format and structure
      const authStore = useAuthStore.getState();
      if (authStore.token) {
        if (!this.isValidTokenFormat(authStore.token)) {
          issues.push('Invalid token format detected');
          shouldClearAuth = true;
          
          this.recordSecurityEvent({
            type: 'suspicious_activity',
            details: 'Token format validation failed',
            severity: 'high'
          });
        }
      }

      // Check consecutive validation failures
      if (this.failureCount >= this.config.maxFailedValidations) {
        issues.push(`Maximum validation failures (${this.config.maxFailedValidations}) exceeded`);
        shouldClearAuth = true;
        
        this.recordSecurityEvent({
          type: 'forced_logout',
          details: `Forced logout after ${this.failureCount} consecutive failures`,
          severity: 'critical'
        });
      }

      return {
        isValid: issues.length === 0,
        issues,
        shouldClearAuth
      };

    } catch (error: any) {
      this.recordSecurityEvent({
        type: 'validation_failure',
        details: `Security validation error: ${error.message}`,
        severity: 'high'
      });

      return {
        isValid: false,
        issues: [`Security validation failed: ${error.message}`],
        shouldClearAuth: true
      };
    }
  }

  /**
   * Record a validation failure
   */
  recordValidationFailure(details: string) {
    this.failureCount++;
    
    this.recordSecurityEvent({
      type: 'validation_failure',
      details,
      severity: this.failureCount >= this.config.maxFailedValidations ? 'critical' : 'medium'
    });

    if (__DEV__) {
      if (__DEV__) console.warn(`[AuthSecurity] Validation failure ${this.failureCount}/${this.config.maxFailedValidations}: ${details}`);
    }
  }

  /**
   * Reset failure count (on successful validation)
   */
  resetFailureCount() {
    if (this.failureCount > 0) {
      if (__DEV__) {
        if (__DEV__) console.log(`[AuthSecurity] Resetting failure count (was ${this.failureCount})`);
      }
      this.failureCount = 0;
    }
  }

  /**
   * Perform automatic cleanup of expired/invalid sessions
   */
  async performAutoCleanup(): Promise<{
    cleaned: boolean;
    reason?: string;
  }> {
    if (!this.config.autoCleanupEnabled) {
      return { cleaned: false };
    }

    try {
      const validation = await this.validateSessionSecurity();
      
      if (validation.shouldClearAuth) {
        const authStore = useAuthStore.getState();
        authStore.clearAuth();
        
        // Clear memory session as well
        supabaseMCP.setToken(null);
        (global as any).__AUTH_USER__ = null;
        
        if (__DEV__) {
          if (__DEV__) console.log('[AuthSecurity] Auto-cleanup performed:', validation.issues);
        }

        return {
          cleaned: true,
          reason: validation.issues.join(', ')
        };
      }

      return { cleaned: false };

    } catch (error: any) {
      this.recordSecurityEvent({
        type: 'validation_failure',
        details: `Auto-cleanup failed: ${error.message}`,
        severity: 'medium'
      });

      return { cleaned: false, reason: error.message };
    }
  }

  /**
   * Handle critical security events
   */
  private handleCriticalEvent(event: SecurityEvent) {
    if (__DEV__) {
      if (__DEV__) console.error('[AuthSecurity] CRITICAL SECURITY EVENT:', event);
    }

    // For critical events, immediately clear auth
    const authStore = useAuthStore.getState();
    authStore.clearAuth();
    supabaseMCP.setToken(null);
    (global as any).__AUTH_USER__ = null;
  }

  /**
   * Get recent security events
   */
  private getRecentEvents(type?: SecurityEvent['type'], timeWindowMs: number = 3600000): SecurityEvent[] {
    const cutoff = Date.now() - timeWindowMs;
    return this.securityEvents.filter(event => 
      event.timestamp > cutoff && (!type || event.type === type)
    );
  }

  /**
   * Validate token format
   */
  private isValidTokenFormat(token: string): boolean {
    // Basic JWT format validation
    if (!token || typeof token !== 'string') return false;
    
    // Should have 3 parts separated by dots
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    
    // Each part should be base64-ish (allowing URL-safe base64)
    const base64Regex = /^[A-Za-z0-9_-]+$/;
    return parts.every(part => part.length > 0 && base64Regex.test(part));
  }

  /**
   * Get security summary
   */
  getSecuritySummary() {
    const recentEvents = this.getRecentEvents(undefined, 86400000); // Last 24 hours
    const criticalEvents = recentEvents.filter(e => e.severity === 'critical');
    const highEvents = recentEvents.filter(e => e.severity === 'high');

    return {
      failureCount: this.failureCount,
      maxFailures: this.config.maxFailedValidations,
      recentEventsCount: recentEvents.length,
      criticalEventsCount: criticalEvents.length,
      highEventsCount: highEvents.length,
      isSecure: criticalEvents.length === 0 && this.failureCount < this.config.maxFailedValidations,
      autoCleanupEnabled: this.config.autoCleanupEnabled,
      lastEvent: this.securityEvents[0] || null
    };
  }

  /**
   * Get security events for debugging
   */
  getSecurityEvents(limit: number = 20): SecurityEvent[] {
    return this.securityEvents.slice(0, limit);
  }

  /**
   * Clear security events and reset counters
   */
  clearSecurityData() {
    this.securityEvents = [];
    this.failureCount = 0;
    
    if (__DEV__) {
      if (__DEV__) console.log('[AuthSecurity] Security data cleared');
    }
  }

  /**
   * Update security configuration
   */
  updateConfig(config: Partial<SecurityConfig>) {
    this.config = { ...this.config, ...config };
    
    if (__DEV__) {
      if (__DEV__) console.log('[AuthSecurity] Configuration updated:', this.config);
    }
  }
}

// Export singleton instance
export const authSecurityManager = new AuthSecurityManager();