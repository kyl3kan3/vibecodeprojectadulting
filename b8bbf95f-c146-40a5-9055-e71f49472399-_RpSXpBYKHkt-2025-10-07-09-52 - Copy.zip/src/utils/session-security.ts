/**
 * Session Security Utilities
 * 
 * Provides advanced security features for session management:
 * - Token validation and integrity checking
 * - Session timeout management
 * - Suspicious activity detection
 * - Security event logging
 * - Session fingerprinting
 */

import { sessionAnalytics, trackHealthAlert } from './session-analytics';
import { supabaseMCP } from '../lib/supabase-mcp';

export interface SessionSecurityConfig {
  maxSessionAge: number; // milliseconds
  tokenValidationInterval: number; // milliseconds
  maxConsecutiveFailures: number;
  enableFingerprintValidation: boolean;
  enableTimeoutWarnings: boolean;
  suspiciousActivityThreshold: number;
}

export interface SecurityAlert {
  id: string;
  type: 'token_invalid' | 'session_expired' | 'suspicious_activity' | 'security_breach' | 'timeout_warning';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  metadata?: Record<string, any>;
}

export interface SessionFingerprint {
  userAgent: string;
  platform: string;
  screenDimensions: string;
  timezone: string;
  language: string;
  timestamp: number;
}

export interface SecurityAuditLog {
  sessionId: string;
  events: SecurityAlert[];
  riskScore: number;
  lastAudit: number;
  recommendations: string[];
}

class SessionSecurityManager {
  private config: SessionSecurityConfig = {
    maxSessionAge: 24 * 60 * 60 * 1000, // 24 hours
    tokenValidationInterval: 5 * 60 * 1000, // 5 minutes
    maxConsecutiveFailures: 3,
    enableFingerprintValidation: false, // Disabled by default for simplicity
    enableTimeoutWarnings: true,
    suspiciousActivityThreshold: 5
  };

  private alerts: SecurityAlert[] = [];
  private maxStoredAlerts: number = 100;
  private validationInterval: NodeJS.Timeout | null = null;
  private sessionStartFingerprint: SessionFingerprint | null = null;
  private consecutiveFailures: number = 0;
  private lastValidationTime: number = 0;

  /**
   * Initialize security monitoring
   */
  initialize(): void {
    if (this.validationInterval) {
      clearInterval(this.validationInterval);
    }

    // Capture initial session fingerprint
    this.captureSessionFingerprint();

    // Start periodic validation
    this.validationInterval = setInterval(() => {
      this.performSecurityValidation();
    }, this.config.tokenValidationInterval);

    // Initial validation
    this.performSecurityValidation();

    if (__DEV__) {
      if (__DEV__) console.log('[SessionSecurity] Security monitoring initialized');
    }
  }

  /**
   * Cleanup security monitoring
   */
  cleanup(): void {
    if (this.validationInterval) {
      clearInterval(this.validationInterval);
      this.validationInterval = null;
    }

    if (__DEV__) {
      if (__DEV__) console.log('[SessionSecurity] Security monitoring cleaned up');
    }
  }

  /**
   * Update security configuration
   */
  updateConfig(newConfig: Partial<SessionSecurityConfig>): void {
    this.config = { ...this.config, ...newConfig };
    
    // Restart monitoring with new config
    if (this.validationInterval) {
      this.cleanup();
      this.initialize();
    }

    if (__DEV__) {
      if (__DEV__) console.log('[SessionSecurity] Configuration updated:', this.config);
    }
  }

  /**
   * Perform comprehensive security validation
   */
  private async performSecurityValidation(): Promise<void> {
    const now = Date.now();
    this.lastValidationTime = now;

    try {
      // Check session age
      this.validateSessionAge();

      // Validate token integrity
      await this.validateTokenIntegrity();

      // Check for suspicious activity
      this.detectSuspiciousActivity();

      // Validate session fingerprint (if enabled)
      if (this.config.enableFingerprintValidation) {
        this.validateSessionFingerprint();
      }

      // Check for timeout warnings
      if (this.config.enableTimeoutWarnings) {
        this.checkTimeoutWarnings();
      }

      // Reset failure count on successful validation
      this.consecutiveFailures = 0;

    } catch (error: any) {
      this.consecutiveFailures++;
      
      this.addSecurityAlert({
        type: 'security_breach',
        severity: 'high',
        message: `Security validation failed: ${error.message}`,
        metadata: { 
          consecutiveFailures: this.consecutiveFailures,
          error: error.message 
        }
      });

      // Escalate if too many consecutive failures
      if (this.consecutiveFailures >= this.config.maxConsecutiveFailures) {
        this.escalateSecurityBreach();
      }
    }
  }

  /**
   * Validate session age and token expiry
   */
  private validateSessionAge(): void {
    const currentSession = sessionAnalytics.getCurrentSession();
    
    if (currentSession.duration && currentSession.duration > this.config.maxSessionAge) {
      this.addSecurityAlert({
        type: 'session_expired',
        severity: 'medium',
        message: 'Session has exceeded maximum age limit',
        metadata: { 
          sessionAge: currentSession.duration,
          maxAge: this.config.maxSessionAge
        }
      });
    }
  }

  /**
   * Validate token integrity and format
   */
  private async validateTokenIntegrity(): Promise<void> {
    const token = (global as any).__AUTH_TOKEN__;
    
    if (!token) {
      this.addSecurityAlert({
        type: 'token_invalid',
        severity: 'critical',
        message: 'Session token is missing',
        metadata: { reason: 'token_missing' }
      });
      return;
    }

    // Basic token format validation
    if (typeof token !== 'string' || token.length < 100 || !token.includes('.')) {
      this.addSecurityAlert({
        type: 'token_invalid',
        severity: 'high',
        message: 'Session token format appears invalid',
        metadata: { 
          tokenLength: token.length,
          hasSegments: token.includes('.'),
          reason: 'format_invalid'
        }
      });
      return;
    }

    // Test token with backend
    try {
      const sessionResult = await supabaseMCP.authGetSession();
      if (!sessionResult || !sessionResult.user) {
        this.addSecurityAlert({
          type: 'token_invalid',
          severity: 'high',
          message: 'Token validation failed with backend',
          metadata: { reason: 'backend_validation_failed' }
        });
      }
    } catch (error: any) {
      this.addSecurityAlert({
        type: 'token_invalid',
        severity: 'medium',
        message: 'Token validation network error',
        metadata: { 
          error: error.message,
          reason: 'network_error'
        }
      });
    }
  }

  /**
   * Detect suspicious activity patterns
   */
  private detectSuspiciousActivity(): void {
    const recentEvents = sessionAnalytics.getRecentEvents(20);
    const now = Date.now();
    const fiveMinutesAgo = now - (5 * 60 * 1000);
    
    // Count rapid events in last 5 minutes
    const rapidEvents = recentEvents.filter(event => 
      event.timestamp > fiveMinutesAgo &&
      (event.type === 'recovery_attempt' || event.type === 'health_alert')
    );

    if (rapidEvents.length > this.config.suspiciousActivityThreshold) {
      this.addSecurityAlert({
        type: 'suspicious_activity',
        severity: 'medium',
        message: 'Unusual number of recovery attempts or health alerts detected',
        metadata: { 
          eventCount: rapidEvents.length,
          threshold: this.config.suspiciousActivityThreshold,
          timeWindow: '5 minutes'
        }
      });
    }

    // Check for rapid authentication attempts
    const authEvents = recentEvents.filter(event => 
      event.timestamp > fiveMinutesAgo &&
      event.type === 'login'
    );

    if (authEvents.length > 3) {
      this.addSecurityAlert({
        type: 'suspicious_activity',
        severity: 'high',
        message: 'Multiple login attempts detected in short timeframe',
        metadata: { 
          loginAttempts: authEvents.length,
          timeWindow: '5 minutes'
        }
      });
    }
  }

  /**
   * Capture session fingerprint for validation
   */
  private captureSessionFingerprint(): void {
    try {
      // In React Native, we have limited fingerprinting options
      const fingerprint: SessionFingerprint = {
        userAgent: 'react-native', // Static in RN
        platform: require('react-native').Platform.OS,
        screenDimensions: `${require('react-native').Dimensions.get('window').width}x${require('react-native').Dimensions.get('window').height}`,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: require('react-native').NativeModules?.SettingsManager?.settings?.AppleLanguages?.[0] || 'en',
        timestamp: Date.now()
      };

      this.sessionStartFingerprint = fingerprint;

      if (__DEV__) {
        if (__DEV__) console.log('[SessionSecurity] Session fingerprint captured:', fingerprint);
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionSecurity] Failed to capture fingerprint:', error);
      }
    }
  }

  /**
   * Validate current session fingerprint against initial
   */
  private validateSessionFingerprint(): void {
    if (!this.sessionStartFingerprint) return;

    try {
      const currentFingerprint: SessionFingerprint = {
        userAgent: 'react-native',
        platform: require('react-native').Platform.OS,
        screenDimensions: `${require('react-native').Dimensions.get('window').width}x${require('react-native').Dimensions.get('window').height}`,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        language: require('react-native').NativeModules?.SettingsManager?.settings?.AppleLanguages?.[0] || 'en',
        timestamp: Date.now()
      };

      // Check for significant changes
      const changes: string[] = [];
      
      if (currentFingerprint.platform !== this.sessionStartFingerprint.platform) {
        changes.push('platform');
      }
      
      if (currentFingerprint.timezone !== this.sessionStartFingerprint.timezone) {
        changes.push('timezone');
      }

      if (changes.length > 0) {
        this.addSecurityAlert({
          type: 'suspicious_activity',
          severity: 'medium',
          message: 'Session fingerprint has changed during session',
          metadata: { 
            changes,
            originalFingerprint: this.sessionStartFingerprint,
            currentFingerprint
          }
        });
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionSecurity] Fingerprint validation error:', error);
      }
    }
  }

  /**
   * Check for session timeout warnings
   */
  private checkTimeoutWarnings(): void {
    const currentSession = sessionAnalytics.getCurrentSession();
    
    if (currentSession.duration) {
      const warningThreshold = this.config.maxSessionAge * 0.8; // 80% of max age
      
      if (currentSession.duration > warningThreshold && currentSession.duration < this.config.maxSessionAge) {
        this.addSecurityAlert({
          type: 'timeout_warning',
          severity: 'low',
          message: 'Session approaching timeout limit',
          metadata: { 
            sessionAge: currentSession.duration,
            timeRemaining: this.config.maxSessionAge - currentSession.duration,
            warningThreshold
          }
        });
      }
    }
  }

  /**
   * Add security alert
   */
  private addSecurityAlert(alertData: Omit<SecurityAlert, 'id' | 'timestamp'>): void {
    const alert: SecurityAlert = {
      ...alertData,
      id: `security_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      timestamp: Date.now()
    };

    this.alerts.unshift(alert);

    // Limit stored alerts
    if (this.alerts.length > this.maxStoredAlerts) {
      this.alerts = this.alerts.slice(0, this.maxStoredAlerts);
    }

    // Track in analytics system
    trackHealthAlert(alert.type, alert.message);

    if (__DEV__) {
      if (__DEV__) console.log(`[SessionSecurity] ${alert.severity.toUpperCase()}: ${alert.message}`, alert.metadata);
    }
  }

  /**
   * Escalate security breach
   */
  private escalateSecurityBreach(): void {
    this.addSecurityAlert({
      type: 'security_breach',
      severity: 'critical',
      message: `Critical: ${this.consecutiveFailures} consecutive security validation failures`,
      metadata: { 
        consecutiveFailures: this.consecutiveFailures,
        maxFailures: this.config.maxConsecutiveFailures,
        action: 'escalation_triggered'
      }
    });

    // Could trigger additional actions like forcing logout, notifying backend, etc.
    if (__DEV__) {
      if (__DEV__) console.error('[SessionSecurity] CRITICAL: Security breach escalation triggered');
    }
  }

  /**
   * Get security alerts
   */
  getAlerts(limit?: number): SecurityAlert[] {
    return limit ? this.alerts.slice(0, limit) : this.alerts;
  }

  /**
   * Get security alerts by severity
   */
  getAlertsBySeverity(severity: SecurityAlert['severity']): SecurityAlert[] {
    return this.alerts.filter(alert => alert.severity === severity);
  }

  /**
   * Get current security status
   */
  getSecurityStatus(): {
    isSecure: boolean;
    riskScore: number;
    activeThreats: number;
    lastValidation: number;
    recommendations: string[];
  } {
    const criticalAlerts = this.getAlertsBySeverity('critical').length;
    const highAlerts = this.getAlertsBySeverity('high').length;
    const mediumAlerts = this.getAlertsBySeverity('medium').length;

    // Calculate risk score (0-100)
    const riskScore = Math.min(100, 
      (criticalAlerts * 40) + 
      (highAlerts * 20) + 
      (mediumAlerts * 10) + 
      (this.consecutiveFailures * 15)
    );

    const isSecure = riskScore < 30 && criticalAlerts === 0;
    const activeThreats = criticalAlerts + highAlerts;

    const recommendations: string[] = [];
    if (criticalAlerts > 0) {
      recommendations.push('Immediate attention required for critical security alerts');
    }
    if (this.consecutiveFailures > 0) {
      recommendations.push('Review recent validation failures');
    }
    if (riskScore > 50) {
      recommendations.push('Consider refreshing session or re-authentication');
    }

    return {
      isSecure,
      riskScore,
      activeThreats,
      lastValidation: this.lastValidationTime,
      recommendations
    };
  }

  /**
   * Generate security audit report
   */
  generateSecurityAudit(): SecurityAuditLog {
    const currentSession = sessionAnalytics.getCurrentSession();
    const status = this.getSecurityStatus();

    return {
      sessionId: currentSession.id || 'unknown',
      events: this.alerts,
      riskScore: status.riskScore,
      lastAudit: Date.now(),
      recommendations: status.recommendations
    };
  }

  /**
   * Clear security alerts
   */
  clearAlerts(severity?: SecurityAlert['severity']): void {
    if (severity) {
      this.alerts = this.alerts.filter(alert => alert.severity !== severity);
    } else {
      this.alerts = [];
    }

    if (__DEV__) {
      if (__DEV__) console.log(`[SessionSecurity] Cleared ${severity || 'all'} security alerts`);
    }
  }

  /**
   * Get current configuration
   */
  getConfig(): SessionSecurityConfig {
    return { ...this.config };
  }
}

// Export singleton instance
export const sessionSecurity = new SessionSecurityManager();

// Convenience functions
export const initializeSessionSecurity = () => sessionSecurity.initialize();
export const getSecurityStatus = () => sessionSecurity.getSecurityStatus();
export const getSecurityAlerts = (limit?: number) => sessionSecurity.getAlerts(limit);
export const generateSecurityAudit = () => sessionSecurity.generateSecurityAudit();
export const clearSecurityAlerts = (severity?: SecurityAlert['severity']) => 
  sessionSecurity.clearAlerts(severity);