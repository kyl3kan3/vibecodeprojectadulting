// Real-time session health monitoring and alerts
import { supabaseMCP } from '../lib/supabase-mcp';
import { trackHealthAlert, trackSessionCheck } from './session-analytics';

export interface SessionHealthStatus {
  isHealthy: boolean;
  lastCheck: number;
  consecutiveFailures: number;
  issues: string[];
  uptime: number;
}

export interface SessionAlert {
  type: 'warning' | 'error' | 'info';
  message: string;
  timestamp: number;
  data?: any;
}

class SessionMonitor {
  private healthStatus: SessionHealthStatus = {
    isHealthy: true,
    lastCheck: 0,
    consecutiveFailures: 0,
    issues: [],
    uptime: Date.now()
  };
  
  private alerts: SessionAlert[] = [];
  private listeners: Set<(status: SessionHealthStatus) => void> = new Set();
  private alertListeners: Set<(alert: SessionAlert) => void> = new Set();
  private monitoringInterval: NodeJS.Timeout | null = null;
  
  private readonly CHECK_INTERVAL_MS = 30000; // 30 seconds
  private readonly MAX_STORED_ALERTS = 50;
  private readonly FAILURE_THRESHOLD = 3;

  start() {
    if (this.monitoringInterval) return;
    
    if (__DEV__) console.log('[SessionMonitor] Starting session health monitoring');
    
    this.monitoringInterval = setInterval(() => {
      this.performHealthCheck();
    }, this.CHECK_INTERVAL_MS);
    
    // Perform initial check
    this.performHealthCheck();
  }

  stop() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      if (__DEV__) console.log('[SessionMonitor] Stopped session health monitoring');
    }
  }

  private async performHealthCheck() {
    const startTime = Date.now();
    const issues: string[] = [];
    
    try {
      // Performance optimization: Skip health check if no session exists
      const token = (global as any).__AUTH_TOKEN__;
      const user = (global as any).__AUTH_USER__;
      
      if (!token && !user) {
        // No session to monitor - skip expensive checks
        const wasHealthy = this.healthStatus.isHealthy;
        this.healthStatus = {
          isHealthy: true,
          lastCheck: startTime,
          consecutiveFailures: 0,
          issues: [],
          uptime: this.healthStatus.uptime
        };
        
        if (!wasHealthy) {
          this.addAlert('info', 'No session to monitor - health restored');
        }
        
        this.notifyHealthListeners();
        trackSessionCheck(true, []);
        return;
      }
      
      // Check memory state consistency
      const proxyToken = (supabaseMCP as any).token;
      
      if (!token) {
        issues.push('No auth token in memory');
      }
      
      if (!user) {
        issues.push('No user data in memory');
      }
      
      if (token !== proxyToken) {
        issues.push('Token mismatch between memory and proxy client');
      }
      
      // Test session validity
      try {
        const session = await supabaseMCP.authGetSession();
        if (!session) {
          issues.push('Session validation returned null');
        } else if (!session.token || !session.user) {
          issues.push('Session missing required data');
        }
      } catch (error: any) {
        issues.push(`Session validation failed: ${error.message}`);
      }
      
      // Update health status
      const wasHealthy = this.healthStatus.isHealthy;
      this.healthStatus = {
        isHealthy: issues.length === 0,
        lastCheck: startTime,
        consecutiveFailures: issues.length > 0 ? this.healthStatus.consecutiveFailures + 1 : 0,
        issues,
        uptime: this.healthStatus.uptime
      };
      
      // Generate alerts for status changes
      if (wasHealthy && !this.healthStatus.isHealthy) {
        this.addAlert('warning', 'Session health degraded', { issues });
      } else if (!wasHealthy && this.healthStatus.isHealthy) {
        this.addAlert('info', 'Session health restored');
      }
      
      // Generate alert for sustained failures
      if (this.healthStatus.consecutiveFailures >= this.FAILURE_THRESHOLD) {
        this.addAlert('error', `Session unhealthy for ${this.healthStatus.consecutiveFailures} consecutive checks`, {
          issues,
          consecutiveFailures: this.healthStatus.consecutiveFailures
        });
      }
      
      // Notify listeners
      this.notifyHealthListeners();
      
      // Track health check in analytics
      trackSessionCheck(this.healthStatus.isHealthy, issues);
      
    } catch (error: any) {
      if (__DEV__) console.warn('[SessionMonitor] Health check failed:', error);
      this.addAlert('error', 'Session monitor check failed', { error: error.message });
    }
  }
  
  private addAlert(type: SessionAlert['type'], message: string, data?: any) {
    const alert: SessionAlert = {
      type,
      message,
      timestamp: Date.now(),
      data
    };
    
    this.alerts.unshift(alert);
    
    // Limit stored alerts
    if (this.alerts.length > this.MAX_STORED_ALERTS) {
      this.alerts = this.alerts.slice(0, this.MAX_STORED_ALERTS);
    }
    
    // Track alert in analytics
    trackHealthAlert(type, message);
    
    if (__DEV__) console.log(`[SessionMonitor] Alert [${type.toUpperCase()}]:`, message, data);
    
    // Notify alert listeners
    this.alertListeners.forEach(listener => {
      try {
        listener(alert);
      } catch (error) {
        if (__DEV__) console.warn('[SessionMonitor] Alert listener error:', error);
      }
    });
  }
  
  private notifyHealthListeners() {
    this.listeners.forEach(listener => {
      try {
        listener(this.healthStatus);
      } catch (error) {
        if (__DEV__) console.warn('[SessionMonitor] Health listener error:', error);
      }
    });
  }

  // Public API
  getHealthStatus(): SessionHealthStatus {
    return { ...this.healthStatus };
  }
  
  getAlerts(): SessionAlert[] {
    return [...this.alerts];
  }
  
  getRecentAlerts(minutes: number = 5): SessionAlert[] {
    const cutoff = Date.now() - (minutes * 60 * 1000);
    return this.alerts.filter(alert => alert.timestamp > cutoff);
  }
  
  onHealthChange(listener: (status: SessionHealthStatus) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  
  onAlert(listener: (alert: SessionAlert) => void): () => void {
    this.alertListeners.add(listener);
    return () => this.alertListeners.delete(listener);
  }
  
  clearAlerts() {
    this.alerts = [];
    if (__DEV__) console.log('[SessionMonitor] Alerts cleared');
  }
  
  forceHealthCheck() {
    if (__DEV__) console.log('[SessionMonitor] Forcing health check');
    this.performHealthCheck();
  }
}

// Export singleton instance
export const sessionMonitor = new SessionMonitor();