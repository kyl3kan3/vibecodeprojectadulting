/**
 * Optional Session Persistence Utilities
 * 
 * Provides optional session persistence features for user convenience:
 * - Secure token storage with encryption
 * - Session restore on app restart
 * - User preference management
 * - Automatic cleanup on logout
 * - Session backup and recovery
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { sessionAnalytics, trackLogin } from './session-analytics';
import { supabaseMCP } from '../lib/supabase-mcp';

export interface PersistenceConfig {
  enabled: boolean;
  encryptionEnabled: boolean;
  maxSessionAge: number; // milliseconds
  autoCleanup: boolean;
  backupEnabled: boolean;
}

export interface PersistedSession {
  token: string;
  user: {
    id: string;
    email?: string;
  };
  timestamp: number;
  expiresAt: number;
  fingerprint?: string;
  encrypted?: boolean;
}

export interface SessionBackup {
  sessions: PersistedSession[];
  analytics: any;
  timestamp: number;
  version: string;
}

class SessionPersistenceManager {
  private config: PersistenceConfig = {
    enabled: false, // Disabled by default to maintain security
    encryptionEnabled: true,
    maxSessionAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    autoCleanup: true,
    backupEnabled: false
  };

  private readonly STORAGE_KEY = '@session_persistence';
  private readonly CONFIG_KEY = '@session_persistence_config';
  private readonly BACKUP_KEY = '@session_backup';

  /**
   * Initialize persistence manager and load config
   */
  async initialize(): Promise<void> {
    try {
      await this.loadConfig();
      
      if (this.config.autoCleanup) {
        await this.cleanupExpiredSessions();
      }

      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Initialized with config:', this.config);
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPersistence] Failed to initialize:', error);
      }
    }
  }

  /**
   * Update persistence configuration
   */
  async updateConfig(newConfig: Partial<PersistenceConfig>): Promise<void> {
    this.config = { ...this.config, ...newConfig };
    
    try {
      await AsyncStorage.setItem(this.CONFIG_KEY, JSON.stringify(this.config));
      
      // If persistence is disabled, clear stored sessions
      if (!this.config.enabled) {
        await this.clearAllSessions();
      }

      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Config updated:', this.config);
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to update config:', error);
      }
      throw error;
    }
  }

  /**
   * Save current session to persistent storage
   */
  async saveSession(token: string, user: { id: string; email?: string }): Promise<boolean> {
    if (!this.config.enabled) {
      return false;
    }

    try {
      const session: PersistedSession = {
        token: this.config.encryptionEnabled ? await this.encryptData(token) : token,
        user,
        timestamp: Date.now(),
        expiresAt: Date.now() + this.config.maxSessionAge,
        fingerprint: await this.generateFingerprint(),
        encrypted: this.config.encryptionEnabled
      };

      const existingSessions = await this.getStoredSessions();
      
      // Remove any existing session for this user
      const filteredSessions = existingSessions.filter(s => s.user.id !== user.id);
      
      // Add new session
      filteredSessions.unshift(session);
      
      // Keep only the most recent 3 sessions
      const sessionsToStore = filteredSessions.slice(0, 3);
      
      await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(sessionsToStore));
      
      // Create backup if enabled
      if (this.config.backupEnabled) {
        await this.createBackup();
      }

      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Session saved for user:', user.id);
      }
      
      return true;
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to save session:', error);
      }
      return false;
    }
  }

  /**
   * Restore session from persistent storage
   */
  async restoreSession(userId?: string): Promise<{ token: string; user: { id: string; email?: string } } | null> {
    if (!this.config.enabled) {
      return null;
    }

    try {
      const sessions = await this.getStoredSessions();
      
      // Find the most recent valid session
      let targetSession: PersistedSession | null = null;
      
      if (userId) {
        targetSession = sessions.find(s => s.user.id === userId && s.expiresAt > Date.now()) || null;
      } else {
        targetSession = sessions.find(s => s.expiresAt > Date.now()) || null;
      }
      
      if (!targetSession) {
        if (__DEV__) {
          if (__DEV__) console.log('[SessionPersistence] No valid session found to restore');
        }
        return null;
      }

      // Validate fingerprint if available
      if (targetSession.fingerprint) {
        const currentFingerprint = await this.generateFingerprint();
        if (currentFingerprint !== targetSession.fingerprint) {
          if (__DEV__) {
            if (__DEV__) console.warn('[SessionPersistence] Session fingerprint mismatch - security concern');
          }
          // Remove suspicious session
          await this.removeSession(targetSession.user.id);
          return null;
        }
      }

      // Decrypt token if encrypted
      const token = targetSession.encrypted 
        ? await this.decryptData(targetSession.token)
        : targetSession.token;

      // Validate token with backend
      try {
        supabaseMCP.setToken(token);
        const sessionResult = await supabaseMCP.authGetSession();
        
        if (!sessionResult || !sessionResult.user) {
          if (__DEV__) {
            if (__DEV__) console.log('[SessionPersistence] Stored token is invalid - removing');
          }
          await this.removeSession(targetSession.user.id);
          return null;
        }

        // Track session restoration
        trackLogin(targetSession.user.id);

        if (__DEV__) {
          if (__DEV__) console.log('[SessionPersistence] Session restored for user:', targetSession.user.id);
        }

        return {
          token,
          user: targetSession.user
        };
      } catch (error) {
        if (__DEV__) {
          if (__DEV__) console.warn('[SessionPersistence] Token validation failed:', error);
        }
        await this.removeSession(targetSession.user.id);
        return null;
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to restore session:', error);
      }
      return null;
    }
  }

  /**
   * Remove specific session from storage
   */
  async removeSession(userId: string): Promise<void> {
    try {
      const sessions = await this.getStoredSessions();
      const filteredSessions = sessions.filter(s => s.user.id !== userId);
      
      await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredSessions));

      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Session removed for user:', userId);
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to remove session:', error);
      }
    }
  }

  /**
   * Clear all stored sessions
   */
  async clearAllSessions(): Promise<void> {
    try {
      await AsyncStorage.removeItem(this.STORAGE_KEY);
      await AsyncStorage.removeItem(this.BACKUP_KEY);

      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] All sessions cleared');
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to clear sessions:', error);
      }
    }
  }

  /**
   * Get all stored sessions
   */
  private async getStoredSessions(): Promise<PersistedSession[]> {
    try {
      const stored = await AsyncStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to get stored sessions:', error);
      }
      return [];
    }
  }

  /**
   * Clean up expired sessions
   */
  async cleanupExpiredSessions(): Promise<number> {
    try {
      const sessions = await this.getStoredSessions();
      const now = Date.now();
      const validSessions = sessions.filter(s => s.expiresAt > now);
      const removedCount = sessions.length - validSessions.length;
      
      if (removedCount > 0) {
        await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(validSessions));
        
        if (__DEV__) {
          if (__DEV__) console.log(`[SessionPersistence] Cleaned up ${removedCount} expired sessions`);
        }
      }
      
      return removedCount;
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to cleanup expired sessions:', error);
      }
      return 0;
    }
  }

  /**
   * Generate device fingerprint for security
   */
  private async generateFingerprint(): Promise<string> {
    try {
      // Simple fingerprint based on device characteristics
      const { Platform, Dimensions } = require('react-native');
      const screen = Dimensions.get('screen');
      
      const fingerprint = [
        Platform.OS,
        Platform.Version,
        `${screen.width}x${screen.height}`,
        new Date().getTimezoneOffset().toString(),
        // Add more device-specific data as needed
      ].join('|');
      
      return fingerprint;
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPersistence] Failed to generate fingerprint:', error);
      }
      return 'unknown';
    }
  }

  /**
   * Simple encryption for token storage (not production-grade)
   */
  private async encryptData(data: string): Promise<string> {
    // In production, use proper encryption libraries like react-native-keychain
    // This is a simple base64 encoding for demo purposes
    try {
      return Buffer.from(data).toString('base64');
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPersistence] Encryption failed, storing plain:', error);
      }
      return data;
    }
  }

  /**
   * Simple decryption for token storage (not production-grade)
   */
  private async decryptData(encryptedData: string): Promise<string> {
    try {
      return Buffer.from(encryptedData, 'base64').toString();
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPersistence] Decryption failed, assuming plain:', error);
      }
      return encryptedData;
    }
  }

  /**
   * Create backup of session data
   */
  private async createBackup(): Promise<void> {
    try {
      const sessions = await this.getStoredSessions();
      const analyticsData = sessionAnalytics.exportData();
      
      const backup: SessionBackup = {
        sessions,
        analytics: analyticsData,
        timestamp: Date.now(),
        version: '1.0.0'
      };
      
      await AsyncStorage.setItem(this.BACKUP_KEY, JSON.stringify(backup));
      
      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Backup created');
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to create backup:', error);
      }
    }
  }

  /**
   * Restore from backup
   */
  async restoreFromBackup(): Promise<boolean> {
    try {
      const backupData = await AsyncStorage.getItem(this.BACKUP_KEY);
      
      if (!backupData) {
        return false;
      }
      
      const backup: SessionBackup = JSON.parse(backupData);
      
      // Restore sessions
      await AsyncStorage.setItem(this.STORAGE_KEY, JSON.stringify(backup.sessions));
      
      if (__DEV__) {
        if (__DEV__) console.log('[SessionPersistence] Restored from backup:', backup.version);
      }
      
      return true;
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to restore from backup:', error);
      }
      return false;
    }
  }

  /**
   * Get persistence status and statistics
   */
  async getStatus(): Promise<{
    enabled: boolean;
    storedSessions: number;
    oldestSession: number | null;
    newestSession: number | null;
    hasBackup: boolean;
    config: PersistenceConfig;
  }> {
    try {
      const sessions = await this.getStoredSessions();
      const backupExists = await AsyncStorage.getItem(this.BACKUP_KEY) !== null;
      
      return {
        enabled: this.config.enabled,
        storedSessions: sessions.length,
        oldestSession: sessions.length > 0 ? Math.min(...sessions.map(s => s.timestamp)) : null,
        newestSession: sessions.length > 0 ? Math.max(...sessions.map(s => s.timestamp)) : null,
        hasBackup: backupExists,
        config: { ...this.config }
      };
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionPersistence] Failed to get status:', error);
      }
      
      return {
        enabled: this.config.enabled,
        storedSessions: 0,
        oldestSession: null,
        newestSession: null,
        hasBackup: false,
        config: { ...this.config }
      };
    }
  }

  /**
   * Load configuration from storage
   */
  private async loadConfig(): Promise<void> {
    try {
      const stored = await AsyncStorage.getItem(this.CONFIG_KEY);
      if (stored) {
        const savedConfig = JSON.parse(stored);
        this.config = { ...this.config, ...savedConfig };
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPersistence] Failed to load config, using defaults:', error);
      }
    }
  }

  /**
   * Get current configuration
   */
  getConfig(): PersistenceConfig {
    return { ...this.config };
  }
}

// Export singleton instance
export const sessionPersistence = new SessionPersistenceManager();

// Convenience functions
export const initializeSessionPersistence = () => sessionPersistence.initialize();
export const enableSessionPersistence = (enabled: boolean) => 
  sessionPersistence.updateConfig({ enabled });
export const saveCurrentSession = (token: string, user: { id: string; email?: string }) =>
  sessionPersistence.saveSession(token, user);
export const restoreLastSession = (userId?: string) => 
  sessionPersistence.restoreSession(userId);
export const clearSessionStorage = () => sessionPersistence.clearAllSessions();
export const getSessionPersistenceStatus = () => sessionPersistence.getStatus();