import { LifeSkill, Resource } from "../types/app";
import { validateURL } from "../api/url-validator";

export type Criterion = {
  key: "C1" | "C2" | "C3" | "C4" | "C5";
  label: string;
  pass: boolean;
  detail?: string;
};

export type SkillCompletenessReport = {
  skillId: string;
  title: string;
  criteria: Criterion[];
  resources: Resource[];
  urlHealthAvg: number;
  resourceCount: number;
  hasHighQualityUrl: boolean;
};

export async function checkSkillCompleteness(skill: LifeSkill): Promise<SkillCompletenessReport> {
  // C1 Overview present
  const c1 = (skill.content.overview || "").trim().length > 0;

  // C2 Key points >= 3
  const c2 = Array.isArray(skill.content.keyPoints) && skill.content.keyPoints.length >= 3;

  // C3 Steps follow 4-step pattern
  const steps = skill.content.stepByStep || [];
  const expected = ["checklist", "input", "checklist", "timer"];
  const c3 = steps.length === 4 && expected.every((t, i) => (steps[i] as any)?.type === t);

  // Resources are now handled by AI substep research feature
  // Users click the sparkle ✨ button on each substep for AI-powered help
  const resources = (skill.content.resources || []) as Resource[];

  // C4 Resources exist and have required fields, with at least one URL
  const hasMinFields = resources.length >= 3 && resources.every(r => !!r.title && !!r.description);
  const hasAnyUrl = resources.some(r => !!r.url);
  const c4 = hasMinFields && hasAnyUrl;

  // C5 URL health check: at least one URL score > 50
  const urls = resources.map(r => r.url).filter(Boolean) as string[];
  let urlHealthAvg = 0;
  let hasHighQualityUrl = false;
  if (urls.length > 0) {
    const results = await Promise.all(urls.map(u => validateURL(u)));
    const scores = results.map(r => r.score);
    urlHealthAvg = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
    hasHighQualityUrl = results.some(r => r.isValid && r.score > 50);
  }
  const c5 = hasHighQualityUrl;

  const criteria: Criterion[] = [
    { key: "C1", label: "Overview present", pass: c1 },
    { key: "C2", label: "≥ 3 key points", pass: c2 },
    { key: "C3", label: "4-step pattern checklist→input→checklist→timer", pass: c3 },
    { key: "C4", label: "≥ 3 resources, one with URL", pass: c4 },
    { key: "C5", label: "At least one high-quality URL (>50)", pass: c5 },
  ];

  return {
    skillId: skill.id,
    title: skill.title,
    criteria,
    resources,
    urlHealthAvg,
    resourceCount: resources.length,
    hasHighQualityUrl,
  };
}

export async function checkFirstFiveLessons(skills: LifeSkill[]): Promise<SkillCompletenessReport[]> {
  const target = skills.slice(0, 5);
  const reports: SkillCompletenessReport[] = [];
  for (const s of target) {
    try {
      reports.push(await checkSkillCompleteness(s));
    } catch (e) {
      reports.push({
        skillId: s.id,
        title: s.title,
        criteria: [
          { key: "C1", label: "Overview present", pass: false, detail: "Check failed" },
          { key: "C2", label: "≥ 3 key points", pass: false },
          { key: "C3", label: "4-step pattern", pass: false },
          { key: "C4", label: "≥ 3 resources", pass: false },
          { key: "C5", label: "High-quality URL", pass: false },
        ],
        resources: [],
        urlHealthAvg: 0,
        resourceCount: 0,
        hasHighQualityUrl: false,
      });
    }
  }
  return reports;
}
