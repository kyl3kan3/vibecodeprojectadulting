import type { AdultingTip } from '../types/adulting';
import type { LifeSkill, SkillCategory } from '../types/app';
import { generateContentAwareSteps } from "./ai-step-generator";

const categoryMap: Record<string, SkillCategory> = {
  finances: 'money_mastery',
  credit: 'money_mastery',
  taxes: 'life_admin',
  investing: 'money_mastery',
  insurance: 'life_admin',
  health_insurance: 'health_wellness',
  healthcare: 'health_wellness',
  fitness: 'health_wellness',
  nutrition: 'health_wellness',
  cooking: 'home_life',
  laundry: 'home_life',
  housing: 'life_admin',
  maintenance: 'life_admin',
  organization: 'home_life',
  time_management: 'personal_growth',
  consumer_rights: 'life_admin',
  shopping: 'life_admin',
  travel: 'personal_growth',
  transportation: 'life_admin',
  relationships: 'relationships',
  mental_health: 'personal_growth',
  technology: 'tech_savvy',
};

const diffMap: Record<string, 'starter' | 'building' | 'mastery'> = {
  beginner: 'starter',
  intermediate: 'building',
  advanced: 'mastery',
};

const sanitizeChecklistText = (text: string, title: string): string => {
  const t = (text || "").trim();
  const genericPatterns = [/^complete\s+step(\s*\d+)?$/i, /^finish\s+step(\s*\d+)?$/i, /^step\s*\d+$/i];
  if (genericPatterns.some((re) => re.test(t))) {
    return `Review what ${title.toLowerCase()} involves and note one takeaway`;
  }
  return t;
};

export function tipToInteractiveSkill(tip: AdultingTip): LifeSkill {
  const skillId = `tip:${tip.id}`;
  const category = categoryMap[tip.category] || 'personal_growth';
  const difficulty = diffMap[tip.difficulty] || 'starter';

  // Standardize to match Master Meal Prep format
  const estimatedTime = 30;
  const xpReward = 80;

  // Build contextual, per-tip steps using lesson meta
  const generated = generateContentAwareSteps({
    title: tip.title,
    description: tip.description,
    key_points: Array.isArray(tip.content.keyPoints) ? tip.content.keyPoints : [],
    category: tip.category,
    difficulty,
    estimated_time: 30
  });

  // Normalize IDs to be tip-scoped
  const steps = generated.steps.map((s, idx) => ({
    ...s,
    id: `${skillId}:step-${idx + 1}`,
    checklist: s.type === 'checklist' && s.checklist ? {
      items: (s.checklist.items || []).map((it, i) => ({ id: it.id || `item-${i}`, text: sanitizeChecklistText(it.text, tip.title) }))
    } : s.checklist
  })) as LifeSkill['content']['stepByStep'];

  // Generate standardized content
  const keyPoints = [
    `Start with understanding the basics of ${tip.category.replace('_', ' ')}`,
    'Focus on practical, actionable steps you can take today',
    'Build consistent habits rather than trying to do everything at once',
    'Track your progress and celebrate small wins along the way'
  ];

  const tips = [
    `Start with just the first few steps to avoid feeling overwhelmed`,
    `Focus on building one habit at a time for lasting change`,
    `Keep track of your progress to stay motivated`
  ];

  const commonMistakes = [
    'Trying to change everything at once instead of taking small steps',
    'Not setting aside dedicated time to work on the skill',
    'Giving up after the first setback instead of staying consistent'
  ];

  return {
    id: skillId,
    title: tip.title,
    description: tip.description,
    category: category as SkillCategory,
    difficulty,
    estimatedTime,
    xpReward,
    tags: [tip.category, 'practical skills', 'personal development', 'life management'],
    content: {
      overview: tip.description,
      keyPoints,
      stepByStep: steps as any,
      tips,
      commonMistakes,
      resources: [
        {
          type: 'tool',
          title: `${tip.title} Guide`,
          description: `Comprehensive guide and resources for ${tip.title.toLowerCase()}`
        }
      ],
    },
  };
}

/**
 * Enhanced version that generates AI-powered resources
 */
export async function tipToInteractiveSkillWithResources(tip: AdultingTip): Promise<LifeSkill> {
  const baseSkill = tipToInteractiveSkill(tip);
  
  // DEPRECATED: Resource generation removed - AI substep research handles this now
  // Resources are now provided through the sparkle ✨ button on each substep
  
  return baseSkill;
}
