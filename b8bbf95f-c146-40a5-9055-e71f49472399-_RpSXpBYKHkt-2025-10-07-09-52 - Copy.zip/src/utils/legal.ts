export const TERMS_URL = "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/";
export const PRIVACY_URL = "https://raw.githubusercontent.com/kyl3kan3/Project-Adulting/refs/heads/main/privacy.md";
export const SUPPORT_EMAIL = "info@decent4.com";
