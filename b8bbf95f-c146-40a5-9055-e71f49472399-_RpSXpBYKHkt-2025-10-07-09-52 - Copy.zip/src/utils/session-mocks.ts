/**
 * Session Mock Utilities for Testing
 * 
 * Provides utilities to create mock session states for testing and development
 * Only available in development mode
 */

import { supabaseMCP } from '../lib/supabase-mcp';
import { sessionAnalytics, trackLogin } from './session-analytics';

// Only export in development
if (!__DEV__) {
  throw new Error('Session mocks should only be used in development mode');
}

export interface MockUser {
  id: string;
  email: string;
  full_name?: string;
  created_at?: string;
}

export interface MockSessionConfig {
  user?: MockUser;
  token?: string;
  includeAnalytics?: boolean;
  sessionDurationMs?: number;
}

/**
 * Create a mock authenticated session for testing
 */
export const createMockSession = (config: MockSessionConfig = {}) => {
  if (!__DEV__) {
    throw new Error('Mock sessions only available in development');
  }

  const mockUser: MockUser = config.user || {
    id: `mock_user_${Date.now()}`,
    email: 'test@example.com',
    full_name: 'Test User',
    created_at: new Date().toISOString()
  };

  const mockToken = config.token || `mock_token_${Date.now()}_${Math.random().toString(36).substring(2)}`;

  // Set mock session in global state
  (global as any).__AUTH_TOKEN__ = mockToken;
  (global as any).__AUTH_USER__ = mockUser;
  
  // Set token in service proxy
  supabaseMCP.setToken(mockToken);

  // Optionally add analytics data
  if (config.includeAnalytics !== false) {
    trackLogin(mockUser.id);
    
    // If session duration is specified, backdate the session start
    if (config.sessionDurationMs) {
      const analytics = sessionAnalytics as any;
      analytics.analytics.sessionStartTime = Date.now() - config.sessionDurationMs;
    }
  }

  if (__DEV__) console.log('[SessionMocks] Created mock session:', {
    userId: mockUser.id,
    email: mockUser.email,
    tokenPrefix: mockToken.substring(0, 20) + '...'
  });

  return {
    user: mockUser,
    token: mockToken
  };
};

/**
 * Create mock session with specific issues for testing recovery
 */
export const createCorruptedMockSession = (issueType: 'token_mismatch' | 'missing_user' | 'invalid_token' = 'token_mismatch') => {
  if (!__DEV__) {
    throw new Error('Mock sessions only available in development');
  }

  const mockUser: MockUser = {
    id: `corrupt_user_${Date.now()}`,
    email: 'corrupt@example.com',
    full_name: 'Corrupted Test User'
  };

  const globalToken = `global_token_${Date.now()}`;
  const proxyToken = `proxy_token_${Date.now()}`;

  switch (issueType) {
    case 'token_mismatch':
      // Set different tokens in global vs proxy
      (global as any).__AUTH_TOKEN__ = globalToken;
      (global as any).__AUTH_USER__ = mockUser;
      supabaseMCP.setToken(proxyToken);
      break;

    case 'missing_user':
      // Set token but no user
      (global as any).__AUTH_TOKEN__ = globalToken;
      (global as any).__AUTH_USER__ = null;
      supabaseMCP.setToken(globalToken);
      break;

    case 'invalid_token':
      // Set malformed token
      (global as any).__AUTH_TOKEN__ = 'invalid_short_token';
      (global as any).__AUTH_USER__ = mockUser;
      supabaseMCP.setToken('invalid_short_token');
      break;
  }

  if (__DEV__) console.log('[SessionMocks] Created corrupted mock session:', {
    issueType,
    userId: mockUser.id,
    globalToken: globalToken?.substring(0, 20) + '...',
    proxyToken: proxyToken?.substring(0, 20) + '...'
  });

  return {
    user: mockUser,
    globalToken,
    proxyToken: issueType === 'token_mismatch' ? proxyToken : globalToken,
    issueType
  };
};

/**
 * Create mock analytics data for testing
 */
export const createMockAnalyticsData = () => {
  if (!__DEV__) {
    throw new Error('Mock analytics only available in development');
  }

  const events = [
    {
      id: 'event_1',
      type: 'login' as const,
      timestamp: Date.now() - 3600000, // 1 hour ago
      userId: 'mock_user_1'
    },
    {
      id: 'event_2',
      type: 'health_alert' as const,
      timestamp: Date.now() - 1800000, // 30 minutes ago
      metadata: { alertType: 'warning', message: 'Test alert' }
    },
    {
      id: 'event_3',
      type: 'recovery_attempt' as const,
      timestamp: Date.now() - 900000, // 15 minutes ago
      metadata: { trigger: 'test', attemptId: 'recovery_1' }
    },
    {
      id: 'event_4',
      type: 'recovery_success' as const,
      timestamp: Date.now() - 850000, // ~14 minutes ago
      duration: 5000,
      metadata: { attemptId: 'recovery_1' }
    }
  ];

  // Add mock events to analytics
  events.forEach(event => {
    sessionAnalytics.trackEvent(event);
  });

  if (__DEV__) console.log('[SessionMocks] Created mock analytics data with', events.length, 'events');
  return events;
};

/**
 * Clear all mock data and reset to empty state
 */
export const clearMockData = () => {
  if (!__DEV__) {
    throw new Error('Mock clearing only available in development');
  }

  // Clear global session state
  (global as any).__AUTH_TOKEN__ = null;
  (global as any).__AUTH_USER__ = null;
  
  // Clear service proxy
  supabaseMCP.setToken(null);
  
  // Clear analytics
  sessionAnalytics.clearData();

  if (__DEV__) console.log('[SessionMocks] All mock data cleared');
};

/**
 * Generate multiple test sessions for stress testing
 */
export const createMultipleMockSessions = (count: number = 5) => {
  if (!__DEV__) {
    throw new Error('Mock sessions only available in development');
  }

  const sessions = [];
  
  for (let i = 0; i < count; i++) {
    const session = createMockSession({
      user: {
        id: `stress_test_user_${i}`,
        email: `test${i}@example.com`,
        full_name: `Test User ${i}`
      },
      includeAnalytics: true,
      sessionDurationMs: Math.random() * 3600000 // Random duration up to 1 hour
    });
    
    sessions.push(session);
    
    // Simulate logout after random time
    setTimeout(() => {
      sessionAnalytics.endSession(session.user.id);
    }, Math.random() * 1000); // Random time up to 1 second
  }

  if (__DEV__) console.log('[SessionMocks] Created', count, 'mock sessions for stress testing');
  return sessions;
};

/**
 * Preset configurations for common test scenarios
 */
export const mockSessionPresets = {
  // Normal healthy session
  healthy: () => createMockSession({
    includeAnalytics: true,
    sessionDurationMs: 600000 // 10 minutes
  }),

  // Long-running session
  longRunning: () => createMockSession({
    includeAnalytics: true, 
    sessionDurationMs: 24 * 60 * 60 * 1000 // 24 hours
  }),

  // Fresh session (just logged in)
  fresh: () => createMockSession({
    includeAnalytics: true,
    sessionDurationMs: 1000 // 1 second
  }),

  // Session with token mismatch
  tokenMismatch: () => createCorruptedMockSession('token_mismatch'),

  // Session with missing user
  missingUser: () => createCorruptedMockSession('missing_user'),

  // Session with invalid token
  invalidToken: () => createCorruptedMockSession('invalid_token')
};

/**
 * Quick test runner for common scenarios
 */
export const runSessionTests = () => {
  if (!__DEV__) {
    throw new Error('Session tests only available in development');
  }

  if (__DEV__) console.log('[SessionMocks] Running session test scenarios...');

  // Test 1: Healthy session
  clearMockData();
  mockSessionPresets.healthy();
  if (__DEV__) console.log('✓ Healthy session test complete');

  setTimeout(() => {
    // Test 2: Token mismatch
    clearMockData();
    mockSessionPresets.tokenMismatch();
    if (__DEV__) console.log('✓ Token mismatch test complete');
  }, 1000);

  setTimeout(() => {
    // Test 3: Create analytics data
    clearMockData();
    createMockAnalyticsData();
    if (__DEV__) console.log('✓ Analytics data test complete');
  }, 2000);

  setTimeout(() => {
    // Test 4: Stress test
    clearMockData();
    createMultipleMockSessions(3);
    if (__DEV__) console.log('✓ Stress test complete');
  }, 3000);

  setTimeout(() => {
    // Clean up
    clearMockData();
    if (__DEV__) console.log('✓ All session tests completed and cleaned up');
  }, 5000);
};