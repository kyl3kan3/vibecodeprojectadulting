/**
 * AI-Powered Step Generator
 * Creates contextual, interactive lesson steps based on lesson content
 */

import { getCoachAIResponse } from "../api/chat-service";
import type { SkillStep } from "../types/app";

export interface LessonContentMeta {
  title: string;
  description: string;
  overview?: string;
  key_points?: string[];
  category?: string;
  difficulty?: "starter" | "building" | "mastery";
  estimated_time?: number;
}

export interface GeneratedSteps {
  steps: SkillStep[];
  quality_score: number;
  fallback_used: boolean;
}

/**
 * Generate contextual steps using AI based on lesson content
 */
export async function generateContextualSteps(lesson: LessonContentMeta): Promise<GeneratedSteps> {
  try {
    const prompt = createStepGenerationPrompt(lesson);
    const { content } = await getCoachAIResponse([
      { role: "user", content: prompt }
    ], { temperature: 0.3, maxTokens: 1500 });

    if (content) {
      const parsed = parseAIResponse(content, lesson.title);
      if (parsed.steps.length === 4 && validateStepPattern(parsed.steps)) {
        return {
          steps: parsed.steps,
          quality_score: calculateQualityScore(parsed.steps, lesson),
          fallback_used: false
        };
      }
    }
  } catch (error) {
    if (__DEV__) console.warn("[AI Step Generator] Failed to generate steps with AI:", (error as any)?.message);
  }

  // Fallback to enhanced content-aware generation
  return generateContentAwareSteps(lesson);
}

/**
 * Create AI prompt for step generation
 */
function createStepGenerationPrompt(lesson: LessonContentMeta): string {
  const keyPointsText = Array.isArray(lesson.key_points) && lesson.key_points.length > 0
    ? `Key points to cover: ${lesson.key_points.join(", ")}`
    : "";

  return `Create 4 interactive learning steps for this skill lesson:\n\n**Lesson:** ${lesson.title}\n**Description:** ${lesson.description}\n${lesson.overview ? `**Overview:** ${lesson.overview}` : ""}\n${keyPointsText}\n**Category:** ${lesson.category || "general"}\n**Difficulty:** ${lesson.difficulty || "starter"}\n**Time:** ${lesson.estimated_time || 30} minutes\n\nCreate exactly 4 steps following this pattern:\n1. **Checklist Step** - "Understand & Prepare" (5-10 min)\n2. **Input Step** - "Plan Your Approach" (3-5 min) \n3. **Checklist Step** - "Take Action" (10-15 min)\n4. **Timer Step** - "Focused Practice" (10-20 min)\n\nRequirements:\n- Make steps specific to the lesson topic, not generic\n- Use lesson's key points in checklist items\n- Input step should ask for personalized planning\n- Timer should be for practical application\n- Each step needs: title, description, timeEstimate, and type-specific content\n\nRespond ONLY with valid JSON:\n{\n  "steps": [\n    {\n      "title": "Step Title",\n      "description": "What the user will do in this step",\n      "timeEstimate": 10,\n      "type": "checklist",\n      "checklist": {\n        "items": [\n          {"id": "item-1", "text": "Specific actionable item"},\n          {"id": "item-2", "text": "Another specific item"}\n        ]\n      }\n    },\n    // ... 3 more steps following the pattern\n  ]\n}`;
}

/**
 * Parse AI response and validate structure
 */
function parseAIResponse(response: string, skillTitle: string): { steps: SkillStep[] } {
  // Clean up response - sometimes AI adds extra text
  const jsonMatch = response.match(/\{[\s\S]*\}/);
  if (!jsonMatch) return { steps: [] };

  try {
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.steps || !Array.isArray(parsed.steps)) {
      return { steps: [] };
    }

    // Add IDs and ensure proper structure
    const steps = parsed.steps.map((step: any, index: number) => ({
      id: `${skillTitle.toLowerCase().replace(/\s+/g, "-")}-step-${index + 1}`,
      title: step.title || `Step ${index + 1}`,
      description: step.description || "",
      timeEstimate: typeof step.timeEstimate === "number" ? step.timeEstimate : 10,
      type: step.type,
      ...(step.checklist && { checklist: step.checklist }),
      ...(step.input && { input: step.input }),
      ...(step.timer && { timer: step.timer }),
      ...(step.quiz && { quiz: step.quiz })
    }));

    return { steps };
  } catch {
    return { steps: [] };
  }
}

/**
 * Validate 4-step pattern compliance
 */
export function validateStepPattern(steps: SkillStep[]): boolean {
  const expectedPattern: Array<SkillStep["type"]> = ["checklist", "input", "checklist", "timer"];
  return steps.length === 4 && steps.every((step, index) => step.type === expectedPattern[index]);
}

/**
 * Generate content-aware steps when AI fails
 */
export function generateContentAwareSteps(lesson: LessonContentMeta): GeneratedSteps {
  const skillId = lesson.title.toLowerCase().replace(/\s+/g, "-");
  const keyPoints = Array.isArray(lesson.key_points) ? lesson.key_points : [];
  const timeEstimate = lesson.estimated_time || 30;
  
  // Extract actionable items from description and key points
  const actionItems = extractActionableItems(lesson.description, keyPoints);
  const secondHalf = actionItems.slice(0, 2);

  const steps: SkillStep[] = [
    {
      id: `${skillId}-step-1`,
      title: "Understand & Prepare",
      description: `Learn the fundamentals of ${lesson.title.toLowerCase()} and assess your starting point`,
      timeEstimate: Math.max(5, Math.round(timeEstimate * 0.25)),
      type: "checklist",
      checklist: {
        items: [
          { 
            id: "understand-1", 
            text: keyPoints[0] || `Review what ${lesson.title.toLowerCase()} involves` 
          },
          { 
            id: "understand-2", 
            text: keyPoints[1] || "Identify your current skill level and goals" 
          },
          ...(keyPoints[2] ? [{ id: "understand-3", text: keyPoints[2] }] : [])
        ]
      }
    },
    {
      id: `${skillId}-step-2`,
      title: "Plan Your Approach",
      description: `Create your personal strategy for learning ${lesson.title.toLowerCase()}`,
      timeEstimate: Math.max(3, Math.round(timeEstimate * 0.15)),
      type: "input",
      input: {
        placeholder: `My plan for mastering ${lesson.title.toLowerCase()} and the first step I will take...`
      }
    },
    {
      id: `${skillId}-step-3`,
      title: "Take Action",
      description: `Complete practical steps to apply your knowledge of ${lesson.title.toLowerCase()}`,
      timeEstimate: Math.max(10, Math.round(timeEstimate * 0.4)),
      type: "checklist",
      checklist: {
        items: [
          { id: "action-1", text: secondHalf[0] || `Take the first practical step in ${lesson.title.toLowerCase()}` },
          { id: "action-2", text: secondHalf[1] || "Practice applying what you have learned" },
          { id: "action-3", text: "Document your progress and any questions that arise" }
        ]
      }
    },
    {
      id: `${skillId}-step-4`,
      title: "Focused Practice",
      description: `Dedicated time to practice and reinforce your ${lesson.title.toLowerCase()} skills`,
      timeEstimate: Math.max(10, Math.round(timeEstimate * 0.2)),
      type: "timer",
      timer: {
        seconds: Math.max(600, Math.round(timeEstimate * 0.2 * 60))
      }
    }
  ];

  return {
    steps,
    quality_score: calculateQualityScore(steps, lesson),
    fallback_used: true
  };
}

/**
 * Extract actionable items from lesson content
 */
function extractActionableItems(description: string, keyPoints: string[]): string[] {
  const items: string[] = [];
  
  // Add key points as actionable items
  keyPoints.forEach(point => {
    if (typeof point === "string" && point.trim()) {
      items.push(point.trim());
    }
  });

  // Extract action words from description
  const actionWords = [
    "learn", "understand", "practice", "apply", "create", "build", "develop",
    "master", "improve", "setup", "configure", "implement", "use", "manage"
  ];

  const sentences = (description || "").split(/[.!?]+/).filter(s => s.trim());
  sentences.forEach(sentence => {
    const hasActionWord = actionWords.some(word => sentence.toLowerCase().includes(word));
    if (hasActionWord && sentence.length > 10 && items.length < 6) {
      items.push(sentence.trim());
    }
  });

  return items;
}

/**
 * Calculate quality score for generated steps
 */
function calculateQualityScore(steps: SkillStep[], lesson: LessonContentMeta): number {
  let score = 0;
  
  // Pattern compliance (25 points)
  if (validateStepPattern(steps)) score += 25;
  
  // Content relevance (25 points)
  const lessonTitle = lesson.title.toLowerCase();
  steps.forEach(step => {
    const titleRelevant = step.title.toLowerCase().includes(lessonTitle) || 
      lessonTitle.split(" ").some(word => word.length > 3 && step.title.toLowerCase().includes(word));
    const descRelevant = step.description.toLowerCase().includes(lessonTitle) ||
      lessonTitle.split(" ").some(word => word.length > 3 && step.description.toLowerCase().includes(word));
    if (titleRelevant || descRelevant) score += 6.25;
  });
  
  // Time distribution (25 points)
  const totalTime = steps.reduce((sum, step) => sum + step.timeEstimate, 0);
  const expectedTime = lesson.estimated_time || 30;
  const timeRatio = Math.min(totalTime, expectedTime) / Math.max(totalTime, expectedTime);
  score += timeRatio * 25;
  
  // Step completeness (25 points)
  steps.forEach(step => {
    let stepScore = 0;
    if (step.title && step.title.length > 5) stepScore += 2;
    if (step.description && step.description.length > 20) stepScore += 2;
    if (step.timeEstimate > 0) stepScore += 1;
    if (step.type === "checklist" && (step as any)?.checklist?.items && (step as any).checklist.items.length >= 2) stepScore += 1.25;
    if (step.type === "input" && (step as any)?.input?.placeholder) stepScore += 1.25;
    if (step.type === "timer" && (step as any)?.timer?.seconds > 0) stepScore += 1.25;
    score += stepScore;
  });

  return Math.round(score);
}

/**
 * Create fallback steps with generic but functional content
 */
export function createFallbackSteps(skillTitle: string, skillId?: string): SkillStep[] {
  const id = skillId || skillTitle.toLowerCase().replace(/\s+/g, "-");
  
  return [
    {
      id: `${id}-step-1`,
      title: "Plan Your Approach",
      description: `Start by understanding the key elements of ${skillTitle.toLowerCase()}`,
      timeEstimate: 10,
      type: "checklist",
      checklist: { 
        items: [
          { id: "item-1", text: "Review the skill overview and requirements" },
          { id: "item-2", text: "Identify your current knowledge level" }
        ] 
      }
    },
    {
      id: `${id}-step-2`,
      title: "Choose Your Strategy",
      description: "Decide on your specific approach and commitment",
      timeEstimate: 5,
      type: "input",
      input: { placeholder: "My strategy and next action..." }
    },
    {
      id: `${id}-step-3`,
      title: "Take Action",
      description: "Complete the practical steps to implement your plan",
      timeEstimate: 10,
      type: "checklist",
      checklist: { 
        items: [
          { id: "action-1", text: "Take the first concrete step" },
          { id: "action-2", text: "Document your progress and learnings" }
        ] 
      }
    },
    {
      id: `${id}-step-4`,
      title: "Implementation Session",
      description: "Spend focused time working on your plan and taking action",
      timeEstimate: 15,
      type: "timer",
      timer: { seconds: 900 }
    }
  ];
}
