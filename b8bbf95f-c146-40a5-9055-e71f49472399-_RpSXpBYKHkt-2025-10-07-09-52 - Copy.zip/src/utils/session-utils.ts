/**
 * Session Management Utility Functions
 * 
 * Provides reusable utilities for session operations across the app:
 * - Session state validation
 * - Session data access helpers  
 * - Session security utilities
 * - Session debugging tools
 */

import { supabaseMCP } from '../lib/supabase-mcp';
import { sessionAnalytics } from './session-analytics';
import { sessionMonitor } from './session-monitor';
import { sessionRecovery } from './session-recovery';

// Types
export interface SessionState {
  token: string | null;
  user: { id: string; email?: string | null } | null;
  isValid: boolean;
  lastValidated: number;
}

export interface SessionValidationResult {
  isValid: boolean;
  issues: string[];
  recommendations: string[];
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export interface SessionDebugInfo {
  globalToken: string | null;
  globalUser: any;
  proxyToken: string | null;
  sessionState: SessionState;
  healthStatus: any;
  recentEvents: any[];
  recoveryHistory: any[];
}

/**
 * Get current session state from all sources
 */
export const getCurrentSessionState = (): SessionState => {
  const token = (global as any).__AUTH_TOKEN__;
  const user = (global as any).__AUTH_USER__;
  const proxyToken = (supabaseMCP as any).token;
  
  return {
    token: token || null,
    user: user || null,
    isValid: !!(token && user && token === proxyToken),
    lastValidated: Date.now()
  };
};

/**
 * Validate session integrity across all storage locations
 */
export const validateSessionIntegrity = async (): Promise<SessionValidationResult> => {
  const issues: string[] = [];
  const recommendations: string[] = [];
  
  const token = (global as any).__AUTH_TOKEN__;
  const user = (global as any).__AUTH_USER__;
  const proxyToken = (supabaseMCP as any).token;
  
  // Check for missing token
  if (!token) {
    issues.push('No auth token found in global state');
    recommendations.push('User needs to log in');
  }
  
  // Check for missing user
  if (!user) {
    issues.push('No user data found in global state');
    recommendations.push('User data may need to be refreshed');
  }
  
  // Check for token mismatch between global and proxy
  if (token && proxyToken && token !== proxyToken) {
    issues.push('Token mismatch between global state and service proxy');
    recommendations.push('Session state needs to be synchronized');
  }
  
  // Check for missing proxy token
  if (token && !proxyToken) {
    issues.push('Service proxy missing auth token');
    recommendations.push('Proxy token needs to be updated');
  }
  
  // Check user object structure
  if (user && !user.id) {
    issues.push('User object missing required ID field');
    recommendations.push('User data may be corrupted');
  }
  
  // Validate token format (basic check)
  if (token && (!token.includes('.') || token.length < 100)) {
    issues.push('Auth token appears to be malformed');
    recommendations.push('Token may need to be refreshed');
  }
  
  // Test basic session functionality
  try {
    const sessionResult = await supabaseMCP.authGetSession();
    if (!sessionResult || !sessionResult.user) {
      issues.push('Session validation with service failed');
      recommendations.push('Session may have expired');
    }
  } catch (error: any) {
    issues.push(`Session service error: ${error.message}`);
    recommendations.push('Check network connectivity or refresh session');
  }
  
  // Determine severity
  let severity: SessionValidationResult['severity'] = 'low';
  
  if (issues.some(issue => issue.includes('missing') || issue.includes('malformed'))) {
    severity = 'high';
  } else if (issues.some(issue => issue.includes('mismatch') || issue.includes('service'))) {
    severity = 'medium';
  } else if (issues.length === 0) {
    severity = 'low';
  }
  
  if (issues.length > 3) {
    severity = 'critical';
  }
  
  return {
    isValid: issues.length === 0,
    issues,
    recommendations,
    severity
  };
};

/**
 * Check if current user is authenticated
 */
export const isUserAuthenticated = (): boolean => {
  const token = (global as any).__AUTH_TOKEN__;
  const user = (global as any).__AUTH_USER__;
  return !!(token && user && user.id);
};

/**
 * Get current user ID safely
 */
export const getCurrentUserId = (): string | null => {
  const user = (global as any).__AUTH_USER__;
  return user?.id || null;
};

/**
 * Get current user email safely
 */
export const getCurrentUserEmail = (): string | null => {
  const user = (global as any).__AUTH_USER__;
  return user?.email || null;
};

/**
 * Get session token safely
 */
export const getSessionToken = (): string | null => {
  return (global as any).__AUTH_TOKEN__ || null;
};

/**
 * Check if session token exists
 */
export const hasSessionToken = (): boolean => {
  const token = (global as any).__AUTH_TOKEN__;
  return !!(token && token.length > 0);
};

/**
 * Clear all session data from memory
 * WARNING: This will log out the user
 */
export const clearAllSessionData = (): void => {
  (global as any).__AUTH_TOKEN__ = null;
  (global as any).__AUTH_USER__ = null;
  supabaseMCP.setToken(null);
  
  if (__DEV__) {
    if (__DEV__) console.log('[SessionUtils] All session data cleared');
  }
};

/**
 * Synchronize session state between global and proxy
 */
export const synchronizeSessionState = (): boolean => {
  try {
    const token = (global as any).__AUTH_TOKEN__;
    const proxyToken = (supabaseMCP as any).token;
    
    if (token && token !== proxyToken) {
      supabaseMCP.setToken(token);
      if (__DEV__) {
        if (__DEV__) console.log('[SessionUtils] Session state synchronized');
      }
      return true;
    }
    
    return false;
  } catch (error) {
    if (__DEV__) {
      if (__DEV__) console.warn('[SessionUtils] Failed to synchronize session state:', error);
    }
    return false;
  }
};

/**
 * Get session duration in milliseconds (if analytics is tracking)
 */
export const getSessionDuration = (): number | null => {
  const currentSession = sessionAnalytics.getCurrentSession();
  return currentSession.duration;
};

/**
 * Get session uptime in a human-readable format
 */
export const getSessionUptime = (): string => {
  const duration = getSessionDuration();
  
  if (!duration) {
    return 'No active session';
  }
  
  const minutes = Math.floor(duration / (1000 * 60));
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days}d ${hours % 24}h ${minutes % 60}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  } else {
    return `${minutes}m`;
  }
};

/**
 * Check if session needs refresh based on age
 */
export const shouldRefreshSession = (maxAgeMs: number = 24 * 60 * 60 * 1000): boolean => {
  const duration = getSessionDuration();
  return duration ? duration > maxAgeMs : false;
};

/**
 * Get comprehensive session debug information
 */
export const getSessionDebugInfo = (): SessionDebugInfo => {
  return {
    globalToken: (global as any).__AUTH_TOKEN__ || null,
    globalUser: (global as any).__AUTH_USER__ || null,
    proxyToken: (supabaseMCP as any).token || null,
    sessionState: getCurrentSessionState(),
    healthStatus: sessionMonitor.getHealthStatus(),
    recentEvents: sessionAnalytics.getRecentEvents(10),
    recoveryHistory: sessionRecovery.getRecoveryHistory().slice(0, 5)
  };
};

/**
 * Create a formatted session status report
 */
export const createSessionStatusReport = (): string => {
  const debugInfo = getSessionDebugInfo();
  const analytics = sessionAnalytics.getSummary();
  const validation = getCurrentSessionState();
  
  return `
SESSION STATUS REPORT
====================
Status: ${validation.isValid ? '✅ Valid' : '❌ Invalid'}
User ID: ${debugInfo.globalUser?.id || 'None'}
Email: ${debugInfo.globalUser?.email || 'None'}
Session Duration: ${getSessionUptime()}
Health Score: ${analytics.healthScore}%

TOKENS
------
Global Token: ${debugInfo.globalToken ? 'Present' : 'Missing'}
Proxy Token: ${debugInfo.proxyToken ? 'Present' : 'Missing'}
Tokens Match: ${debugInfo.globalToken === debugInfo.proxyToken ? 'Yes' : 'No'}

ANALYTICS
---------
Total Sessions: ${sessionAnalytics.getMetrics().totalSessions}
Recovery Attempts: ${sessionAnalytics.getMetrics().recoveryAttempts}
Health Alerts: ${sessionAnalytics.getMetrics().healthAlerts}
Recent Activity: ${analytics.recentActivity}

HEALTH
------
Is Healthy: ${debugInfo.healthStatus?.isHealthy ? 'Yes' : 'No'}
Issues: ${debugInfo.healthStatus?.issues?.join(', ') || 'None'}
Last Check: ${new Date(debugInfo.healthStatus?.lastCheck || 0).toLocaleString()}
  `.trim();
};

/**
 * Export session data for debugging or analytics
 */
export const exportSessionData = () => {
  return {
    timestamp: Date.now(),
    sessionState: getCurrentSessionState(),
    debugInfo: getSessionDebugInfo(),
    analytics: sessionAnalytics.exportData(),
    statusReport: createSessionStatusReport()
  };
};

/**
 * Utility to safely execute code with authenticated session
 */
export const withAuthenticatedSession = async <T>(
  callback: (userId: string, token: string) => Promise<T>,
  fallback?: () => Promise<T>
): Promise<T> => {
  const userId = getCurrentUserId();
  const token = getSessionToken();
  
  if (!userId || !token) {
    if (fallback) {
      return fallback();
    }
    throw new Error('No authenticated session available');
  }
  
  return callback(userId, token);
};

/**
 * Utility to safely access user data with defaults
 */
export const getUserData = <T = any>(
  selector: (user: any) => T, 
  defaultValue: T
): T => {
  const user = (global as any).__AUTH_USER__;
  
  if (!user) {
    return defaultValue;
  }
  
  try {
    return selector(user);
  } catch (error) {
    if (__DEV__) {
      if (__DEV__) console.warn('[SessionUtils] Error accessing user data:', error);
    }
    return defaultValue;
  }
};

// Convenience functions for common data access patterns
export const getUserId = () => getUserData(user => user.id, null);
export const getUserEmail = () => getUserData(user => user.email, null);
export const getUserName = () => getUserData(user => user.full_name || user.name, null);
export const getUserCreatedAt = () => getUserData(user => user.created_at, null);

/**
 * Check session health with detailed results
 */
export const performHealthCheck = async (): Promise<{
  isHealthy: boolean;
  issues: string[];
  suggestions: string[];
  canRecover: boolean;
}> => {
  try {
    // Force a fresh health check
    sessionMonitor.forceHealthCheck();
    
    // Get current health status
    const health = sessionMonitor.getHealthStatus();
    const validation = await validateSessionIntegrity();
    
    const allIssues = [...health.issues, ...validation.issues];
    const suggestions = validation.recommendations;
    
    // Determine if recovery is likely to help
    const canRecover = allIssues.some(issue => 
      issue.includes('mismatch') || 
      issue.includes('missing proxy') ||
      issue.includes('synchronization')
    );
    
    return {
      isHealthy: health.isHealthy && validation.isValid,
      issues: allIssues,
      suggestions,
      canRecover
    };
  } catch (error: any) {
    return {
      isHealthy: false,
      issues: [`Health check failed: ${error.message}`],
      suggestions: ['Try refreshing the session or logging out and back in'],
      canRecover: true
    };
  }
};