// Simple dev-safe logger to avoid red error overlays in development
// Use console.error only for truly fatal conditions.
export const logger = {
  error: (message?: any, ...optionalParams: any[]) => {
    // Still send to console for debugging without triggering overlay in prod/dev UI
    if (__DEV__) {
      if (__DEV__) console.warn(message, ...optionalParams);
    } else {
      if (__DEV__) console.error(message, ...optionalParams);
    }
  },
  warn: (message?: any, ...optionalParams: any[]) => console.warn(message, ...optionalParams),
  info: (message?: any, ...optionalParams: any[]) => console.log(message, ...optionalParams),
};
