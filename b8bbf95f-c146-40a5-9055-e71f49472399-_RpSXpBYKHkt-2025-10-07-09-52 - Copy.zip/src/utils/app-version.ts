/**
 * App Version Utility
 * Automatically syncs version from app.json
 */

import Constants from 'expo-constants';

/**
 * Get the current app version from app.json/expo config
 * Falls back to package.json version if not available
 */
export function getAppVersion(): string {
  try {
    // Primary source: expo config (app.json)
    const expoVersion = Constants.expoConfig?.version;
    if (expoVersion) {
      return expoVersion;
    }

    // Fallback: Check manifest (with type assertion)
    const manifest = Constants.manifest as any;
    if (manifest?.version) {
      return manifest.version;
    }

    // Ultimate fallback
    return '1.0.0';
  } catch (error) {
    if (__DEV__) console.warn('[AppVersion] Error getting version:', error);
    return '1.0.0';
  }
}

/**
 * Get the build number (iOS/Android)
 */
export function getBuildNumber(): string {
  try {
    // iOS build number
    const iosBuildNumber = Constants.expoConfig?.ios?.buildNumber;
    if (iosBuildNumber) {
      return iosBuildNumber;
    }

    // Android version code
    const androidVersionCode = Constants.expoConfig?.android?.versionCode;
    if (androidVersionCode) {
      return androidVersionCode.toString();
    }

    return '1';
  } catch (error) {
    if (__DEV__) console.warn('[AppVersion] Error getting build number:', error);
    return '1';
  }
}

/**
 * Get full version string with build number
 * Example: "1.0.0 (13)"
 */
export function getFullVersionString(): string {
  const version = getAppVersion();
  const build = getBuildNumber();
  return `${version} (${build})`;
}

/**
 * Get platform-specific version info
 */
export function getVersionInfo() {
  return {
    version: getAppVersion(),
    buildNumber: getBuildNumber(),
    fullVersion: getFullVersionString(),
    platform: Constants.platform?.ios ? 'iOS' : 'Android',
    expoVersion: Constants.expoVersion || 'Unknown',
  };
}
