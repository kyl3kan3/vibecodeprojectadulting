// Centralized profile display name logic
// Single source of truth for how user names are displayed throughout the app

import type { Profile, User } from '../contexts/AuthContext';

/**
 * Get the display name for a user with proper fallback priority
 * Priority: username (@username) > full_name > email prefix > 'Friend'
 */
export function getDisplayName(
  profile: Profile | null,
  user: User | null,
  userProfile?: any
): string {
  // Priority order:
  if (profile?.username) return `@${profile.username}`;
  if (profile?.full_name) return profile.full_name;
  if (userProfile?.name) return userProfile.name;
  if (user?.email) return user.email.split('@')[0];
  return 'Friend';
}

/**
 * Get a short version of the name (for avatars, small spaces)
 * Returns just first name or username without @ symbol
 */
export function getShortName(
  profile: Profile | null,
  user: User | null
): string {
  // For avatars/small spaces - just first name or username
  if (profile?.username) return profile.username;
  if (profile?.full_name) {
    // Return first word of full name
    return profile.full_name.split(' ')[0];
  }
  if (user?.email) return user.email.split('@')[0];
  return 'Friend';
}

/**
 * Get the full name without @ symbol (for formal contexts)
 */
export function getFormalName(
  profile: Profile | null,
  user: User | null
): string {
  if (profile?.full_name) return profile.full_name;
  if (profile?.username) return profile.username;
  if (user?.email) return user.email.split('@')[0];
  return 'Friend';
}

/**
 * Check if user has set a custom identity (username or full name)
 */
export function hasCustomIdentity(profile: Profile | null): boolean {
  return !!(profile?.username || profile?.full_name);
}

/**
 * Validate username format
 * Rules: 3-20 characters, alphanumeric and underscores only, no spaces
 */
export function validateUsername(username: string): { valid: boolean; error?: string } {
  if (!username || username.trim().length === 0) {
    return { valid: false, error: 'Username is required' };
  }

  const trimmed = username.trim();

  if (trimmed.length < 3) {
    return { valid: false, error: 'Username must be at least 3 characters' };
  }

  if (trimmed.length > 20) {
    return { valid: false, error: 'Username must be 20 characters or less' };
  }

  // Only allow alphanumeric and underscores
  const validPattern = /^[a-zA-Z0-9_]+$/;
  if (!validPattern.test(trimmed)) {
    return { valid: false, error: 'Username can only contain letters, numbers, and underscores' };
  }

  // Cannot start with underscore
  if (trimmed.startsWith('_')) {
    return { valid: false, error: 'Username cannot start with an underscore' };
  }

  // Cannot be all numbers
  if (/^\d+$/.test(trimmed)) {
    return { valid: false, error: 'Username cannot be all numbers' };
  }

  return { valid: true };
}

/**
 * Sanitize username input (lowercase, trim, remove invalid chars)
 */
export function sanitizeUsername(username: string): string {
  return username
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9_]/g, ''); // Remove any invalid characters
}
