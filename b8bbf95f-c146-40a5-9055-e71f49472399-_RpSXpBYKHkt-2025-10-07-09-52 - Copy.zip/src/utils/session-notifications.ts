/**
 * Session Notifications System
 * 
 * Provides intelligent notifications and alerts for session management events:
 * - Session expiry warnings
 * - Security breach alerts
 * - Recovery success/failure notifications
 * - Performance degradation warnings
 * - Custom notification rules
 */

import * as Notifications from 'expo-notifications';
import { sessionAnalytics } from './session-analytics';
import { sessionSecurity, SecurityAlert } from './session-security';
import { sessionMonitor, SessionAlert } from './session-monitor';


export interface NotificationRule {
  id: string;
  name: string;
  enabled: boolean;
  trigger: 'security_alert' | 'session_expiry' | 'recovery_failure' | 'performance_degradation' | 'health_critical';
  severity: 'low' | 'medium' | 'high' | 'critical';
  cooldownMs: number;
  lastTriggered: number;
  conditions?: Record<string, any>;
}

export interface SessionNotification {
  id: string;
  title: string;
  body: string;
  priority: 'default' | 'high' | 'max';
  category: string;
  data: Record<string, any>;
  timestamp: number;
  ruleId?: string;
}

class SessionNotificationManager {
  private rules: NotificationRule[] = [
    {
      id: 'session_expiry_warning',
      name: 'Session Expiry Warning',
      enabled: true,
      trigger: 'session_expiry',
      severity: 'medium',
      cooldownMs: 30 * 60 * 1000, // 30 minutes
      lastTriggered: 0,
      conditions: { warningThreshold: 0.8 } // Warn at 80% of max age
    },
    {
      id: 'security_breach_alert',
      name: 'Security Breach Alert',
      enabled: true,
      trigger: 'security_alert',
      severity: 'critical',
      cooldownMs: 5 * 60 * 1000, // 5 minutes
      lastTriggered: 0,
      conditions: { minSeverity: 'high' }
    },
    {
      id: 'recovery_failure_alert',
      name: 'Recovery Failure Alert',
      enabled: true,
      trigger: 'recovery_failure',
      severity: 'high',
      cooldownMs: 10 * 60 * 1000, // 10 minutes
      lastTriggered: 0
    },
    {
      id: 'health_critical_alert',
      name: 'Critical Health Alert',
      enabled: true,
      trigger: 'health_critical',
      severity: 'critical',
      cooldownMs: 15 * 60 * 1000, // 15 minutes
      lastTriggered: 0,
      conditions: { consecutiveFailures: 5 }
    },
    {
      id: 'performance_degradation_warning',
      name: 'Performance Degradation Warning',
      enabled: false, // Disabled by default to avoid noise
      trigger: 'performance_degradation',
      severity: 'low',
      cooldownMs: 60 * 60 * 1000, // 1 hour
      lastTriggered: 0,
      conditions: { memoryThreshold: 500, riskScoreThreshold: 60 }
    }
  ];

  private notifications: SessionNotification[] = [];
  private maxStoredNotifications: number = 50;
  private initialized: boolean = false;
  private listeners: Array<(notification: SessionNotification) => void> = [];

  /**
   * Initialize the notification system
   */
  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      // Configure notification handler
      Notifications.setNotificationHandler({
        handleNotification: async (notification) => {
          // Check if it's a session-related notification
          const isSessionNotification = notification.request.content.categoryIdentifier?.startsWith('session_');
          
          return {
            shouldShowAlert: true,
            shouldPlaySound: isSessionNotification || false,
            shouldSetBadge: false,
            shouldShowBanner: true,
            shouldShowList: true
          };
        },
      });

      // Set up notification categories
      await this.setupNotificationCategories();

      // Set up event listeners
      this.setupEventListeners();

      this.initialized = true;

      if (__DEV__) {
        if (__DEV__) console.log('[SessionNotifications] Initialized successfully');
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionNotifications] Failed to initialize:', error);
      }
    }
  }

  /**
   * Set up notification categories for different types of session alerts
   */
  private async setupNotificationCategories(): Promise<void> {
    try {
      // Note: Advanced notification categories may not be fully supported in all Expo versions
      // Using basic notification setup for maximum compatibility
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionNotifications] Failed to setup categories:', error);
      }
    }
  }

  /**
   * Set up event listeners for session components
   */
  private setupEventListeners(): void {
    // Note: Direct event listeners would need to be implemented in the respective managers
    // For now, we'll use periodic checks for monitoring
    
    // Periodic checks for various conditions
    setInterval(() => {
      this.checkSessionExpiry();
      this.checkSecurityStatus();
      this.checkHealthStatus();
    }, 5 * 60 * 1000); // Check every 5 minutes
  }

  /**
   * Check security status periodically
   */
  private checkSecurityStatus(): void {
    const alerts = sessionSecurity.getAlerts(5);
    const recentAlerts = alerts.filter(alert => Date.now() - alert.timestamp < 5 * 60 * 1000);
    
    recentAlerts.forEach(alert => this.handleSecurityAlert(alert));
  }

  /**
   * Check health status periodically
   */
  private checkHealthStatus(): void {
    const healthStatus = sessionMonitor.getHealthStatus();
    
    if (!healthStatus.isHealthy && healthStatus.consecutiveFailures >= 5) {
      // Trigger health critical alert
      const rule = this.rules.find(r => r.id === 'health_critical_alert');
      if (rule && rule.enabled && Date.now() - rule.lastTriggered >= rule.cooldownMs) {
        this.sendNotification({
          title: 'Critical Health Alert',
          body: `Session has ${healthStatus.consecutiveFailures} consecutive failures`,
          priority: 'max',
          category: 'session_recovery',
          data: { consecutiveFailures: healthStatus.consecutiveFailures },
          ruleId: rule.id
        });
        rule.lastTriggered = Date.now();
      }
    }
  }

  /**
   * Handle security alerts
   */
  private handleSecurityAlert(alert: SecurityAlert): void {
    const rule = this.rules.find(r => r.id === 'security_breach_alert');
    if (!rule || !rule.enabled) return;

    // Check severity threshold
    const minSeverity = rule.conditions?.minSeverity || 'medium';
    const severityLevels = { low: 1, medium: 2, high: 3, critical: 4 };
    
    if (severityLevels[alert.severity] < severityLevels[minSeverity as keyof typeof severityLevels]) {
      return;
    }

    // Check cooldown
    if (Date.now() - rule.lastTriggered < rule.cooldownMs) {
      return;
    }

    this.sendNotification({
      title: 'Security Alert',
      body: alert.message,
      priority: alert.severity === 'critical' ? 'max' : 'high',
      category: 'session_security',
      data: {
        alertId: alert.id,
        severity: alert.severity,
        type: alert.type
      },
      ruleId: rule.id
    });

    rule.lastTriggered = Date.now();
  }

  /**
   * Handle session monitor alerts
   */
  private handleMonitorAlert(alert: SessionAlert): void {
    if (alert.type === 'error') {
      // Check for critical health conditions
      const rule = this.rules.find(r => r.id === 'health_critical_alert');
      if (!rule || !rule.enabled) return;

      const consecutiveFailures = alert.data?.consecutiveFailures || 0;
      const threshold = rule.conditions?.consecutiveFailures || 5;

      if (consecutiveFailures >= threshold) {
        // Check cooldown
        if (Date.now() - rule.lastTriggered < rule.cooldownMs) {
          return;
        }

        this.sendNotification({
          title: 'Critical Session Health Alert',
          body: `Session has failed ${consecutiveFailures} consecutive health checks`,
          priority: 'max',
          category: 'session_recovery',
          data: {
            consecutiveFailures,
            alertType: alert.type
          },
          ruleId: rule.id
        });

        rule.lastTriggered = Date.now();
      }
    }
  }

  /**
   * Handle recovery failures
   */
  private handleRecoveryFailure(event: any): void {
    const rule = this.rules.find(r => r.id === 'recovery_failure_alert');
    if (!rule || !rule.enabled) return;

    // Check cooldown
    if (Date.now() - rule.lastTriggered < rule.cooldownMs) {
      return;
    }

    this.sendNotification({
      title: 'Session Recovery Failed',
      body: 'Automatic session recovery has failed. Manual intervention may be required.',
      priority: 'high',
      category: 'session_recovery',
      data: {
        eventId: event.id,
        metadata: event.metadata
      },
      ruleId: rule.id
    });

    rule.lastTriggered = Date.now();
  }

  /**
   * Check for session expiry and send warnings
   */
  private checkSessionExpiry(): void {
    const rule = this.rules.find(r => r.id === 'session_expiry_warning');
    if (!rule || !rule.enabled) return;

    const currentSession = sessionAnalytics.getCurrentSession();
    if (!currentSession.duration) return;

    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    const warningThreshold = rule.conditions?.warningThreshold || 0.8;
    const warningAge = maxAge * warningThreshold;

    if (currentSession.duration > warningAge && currentSession.duration < maxAge) {
      // Check cooldown
      if (Date.now() - rule.lastTriggered < rule.cooldownMs) {
        return;
      }

      const timeRemaining = maxAge - currentSession.duration;
      const hoursRemaining = Math.floor(timeRemaining / (60 * 60 * 1000));
      const minutesRemaining = Math.floor((timeRemaining % (60 * 60 * 1000)) / (60 * 1000));

      this.sendNotification({
        title: 'Session Expiry Warning',
        body: `Your session will expire in ${hoursRemaining}h ${minutesRemaining}m`,
        priority: 'default',
        category: 'session_expiry',
        data: {
          timeRemaining,
          sessionDuration: currentSession.duration
        },
        ruleId: rule.id
      });

      rule.lastTriggered = Date.now();
    }
  }

  /**
   * Send a session notification
   */
  private async sendNotification(notificationData: Omit<SessionNotification, 'id' | 'timestamp'>): Promise<void> {
    const notification: SessionNotification = {
      ...notificationData,
      id: `session_notif_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      timestamp: Date.now()
    };

    // Store notification
    this.notifications.unshift(notification);
    
    // Limit stored notifications
    if (this.notifications.length > this.maxStoredNotifications) {
      this.notifications = this.notifications.slice(0, this.maxStoredNotifications);
    }

    // Send notification
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: notification.title,
          body: notification.body,
          data: notification.data,
          categoryIdentifier: notification.category,
          priority: notification.priority === 'max' ? 
            Notifications.AndroidNotificationPriority.MAX : 
            notification.priority === 'high' ?
            Notifications.AndroidNotificationPriority.HIGH :
            Notifications.AndroidNotificationPriority.DEFAULT
        },
        trigger: null // Send immediately
      });

      // Notify listeners
      this.listeners.forEach(listener => {
        try {
          listener(notification);
        } catch (error) {
          if (__DEV__) {
            if (__DEV__) console.warn('[SessionNotifications] Listener error:', error);
          }
        }
      });

      if (__DEV__) {
        if (__DEV__) console.log('[SessionNotifications] Sent:', notification.title);
      }
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionNotifications] Failed to send notification:', error);
      }
    }
  }

  /**
   * Update notification rule
   */
  updateRule(ruleId: string, updates: Partial<NotificationRule>): void {
    const ruleIndex = this.rules.findIndex(r => r.id === ruleId);
    if (ruleIndex !== -1) {
      this.rules[ruleIndex] = { ...this.rules[ruleIndex], ...updates };
      
      if (__DEV__) {
        if (__DEV__) console.log('[SessionNotifications] Rule updated:', ruleId);
      }
    }
  }

  /**
   * Add custom notification rule
   */
  addCustomRule(rule: NotificationRule): void {
    this.rules.push(rule);
    
    if (__DEV__) {
      if (__DEV__) console.log('[SessionNotifications] Custom rule added:', rule.id);
    }
  }

  /**
   * Get all notification rules
   */
  getRules(): NotificationRule[] {
    return [...this.rules];
  }

  /**
   * Get recent notifications
   */
  getNotifications(limit?: number): SessionNotification[] {
    return limit ? this.notifications.slice(0, limit) : [...this.notifications];
  }

  /**
   * Clear notifications
   */
  clearNotifications(): void {
    this.notifications = [];
    
    if (__DEV__) {
      if (__DEV__) console.log('[SessionNotifications] Notifications cleared');
    }
  }

  /**
   * Subscribe to notification events
   */
  onNotification(callback: (notification: SessionNotification) => void): () => void {
    this.listeners.push(callback);
    
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  /**
   * Request notification permissions
   */
  async requestPermissions(): Promise<boolean> {
    try {
      const { status } = await Notifications.requestPermissionsAsync();
      return status === 'granted';
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.error('[SessionNotifications] Permission request failed:', error);
      }
      return false;
    }
  }

  /**
   * Get notification system status
   */
  async getStatus(): Promise<{
    initialized: boolean;
    permissionsGranted: boolean;
    activeRules: number;
    totalNotifications: number;
    lastNotification: number | null;
  }> {
    let permissionsGranted = false;
    
    try {
      const { status } = await Notifications.getPermissionsAsync();
      permissionsGranted = status === 'granted';
    } catch (error) {
      // Permissions check failed
    }

    return {
      initialized: this.initialized,
      permissionsGranted,
      activeRules: this.rules.filter(r => r.enabled).length,
      totalNotifications: this.notifications.length,
      lastNotification: this.notifications.length > 0 ? this.notifications[0].timestamp : null
    };
  }
}

// Export singleton instance
export const sessionNotifications = new SessionNotificationManager();

// Convenience functions
export const initializeSessionNotifications = () => sessionNotifications.initialize();
export const requestNotificationPermissions = () => sessionNotifications.requestPermissions();
export const getNotificationRules = () => sessionNotifications.getRules();
export const getRecentNotifications = (limit?: number) => sessionNotifications.getNotifications(limit);
export const updateNotificationRule = (ruleId: string, updates: Partial<NotificationRule>) =>
  sessionNotifications.updateRule(ruleId, updates);