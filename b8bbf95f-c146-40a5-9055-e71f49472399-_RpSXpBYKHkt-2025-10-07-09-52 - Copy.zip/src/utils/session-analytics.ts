/**
 * Session Analytics and Usage Tracking
 * 
 * Provides comprehensive session analytics including:
 * - Session duration tracking
 * - Auth event monitoring 
 * - Performance metrics
 * - Usage patterns
 * - Error frequency analysis
 */

export interface SessionEvent {
  id: string;
  type: 'login' | 'logout' | 'token_refresh' | 'recovery_attempt' | 'recovery_success' | 'recovery_failure' | 'session_check' | 'health_alert';
  timestamp: number;
  duration?: number; // in milliseconds
  metadata?: Record<string, any>;
  userId?: string;
}

export interface SessionMetrics {
  totalSessions: number;
  averageSessionDuration: number;
  totalLoginAttempts: number;
  successfulLogins: number;
  failedLogins: number;
  recoveryAttempts: number;
  successfulRecoveries: number;
  healthAlerts: number;
  lastSessionStart?: number;
  currentSessionDuration?: number;
}

export interface SessionAnalytics {
  // Current session
  sessionStartTime: number | null;
  currentSessionId: string | null;
  
  // Event tracking
  events: SessionEvent[];
  maxEvents: number;
  
  // Metrics cache
  metricsCache: SessionMetrics | null;
  metricsCacheTime: number;
  cacheValidityMs: number;
  
  // Listeners
  listeners: Array<(event: SessionEvent) => void>;
}

class SessionAnalyticsManager {
  private analytics: SessionAnalytics = {
    sessionStartTime: null,
    currentSessionId: null,
    events: [],
    maxEvents: 1000, // Keep last 1000 events
    metricsCache: null,
    metricsCacheTime: 0,
    cacheValidityMs: 5 * 60 * 1000, // 5 minutes
    listeners: []
  };

  /**
   * Start tracking a new session
   */
  startSession(userId?: string): string {
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    
    this.analytics.sessionStartTime = Date.now();
    this.analytics.currentSessionId = sessionId;
    
    this.trackEvent({
      id: `login_${Date.now()}`,
      type: 'login',
      timestamp: Date.now(),
      userId,
      metadata: { sessionId }
    });
    
    if (__DEV__) {
      if (__DEV__) console.log(`[SessionAnalytics] Session started: ${sessionId}`);
    }
    
    return sessionId;
  }

  /**
   * End current session tracking
   */
  endSession(userId?: string): void {
    if (!this.analytics.sessionStartTime || !this.analytics.currentSessionId) {
      return;
    }
    
    const duration = Date.now() - this.analytics.sessionStartTime;
    
    this.trackEvent({
      id: `logout_${Date.now()}`,
      type: 'logout',
      timestamp: Date.now(),
      duration,
      userId,
      metadata: { 
        sessionId: this.analytics.currentSessionId,
        sessionDuration: duration
      }
    });
    
    if (__DEV__) {
      if (__DEV__) console.log(`[SessionAnalytics] Session ended: ${this.analytics.currentSessionId}, Duration: ${(duration / 1000).toFixed(1)}s`);
    }
    
    this.analytics.sessionStartTime = null;
    this.analytics.currentSessionId = null;
    this.invalidateCache();
  }

  /**
   * Track a session-related event
   */
  trackEvent(event: SessionEvent): void {
    // Performance optimization: Batch session_check events to reduce memory usage
    if (event.type === 'session_check') {
      // Only keep every 10th session check to reduce noise
      const checkCount = this.analytics.events.filter(e => e.type === 'session_check').length;
      if (checkCount % 10 !== 0 && this.analytics.events.length > 0) {
        // Skip this session check event
        return;
      }
    }
    
    // Add event to history
    this.analytics.events.unshift(event);
    
    // Keep only the most recent events (with performance-conscious cleanup)
    if (this.analytics.events.length > this.analytics.maxEvents) {
      // Use more efficient splice instead of slice for memory
      this.analytics.events.splice(this.analytics.maxEvents);
    }
    
    // Performance optimization: Only invalidate cache for significant events
    if (event.type !== 'session_check') {
      this.invalidateCache();
    }
    
    // Notify listeners (with error resilience)
    this.analytics.listeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        if (__DEV__) {
          if (__DEV__) console.warn('[SessionAnalytics] Listener error:', error);
        }
      }
    });
    
    if (__DEV__ && event.type !== 'session_check') {
      if (__DEV__) console.log(`[SessionAnalytics] Event tracked: ${event.type}`, event.metadata);
    }
  }

  /**
   * Get current session metrics
   */
  getMetrics(): SessionMetrics {
    const now = Date.now();
    
    // Return cached metrics if still valid
    if (
      this.analytics.metricsCache &&
      (now - this.analytics.metricsCacheTime) < this.analytics.cacheValidityMs
    ) {
      // Update current session duration if session is active
      if (this.analytics.sessionStartTime) {
        return {
          ...this.analytics.metricsCache,
          currentSessionDuration: now - this.analytics.sessionStartTime
        };
      }
      return this.analytics.metricsCache;
    }
    
    // Calculate fresh metrics
    const events = this.analytics.events;
    const loginEvents = events.filter(e => e.type === 'login');
    const logoutEvents = events.filter(e => e.type === 'logout');
    const recoveryAttempts = events.filter(e => e.type === 'recovery_attempt');
    const successfulRecoveries = events.filter(e => e.type === 'recovery_success');
    const healthAlerts = events.filter(e => e.type === 'health_alert');
    
    // Calculate session durations
    const sessionDurations: number[] = [];
    logoutEvents.forEach(logout => {
      if (logout.duration) {
        sessionDurations.push(logout.duration);
      }
    });
    
    const averageSessionDuration = sessionDurations.length > 0
      ? sessionDurations.reduce((sum, duration) => sum + duration, 0) / sessionDurations.length
      : 0;
    
    const lastLoginEvent = loginEvents[0];
    
    const metrics: SessionMetrics = {
      totalSessions: loginEvents.length,
      averageSessionDuration,
      totalLoginAttempts: loginEvents.length,
      successfulLogins: loginEvents.length, // All tracked logins are successful
      failedLogins: 0, // We don't currently track failed login attempts
      recoveryAttempts: recoveryAttempts.length,
      successfulRecoveries: successfulRecoveries.length,
      healthAlerts: healthAlerts.length,
      lastSessionStart: lastLoginEvent?.timestamp,
      currentSessionDuration: this.analytics.sessionStartTime 
        ? now - this.analytics.sessionStartTime 
        : undefined
    };
    
    // Cache the metrics
    this.analytics.metricsCache = metrics;
    this.analytics.metricsCacheTime = now;
    
    return metrics;
  }

  /**
   * Get recent events (last N events)
   */
  getRecentEvents(limit: number = 50): SessionEvent[] {
    return this.analytics.events.slice(0, limit);
  }

  /**
   * Get events by type
   */
  getEventsByType(type: SessionEvent['type'], limit?: number): SessionEvent[] {
    const filtered = this.analytics.events.filter(e => e.type === type);
    return limit ? filtered.slice(0, limit) : filtered;
  }

  /**
   * Get events within time range
   */
  getEventsInTimeRange(startTime: number, endTime: number): SessionEvent[] {
    return this.analytics.events.filter(
      e => e.timestamp >= startTime && e.timestamp <= endTime
    );
  }

  /**
   * Get current session info
   */
  getCurrentSession(): { id: string | null; startTime: number | null; duration: number | null } {
    return {
      id: this.analytics.currentSessionId,
      startTime: this.analytics.sessionStartTime,
      duration: this.analytics.sessionStartTime 
        ? Date.now() - this.analytics.sessionStartTime 
        : null
    };
  }

  /**
   * Subscribe to analytics events
   */
  onEvent = (callback: (event: SessionEvent) => void): (() => void) => {
    this.analytics.listeners.push(callback);
    
    return () => {
      const index = this.analytics.listeners.indexOf(callback);
      if (index > -1) {
        this.analytics.listeners.splice(index, 1);
      }
    };
  }

  /**
   * Get analytics summary for display
   */
  getSummary(): {
    currentSession: string;
    totalEvents: number;
    recentActivity: string;
    healthScore: number;
  } {
    const metrics = this.getMetrics();
    const recentEvents = this.getRecentEvents(10);
    const currentSession = this.getCurrentSession();
    
    // Calculate health score based on recovery success rate
    const recoverySuccessRate = metrics.recoveryAttempts > 0 
      ? (metrics.successfulRecoveries / metrics.recoveryAttempts) * 100 
      : 100;
    
    const alertFrequency = metrics.totalSessions > 0 
      ? metrics.healthAlerts / metrics.totalSessions 
      : 0;
    
    const healthScore = Math.max(0, Math.min(100, 
      recoverySuccessRate - (alertFrequency * 10)
    ));
    
    const recentActivity = recentEvents.length > 0 
      ? `Last: ${recentEvents[0].type} (${new Date(recentEvents[0].timestamp).toLocaleTimeString()})`
      : 'No recent activity';
    
    const currentSessionText = currentSession.id 
      ? `Active (${((currentSession.duration || 0) / 1000 / 60).toFixed(1)}m)`
      : 'None';
    
    return {
      currentSession: currentSessionText,
      totalEvents: this.analytics.events.length,
      recentActivity,
      healthScore: Math.round(healthScore)
    };
  }

  /**
   * Export analytics data for debugging
   */
  exportData(): {
    metrics: SessionMetrics;
    recentEvents: SessionEvent[];
    currentSession: { id: string | null; startTime: number | null; duration: number | null };
    summary: { currentSession: string; totalEvents: number; recentActivity: string; healthScore: number };
  } {
    return {
      metrics: this.getMetrics(),
      recentEvents: this.getRecentEvents(100),
      currentSession: this.getCurrentSession(),
      summary: this.getSummary()
    };
  }

  /**
   * Clear all analytics data
   */
  clearData(): void {
    this.analytics.events.length = 0; // More memory-efficient than reassignment
    this.analytics.sessionStartTime = null;
    this.analytics.currentSessionId = null;
    this.analytics.listeners.length = 0; // Clear listeners too
    this.invalidateCache();
    
    if (__DEV__) {
      if (__DEV__) console.log('[SessionAnalytics] All data cleared');
    }
  }

  /**
   * Perform memory cleanup by removing old events
   */
  performMemoryCleanup(): number {
    const initialCount = this.analytics.events.length;
    const cutoffTime = Date.now() - (24 * 60 * 60 * 1000); // 24 hours ago
    
    // Keep only events from the last 24 hours and limit to half of maxEvents
    this.analytics.events = this.analytics.events
      .filter(event => event.timestamp > cutoffTime)
      .slice(0, Math.floor(this.analytics.maxEvents / 2));
    
    const cleaned = initialCount - this.analytics.events.length;
    
    if (cleaned > 0) {
      this.invalidateCache();
      if (__DEV__) {
        if (__DEV__) console.log(`[SessionAnalytics] Cleaned up ${cleaned} old events`);
      }
    }
    
    return cleaned;
  }

  /**
   * Invalidate metrics cache
   */
  private invalidateCache(): void {
    this.analytics.metricsCache = null;
    this.analytics.metricsCacheTime = 0;
  }
}

// Export singleton instance
export const sessionAnalytics = new SessionAnalyticsManager();

// Helper functions for common tracking scenarios
export const trackLogin = (userId?: string) => {
  return sessionAnalytics.startSession(userId);
};

export const trackLogout = (userId?: string) => {
  sessionAnalytics.endSession(userId);
};

export const trackRecoveryAttempt = (metadata?: Record<string, any>) => {
  sessionAnalytics.trackEvent({
    id: `recovery_attempt_${Date.now()}`,
    type: 'recovery_attempt',
    timestamp: Date.now(),
    metadata
  });
};

export const trackRecoverySuccess = (duration?: number, metadata?: Record<string, any>) => {
  sessionAnalytics.trackEvent({
    id: `recovery_success_${Date.now()}`,
    type: 'recovery_success',
    timestamp: Date.now(),
    duration,
    metadata
  });
};

export const trackRecoveryFailure = (metadata?: Record<string, any>) => {
  sessionAnalytics.trackEvent({
    id: `recovery_failure_${Date.now()}`,
    type: 'recovery_failure',
    timestamp: Date.now(),
    metadata
  });
};

export const trackHealthAlert = (alertType: string, message: string) => {
  sessionAnalytics.trackEvent({
    id: `health_alert_${Date.now()}`,
    type: 'health_alert',
    timestamp: Date.now(),
    metadata: { alertType, message }
  });
};

export const trackSessionCheck = (isHealthy: boolean, issues: string[]) => {
  sessionAnalytics.trackEvent({
    id: `session_check_${Date.now()}`,
    type: 'session_check',
    timestamp: Date.now(),
    metadata: { isHealthy, issueCount: issues.length, issues: issues.slice(0, 3) }
  });
};