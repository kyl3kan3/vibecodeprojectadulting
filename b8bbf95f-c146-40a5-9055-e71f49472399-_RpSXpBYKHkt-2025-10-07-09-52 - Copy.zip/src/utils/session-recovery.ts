// Automatic session recovery mechanisms for network failures and state inconsistencies
import { supabaseMCP } from '../lib/supabase-mcp';
import { sessionMonitor, SessionAlert } from './session-monitor';
import { trackRecoveryAttempt, trackRecoverySuccess, trackRecoveryFailure } from './session-analytics';

export interface RecoveryAttempt {
  id: string;
  type: 'state_sync' | 'token_refresh' | 'full_recovery';
  startTime: number;
  endTime?: number;
  success: boolean;
  error?: string;
  steps: string[];
}

export interface RecoveryConfig {
  maxAttempts: number;
  retryDelayMs: number;
  enableAutoRecovery: boolean;
  recoveryTimeoutMs: number;
}

class SessionRecovery {
  private recoveryAttempts: RecoveryAttempt[] = [];
  private isRecovering = false;
  private recoveryTimeout: NodeJS.Timeout | null = null;
  
  private config: RecoveryConfig = {
    maxAttempts: 3,
    retryDelayMs: 2000,
    enableAutoRecovery: true,
    recoveryTimeoutMs: 30000
  };
  
  private readonly MAX_STORED_ATTEMPTS = 20;

  constructor() {
    // Listen to session monitor alerts for automatic recovery
    sessionMonitor.onAlert((alert) => {
      if (this.config.enableAutoRecovery && this.shouldTriggerRecovery(alert)) {
        this.attemptRecovery('auto_triggered');
      }
    });
  }

  private shouldTriggerRecovery(alert: SessionAlert): boolean {
    // Trigger recovery for critical session issues
    if (alert.type === 'error') {
      return true;
    }
    
    if (alert.type === 'warning' && alert.message.includes('Session health degraded')) {
      return true;
    }
    
    return false;
  }

  async attemptRecovery(trigger: string = 'manual'): Promise<boolean> {
    if (this.isRecovering) {
      if (__DEV__) console.log('[SessionRecovery] Recovery already in progress');
      return false;
    }

    const attemptId = `recovery_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const attempt: RecoveryAttempt = {
      id: attemptId,
      type: 'full_recovery',
      startTime: Date.now(),
      success: false,
      steps: [`Initiated by: ${trigger}`]
    };

    this.isRecovering = true;
    if (__DEV__) console.log('[SessionRecovery] Starting recovery attempt:', attemptId);
    
    // Track recovery attempt in analytics
    trackRecoveryAttempt({ trigger, attemptId });

    try {
      // Set recovery timeout
      this.recoveryTimeout = setTimeout(() => {
        attempt.steps.push('Recovery timed out');
        attempt.error = 'Recovery operation timed out';
        this.completeRecovery(attempt, false);
      }, this.config.recoveryTimeoutMs);

      // Step 1: Diagnose current state
      attempt.steps.push('Diagnosing session state');
      const diagnosis = await this.diagnoseSessionState();
      attempt.steps.push(`Diagnosis: ${JSON.stringify(diagnosis)}`);

      // Step 2: Attempt state synchronization
      if (diagnosis.hasTokenMismatch || diagnosis.hasMissingData) {
        attempt.steps.push('Attempting state synchronization');
        const syncSuccess = await this.synchronizeSessionState();
        attempt.steps.push(`State sync: ${syncSuccess ? 'success' : 'failed'}`);
        
        if (syncSuccess) {
          return this.completeRecovery(attempt, true);
        }
      }

      // Step 3: Attempt session validation
      attempt.steps.push('Validating session');
      const session = await supabaseMCP.authGetSession();
      if (session && session.token && session.user) {
        attempt.steps.push('Session validation successful');
        return this.completeRecovery(attempt, true);
      }
      attempt.steps.push('Session validation failed');

      // Step 4: Clear and reset session state
      attempt.steps.push('Clearing corrupted session state');
      await this.clearCorruptedState();

      // Step 5: Force session monitor recheck
      attempt.steps.push('Triggering health recheck');
      sessionMonitor.forceHealthCheck();

      return this.completeRecovery(attempt, true);

    } catch (error: any) {
      attempt.error = error.message;
      attempt.steps.push(`Recovery failed: ${error.message}`);
      if (__DEV__) console.error('[SessionRecovery] Recovery attempt failed:', error);
      return this.completeRecovery(attempt, false);
    }
  }

  private async diagnoseSessionState(): Promise<{
    hasToken: boolean;
    hasUser: boolean;
    hasTokenMismatch: boolean;
    hasMissingData: boolean;
    issues: string[];
  }> {
    const token = (global as any).__AUTH_TOKEN__;
    const user = (global as any).__AUTH_USER__;
    const proxyToken = (supabaseMCP as any).token;
    
    const diagnosis = {
      hasToken: !!token,
      hasUser: !!user,
      hasTokenMismatch: token !== proxyToken,
      hasMissingData: !token || !user,
      issues: [] as string[]
    };

    if (!diagnosis.hasToken) diagnosis.issues.push('Missing auth token');
    if (!diagnosis.hasUser) diagnosis.issues.push('Missing user data');
    if (diagnosis.hasTokenMismatch) diagnosis.issues.push('Token mismatch');
    
    return diagnosis;
  }

  private async synchronizeSessionState(): Promise<boolean> {
    try {
      const token = (global as any).__AUTH_TOKEN__;
      const user = (global as any).__AUTH_USER__;
      const proxyToken = (supabaseMCP as any).token;

      // Sync token if mismatch
      if (token && token !== proxyToken) {
        supabaseMCP.setToken(token);
        if (__DEV__) console.log('[SessionRecovery] Synced proxy token');
      } else if (proxyToken && !token) {
        (global as any).__AUTH_TOKEN__ = proxyToken;
        if (__DEV__) console.log('[SessionRecovery] Synced global token');
      }

      // Validate we have both token and user
      const finalToken = (global as any).__AUTH_TOKEN__;
      const finalUser = (global as any).__AUTH_USER__;
      
      return !!(finalToken && finalUser);
    } catch (error) {
      if (__DEV__) console.warn('[SessionRecovery] State sync failed:', error);
      return false;
    }
  }

  private async clearCorruptedState(): Promise<void> {
    try {
      // Clear all session state
      supabaseMCP.setToken(null);
      (global as any).__AUTH_TOKEN__ = null;
      (global as any).__AUTH_USER__ = null;
      
      if (__DEV__) console.log('[SessionRecovery] Cleared corrupted session state');
    } catch (error) {
      if (__DEV__) console.warn('[SessionRecovery] Failed to clear state:', error);
    }
  }

  private completeRecovery(attempt: RecoveryAttempt, success: boolean): boolean {
    this.isRecovering = false;
    
    if (this.recoveryTimeout) {
      clearTimeout(this.recoveryTimeout);
      this.recoveryTimeout = null;
    }

    attempt.endTime = Date.now();
    attempt.success = success;
    attempt.steps.push(`Recovery ${success ? 'completed successfully' : 'failed'}`);

    // Store attempt
    this.recoveryAttempts.unshift(attempt);
    if (this.recoveryAttempts.length > this.MAX_STORED_ATTEMPTS) {
      this.recoveryAttempts = this.recoveryAttempts.slice(0, this.MAX_STORED_ATTEMPTS);
    }

    const duration = attempt.endTime - attempt.startTime;
    
    // Track recovery result in analytics
    if (success) {
      trackRecoverySuccess(duration, { attemptId: attempt.id, type: attempt.type });
    } else {
      trackRecoveryFailure({ attemptId: attempt.id, error: attempt.error, type: attempt.type });
    }
    if (__DEV__) {
      if (__DEV__) console.log(`[SessionRecovery] Recovery ${success ? 'succeeded' : 'failed'} in ${duration}ms`);
    }

    return success;
  }

  // Public API
  isRecoveryInProgress(): boolean {
    return this.isRecovering;
  }

  getRecoveryHistory(): RecoveryAttempt[] {
    return [...this.recoveryAttempts];
  }

  getLastRecoveryAttempt(): RecoveryAttempt | null {
    return this.recoveryAttempts[0] || null;
  }

  updateConfig(newConfig: Partial<RecoveryConfig>): void {
    this.config = { ...this.config, ...newConfig };
    if (__DEV__) console.log('[SessionRecovery] Config updated:', this.config);
  }

  getConfig(): RecoveryConfig {
    return { ...this.config };
  }

  clearHistory(): void {
    this.recoveryAttempts = [];
    if (__DEV__) console.log('[SessionRecovery] Recovery history cleared');
  }

  // Manual recovery methods
  async recoverFromTokenMismatch(): Promise<boolean> {
    if (this.isRecovering) return false;
    return this.synchronizeSessionState();
  }

  async recoverFromCorruption(): Promise<boolean> {
    if (this.isRecovering) return false;
    await this.clearCorruptedState();
    sessionMonitor.forceHealthCheck();
    return true;
  }
}

// Export singleton instance
export const sessionRecovery = new SessionRecovery();