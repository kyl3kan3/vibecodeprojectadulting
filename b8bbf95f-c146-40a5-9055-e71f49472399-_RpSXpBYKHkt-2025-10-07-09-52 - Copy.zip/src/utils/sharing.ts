import { Share, Platform } from 'react-native';
import { AdultingTip } from '../types/adulting';

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career: 'Career',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social',
  transportation: 'Transportation',
  technology: 'Technology',
};

export const shareTip = async (tip: AdultingTip): Promise<boolean> => {
  try {
    const category = categoryLabels[tip.category];
    const shareText = `💡 Adulting Tip: ${tip.title}\n\n${tip.content?.overview || tip.description || 'No description available'}\n\n📂 Category: ${category}\n🎯 Difficulty: ${tip.difficulty}${tip.estimatedTime ? `\n⏱️ Time: ${tip.estimatedTime}` : ''}\n\nShared from ProjectAdulting 📱`;

    const shareOptions = {
      message: shareText,
      title: `Adulting Tip: ${tip.title}`,
    };

    const result = await Share.share(shareOptions);
    
    if (result.action === Share.sharedAction) {
      return true;
    }
    
    return false;
  } catch (error) {
    if (__DEV__) console.error('Error sharing tip:', error);
    return false;
  }
};

export const shareProgress = async (stats: {
  streakDays: number;
  completedTips: number;
  totalTips: number;
}): Promise<boolean> => {
  try {
    const completionPercentage = Math.round((stats.completedTips / stats.totalTips) * 100);
    
    const shareText = `🎯 My Adulting Progress!\n\n🔥 ${stats.streakDays} day streak\n✅ ${stats.completedTips}/${stats.totalTips} tips completed (${completionPercentage}%)\n\nBuilding life skills one tip at a time with ProjectAdulting! 📱`;

    const shareOptions = {
      message: shareText,
      title: 'My Adulting Progress',
    };

    const result = await Share.share(shareOptions);
    
    if (result.action === Share.sharedAction) {
      return true;
    }
    
    return false;
  } catch (error) {
    if (__DEV__) console.error('Error sharing progress:', error);
    return false;
  }
};

export const shareApp = async (): Promise<boolean> => {
  try {
    const shareText = `🌟 Just discovered ProjectAdulting!\n\nIt's helping me master essential life skills like finances, cooking, taxes, and more through daily bite-sized tips.\n\nPerfect for anyone figuring out adult life! 💪\n\nGet it now: [App Store Link]`;

    const shareOptions = {
      message: shareText,
      title: 'Check out ProjectAdulting!',
    };

    const result = await Share.share(shareOptions);
    
    if (result.action === Share.sharedAction) {
      return true;
    }
    
    return false;
  } catch (error) {
    if (__DEV__) console.error('Error sharing app:', error);
    return false;
  }
};