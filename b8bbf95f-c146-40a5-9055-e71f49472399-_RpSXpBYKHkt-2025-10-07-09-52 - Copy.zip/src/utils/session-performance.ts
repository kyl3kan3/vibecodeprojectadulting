/**
 * Session Performance Optimization Utilities
 * 
 * Provides utilities for optimizing session management performance:
 * - Memory cleanup
 * - Performance monitoring
 * - Resource usage optimization
 * - Automatic maintenance
 */

import { sessionAnalytics } from './session-analytics';
import { sessionMonitor } from './session-monitor';
import { sessionRecovery } from './session-recovery';

export interface PerformanceMetrics {
  memoryUsage: {
    eventsCount: number;
    alertsCount: number;
    recoveryAttemptsCount: number;
    listenersCount: number;
  };
  timing: {
    lastHealthCheck: number;
    averageHealthCheckDuration: number;
    lastRecoveryAttempt: number;
    sessionUptime: number;
  };
  efficiency: {
    healthCheckSuccess: number;
    recoverySuccessRate: number;
    cacheHitRate: number;
  };
}

export interface OptimizationResult {
  cleaned: {
    events: number;
    alerts: number;
    recoveryHistory: number;
  };
  timingSaved: number;
  memoryFreed: number; // Estimated in KB
}

class SessionPerformanceManager {
  private lastCleanupTime: number = 0;
  private cleanupIntervalMs: number = 30 * 60 * 1000; // 30 minutes
  private performanceHistory: Array<{
    timestamp: number;
    metrics: PerformanceMetrics;
  }> = [];
  
  private maxHistoryEntries: number = 50;

  /**
   * Get current performance metrics
   */
  getCurrentMetrics(): PerformanceMetrics {
    const analytics = sessionAnalytics as any;
    const monitor = sessionMonitor as any;
    const recovery = sessionRecovery as any;
    const healthStatus = sessionMonitor.getHealthStatus();
    const currentSession = sessionAnalytics.getCurrentSession();

    return {
      memoryUsage: {
        eventsCount: analytics.analytics?.events?.length || 0,
        alertsCount: monitor.alerts?.length || 0,
        recoveryAttemptsCount: recovery.recoveryAttempts?.length || 0,
        listenersCount: (analytics.analytics?.listeners?.length || 0) + 
                       (monitor.healthListeners?.length || 0) + 
                       (monitor.alertListeners?.length || 0)
      },
      timing: {
        lastHealthCheck: healthStatus?.lastCheck || 0,
        averageHealthCheckDuration: this.calculateAverageHealthCheckDuration(),
        lastRecoveryAttempt: recovery.getLastRecoveryAttempt()?.startTime || 0,
        sessionUptime: currentSession.duration || 0
      },
      efficiency: {
        healthCheckSuccess: healthStatus?.consecutiveFailures === 0 ? 100 : 
                           Math.max(0, 100 - (healthStatus?.consecutiveFailures || 0) * 10),
        recoverySuccessRate: this.calculateRecoverySuccessRate(),
        cacheHitRate: this.calculateCacheHitRate()
      }
    };
  }

  /**
   * Perform comprehensive cleanup of all session management components
   */
  performOptimization(force: boolean = false): OptimizationResult {
    const now = Date.now();
    
    if (!force && (now - this.lastCleanupTime) < this.cleanupIntervalMs) {
      return {
        cleaned: { events: 0, alerts: 0, recoveryHistory: 0 },
        timingSaved: 0,
        memoryFreed: 0
      };
    }

    const startTime = Date.now();
    
    // Clean up analytics events
    const cleanedEvents = sessionAnalytics.performMemoryCleanup();
    
    // Clean up monitoring alerts (keep only recent 25)
    const monitor = sessionMonitor as any;
    const initialAlerts = monitor.alerts?.length || 0;
    if (monitor.alerts && monitor.alerts.length > 25) {
      monitor.alerts.splice(25);
    }
    const cleanedAlerts = initialAlerts - (monitor.alerts?.length || 0);
    
    // Clean up recovery history (keep only recent 10)
    const recovery = sessionRecovery as any;
    const initialRecovery = recovery.recoveryAttempts?.length || 0;
    if (recovery.recoveryAttempts && recovery.recoveryAttempts.length > 10) {
      recovery.recoveryAttempts.splice(10);
    }
    const cleanedRecoveryHistory = initialRecovery - (recovery.recoveryAttempts?.length || 0);
    
    const afterMetrics = this.getCurrentMetrics();
    const endTime = Date.now();
    
    // Estimate memory saved (rough calculation)
    const estimatedMemoryFreed = (
      (cleanedEvents * 0.2) + // ~0.2KB per event
      (cleanedAlerts * 0.1) + // ~0.1KB per alert
      (cleanedRecoveryHistory * 0.5) // ~0.5KB per recovery attempt
    );
    
    this.lastCleanupTime = now;
    
    const result: OptimizationResult = {
      cleaned: {
        events: cleanedEvents,
        alerts: cleanedAlerts,
        recoveryHistory: cleanedRecoveryHistory
      },
      timingSaved: endTime - startTime,
      memoryFreed: Math.round(estimatedMemoryFreed)
    };
    
    // Store performance snapshot
    this.recordPerformanceSnapshot(afterMetrics);
    
    if (__DEV__) {
      if (__DEV__) console.log('[SessionPerformance] Optimization completed:', result);
    }
    
    return result;
  }

  /**
   * Set automatic optimization schedule
   */
  enableAutoOptimization(intervalMinutes: number = 30): () => void {
    this.cleanupIntervalMs = intervalMinutes * 60 * 1000;
    
    const optimizationInterval = setInterval(() => {
      const result = this.performOptimization();
      
      if (result.cleaned.events > 0 || result.cleaned.alerts > 0) {
        if (__DEV__) {
          if (__DEV__) console.log('[SessionPerformance] Auto-optimization triggered:', result);
        }
      }
    }, this.cleanupIntervalMs);
    
    if (__DEV__) {
      if (__DEV__) console.log(`[SessionPerformance] Auto-optimization enabled (every ${intervalMinutes}m)`);
    }
    
    return () => {
      clearInterval(optimizationInterval);
      if (__DEV__) {
        if (__DEV__) console.log('[SessionPerformance] Auto-optimization disabled');
      }
    };
  }

  /**
   * Get performance recommendations
   */
  getRecommendations(): string[] {
    const metrics = this.getCurrentMetrics();
    const recommendations: string[] = [];
    
    // Memory usage recommendations
    if (metrics.memoryUsage.eventsCount > 500) {
      recommendations.push('Consider reducing analytics event retention period');
    }
    
    if (metrics.memoryUsage.alertsCount > 50) {
      recommendations.push('Alert history is growing large - consider cleanup');
    }
    
    if (metrics.memoryUsage.recoveryAttemptsCount > 20) {
      recommendations.push('Recovery attempt history should be cleaned up');
    }
    
    // Efficiency recommendations
    if (metrics.efficiency.healthCheckSuccess < 80) {
      recommendations.push('Session health checks are failing frequently - investigate issues');
    }
    
    if (metrics.efficiency.recoverySuccessRate < 70) {
      recommendations.push('Session recovery success rate is low - review recovery logic');
    }
    
    // Timing recommendations
    if (metrics.timing.sessionUptime > 24 * 60 * 60 * 1000) {
      recommendations.push('Session has been active for over 24 hours - consider refresh');
    }
    
    if (this.performanceHistory.length > 10) {
      const recentTrend = this.analyzePerformanceTrend();
      if (recentTrend.declining) {
        recommendations.push('Performance is declining - consider immediate optimization');
      }
    }
    
    return recommendations;
  }

  /**
   * Get performance summary for debugging
   */
  getPerformanceSummary(): {
    current: PerformanceMetrics;
    recommendations: string[];
    lastOptimization: number;
    optimizationHistory: Array<{ timestamp: number; result: OptimizationResult }>;
  } {
    return {
      current: this.getCurrentMetrics(),
      recommendations: this.getRecommendations(),
      lastOptimization: this.lastCleanupTime,
      optimizationHistory: this.performanceHistory.map(entry => ({
        timestamp: entry.timestamp,
        result: {
          cleaned: { events: 0, alerts: 0, recoveryHistory: 0 },
          timingSaved: 0,
          memoryFreed: 0
        }
      })).slice(-10)
    };
  }

  /**
   * Analyze if performance is improving or declining
   */
  private analyzePerformanceTrend(): { declining: boolean; trend: number } {
    if (this.performanceHistory.length < 5) {
      return { declining: false, trend: 0 };
    }
    
    const recent = this.performanceHistory.slice(-5);
    const efficiency = recent.map(entry => 
      entry.metrics.efficiency.healthCheckSuccess + 
      entry.metrics.efficiency.recoverySuccessRate
    );
    
    let trend = 0;
    for (let i = 1; i < efficiency.length; i++) {
      trend += efficiency[i] - efficiency[i-1];
    }
    
    return {
      declining: trend < -20, // Significant decline
      trend: trend / (efficiency.length - 1)
    };
  }

  private recordPerformanceSnapshot(metrics: PerformanceMetrics): void {
    this.performanceHistory.push({
      timestamp: Date.now(),
      metrics
    });
    
    // Keep only recent history
    if (this.performanceHistory.length > this.maxHistoryEntries) {
      this.performanceHistory.splice(0, this.performanceHistory.length - this.maxHistoryEntries);
    }
  }

  private calculateAverageHealthCheckDuration(): number {
    // This would need to be tracked in the session monitor
    // For now, return a reasonable estimate
    return 50; // ~50ms average
  }

  private calculateRecoverySuccessRate(): number {
    const recovery = sessionRecovery as any;
    const attempts = recovery.recoveryAttempts || [];
    
    if (attempts.length === 0) return 100;
    
    const successful = attempts.filter((attempt: any) => attempt.success).length;
    return Math.round((successful / attempts.length) * 100);
  }

  private calculateCacheHitRate(): number {
    const analytics = sessionAnalytics as any;
    
    // Estimate cache hit rate based on metrics cache usage
    // This is a simplified calculation
    if (analytics.analytics?.metricsCacheTime > 0) {
      const cacheAge = Date.now() - analytics.analytics.metricsCacheTime;
      const cacheValidityMs = analytics.analytics.cacheValidityMs || 300000;
      
      if (cacheAge < cacheValidityMs) {
        return 85; // Estimate good cache usage
      }
    }
    
    return 60; // Default estimate
  }

  /**
   * Force garbage collection hint (if available)
   */
  forceGarbageCollection(): boolean {
    // In React Native, we can't directly force GC, but we can clear references
    try {
      // Clear any potential circular references
      const analytics = sessionAnalytics as any;
      
      // Force cache invalidation to clear cached objects
      if (analytics.invalidateCache) {
        analytics.invalidateCache();
      }
      
      if (__DEV__) {
        if (__DEV__) console.log('[SessionPerformance] Garbage collection hints applied');
      }
      
      return true;
    } catch (error) {
      if (__DEV__) {
        if (__DEV__) console.warn('[SessionPerformance] GC hints failed:', error);
      }
      return false;
    }
  }
}

// Export singleton instance
export const sessionPerformance = new SessionPerformanceManager();

// Convenience functions
export const optimizeSessionPerformance = () => sessionPerformance.performOptimization();
export const getSessionPerformanceMetrics = () => sessionPerformance.getCurrentMetrics();
export const getSessionPerformanceRecommendations = () => sessionPerformance.getRecommendations();
export const enableAutoSessionOptimization = (intervalMinutes?: number) => 
  sessionPerformance.enableAutoOptimization(intervalMinutes);