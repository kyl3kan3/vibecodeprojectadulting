/**
 * Test Utilities
 * Helper functions and mocks for testing
 */

import React from 'react';
import { render as rtlRender } from '@testing-library/react-native';
import type { RenderOptions } from '@testing-library/react-native';

// Mock store provider wrapper
export function TestProviders({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

// Custom render function with providers
export function render(
  ui: React.ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
) {
  return rtlRender(ui, { wrapper: TestProviders, ...options });
}

// Mock database service responses
export const mockDatabaseSuccess = <T,>(data: T) => ({
  success: true,
  data,
  error: null,
});

export const mockDatabaseError = (message: string) => ({
  success: false,
  data: null,
  error: { message, code: 'TEST_ERROR', retryable: false },
});

// Mock lesson data
export const mockLesson = {
  id: 'test-lesson-1',
  title: 'Test Lesson',
  description: 'A test lesson',
  category: 'personal_growth' as const,
  difficulty: 'starter' as const,
  estimatedTime: 30,
  xpReward: 50,
  tags: ['test'],
  content: {
    overview: 'Test overview',
    keyPoints: ['Point 1', 'Point 2'],
    stepByStep: [],
    tips: ['Tip 1'],
    resources: [],
    commonMistakes: [],
    stepResources: {},
  },
};

// Mock user progress
export const mockUserProgress = {
  id: 'progress-1',
  user_id: 'user-123',
  tip_id: 'tip-1',
  completed_at: '2025-09-30T00:00:00Z',
  difficulty_rating: 4,
  notes: 'Test notes',
  created_at: '2025-09-30T00:00:00Z',
};

// Mock navigation
export const mockNavigation = {
  navigate: jest.fn(),
  goBack: jest.fn(),
  reset: jest.fn(),
  setOptions: jest.fn(),
};

// Mock route
export const mockRoute = {
  params: {},
  key: 'test-route',
  name: 'TestScreen' as const,
};

// Re-export everything from RTL
export * from '@testing-library/react-native';
