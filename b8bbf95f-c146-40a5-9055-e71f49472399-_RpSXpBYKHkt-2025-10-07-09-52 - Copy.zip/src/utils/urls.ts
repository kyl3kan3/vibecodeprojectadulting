export function ensureHttpUrl(raw?: string | null): string | null {
  if (!raw) return null;
  const s = String(raw).trim();
  if (!s) return null;
  try {
    // Already has scheme
    if (/^https?:\/\//i.test(s)) {
      // Validate URL constructability
      const u = new URL(s);
      return u.toString();
    }
    // Bare domain patterns (example.com/path)
    if (/^([a-z0-9-]+\.)+[a-z]{2,}(\/[^\s]*)?$/i.test(s)) {
      const u = new URL(`https://${s}`);
      return u.toString();
    }
  } catch {
    return null;
  }
  return null;
}

export function extractFirstUrl(text?: string | null): string | null {
  if (!text) return null;
  const match = text.match(/https?:\/\/[^\s)]+/i);
  if (match && match[0]) {
    try {
      const u = new URL(match[0]);
      return u.toString();
    } catch {}
  }
  // Try bare domains
  const dm = text.match(/\b([a-z0-9-]+\.)+[a-z]{2,}(\/[\w\-._~:/?#[\]@!$&'()*+,;=%]*)?/i);
  if (dm && dm[0]) {
    const ensured = ensureHttpUrl(dm[0]);
    if (ensured) return ensured;
  }
  return null;
}

export function isProbablyUrl(s?: string | null): boolean {
  if (!s) return false;
  return /^https?:\/\//i.test(s) || /^([a-z0-9-]+\.)+[a-z]{2,}/i.test(s);
}
