import React from "react";
import { View, Text, ScrollView, Pressable, Linking, ActivityIndicator } from "react-native";
import * as WebBrowser from "expo-web-browser";
import { TERMS_URL, PRIVACY_URL } from "../utils/legal";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useUIStore } from "../state";
import { storekit, type SKProduct } from "../services/storekit";

export default function PaywallScreen() {
  const { setIsPro } = useUIStore();

  const [loading, setLoading] = React.useState(true);
  const [restoring, setRestoring] = React.useState(false);
  const [purchasing, setPurchasing] = React.useState<string | null>(null);
  const [packages, setPackages] = React.useState<SKProduct[]>([]);
  const [message, setMessage] = React.useState<string | null>(null);

  React.useEffect(() => {
    storekit.init();
    let mounted = true;
    (async () => {
      try {
        const { active } = await storekit.getActive();
        setIsPro(active);
        const prods = await storekit.getProducts();
        if (mounted) setPackages(prods);
      } catch (e) {
        if (mounted) setMessage("We could not load products. Try again soon.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [setIsPro]);

  const openManage = async () => {
    try { await Linking.openURL("itms-apps://apps.apple.com/account/subscriptions"); } catch {}
  };

  const onRestore = async () => {
    setMessage(null);
    setRestoring(true);
    try {
      const state = await storekit.restore();
      if (state === "restored") {
        setIsPro(true);
        setMessage("Purchases restored on this device.");
      } else if (state === "error") {
        setMessage("Restore failed. Please try again.");
      } else {
        setMessage("No active subscriptions found to restore.");
      }
    } catch {
      setMessage("Restore failed. Please try again.");
    } finally {
      setRestoring(false);
    }
  };

  const selectPlan = async (productId: string) => {
    setMessage(null);
    setPurchasing(productId);
    try {
      // Expo Go cannot present the Apple purchase sheet. Open Manage instead.
      let ownership: string | undefined = undefined;
      try { const Constants = require("expo-constants").default; ownership = Constants?.appOwnership; } catch {}
      if (ownership === "expo") {
        const ok = await storekit.openManageSubscriptions();
        setMessage(ok ? "Purchases are managed in the App Store on this build." : "Cannot open Apple Subscriptions here. Try from Settings > Apple ID > Subscriptions.");
        return;
      }

      const state = await storekit.purchase(productId);
      if (state === "purchased") {
        setIsPro(true);
        setMessage("You are now Pro. Enjoy!");
      } else if (state === "deferred") {
        setMessage("Purchase pending approval.");
      } else if (state === "error") {
        setMessage("Purchase failed. Please try again.");
      } else {
        setMessage("Purchase cancelled.");
      }
    } catch {
      setMessage("Could not complete purchase. Try again.");
    } finally {
      setPurchasing(null);
    }
  };

  const plansToRender: SKProduct[] = packages;

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: 32 }}>
        <View className="px-6 pt-8 pb-4">
          <View className="items-center">
            <View className="w-20 h-20 bg-emerald-500 rounded-full items-center justify-center mb-4">
              <Ionicons name="star" size={28} color="#111827" />
            </View>
            <Text className="text-white text-3xl font-black mb-2">Unlock Pro</Text>
            <Text className="text-gray-400 text-center">More AI answers, faster responses, and premium learning tools</Text>
          </View>
        </View>

        <View className="px-6">
          <View className="bg-yellow-500/10 border border-yellow-600 rounded-2xl p-3 mb-4">
            <Text className="text-yellow-400 text-sm">Purchases require a development or store build with StoreKit 2. In Expo Go they are unavailable.</Text>
          </View>
          {["200+ AI questions/month on Plus, Unlimited on Pro","Priority AI queue for faster replies","Personalized learning insights","Early access to new features"].map((f, i) => (
            <View key={i} className="flex-row items-center mb-3">
              <View className="w-6 h-6 bg-emerald-500 rounded-full items-center justify-center mr-3">
                <Ionicons name="checkmark" size={14} color="#111827" />
              </View>
              <Text className="text-white text-base flex-1">{f}</Text>
            </View>
          ))}
        </View>

        {loading ? (
          <View className="px-6 mt-6 items-center">
            <ActivityIndicator color="#10B981" />
            <Text className="text-gray-400 mt-3">Loading offers…</Text>
          </View>
        ) : (
          <View className="px-6 mt-6">
            {plansToRender.map((p) => (
              <Pressable
                key={p.id}
                onPress={() => selectPlan(p.id)}
                disabled={!!purchasing}
                className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4"
              >
                <View className="flex-row items-center justify-between">
                  <View>
                    <Text className="text-white text-xl font-black">{p.title}</Text>
                    <Text className="text-gray-400">{p.subscriptionPeriod === "P1Y" ? "Annual" : p.subscriptionPeriod === "P1W" ? "Weekly" : "Monthly"}</Text>
                  </View>
                  {purchasing === p.id ? (
                    <ActivityIndicator color="#10B981" />
                  ) : p.priceString ? (
                    <Text className="text-emerald-400 font-bold text-xl">{p.priceString}</Text>
                  ) : (
                    <Text className="text-emerald-400 font-bold text-xl">Subscribe</Text>
                  )}
                </View>
              </Pressable>
            ))}
            <Text className="text-gray-500 text-xs">*Fair use policy applies.</Text>
          </View>
        )}

        {message && (
          <View className="px-6 mt-4">
            <Text className="text-gray-300">{message}</Text>
          </View>
        )}

        <View className="px-6 mt-6">
          <View className="flex-row justify-between">
            <Pressable onPress={onRestore} disabled={restoring} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700">
              {restoring ? (
                <View className="flex-row items-center">
                  <ActivityIndicator color="#9CA3AF" />
                  <Text className="text-white font-bold ml-2">Restoring…</Text>
                </View>
              ) : (
                <Text className="text-white font-bold">Restore Purchases</Text>
              )}
            </Pressable>
            <Pressable onPress={openManage} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700">
              <Text className="text-white font-bold">Manage</Text>
            </Pressable>
          </View>
          <View className="flex-row justify-center mt-4">
            <Pressable onPress={() => WebBrowser.openBrowserAsync(TERMS_URL)}>
              <Text className="text-gray-400">Terms of Use</Text>
            </Pressable>
            <Text className="text-gray-700 mx-3">•</Text>
            <Pressable onPress={() => WebBrowser.openBrowserAsync(PRIVACY_URL)}>
              <Text className="text-gray-400">Privacy Policy</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
