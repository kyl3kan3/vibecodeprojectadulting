import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Switch, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useUIStore } from '../state';
import * as Notifications from 'expo-notifications';
import { DailyReminderService } from '../services/dailyReminders';

const timeSlots = [
  { label: '8:00 AM', value: '08:00' },
  { label: '12:00 PM', value: '12:00' },
  { label: '6:00 PM', value: '18:00' },
  { label: '8:00 PM', value: '20:00' },
];

const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function NotificationSettingsScreen() {
  const navigation = useNavigation();
  const { userProfile } = useUIStore();
  
  const [notificationsEnabled, setNotificationsEnabled] = useState(
    userProfile?.preferences?.notificationsEnabled ?? false
  );
  const [selectedTime, setSelectedTime] = useState(
    userProfile?.preferences?.reminderTime || '18:00'
  );
  const [selectedDays, setSelectedDays] = useState(
    userProfile?.preferences?.reminderDays || [1, 2, 3, 4, 5] // Mon-Fri
  );

  // Weekly digest
  const [weeklyEnabled, setWeeklyEnabled] = useState(
    userProfile?.preferences?.weeklyDigestEnabled ?? false
  );
  const [weeklyTime, setWeeklyTime] = useState(
    userProfile?.preferences?.weeklyDigestTime || '09:00'
  );
  const [weeklyDay, setWeeklyDay] = useState(
    typeof userProfile?.preferences?.weeklyDigestDay === 'number' ? userProfile?.preferences?.weeklyDigestDay! : 0
  );

  const requestNotificationPermission = async () => {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    
    if (finalStatus !== 'granted') {
      Alert.alert(
        'Permission Required',
        'Please enable notifications in your device settings to receive daily reminders.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'OK', style: 'default' }
        ]
      );
      return false;
    }
    
    return true;
  };

  const handleToggleNotifications = async (enabled: boolean) => {
    if (enabled) {
      const hasPermission = await requestNotificationPermission();
      if (!hasPermission) {
        return;
      }
    }

    setNotificationsEnabled(enabled);
    
    if (!userProfile) return;
    const updatedProfile = {
      ...userProfile,
      preferences: {
        ...userProfile?.preferences,
        notificationsEnabled: enabled,
        reminderTime: selectedTime,
        reminderDays: selectedDays,
      }
    };
    
    // App initialization happens in AuthContext
    await DailyReminderService.scheduleDailyReminders(updatedProfile);
    await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
  };

  const handleTimeChange = async (time: string) => {
    setSelectedTime(time);
    if (notificationsEnabled) {
      if (!userProfile) return;
      const updatedProfile = {
        ...userProfile,
        preferences: {
          ...userProfile?.preferences,
          notificationsEnabled,
          reminderTime: time,
          reminderDays: selectedDays,
        }
      };
      // App initialization happens in AuthContext
      await DailyReminderService.scheduleDailyReminders(updatedProfile);
      await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
    }
  };

  const handleDayToggle = async (day: number) => {
    const newDays = selectedDays.includes(day)
      ? selectedDays.filter(d => d !== day)
      : [...selectedDays, day].sort();
    
    setSelectedDays(newDays);
    if (notificationsEnabled) {
      if (!userProfile) return;
      const updatedProfile = {
        ...userProfile,
        preferences: {
          ...userProfile?.preferences,
          notificationsEnabled,
          reminderTime: selectedTime,
          reminderDays: newDays,
        }
      };
      // App initialization happens in AuthContext
      await DailyReminderService.scheduleDailyReminders(updatedProfile);
      await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
    }
  };

  const handleToggleWeekly = async (enabled: boolean) => {
    setWeeklyEnabled(enabled);
    if (!userProfile) return;
    const updatedProfile = {
      ...userProfile,
      preferences: {
        ...userProfile?.preferences,
        weeklyDigestEnabled: enabled,
        weeklyDigestTime: weeklyTime,
        weeklyDigestDay: weeklyDay,
      }
    };
    // App initialization happens in AuthContext
    await DailyReminderService.scheduleDailyReminders(updatedProfile);
    await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
  };

  const handleWeeklyTimeChange = async (time: string) => {
    setWeeklyTime(time);
    if (!userProfile) return;
    const updatedProfile = {
      ...userProfile,
      preferences: {
        ...userProfile?.preferences,
        weeklyDigestEnabled: weeklyEnabled,
        weeklyDigestTime: time,
        weeklyDigestDay: weeklyDay,
      }
    };
    // App initialization happens in AuthContext
    await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
  };

  const handleWeeklyDayChange = async (day: number) => {
    setWeeklyDay(day);
    if (!userProfile) return;
    const updatedProfile = {
      ...userProfile,
      preferences: {
        ...userProfile?.preferences,
        weeklyDigestEnabled: weeklyEnabled,
        weeklyDigestTime: weeklyTime,
        weeklyDigestDay: day,
      }
    };
    // App initialization happens in AuthContext
    await DailyReminderService.scheduleWeeklyDigest(updatedProfile);
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      {/* Header */}
      <View className="px-6 py-6 border-b border-gray-700">
        <View className="flex-row items-center">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="w-12 h-12 rounded-2xl bg-gray-800 border border-gray-700 items-center justify-center mr-4"
          >
            <Ionicons name="chevron-back" size={20} color="#10B981" />
          </Pressable>
          <Text className="text-white text-2xl font-black">Daily Reminders</Text>
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Toggle Section */}
        <View className="bg-gray-800 border border-gray-700 mx-6 mt-6 rounded-3xl">
          <View className="p-6">
            <View className="flex-row items-center justify-between">
              <View className="flex-1 mr-4">
                <Text className="text-white text-xl font-black mb-3">
                  Enable Daily Reminders
                </Text>
                <Text className="text-gray-400">
                  Get personalized daily adulting tips and build consistent habits
                </Text>
              </View>
              <Switch
                value={notificationsEnabled}
                onValueChange={handleToggleNotifications}
                trackColor={{ false: '#374151', true: '#065F46' }}
                thumbColor={notificationsEnabled ? '#10B981' : '#6B7280'}
              />
            </View>
          </View>
        </View>

        {notificationsEnabled && (
          <>
            {/* Time Selection */}
            <View className="bg-gray-800 border border-gray-700 mx-6 mt-4 rounded-3xl">
              <View className="p-6">
                <Text className="text-white text-xl font-black mb-4">
                  Reminder Time
                </Text>
                <View className="flex-row flex-wrap">
                  {timeSlots.map((slot) => (
                    <Pressable
                      key={slot.value}
                      onPress={() => handleTimeChange(slot.value)}
                      className={`mr-3 mb-3 px-4 py-3 rounded-xl border-2 ${
                        selectedTime === slot.value
                          ? 'border-emerald-500 bg-emerald-500/20'
                          : 'border-gray-600 bg-gray-700'
                      }`}
                    >
                      <Text className={`font-bold ${
                        selectedTime === slot.value ? 'text-emerald-400' : 'text-gray-300'
                      }`}>
                        {slot.label}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </View>

            {/* Days Selection */}
            <View className="bg-gray-800 border border-gray-700 mx-6 mt-4 rounded-3xl">
              <View className="p-6">
                <Text className="text-white text-xl font-black mb-4">
                  Reminder Days
                </Text>
                <View className="flex-row justify-between">
                  {dayLabels.map((day, index) => (
                    <Pressable
                      key={index}
                      onPress={() => handleDayToggle(index)}
                      className={`w-12 h-12 rounded-full items-center justify-center border-2 ${
                        selectedDays.includes(index)
                          ? 'border-emerald-500 bg-emerald-500/20'
                          : 'border-gray-600 bg-gray-700'
                      }`}
                    >
                      <Text className={`font-bold ${
                        selectedDays.includes(index) ? 'text-emerald-400' : 'text-gray-300'
                      }`}>
                        {day}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </View>

            {/* Preview */}
            <View className="bg-emerald-900/50 border border-emerald-700 mx-6 mt-4 rounded-3xl">
              <View className="p-6">
                <View className="flex-row items-center justify-between mb-4">
                  <View className="flex-row items-center">
                    <Ionicons name="notifications" size={20} color="#10B981" />
                    <Text className="text-lg font-bold text-emerald-400 ml-2">
                      PREVIEW
                    </Text>
                  </View>
                  <Pressable
                    onPress={async () => {
                      try {
                        const testProfile = {
                          ...userProfile,
                          preferences: {
                            ...userProfile?.preferences,
                            notificationsEnabled,
                            reminderTime: selectedTime,
                            reminderDays: selectedDays,
                          }
                        };
                        await DailyReminderService.sendTestNotification(testProfile);
                        Alert.alert('Test Sent!', 'Check your notifications in a few seconds.');
                      } catch (error) {
                        Alert.alert('Error', 'Could not send test notification.');
                      }
                    }}
                    className="bg-emerald-500 px-3 py-1 rounded-full"
                  >
                    <Text className="text-gray-900 text-xs font-bold">TEST</Text>
                  </Pressable>
                </View>
                <Text className="text-emerald-300 mb-2 font-semibold">
                  🎯 Ready to grow today?
                </Text>
                <Text className="text-emerald-400">
                  💰 Check your spending from yesterday - small habits lead to big savings!
                </Text>
                <Text className="text-emerald-500 text-sm mt-4 font-medium">
                  You'll receive personalized reminders {selectedDays.length > 0 ? 
                    `${selectedDays.length} day${selectedDays.length > 1 ? 's' : ''} a week` : 
                    'no days selected'
                  } at {timeSlots.find(slot => slot.value === selectedTime)?.label}
                </Text>
              </View>
            </View>
          </>
        )}

        {/* Weekly Digest */}
        <View className="bg-gray-800 border border-gray-700 mx-6 mt-4 rounded-3xl">
          <View className="p-6">
            <View className="flex-row items-center justify-between mb-4">
              <View className="flex-1 mr-4">
                <Text className="text-white text-xl font-black mb-1">Weekly Digest</Text>
                <Text className="text-gray-400">Sunday summary of your progress</Text>
              </View>
              <Switch
                value={weeklyEnabled}
                onValueChange={handleToggleWeekly}
                trackColor={{ false: '#374151', true: '#065F46' }}
                thumbColor={weeklyEnabled ? '#10B981' : '#6B7280'}
              />
            </View>

            {weeklyEnabled && (
              <>
                {/* Weekly Day */}
                <Text className="text-white text-base font-bold mb-3">Day</Text>
                <View className="flex-row justify-between mb-4">
                  {dayLabels.map((day, index) => (
                    <Pressable
                      key={index}
                      onPress={() => handleWeeklyDayChange(index)}
                      className={`w-12 h-12 rounded-full items-center justify-center border-2 ${
                        weeklyDay === index
                          ? 'border-emerald-500 bg-emerald-500/20'
                          : 'border-gray-600 bg-gray-700'
                      }`}
                    >
                      <Text className={`${weeklyDay === index ? 'text-emerald-400' : 'text-gray-300'} font-bold`}>
                        {day}
                      </Text>
                    </Pressable>
                  ))}
                </View>

                {/* Weekly Time */}
                <Text className="text-white text-base font-bold mb-3">Time</Text>
                <View className="flex-row flex-wrap">
                  {timeSlots.map((slot) => (
                    <Pressable
                      key={slot.value}
                      onPress={() => handleWeeklyTimeChange(slot.value)}
                      className={`mr-3 mb-3 px-4 py-3 rounded-xl border-2 ${
                        weeklyTime === slot.value
                          ? 'border-emerald-500 bg-emerald-500/20'
                          : 'border-gray-600 bg-gray-700'
                      }`}
                    >
                      <Text className={`font-bold ${
                        weeklyTime === slot.value ? 'text-emerald-400' : 'text-gray-300'
                      }`}>
                        {slot.label}
                      </Text>
                    </Pressable>
                  ))}
                </View>

                {/* Weekly Test */}
                <View className="bg-emerald-900/50 border border-emerald-700 rounded-2xl p-4 mt-4">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-emerald-400 font-bold">Preview</Text>
                    <Pressable onPress={async () => {
                      try {
                        const testProfile = {
                          ...userProfile,
                          preferences: {
                            ...userProfile?.preferences,
                            weeklyDigestEnabled: weeklyEnabled,
                            weeklyDigestTime: weeklyTime,
                            weeklyDigestDay: weeklyDay,
                          }
                        };
                        await DailyReminderService.sendWeeklyDigestTest(testProfile);
                        Alert.alert('Test Sent!', 'Check your notifications in a few seconds.');
                      } catch {}
                    }} className="bg-emerald-500 px-3 py-1 rounded-full">
                      <Text className="text-gray-900 text-xs font-bold">TEST</Text>
                    </Pressable>
                  </View>
                  <Text className="text-emerald-500 text-xs">Will send {dayLabels[weeklyDay]} at {timeSlots.find(t => t.value === weeklyTime)?.label}</Text>
                </View>
              </>
            )}
          </View>
        </View>

        {/* Tips Section */}
        <View className="bg-gray-800 border border-gray-700 mx-6 mt-4 mb-8 rounded-3xl">
          <View className="p-6">
            <View className="flex-row items-center mb-4">
              <Ionicons name="bulb" size={20} color="#8B5CF6" />
              <Text className="text-white text-xl font-black ml-2">
                Pro Tips
              </Text>
            </View>
            <View className="space-y-3">
              <Text className="text-gray-400">
                • Set reminders for times when you're usually free
              </Text>
              <Text className="text-gray-400">
                • Consistency is key - start with 3-4 days per week
              </Text>
              <Text className="text-gray-400">
                • You can always adjust these settings later
              </Text>
              <Text className="text-gray-400">
                • Turn off reminders anytime without losing your progress
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
