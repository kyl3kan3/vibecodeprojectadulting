import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { achievements as ALL } from "../types/achievements";
import { useProgressStore } from "../state";
import { useNavigation } from "@react-navigation/native";

export default function AchievementsScreen() {
  const navigation = useNavigation<any>();
  const { userProgress } = useProgressStore();
  const unlocked = new Set(userProgress.achievements);

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 pt-6 pb-4 border-b border-gray-800">
        <View className="flex-row items-center">
          <Pressable onPress={() => navigation.goBack()} className="w-12 h-12 rounded-2xl bg-gray-800 border border-gray-700 items-center justify-center mr-4">
            <Ionicons name="chevron-back" size={20} color="#10B981" />
          </Pressable>
          <Text className="text-white text-2xl font-black">Badges</Text>
        </View>
      </View>
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 24 }}>
        {ALL.map((a) => {
          const isUnlocked = unlocked.has(a.id);
          return (
            <View key={a.id} className={`rounded-3xl p-4 mb-3 border ${isUnlocked ? 'bg-emerald-900/20 border-emerald-700' : 'bg-gray-800 border-gray-700'}`}>
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-3">
                    <Ionicons name={a.icon as any} size={22} color="#111827" />
                  </View>
                  <View>
                    <Text className="text-white font-bold">{a.title}</Text>
                    <Text className="text-gray-400 text-sm">{a.description}</Text>
                  </View>
                </View>
                {isUnlocked ? (
                  <Ionicons name="checkmark-circle" size={22} color="#10B981" />
                ) : (
                  <Text className="text-gray-500 text-xs">Locked</Text>
                )}
              </View>
            </View>
          );
        })}
        <View className="h-10" />
      </ScrollView>
    </SafeAreaView>
  );
}
