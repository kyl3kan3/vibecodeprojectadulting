import React, { useState, useRef, useEffect } from 'react';
import { View, Text, ScrollView, TextInput, Pressable, KeyboardAvoidingView, Platform, Alert, Animated } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { SafeLinearGradient as LinearGradient } from "../components/SafeLinearGradient";
import { getCoachAIResponse } from '../api/chat-service';
import type { AIMessage } from '../types/ai';
import { useAIStore, useProgressStore, useUIStore } from '../state';
import { TipCategory } from '../types/adulting';
import { cn } from '../utils/cn';
import NetInfo from '@react-native-community/netinfo';


interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actionItems?: string[];
}

const quickQuestions = [
  { 
    text: "How do I get renter's insurance?", 
    category: "housing",
    icon: "home"
  },
  { 
    text: "What's a good credit score?", 
    category: "finances",
    icon: "card"
  },
  { 
    text: "How do I negotiate salary?", 
    category: "career",
    icon: "briefcase"
  },
  { 
    text: "Tax deductions for beginners?", 
    category: "taxes",
    icon: "document-text"
  },
  { 
    text: "Meal prep tips?", 
    category: "cooking",
    icon: "restaurant"
  },
  { 
    text: "Health insurance basics?", 
    category: "health",
    icon: "medical"
  },
];

export default function CoachScreen() {
  const insets = useSafeAreaInsets();
  const { addTodoItem } = useProgressStore();
  const { 
    startConversationTracking, 
    addConversationMessage, 
    endConversationAndGenerateModules,
    getPendingModuleSuggestions 
  } = useAIStore();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showQuickQuestions, setShowQuickQuestions] = useState(true);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Animate in the welcome message
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
    
    // Start conversation tracking
    const sessionId = startConversationTracking();
    setConversationId(sessionId);

    // NetInfo subscription
    const sub = NetInfo.addEventListener((state) => {
      setIsOffline(!(state.isConnected && state.isInternetReachable !== false));
    });
    return () => sub && sub();
  }, []);

  const navigation = useNavigation<any>();
  const isPro = useUIStore(s => s.isPro);
  const aiUsage = useProgressStore(s => s.aiUsage);
  const freeLimit = 3;
  const incrementAIUsage = useProgressStore(s => s.incrementAIUsage);
  const resetAIUsageMonthlyIfNeeded = useProgressStore(s => s.resetAIUsageMonthlyIfNeeded);

  useEffect(() => {
    resetAIUsageMonthlyIfNeeded();
  }, [resetAIUsageMonthlyIfNeeded]);



  const sendMessage = async (text: string) => {
    if (__DEV__) console.log('[CoachScreen] sendMessage called with text:', text);
    if (!text.trim() || isLoading) {
      if (__DEV__) console.log('[CoachScreen] Early return - empty text or loading');
      return;
    }

    // Subscription gate for free users
    if (!isPro) {
      resetAIUsageMonthlyIfNeeded();
      const count = useProgressStore.getState().aiUsage;
      const limit = 3;
        if (count >= limit) {
          navigation.navigate('SubscriptionSheet');
          return;
        }
      incrementAIUsage();
    }

    // Hide quick questions after first message
    if (showQuickQuestions) {
      setShowQuickQuestions(false);
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    // Track message in conversation
    if (conversationId) {
      addConversationMessage(conversationId, {
        id: userMessage.id,
        role: 'user',
        content: userMessage.content,
        timestamp: userMessage.timestamp
      });
    }

    try {
      if (__DEV__) console.log('[CoachScreen] Entering try block - about to make AI call');
      // Context prompt is now provided as a system message in aiMessages

      // Build messages for AI (system + short history + current user)
      const prefs = useUIStore.getState()?.userProfile?.preferences || {};
      const tone = (prefs as any).aiTone || 'friendly';
      const depth = (prefs as any).aiDepth || 'brief';
      const safety = (prefs as any).safetyMode ? 'Avoid sensitive, graphic, or adult-only topics. Keep content safe and respectful.' : '';
      const systemPrompt = `You are an expert Project Adulting AI assistant helping young adults (18-30) with practical life skills.
Use a ${tone} tone and keep explanations ${depth}. Provide concise, actionable guidance with numbered steps when appropriate. Keep it US-focused unless asked otherwise, and encourage professional consultation when needed.
${safety}

IMPORTANT: Always include specific, actionable steps that users can add to their todo list. Format action items clearly as numbered lists that can be automatically parsed and added to their todo list. Focus on concrete next steps they can take today.`;
      const cleanedHistory: AIMessage[] = messages
        .filter(m => !(m.role === 'assistant' && (m.content.toLowerCase().includes('projectadulting coach') || m.content.toLowerCase().includes('ask me anything'))))
        .filter(m => !(m.role === 'assistant' && (m.content.trim().length < 40)))
        .slice(-4)
        .map(m => ({ role: m.role, content: m.content }));
      const aiMessages: AIMessage[] = [
        { role: 'system', content: systemPrompt },
        ...cleanedHistory,
        { role: 'user', content: text.trim() }
      ];

      if (__DEV__) console.log('[CoachScreen] About to call getCoachAIResponse with', aiMessages.length, 'messages');
      let response = await getCoachAIResponse(aiMessages, { model: 'gpt-4o-mini', temperature: 0.2, maxTokens: 700 });
      if (__DEV__) console.log('[CoachScreen] Got response:', response);

      // Anti-generic guard: retry once with stricter instruction if needed
      const isGeneric = (s: string) => {
        const t = s.trim().toLowerCase();
        if (t.length < 40) return true;
        const phrases = [
          "how can i help", "how can i assist", "what can i help", "how may i assist", "how may i help", "how can we help",
          "happy to help", "how can i support", "let me know how i can", "how can i be of assistance"
        ];
        return phrases.some(p => t.includes(p));
      };
      if (isGeneric(response.content)) {
        const stricter: AIMessage[] = [
          { role: 'system', content: systemPrompt + "\nDo not ask how you can help. Provide concrete, step-by-step guidance immediately." },
          ...cleanedHistory,
          { role: 'user', content: text.trim() }
        ];
        try { response = await getCoachAIResponse(stricter, { model: 'gpt-4o-mini', temperature: 0.2, maxTokens: 700 }); } catch {}
        if (isGeneric(response.content)) {
          response = { content: `Here is a practical plan you can start now for \"${text.trim()}\":\n1. Define a clear next step you can do in 20 minutes.\n2. Gather any info or documents you will need.\n3. Take that step today and set a reminder for the next step.\n4. Tell me your situation (age, state, budget) and I will tailor exact steps.` } as any;
        }
      }

      // Parse action items from response
      const actionItems = parseActionItems(response.content);
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        actionItems: actionItems.length > 0 ? actionItems : undefined,
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Track assistant message and check for module generation
      if (conversationId) {
        addConversationMessage(conversationId, {
          id: assistantMessage.id,
          role: 'assistant',
          content: assistantMessage.content,
          timestamp: assistantMessage.timestamp,
          actionItems: actionItems.length > 0 ? actionItems : undefined
        });

        // Check if we should generate modules (after 6+ messages)
        if (messages.length >= 5) {
          setTimeout(async () => {
            try {
              const suggestions = await endConversationAndGenerateModules(conversationId);
              if (suggestions.length > 0) {
                Alert.alert(
                  'New Learning Module Available! 🎓',
                  `I've created a personalized learning module "${suggestions[0].module.title}" based on our conversation. Check your Skills section to review it!`,
                  [{ text: 'Got it!', style: 'default' }]
                );
              }
            } catch (error) {
              if (__DEV__) console.error('Module generation error:', error);
            }
          }, 2000);
        }
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      if (__DEV__) console.error('AI Chat Error:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `I'm having trouble connecting right now. Error: ${msg}. Please try again in a moment! 🤖`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }

    // Scroll to bottom after a short delay
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const handleQuickQuestion = (question: string) => {
    sendMessage(question);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const parseActionItems = (content: string): string[] => {
    // First try to find explicit "ACTION ITEMS:" section
    const actionItemsRegex = /ACTION ITEMS?:\s*((?:\d+\..*(?:\n|$))+)/i;
    const match = content.match(actionItemsRegex);
    
    if (match) {
      const actionItemsText = match[1];
      const items = actionItemsText
        .split(/\d+\./)
        .filter(item => item.trim())
        .map(item => item.trim().replace(/\n/g, ' '))
        .filter(item => item.length > 0);
      
      return items;
    }
    
    // Fallback: Look for numbered lists that might be action items
    const numberedListRegex = /(?:^|\n)\d+\.\s+(.+?)(?=\n\d+\.|\n\n|$)/g;
    const numberedMatches = [...content.matchAll(numberedListRegex)];
    
    if (numberedMatches.length > 0) {
      const potentialActions = numberedMatches
        .map(match => match[1].trim())
        .filter(item => {
          // Filter for actionable items (contains action verbs)
          const actionVerbs = ['start', 'create', 'set up', 'contact', 'apply', 'research', 'call', 'visit', 'download', 'open', 'check', 'review', 'compare', 'gather', 'schedule', 'practice', 'learn', 'find', 'get', 'make', 'build', 'track', 'organize', 'update', 'sign up', 'register'];
          return actionVerbs.some(verb => item.toLowerCase().includes(verb));
        });
      
      if (potentialActions.length > 0) {
        return potentialActions.slice(0, 5); // Limit to 5 items
      }
    }
    
    // Final fallback: Look for bullet points with action verbs
    const bulletRegex = /(?:^|\n)[-•*]\s+(.+?)(?=\n[-•*]|\n\n|$)/g;
    const bulletMatches = [...content.matchAll(bulletRegex)];
    
    if (bulletMatches.length > 0) {
      const potentialActions = bulletMatches
        .map(match => match[1].trim())
        .filter(item => {
          const actionVerbs = ['start', 'create', 'set up', 'contact', 'apply', 'research', 'call', 'visit', 'download', 'open', 'check', 'review', 'compare', 'gather', 'schedule', 'practice', 'learn', 'find', 'get', 'make', 'build', 'track', 'organize', 'update', 'sign up', 'register'];
          return actionVerbs.some(verb => item.toLowerCase().includes(verb));
        });
      
      return potentialActions.slice(0, 3); // Limit to 3 items for bullet points
    }
    
    return [];
  };

  const addActionToTodo = (action: string, messageId: string) => {
    const category = determineCategory(action);
    addTodoItem({
      title: action,
      description: `From AI Coach conversation`,
      category: category,
      completed: false,
    });
    
    Alert.alert("Added to Todo! ✅", "This action has been added to your todo list.");
  };

  const determineCategory = (action: string): TipCategory => {
    const actionLower = action.toLowerCase();
    
    if (actionLower.includes('budget') || actionLower.includes('money') || actionLower.includes('save') || actionLower.includes('invest')) {
      return 'finances';
    } else if (actionLower.includes('job') || actionLower.includes('resume') || actionLower.includes('interview') || actionLower.includes('career')) {
      return 'career';
    } else if (actionLower.includes('cook') || actionLower.includes('meal') || actionLower.includes('food')) {
      return 'cooking';
    } else if (actionLower.includes('health') || actionLower.includes('doctor') || actionLower.includes('exercise')) {
      return 'healthcare';
    } else if (actionLower.includes('insurance')) {
      return 'health_insurance';
    } else if (actionLower.includes('tax')) {
      return 'taxes';
    } else if (actionLower.includes('house') || actionLower.includes('rent') || actionLower.includes('apartment')) {
      return 'housing';
    } else if (actionLower.includes('clean') || actionLower.includes('organize')) {
      return 'organization';
    }
    
    return 'education'; // default category
  };

  const clearChat = () => {
    setMessages([]);
    setShowQuickQuestions(true);
    
    // End current conversation and start new one
    if (conversationId) {
      endConversationAndGenerateModules(conversationId);
    }
    const newSessionId = startConversationTracking();
    setConversationId(newSessionId);
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <KeyboardAvoidingView 
        className="flex-1" 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View className="bg-gray-800 border-b border-gray-700 px-6 py-6">
          <View className="flex-row items-center justify-between">
            <View className="flex-1">
              <Text className="text-white text-3xl font-black">Your Coach</Text>
              <Text className="text-gray-400 text-base">Ask me anything about adulting!</Text>
            </View>
            <View className="w-16 h-16 bg-emerald-500 rounded-full items-center justify-center">
              <Ionicons name="chatbubble-ellipses" size={24} color="#111827" />
            </View>
          </View>
          {isOffline && (
            <View className="mt-3 bg-yellow-100 border border-yellow-300 rounded-2xl p-3">
              <Text className="text-yellow-800 text-sm">You are offline. Messages will send when you are back online.</Text>
            </View>
          )}
          {messages.length > 0 && (
            <Pressable
              onPress={clearChat}
              className="bg-emerald-500 rounded-2xl px-4 py-2 self-start mt-4"
            >
              <Text className="text-gray-900 text-sm font-bold">NEW CHAT</Text>
            </Pressable>
          )}
        </View>

        {/* Chat Area */}
        <ScrollView 
          ref={scrollViewRef}
          className="flex-1 px-4"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingTop: 16, paddingBottom: 16 }}
        >
          {/* Welcome Message */}
          {showQuickQuestions && (
            <Animated.View style={{ opacity: fadeAnim }}>
              <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-6">
                <View className="flex-row items-center mb-4">
                  <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-4">
                    <Ionicons name="sparkles" size={24} color="#111827" />
                  </View>
                  <Text className="text-white font-black text-xl">Welcome to your personal coach!</Text>
                </View>
                <Text className="text-gray-400 leading-relaxed mb-6">
                  I'm here to help you navigate the challenges of adult life. Whether you need advice on finances, career, health, cooking, or any other life skills, just ask! 
                  Free users get {freeLimit} AI messages per month. Upgrade to Pro for unlimited coaching!
                </Text>
                
                {/* Quick Questions */}
                <Text className="text-white font-black mb-4">POPULAR QUESTIONS:</Text>
                <View className="space-y-3">
                  {quickQuestions.map((question, index) => (
                    <Pressable
                      key={index}
                      onPress={() => handleQuickQuestion(question.text)}
                      className="bg-gray-700 rounded-2xl p-4 flex-row items-center"
                    >
                      <View className="w-10 h-10 bg-emerald-500 rounded-xl items-center justify-center mr-3">
                        <Ionicons name={question.icon as any} size={20} color="#111827" />
                      </View>
                      <Text className="text-white flex-1 font-medium">{question.text}</Text>
                      <Ionicons name="arrow-forward" size={20} color="#10B981" />
                    </Pressable>
                  ))}
                </View>
              </View>
            </Animated.View>
          )}

          {/* Subscription Upgrade Prompt */}
          {!isPro && aiUsage >= Math.floor(freeLimit * 0.8) && aiUsage < freeLimit && (
            <View className="mb-4 max-w-[85%] self-start">
              <View className="bg-gradient-to-r from-amber-500 to-orange-500 border border-amber-400 rounded-3xl rounded-bl-lg p-4">
                <View className="flex-row items-center mb-3">
                  <View className="w-8 h-8 bg-white rounded-full items-center justify-center mr-3">
                    <Ionicons name="star" size={16} color="#F59E0B" />
                  </View>
                  <Text className="text-white font-bold text-lg">Upgrade to Pro!</Text>
                </View>
                <Text className="text-white text-sm leading-relaxed mb-4">
                  You've used {aiUsage} of {freeLimit} free AI messages this month. Upgrade to Pro for unlimited coaching!
                </Text>
                <Pressable
                  onPress={() => navigation.navigate('SubscriptionSheet' as never)}
                  className="bg-white rounded-2xl px-6 py-3 self-start"
                >
                  <Text className="text-amber-600 font-bold">Upgrade Now</Text>
                </Pressable>
              </View>
            </View>
          )}

          {/* Chat Messages */}
          {messages.map((message) => (
            <View
              key={message.id}
              className={cn(
                "mb-4 max-w-[85%]",
                message.role === 'user' ? "self-end" : "self-start"
              )}
            >
              <View
                className={cn(
                  "rounded-3xl p-4",
                  message.role === 'user'
                    ? "bg-emerald-500 rounded-br-lg"
                    : "bg-gray-800 border border-gray-700 rounded-bl-lg"
                )}
              >
                {message.role === 'assistant' && (
                  <View className="flex-row items-center mb-2">
                    <View className="w-6 h-6 bg-emerald-500 rounded-full items-center justify-center mr-2">
                      <Ionicons name="sparkles" size={12} color="#111827" />
                    </View>
                    <Text className="text-emerald-400 text-xs font-bold uppercase tracking-wide">
                      COACH
                    </Text>
                  </View>
                )}
                <Text
                  className={cn(
                    "text-base leading-relaxed",
                    message.role === 'user' ? "text-gray-900 font-medium" : "text-white"
                  )}
                >
                  {message.content}
                </Text>
                
                {/* Action Items */}
                {message.role === 'assistant' && message.actionItems && message.actionItems.length > 0 && (
                  <View className="mt-4 border-t border-gray-600 pt-4">
                    <Text className="text-emerald-400 text-sm font-bold mb-3 uppercase tracking-wide">
                      Quick Actions
                    </Text>
                    {message.actionItems.map((action, index) => (
                      <Pressable
                        key={index}
                        onPress={() => addActionToTodo(action, message.id)}
                        className="bg-gray-700 border border-gray-600 rounded-2xl p-3 mb-2 flex-row items-center"
                      >
                        <View className="w-6 h-6 bg-emerald-500 rounded-full items-center justify-center mr-3">
                          <Text className="text-gray-900 text-xs font-bold">{index + 1}</Text>
                        </View>
                        <Text className="text-white flex-1 text-sm leading-relaxed">{action}</Text>
                        <View className="flex-row items-center ml-2">
                          <Ionicons name="add-circle-outline" size={16} color="#10B981" />
                          <Text className="text-emerald-400 text-xs font-bold ml-1">ADD</Text>
                        </View>
                      </Pressable>
                    ))}
                  </View>
                )}
              </View>
              <Text
                className={cn(
                  "text-xs text-gray-400 mt-1 px-2",
                  message.role === 'user' ? "text-right" : "text-left"
                )}
              >
                {formatTime(message.timestamp)}
              </Text>
            </View>
          ))}

          {/* Loading indicator */}
          {isLoading && (
            <View className="mb-4 max-w-[85%] self-start">
              <View className="bg-white border border-gray-100 rounded-3xl rounded-bl-lg p-4 shadow-sm">
                <View className="flex-row items-center mb-2">
                  <View className="w-6 h-6 bg-purple-100 rounded-full items-center justify-center mr-2">
                    <Ionicons name="sparkles" size={12} color="#8B5CF6" />
                  </View>
                  <Text className="text-purple-600 text-xs font-semibold uppercase tracking-wide">
                    Coach
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <View className="flex-row space-x-1 mr-3">
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                  </View>
                  <Text className="text-gray-500 text-sm">Thinking...</Text>
                </View>
              </View>
            </View>
          )}
        </ScrollView>

        {/* Input Area */}
        <View className="bg-gray-800 border-t border-gray-700 px-4 py-4" style={{ paddingBottom: insets.bottom + 16 }}>
          <View className="flex-row items-end space-x-3">
            <View className="flex-1 bg-gray-700 rounded-3xl px-5 py-3">
              <TextInput
                value={inputText}
                onChangeText={setInputText}
                placeholder="Ask me anything..."
                placeholderTextColor="#9CA3AF"
                multiline
                maxLength={500}
                className="text-white text-base max-h-24"
                onSubmitEditing={() => sendMessage(inputText)}
                blurOnSubmit={false}
              />
            </View>
            <Pressable
              onPress={() => sendMessage(inputText)}
              disabled={!inputText.trim() || isLoading}
            >
              {inputText.trim() && !isLoading ? (
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={{ width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' }}
                >
                  <Ionicons 
                    name="send" 
                    size={20} 
                    color="#111827" 
                  />
                </LinearGradient>
              ) : (
                <View className="w-12 h-12 rounded-full items-center justify-center bg-gray-600">
                  <Ionicons 
                    name="send" 
                    size={20} 
                    color="#9CA3AF" 
                  />
                </View>
              )}
            </Pressable>
          </View>
          
          {/* Character count */}
          {inputText.length > 0 && (
            <Text className="text-xs text-gray-400 text-right mt-2 mr-16">
              {inputText.length}/500
            </Text>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
