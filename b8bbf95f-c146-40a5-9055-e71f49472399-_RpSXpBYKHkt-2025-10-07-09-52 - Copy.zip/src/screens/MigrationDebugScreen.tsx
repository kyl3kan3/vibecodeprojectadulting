/**
 * Migration Debug Screen
 * Shows what's in the old store to help diagnose migration issues
 */

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

export default function MigrationDebugScreen() {
  const navigation = useNavigation();
  const [oldStoreData, setOldStoreData] = useState<any>(null);
  const [migrationComplete, setMigrationComplete] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const oldStore = await AsyncStorage.getItem('project-adulting-store');
      const migrationFlag = await AsyncStorage.getItem('phase1-migration-complete');
      
      if (oldStore) {
        const parsed = JSON.parse(oldStore);
        setOldStoreData(parsed.state || null);
      }
      
      setMigrationComplete(migrationFlag === 'true');
    } catch (error) {
      if (__DEV__) console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  if (loading) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 items-center justify-center">
          <Text className="text-white">Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 py-4 border-b border-gray-800">
        <View className="flex-row items-center">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </Pressable>
          <Text className="text-white text-2xl font-bold">Migration Debug</Text>
        </View>
      </View>

      <ScrollView className="flex-1 px-6 py-4">
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">Migration Status</Text>
          <Text className={migrationComplete ? 'text-green-400' : 'text-yellow-400'}>
            {migrationComplete ? '✅ Complete' : '⏳ Not Run'}
          </Text>
        </View>

        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">Old Store Exists?</Text>
          <Text className={oldStoreData ? 'text-green-400' : 'text-red-400'}>
            {oldStoreData ? '✅ Yes' : '❌ No'}
          </Text>
        </View>

        {oldStoreData && (
          <>
            <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
              <Text className="text-white text-lg font-bold mb-3">📚 Old Store Data</Text>
              <View className="space-y-2">
                <Text className="text-gray-300">Skills: <Text className="text-white font-bold">{oldStoreData.skills?.length || 0}</Text></Text>
                <Text className="text-gray-300">Completed Skills: <Text className="text-white font-bold">{oldStoreData.completedSkills?.length || 0}</Text></Text>
                <Text className="text-gray-300">Total XP: <Text className="text-white font-bold">{oldStoreData.totalXP || 0}</Text></Text>
                <Text className="text-gray-300">User Name: <Text className="text-white font-bold">{oldStoreData.userProfile?.name || oldStoreData.user?.name || 'Not set'}</Text></Text>
                <Text className="text-gray-300">Age: <Text className="text-white font-bold">{oldStoreData.userProfile?.age || 'Not set'}</Text></Text>
                <Text className="text-gray-300">Streak (old): <Text className="text-white font-bold">{oldStoreData.userProgress?.streak || oldStoreData.userProgress?.streakDays || 0}</Text></Text>
              </View>
            </View>

            <View className="bg-blue-800 rounded-2xl p-4 mb-4">
              <Text className="text-white text-sm font-bold mb-2">🔍 Debug Info</Text>
              <Text className="text-blue-200 text-xs">CompletedSkills type: {typeof oldStoreData.completedSkills}</Text>
              <Text className="text-blue-200 text-xs">Is Array: {Array.isArray(oldStoreData.completedSkills) ? 'Yes' : 'No'}</Text>
              <Text className="text-blue-200 text-xs">UserProfile exists: {oldStoreData.userProfile ? 'Yes' : 'No'}</Text>
              <Text className="text-blue-200 text-xs">UserProgress exists: {oldStoreData.userProgress ? 'Yes' : 'No'}</Text>
              
              {oldStoreData.completedSkills && oldStoreData.completedSkills.length > 0 && (
                <View className="mt-2">
                  <Text className="text-blue-200 text-xs">First completed skill: {oldStoreData.completedSkills[0]}</Text>
                </View>
              )}
            </View>
          </>
        )}

        <Pressable 
          onPress={loadData}
          className="bg-blue-600 rounded-2xl p-4 items-center mb-4"
        >
          <Text className="text-white font-bold">🔄 Refresh</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}
