import React from "react";
import { View, Text, Pressable, TextInput, FlatList } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { HOW_TO_GUIDES } from "../data/how-to-guides";
import NetInfo from "@react-native-community/netinfo";
import { useNavigation } from "@react-navigation/native";
import { useUIStore } from "../state";

const categoryLabel = (key?: string) => {
  const map: Record<string, string> = {
    finances: "Money Mastery",
    housing: "Housing",
    taxes: "Taxes",
    cooking: "Cooking",
    credit: "Credit",
    career: "Career Growth",
  };
  return (key && map[key]) || (key ? key.replace(/_/g, " ") : "General");
};

const difficultyPill = (d: string) => ({
  bg: d === "advanced" ? "#7F1D1D" : d === "intermediate" ? "#78350F" : "#064E3B",
  fg: d === "advanced" ? "#FCA5A5" : d === "intermediate" ? "#FCD34D" : "#A7F3D0",
});

export default function HowToGuidesScreen() {
  const [query, setQuery] = React.useState("");
  const [selectedCategory, setSelectedCategory] = React.useState<string | "all">("all");
  const [selectedDifficulty, setSelectedDifficulty] = React.useState<"all" | "beginner" | "intermediate" | "advanced">("all");
  const [offline, setOffline] = React.useState(false);

  React.useEffect(() => {
    const sub = NetInfo.addEventListener((s) => setOffline(!(s.isConnected && s.isInternetReachable !== false)));
    return () => sub && sub();
  }, []);

  const guides = React.useMemo(() => {
    return HOW_TO_GUIDES.filter((g) => {
      const q = query.trim().toLowerCase();
      const qMatch = !q || g.title.toLowerCase().includes(q) || g.description.toLowerCase().includes(q);
      const cMatch = selectedCategory === "all" || g.category === selectedCategory;
      const dMatch = selectedDifficulty === "all" || g.difficulty === selectedDifficulty;
      return qMatch && cMatch && dMatch;
    });
  }, [query, selectedCategory, selectedDifficulty]);

  const renderItem = ({ item }: { item: typeof HOW_TO_GUIDES[number] }) => {
    const total = item.steps.length;
    const pct = useUIStore.getState().getGuideProgressPct(item.id);
    const diff = difficultyPill(item.difficulty);

    return (
      <Pressable
        onPress={() => {
          try {
            const nav: any = require("@react-navigation/native").useNavigation?.();
            nav?.navigate?.("GuideDetail" as never, { guideId: item.id } as never);
          } catch {}
        }}
        className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4"
      >
        <View className="flex-row items-center justify-between mb-3">
          <View className="flex-row items-center">
            <View className="bg-emerald-500 px-3 py-1 rounded-full mr-3">
              <Text className="text-xs font-bold text-gray-900">{categoryLabel(String(item.category)).toUpperCase()}</Text>
            </View>
            <View style={{ backgroundColor: diff.bg }} className="px-3 py-1 rounded-full">
              <Text style={{ color: diff.fg }} className="text-xs font-bold capitalize">{item.difficulty}</Text>
            </View>
          </View>
          <View className="items-end">
            <Text className="text-emerald-400 font-bold">{pct}%</Text>
            <Text className="text-gray-400 text-xs">complete</Text>
          </View>
        </View>
        <Text className="text-white text-xl font-black mb-1">{item.title}</Text>
        <Text className="text-gray-400 mb-3" numberOfLines={2}>{item.description}</Text>
        <View className="flex-row items-center justify-between">
          <Text className="text-gray-400 text-sm">⏱️ {item.estimatedTime}</Text>
          <View className="flex-row items-center">
            <Text className="text-emerald-400 text-sm font-bold mr-2">VIEW GUIDE</Text>
            <Ionicons name="chevron-forward" size={18} color="#10B981" />
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 pt-6 pb-4">
        <Text className="text-white text-3xl font-black mb-6">How‑To Guides</Text>
        <View className="relative mb-4">
          <Ionicons name="search" size={20} color="#6B7280" style={{ position: "absolute", left: 16, top: 14 }} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search guides..."
            placeholderTextColor="#6B7280"
            className="bg-gray-800 border border-gray-700 rounded-3xl pl-12 pr-4 py-4 text-white"
          />
          {query.length > 0 && (
            <Pressable onPress={() => setQuery("")} style={{ position: "absolute", right: 16, top: 14 }}>
              <Ionicons name="close-circle" size={20} color="#6B7280" />
            </Pressable>
          )}
        </View>

        {/* Filters */}
        <View className="flex-row mb-2">
          {(["all", "finances", "housing", "taxes", "cooking", "credit", "career"] as const).map((c) => (
            <Pressable key={c} onPress={() => setSelectedCategory(c as any)} className="mr-2 mb-2">
              {selectedCategory === c ? (
                <View className="bg-emerald-600 px-3 py-2 rounded-full">
                  <Text className="text-gray-900 font-bold text-xs">{categoryLabel(String(c)).toUpperCase()}</Text>
                </View>
              ) : (
                <View className="bg-gray-800 border border-gray-700 px-3 py-2 rounded-full">
                  <Text className="text-gray-400 font-bold text-xs">{categoryLabel(String(c)).toUpperCase()}</Text>
                </View>
              )}
            </Pressable>
          ))}
        </View>

        <View className="flex-row mb-4">
          {(["all", "beginner", "intermediate", "advanced"] as const).map((d) => (
            <Pressable key={d} onPress={() => setSelectedDifficulty(d as any)} className="mr-2 mb-2">
              {selectedDifficulty === d ? (
                <View className="bg-emerald-600 px-3 py-2 rounded-full">
                  <Text className="text-gray-900 font-bold text-xs">{String(d).toUpperCase()}</Text>
                </View>
              ) : (
                <View className="bg-gray-800 border border-gray-700 px-3 py-2 rounded-full">
                  <Text className="text-gray-400 font-bold text-xs">{String(d).toUpperCase()}</Text>
                </View>
              )}
            </Pressable>
          ))}
        </View>

        {offline && (
          <View className="bg-yellow-500/10 border border-yellow-600 rounded-2xl p-3 mb-2">
            <Text className="text-yellow-400 text-sm">Offline mode: AI features limited. Guides are available.</Text>
          </View>
        )}
      </View>

      <FlatList
        data={guides}
        renderItem={renderItem}
        keyExtractor={(g) => g.id}
        contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 100 }}
        ListEmptyComponent={
          <View className="items-center py-16">
            <Ionicons name="search-outline" size={56} color="#6B7280" />
            <Text className="text-white text-xl font-black mt-3">No Guides Found</Text>
            <Text className="text-gray-400 mt-2">Try different filters or search terms</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}
