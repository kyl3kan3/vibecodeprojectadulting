import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, Linking } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../utils/cn';

interface TipDetailScreenProps {
  tipId?: string;
  onClose?: () => void;
  tip?: any; // Pass tip data as prop
}

const categoryColors: Record<string, string> = {
  finances: '#10B981',
  health_insurance: '#3B82F6',
  cooking: '#F59E0B',
  laundry: '#8B5CF6',
  taxes: '#EF4444',
  housing: '#06B6D4',
  career_work: '#6366F1',
  legal: '#84CC16',
  maintenance: '#F97316',
  social: '#EC4899',
  credit: '#7C3AED',
  fitness: '#EF4444',
  mental_health: '#06B6D4',
  healthcare: '#10B981',
  relationships: '#F59E0B',
  education: '#3B82F6',
  personal_care: '#8B5CF6',
  safety: '#EF4444',
  transportation: '#6366F1',
  technology: '#84CC16',
  nutrition: '#F97316',
  shopping: '#EC4899',
  time_management: '#10B981',
  communication: '#3B82F6',
  organization: '#F59E0B',
  goal_setting: '#8B5CF6',
  networking: '#EF4444',
  side_hustles: '#06B6D4',
  insurance: '#6366F1',
  investing: '#84CC16',
  daily_living: '#F97316',
  personal_development: '#EC4899',
  consumer_rights: '#10B981',
  travel: '#3B82F6',
  environment: '#F59E0B',
  // Legacy categories for backward compatibility
  money_mastery: '#10B981',
  home_life: '#06B6D4',
  career_growth: '#6366F1',
  life_admin: '#F59E0B',
  personal_growth: '#EC4899',
  tech_savvy: '#84CC16',
  career_development: '#6366F1',
  health_wellness: '#10B981',
  life_skills: '#F59E0B',
};

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career_work: 'Career & Work',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social Skills',
  credit: 'Credit',
  fitness: 'Fitness',
  mental_health: 'Mental Health',
  healthcare: 'Healthcare',
  relationships: 'Relationships',
  education: 'Education',
  personal_care: 'Personal Care',
  safety: 'Safety',
  transportation: 'Transportation',
  technology: 'Technology',
  nutrition: 'Nutrition',
  shopping: 'Shopping',
  time_management: 'Time Management',
  communication: 'Communication',
  organization: 'Organization',
  goal_setting: 'Goal Setting',
  networking: 'Networking',
  side_hustles: 'Side Hustles',
  insurance: 'Insurance',
  investing: 'Investing',
  daily_living: 'Daily Living',
  personal_development: 'Personal Development',
  consumer_rights: 'Consumer Rights',
  travel: 'Travel',
  environment: 'Environment',
  // Legacy categories for backward compatibility
  money_mastery: 'Money Mastery',
  home_life: 'Home Life',
  career_growth: 'Career Growth',
  life_admin: 'Life Admin',
  personal_growth: 'Personal Growth',
  tech_savvy: 'Tech Savvy',
  career_development: 'Career Development',
  health_wellness: 'Health & Wellness',
  life_skills: 'Life Skills',
};

const categoryIcons: Record<string, string> = {
  finances: 'card',
  health_insurance: 'medical',
  cooking: 'restaurant',
  laundry: 'shirt',
  taxes: 'calculator',
  housing: 'home',
  career_work: 'briefcase',
  legal: 'document-text',
  maintenance: 'construct',
  social: 'people',
  credit: 'card',
  fitness: 'fitness',
  mental_health: 'heart',
  healthcare: 'medical',
  relationships: 'people',
  education: 'school',
  personal_care: 'person',
  safety: 'shield',
  transportation: 'car',
  technology: 'laptop',
  nutrition: 'nutrition',
  shopping: 'bag',
  time_management: 'time',
  communication: 'chatbubbles',
  organization: 'list',
  goal_setting: 'flag',
  networking: 'people',
  side_hustles: 'briefcase',
  insurance: 'shield',
  investing: 'trending-up',
  daily_living: 'home',
  personal_development: 'person',
  consumer_rights: 'shield',
  travel: 'airplane',
  environment: 'leaf',
};

const difficultyColors = {
  beginner: 'bg-green-100 text-green-700',
  intermediate: 'bg-yellow-100 text-yellow-700',
  advanced: 'bg-red-100 text-red-700',
};

export default function TipDetailScreen({ tipId, onClose, tip }: TipDetailScreenProps = {}) {
  if (__DEV__) console.log('🔍 TipDetailScreen: Received props:', { tipId, onClose: !!onClose, tip: !!tip });
  
  // Safe fallback for useSafeAreaInsets
  let insets;
  try {
    insets = useSafeAreaInsets();
  } catch (error) {
    if (__DEV__) console.warn('SafeAreaInsets not available, using fallback');
    insets = { top: 0, bottom: 0, left: 0, right: 0 };
  }

  if (!tipId) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900 justify-center items-center">
        <Ionicons name="alert-circle-outline" size={64} color="#6B7280" />
        <Text className="text-xl font-bold text-white mt-4">Invalid Tip</Text>
        <Text className="text-gray-400 mt-2 text-center px-6">
          No tip ID provided. Please try again.
        </Text>
        {onClose && (
          <Pressable onPress={onClose} className="mt-6 bg-emerald-600 rounded-xl px-6 py-3">
            <Text className="text-white font-bold">Go Back</Text>
          </Pressable>
        )}
      </SafeAreaView>
    );
  }

  // Use passed tip or create a fallback
  const tipData = tip || {
    id: tipId,
    title: "Sample Tip",
    category: "finances",
    difficulty: "beginner",
    estimatedTime: "5 min",
    content: {
      overview: "This is a sample tip for testing purposes.",
      keyPoints: ["Point 1", "Point 2"],
      stepByStep: [
        { title: "Step 1", description: "Do this first" },
        { title: "Step 2", description: "Then do this" }
      ],
      tips: ["Tip 1", "Tip 2"],
      resources: [
        "https://www.example.com/guide",
        "www.test-website.org",
        "Sample resource - Understanding the basics",
        "https://www.google.com"
      ],
      commonMistakes: []
    },
    tags: ["test"],
    isUnlocked: true
  };

  // Local state for user interactions
  const [isCompleted, setIsCompleted] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  // Simple functions that don't use store
  const markTipCompleted = (id: string) => {
    setIsCompleted(true);
    Alert.alert("Awesome! 🎉", "You've completed this tip. Keep building those life skills!");
  };

  const toggleTipBookmark = (id: string) => {
    setIsBookmarked(!isBookmarked);
  };

  const addTodoItem = (item: any) => {
    Alert.alert("Added! ✅", "This action has been added to your todo list!");
  };

  const isSkillUnlocked = (id: string) => true;
  const isPro = false;

  // Function to handle link clicks
  const handleLinkPress = async (resource: string) => {
    try {
      // Check if it's a URL
      if (resource.includes('http://') || resource.includes('https://') || resource.includes('www.')) {
        let url = resource;
        // Add https:// if it starts with www.
        if (resource.startsWith('www.')) {
          url = 'https://' + resource;
        }
        
        const supported = await Linking.canOpenURL(url);
        if (supported) {
          await Linking.openURL(url);
        } else {
          Alert.alert('Error', 'Cannot open this link');
        }
      } else {
        // For non-URL resources, show a more helpful alert with options
        Alert.alert(
          'Resource Information', 
          resource,
          [
            { text: 'Ask ChatGPT', onPress: () => {
              const searchQuery = encodeURIComponent(`Help me find resources about: ${resource}`);
              const chatgptUrl = `https://chat.openai.com/?q=${searchQuery}`;
              Linking.openURL(chatgptUrl).catch(() => {
                // Fallback to Google if ChatGPT doesn't work
                const googleUrl = `https://www.google.com/search?q=${searchQuery}`;
                Linking.openURL(googleUrl).catch(() => {
                  Alert.alert('Error', 'Could not open search');
                });
              });
            }},
            { text: 'Google Search', onPress: () => {
              const searchQuery = encodeURIComponent(resource);
              const searchUrl = `https://www.google.com/search?q=${searchQuery}`;
              Linking.openURL(searchUrl).catch(() => {
                Alert.alert('Error', 'Could not open search');
              });
            }},
            { text: 'OK', style: 'default' }
          ]
        );
      }
    } catch (error) {
      if (__DEV__) console.error('Error opening link:', error);
      Alert.alert('Error', 'Could not open this resource');
    }
  };

  const categoryColor = categoryColors[tipData.category] || '#6B7280';
  const categoryName = categoryLabels[tipData.category] || tipData.category;
  const categoryIcon = categoryIcons[tipData.category] || 'help-circle';
  const difficultyStyle = difficultyColors[tipData.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' };
  const canAccess = isPro || isSkillUnlocked(tipData.id);

  // Tabs: Overview, Steps, Resources
  const [activeTab, setActiveTab] = useState<"overview" | "steps" | "resources">("overview");

  const handleMarkCompleted = () => {
    if (!isCompleted) {
      markTipCompleted(tipData.id);
    }
  };

  const handleBookmark = () => {
    toggleTipBookmark(tipData.id);
  };

  const handleAddToTodo = (action: string) => {
    addTodoItem({
      title: action,
      description: `From tip: ${tipData.title}`,
      category: tipData.category,
      completed: false,
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
        {/* Header */}
      <View className="px-6 pt-6 pb-4">
        <View className="flex-row items-center justify-between mb-4">
          <Pressable onPress={onClose} className="w-10 h-10 bg-gray-800 rounded-full items-center justify-center">
            <Ionicons name="close" size={24} color="#9CA3AF" />
          </Pressable>
          
          <View className="flex-row items-center space-x-2">
            <Pressable onPress={handleBookmark} className="w-10 h-10 bg-gray-800 rounded-full items-center justify-center">
              <Ionicons 
                name={isBookmarked ? "bookmark" : "bookmark-outline"} 
                size={20} 
                color={isBookmarked ? "#F59E0B" : "#9CA3AF"} 
              />
            </Pressable>
          </View>
        </View>

        {/* Category & Difficulty */}
        <View className="flex-row items-center mb-4">
          <View className={cn("px-3 py-1 rounded-full border", categoryColor)}>
            <Text className={cn("text-sm font-medium", categoryColor)}>
                {categoryName}
              </Text>
          </View>
          <View className={cn("px-3 py-1 rounded-full ml-2", typeof difficultyStyle === 'object' ? difficultyStyle.bg : 'bg-gray-500')}>
            <Text className={cn("text-sm font-bold uppercase", typeof difficultyStyle === 'object' ? difficultyStyle.text : 'text-white')}>
                      {tip.difficulty}
                    </Text>
                  </View>
                  {tip.estimatedTime && (
                    <View className="bg-gray-700 rounded-full px-3 py-1 ml-2">
              <Text className="text-gray-300 text-sm font-bold">
                        {tip.estimatedTime}
                      </Text>
                    </View>
                  )}
                </View>
                
        {/* Title */}
        <Text className="text-white text-2xl font-black mb-2 leading-tight">
          {tipData.title}
                </Text>
              </View>

          {/* Tabs */}
      <View className="px-6 mb-4">
        <View className="flex-row bg-gray-800 rounded-2xl p-1">
          {[
            { key: "overview", label: "Overview", icon: "document-text" },
            { key: "steps", label: "Steps", icon: "list" },
            { key: "resources", label: "Resources", icon: "library" }
                    ].map((tab) => (
                      <Pressable
                        key={tab.key}
                        onPress={() => setActiveTab(tab.key as any)}
                        className={cn(
                "flex-1 flex-row items-center justify-center py-3 rounded-xl",
                activeTab === tab.key ? "bg-emerald-600" : "bg-transparent"
              )}
            >
              <Ionicons 
                name={tab.icon as any} 
                size={16} 
                color={activeTab === tab.key ? "#111827" : "#9CA3AF"} 
                style={{ marginRight: 6 }}
              />
                        <Text className={cn(
                "text-sm font-bold",
                activeTab === tab.key ? "text-gray-900" : "text-gray-400"
                        )}>
                          {tab.label}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

      {/* Content */}
      <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
        {activeTab === "overview" && (
          <View>
            <Text className="text-white text-lg font-bold mb-3">Overview</Text>
            <Text className="text-gray-300 leading-relaxed mb-6">
              {tipData.content.overview}
                    </Text>

            {tipData.content.keyPoints && tipData.content.keyPoints.length > 0 && (
              <View className="mb-6">
                <Text className="text-white text-lg font-bold mb-3">Key Points</Text>
                {tipData.content.keyPoints.map((point: string, index: number) => (
                    <Pressable
                    key={index}
                    onPress={() => handleLinkPress(point)}
                    className="flex-row items-start mb-2 p-2 rounded-lg bg-gray-800/50"
                  >
                    <Ionicons name="checkmark-circle" size={20} color="#10B981" style={{ marginRight: 8, marginTop: 2 }} />
                    <Text className="text-gray-300 flex-1">{point}</Text>
                    </Pressable>
                ))}
                  </View>
                )}

            {tipData.content.tips && tipData.content.tips.length > 0 && (
                      <View className="mb-6">
                <Text className="text-white text-lg font-bold mb-3">Pro Tips</Text>
                {tipData.content.tips.map((tipText: string, index: number) => (
                            <Pressable
                              key={index}
                    onPress={() => handleLinkPress(tipText)}
                    className="flex-row items-start mb-2 p-2 rounded-lg bg-gray-800/50"
                  >
                    <Ionicons name="bulb" size={20} color="#F59E0B" style={{ marginRight: 8, marginTop: 2 }} />
                    <Text className="text-gray-300 flex-1">{tipText}</Text>
                            </Pressable>
                          ))}
                        </View>
            )}

            {tipData.content.commonMistakes && tipData.content.commonMistakes.length > 0 && (
              <View className="mb-6">
                <Text className="text-white text-lg font-bold mb-3">Common Mistakes to Avoid</Text>
                {tipData.content.commonMistakes.map((mistake: string, index: number) => (
                  <View key={index} className="flex-row items-start mb-2">
                    <Ionicons name="warning" size={20} color="#EF4444" style={{ marginRight: 8, marginTop: 2 }} />
                    <Text className="text-gray-300 flex-1">{mistake}</Text>
                  </View>
                ))}
                      </View>
                    )}
                  </View>
                )}

        {activeTab === "steps" && (
                  <View>
            <Text className="text-white text-lg font-bold mb-3">Step by Step</Text>
            {tipData.content.stepByStep && tipData.content.stepByStep.length > 0 ? (
              tipData.content.stepByStep.map((step: any, index: number) => (
                <View key={index} className="mb-4">
                          <View className="flex-row items-start">
                    <View className="w-8 h-8 bg-emerald-600 rounded-full items-center justify-center mr-3 mt-1">
                      <Text className="text-white font-bold text-sm">{index + 1}</Text>
                            </View>
                            <View className="flex-1">
                      <Text className="text-white font-bold mb-1">Step {index + 1}</Text>
                              <Text className="text-gray-300 leading-relaxed">
                        {typeof step === 'string' ? step : (step.title || step.description || step)}
                                </Text>
                            </View>
                          </View>
                        </View>
                      ))
                    ) : (
              <Text className="text-gray-400">No steps available for this tip.</Text>
            )}
          </View>
        )}

        {activeTab === "resources" && (
          <View>
            <Text className="text-white text-lg font-bold mb-3">Resources</Text>
            {tipData.content.resources && tipData.content.resources.length > 0 ? (
              tipData.content.resources.map((resource: any, index: number) => {
                const resourceText = typeof resource === 'string' ? resource : (resource.title || resource.description || resource);
                const isUrl = resourceText.includes('http://') || resourceText.includes('https://') || resourceText.includes('www.') || resourceText.includes('.com') || resourceText.includes('.org') || resourceText.includes('.net');
                
                return (
                  <Pressable
                    key={index}
                    onPress={() => handleLinkPress(resourceText)}
                    className="mb-4 bg-gray-800 rounded-xl p-4 border border-gray-700"
                  >
                    <View className="flex-row items-start">
                      <Ionicons 
                        name={isUrl ? "link" : "chatbubble"} 
                        size={20} 
                        color={isUrl ? "#3B82F6" : "#10B981"} 
                        style={{ marginRight: 8, marginTop: 2 }} 
                      />
                      <View className="flex-1">
                        <Text className={`flex-1 leading-relaxed ${isUrl ? 'text-blue-400' : 'text-gray-300'}`}>
                          {resourceText}
                        </Text>
                        {isUrl ? (
                          <Text className="text-gray-500 text-sm mt-1">Tap to open</Text>
                        ) : (
                          <Text className="text-gray-500 text-sm mt-1">Tap to ask ChatGPT or search</Text>
                        )}
                      </View>
                      {isUrl ? (
                        <Ionicons name="open-outline" size={16} color="#3B82F6" />
                      ) : (
                        <Ionicons name="chatbubble-outline" size={16} color="#10B981" />
                      )}
                    </View>
                  </Pressable>
                );
              })
            ) : (
              <Text className="text-gray-400">No resources available for this tip.</Text>
                    )}
                  </View>
                )}

        {/* Action Buttons */}
        <View className="py-6">
          {!isCompleted && (
            <Pressable
              onPress={handleMarkCompleted}
              className="bg-emerald-600 rounded-2xl px-4 py-3 mb-4 items-center"
            >
              <Text className="text-gray-900 font-bold">Mark as Completed</Text>
            </Pressable>
          )}

          <Pressable
            onPress={() => handleAddToTodo("Practice this tip")}
            className="rounded-2xl px-4 py-3 mb-6 items-center bg-blue-600"
          >
            <Text className="text-white font-semibold">Add to Todo List</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}