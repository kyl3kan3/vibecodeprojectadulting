/**
 * Progress Sync Screen
 * Allows users to manually sync progress to cloud and view sync status
 */

import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useLessonsStore } from '../state/lessons-store';
import { lessonProgressService } from '../services/database';

export default function ProgressSyncScreen() {
  const navigation = useNavigation();
  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<{
    succeeded: number;
    failed: number;
    message: string;
  } | null>(null);

  const { skillProgress, loadProgressFromCloud, uploadLocalProgressToCloud } = useLessonsStore();

  const localProgressCount = Object.keys(skillProgress).length;

  const handleUploadToCloud = async () => {
    Alert.alert(
      'Upload Progress to Cloud',
      `This will upload ${localProgressCount} skill progress records to Supabase. Continue?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Upload',
          onPress: async () => {
            setSyncing(true);
            setSyncStatus(null);
            try {
              const result = await uploadLocalProgressToCloud();
              setSyncStatus({
                succeeded: result.succeeded,
                failed: result.failed,
                message: `Successfully uploaded ${result.succeeded} records. ${result.failed} failed.`
              });
              
              if (result.succeeded > 0) {
                Alert.alert('Success', `Uploaded ${result.succeeded} skill progress records to cloud!`);
              }
            } catch (error: any) {
              Alert.alert('Sync Error', error.message || 'Failed to upload progress. Check your internet connection and try again.');
            } finally {
              setSyncing(false);
            }
          }
        }
      ]
    );
  };

  const handleDownloadFromCloud = async () => {
    Alert.alert(
      'Download Progress from Cloud',
      'This will download your progress from Supabase and merge it with local data. Cloud data takes precedence. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Download',
          onPress: async () => {
            setSyncing(true);
            setSyncStatus(null);
            try {
              await loadProgressFromCloud();
              setSyncStatus({
                succeeded: 0,
                failed: 0,
                message: 'Successfully synced progress from cloud!'
              });
              Alert.alert('Success', 'Progress synced from cloud!');
            } catch (error: any) {
              Alert.alert('Sync Error', error.message || 'Failed to download progress. Check your internet connection and try again.');
            } finally {
              setSyncing(false);
            }
          }
        }
      ]
    );
  };

  const handleViewCloudStats = async () => {
    setSyncing(true);
    try {
      const result = await lessonProgressService.getProgressStats();
      
      if (!result.success || !result.data) {
        throw new Error('Failed to fetch stats');
      }

      const stats = result.data;
      Alert.alert(
        'Cloud Progress Stats',
        `Total Skills: ${stats.totalLessons}\n` +
        `Completed: ${stats.completedLessons}\n` +
        `In Progress: ${stats.inProgressLessons}\n` +
        `Steps Completed: ${stats.totalStepsCompleted}\n` +
        `Average Rating: ${stats.averageRating.toFixed(1)}/5`
      );
    } catch (error: any) {
      Alert.alert('Sync Error', error.message || 'Failed to fetch cloud statistics. Check your internet connection and try again.');
    } finally {
      setSyncing(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 py-4 border-b border-gray-800">
        <View className="flex-row items-center">
          <Pressable 
            onPress={() => navigation.goBack()} 
            className="mr-4 p-2 -ml-2"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </Pressable>
          <Text className="text-white text-2xl font-bold">Progress Sync</Text>
        </View>
      </View>

      <ScrollView className="flex-1 px-6 py-4">
        {/* Local Progress Info */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">📱 Local Progress</Text>
          <Text className="text-gray-300">
            Skill Records: <Text className="text-white font-bold">{localProgressCount}</Text>
          </Text>
          <Text className="text-gray-400 text-sm mt-2">
            Progress stored on this device in AsyncStorage
          </Text>
        </View>

        {/* Sync Status */}
        {syncStatus && (
          <View className={`rounded-2xl p-4 mb-4 border ${syncStatus.failed > 0 ? 'bg-yellow-900/30 border-yellow-600' : 'bg-green-900/30 border-green-600'}`}>
            <Text className={`${syncStatus.failed > 0 ? 'text-yellow-400' : 'text-green-400'} font-bold mb-2`}>
              {syncStatus.failed > 0 ? '⚠️ Sync Completed with Errors' : '✅ Sync Successful'}
            </Text>
            <Text className="text-gray-300 text-sm">{syncStatus.message}</Text>
          </View>
        )}

        {/* Sync Actions */}
        <View className="space-y-3">
          <Pressable 
            onPress={handleUploadToCloud}
            disabled={syncing || localProgressCount === 0}
            className={`rounded-2xl p-4 items-center ${syncing || localProgressCount === 0 ? 'bg-gray-700' : 'bg-blue-600'}`}
          >
            {syncing ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <View className="flex-row items-center">
                <Ionicons name="cloud-upload" size={20} color="white" className="mr-2" />
                <Text className="text-white font-bold ml-2">☁️ Upload to Cloud</Text>
              </View>
            )}
          </Pressable>

          <Pressable 
            onPress={handleDownloadFromCloud}
            disabled={syncing}
            className={`rounded-2xl p-4 items-center ${syncing ? 'bg-gray-700' : 'bg-emerald-600'}`}
          >
            {syncing ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <View className="flex-row items-center">
                <Ionicons name="cloud-download" size={20} color="white" className="mr-2" />
                <Text className="text-white font-bold ml-2">📥 Download from Cloud</Text>
              </View>
            )}
          </Pressable>

          <Pressable 
            onPress={handleViewCloudStats}
            disabled={syncing}
            className={`rounded-2xl p-4 items-center ${syncing ? 'bg-gray-700' : 'bg-purple-600'}`}
          >
            <Text className="text-white font-bold">📊 View Cloud Stats</Text>
          </Pressable>
        </View>

        {/* Information */}
        <View className="bg-gray-800 rounded-2xl p-4 mt-6 border border-gray-700">
          <Text className="text-white text-sm font-bold mb-2">ℹ️ How Cloud Sync Works</Text>
          <Text className="text-gray-400 text-sm leading-5 mb-2">
            • Progress automatically syncs to cloud when you complete steps or skills
          </Text>
          <Text className="text-gray-400 text-sm leading-5 mb-2">
            • Use "Upload to Cloud" to backup existing progress
          </Text>
          <Text className="text-gray-400 text-sm leading-5 mb-2">
            • Use "Download from Cloud" to restore progress on a new device
          </Text>
          <Text className="text-gray-400 text-sm leading-5">
            • Cloud data always takes precedence during sync
          </Text>
        </View>

        {/* Warning */}
        <View className="bg-yellow-900/30 border border-yellow-600 rounded-2xl p-4 mt-4 mb-8">
          <Text className="text-yellow-400 text-sm font-bold mb-2">⚠️ Important</Text>
          <Text className="text-yellow-300 text-sm leading-5">
            Make sure you're logged in to the correct account before syncing. Progress is tied to your user account.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
