import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAIStore, useUIStore } from '../state';
import { LearningInsight } from '../api/ai-learning-service';
import { cn } from '../utils/cn';
import { useNavigation } from '@react-navigation/native';

const insightIcons = {
  strength: 'trophy',
  improvement: 'trending-up',
  milestone: 'flag',
  suggestion: 'bulb'
} as const;

const insightColors = {
  strength: 'bg-emerald-500',
  improvement: 'bg-blue-500', 
  milestone: 'bg-purple-500',
  suggestion: 'bg-amber-500'
} as const;

export default function LearningInsightsScreen() {
  const navigation = useNavigation<any>();
  const {
    learningAnalysis, 
    learningInsights, 
    updateAIInsights,
    getLearningPattern,
    getPerformanceMetrics,
    getOptimalDifficulty
  } = useAIStore();
  const { userProfile, isPro } = useUIStore();
  
  const [isLoading, setIsLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [optimalDifficulty, setOptimalDifficulty] = useState<string>('building');

  useEffect(() => {
    if (isPro) {
      loadInsights();
      loadOptimalDifficulty();
    }
  }, [isPro]);

  const loadInsights = async () => {
    if (!isPro) return;
    if (!learningInsights || learningInsights.length === 0 || !learningAnalysis) {
      setIsLoading(true);
      await updateAIInsights([]);
      setIsLoading(false);
    }
  };

  const loadOptimalDifficulty = async () => {
    try {
      const difficulty = getOptimalDifficulty('general');
      setOptimalDifficulty(difficulty);
    } catch (error) {
      if (__DEV__) console.error('Error loading optimal difficulty:', error);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await updateAIInsights([]);
    await loadOptimalDifficulty();
    setRefreshing(false);
  };

  const learningPattern = getLearningPattern();
  const performanceMetrics = getPerformanceMetrics();

  if (!isPro) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          <View className="px-6 py-8">
            <Text className="text-white text-3xl font-black mb-2">Learning Insights</Text>
            <Text className="text-gray-400 text-lg">Unlock personalized insights with Pro</Text>
          </View>
          <View className="px-6">
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-4 opacity-80">
              <View className="flex-row items-center mb-3">
                <View className="w-10 h-10 bg-emerald-500 rounded-xl items-center justify-center mr-3">
                  <Ionicons name="analytics" size={20} color="#111827" />
                </View>
                <Text className="text-white font-bold text-lg flex-1">Your Learning Profile (Preview)</Text>
              </View>
              <Text className="text-gray-400">See strengths, focus areas, and tailored tips.</Text>
            </View>
            <Pressable onPress={() => (require('@react-navigation/native').useNavigation() as any).navigate('SubscriptionSheet')} className="bg-emerald-600 rounded-2xl px-4 py-3 items-center">
              <Text className="text-gray-900 font-bold">Upgrade to Pro</Text>
            </Pressable>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 justify-center items-center">
          <ActivityIndicator size="large" color="#10B981" />
          <Text className="text-white mt-4 text-lg">Analyzing your learning...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1"
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor="#10B981" />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View className="px-6 py-8">
          <Text className="text-white text-3xl font-black mb-2">Learning Insights</Text>
          <Text className="text-gray-400 text-lg">AI-powered analysis of your progress</Text>
        </View>

        {/* Learning Analysis Summary */}
        {learningAnalysis && (
          <View className="px-6 mb-6">
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6">
              <View className="flex-row items-center mb-4">
                <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="analytics" size={24} color="#111827" />
                </View>
                <Text className="text-white text-xl font-black">Your Learning Profile</Text>
              </View>
              
              <Text className="text-emerald-400 text-base leading-relaxed mb-4">
                {learningAnalysis.motivationalMessage}
              </Text>

              <View className="flex-row flex-wrap gap-2 mb-4">
                <Text className="text-gray-400 text-sm font-bold">RECOMMENDED DIFFICULTY:</Text>
                <View className={cn(
                  "px-3 py-1 rounded-full",
                  optimalDifficulty === 'starter' ? 'bg-green-500' :
                  optimalDifficulty === 'building' ? 'bg-yellow-500' : 'bg-red-500'
                )}>
                  <Text className="text-white text-xs font-bold uppercase">{optimalDifficulty}</Text>
                </View>
              </View>

              {learningAnalysis.strengths.length > 0 && (
                <View className="mb-4">
                  <Text className="text-emerald-400 text-sm font-bold mb-2">STRENGTHS:</Text>
                  {learningAnalysis.strengths.map((strength, index) => (
                    <Text key={index} className="text-gray-300 text-sm mb-1">• {strength}</Text>
                  ))}
                </View>
              )}

              {learningAnalysis.recommendedFocusAreas.length > 0 && (
                <View>
                  <Text className="text-blue-400 text-sm font-bold mb-2">FOCUS AREAS:</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {learningAnalysis.recommendedFocusAreas.map((area, index) => (
                      <View key={index} className="bg-blue-500 px-2 py-1 rounded-lg">
                        <Text className="text-white text-xs font-medium">{area.replace('_', ' ')}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Performance Metrics */}
        {performanceMetrics && (
          <View className="px-6 mb-6">
            <Text className="text-white text-2xl font-black mb-4">Performance Metrics</Text>
            <View className="flex-row flex-wrap gap-3">
              <View className="bg-emerald-500 rounded-2xl p-4 flex-1 min-w-[140px]">
                <Text className="text-emerald-100 text-xs font-bold mb-1">COMPLETION RATE</Text>
                <Text className="text-white text-2xl font-black">{performanceMetrics.completionRate}%</Text>
              </View>
              
              <View className="bg-purple-500 rounded-2xl p-4 flex-1 min-w-[140px]">
                <Text className="text-purple-100 text-xs font-bold mb-1">AVG RATING</Text>
                <Text className="text-white text-2xl font-black">{performanceMetrics.averageRating.toFixed(1)}</Text>
              </View>

              <View className="bg-blue-500 rounded-2xl p-4 flex-1 min-w-[140px]">
                <Text className="text-blue-100 text-xs font-bold mb-1">GOAL ACHIEVEMENT</Text>
                <Text className="text-white text-2xl font-black">{performanceMetrics.goalAchievementRate}%</Text>
              </View>

              <View className="bg-orange-500 rounded-2xl p-4 flex-1 min-w-[140px]">
                <Text className="text-orange-100 text-xs font-bold mb-1">STREAK CONSISTENCY</Text>
                <Text className="text-white text-2xl font-black">{performanceMetrics.streakConsistency}%</Text>
              </View>
            </View>
          </View>
        )}

        {/* Learning Pattern */}
        {learningPattern && (
          <View className="px-6 mb-6">
            <Text className="text-white text-2xl font-black mb-4">Learning Pattern</Text>
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6">
              <View className="flex-row justify-between items-center mb-4">
                <Text className="text-gray-400 text-sm font-bold">Session Length</Text>
                <Text className="text-white font-bold">{learningPattern.averageSessionLength} min</Text>
              </View>
              
              <View className="flex-row justify-between items-center mb-4">
                <Text className="text-gray-400 text-sm font-bold">Weekly Velocity</Text>
                <Text className="text-white font-bold">{learningPattern.completionVelocity} skills</Text>
              </View>

              <View className="flex-row justify-between items-center mb-4">
                <Text className="text-gray-400 text-sm font-bold">Engagement Trend</Text>
                <View className={cn(
                  "px-2 py-1 rounded-lg",
                  learningPattern.engagementTrend === 'increasing' ? 'bg-green-500' :
                  learningPattern.engagementTrend === 'stable' ? 'bg-yellow-500' : 'bg-red-500'
                )}>
                  <Text className="text-white text-xs font-bold">{learningPattern.engagementTrend}</Text>
                </View>
              </View>

              {learningPattern.strongCategories.length > 0 && (
                <View>
                  <Text className="text-emerald-400 text-sm font-bold mb-2">STRONG CATEGORIES:</Text>
                  <View className="flex-row flex-wrap gap-1">
                    {learningPattern.strongCategories.map((category, index) => (
                      <Text key={index} className="text-emerald-300 text-xs">
                        {category.replace('_', ' ')}{index < learningPattern.strongCategories.length - 1 ? ', ' : ''}
                      </Text>
                    ))}
                  </View>
                </View>
              )}
            </View>
          </View>
        )}

        {/* AI Learning Insights */}
        <View className="px-6 mb-8">
          <Text className="text-white text-2xl font-black mb-4">Personalized Insights</Text>
          {learningInsights && learningInsights.length > 0 ? (
            <View className="space-y-4">
              {learningInsights.map((insight, index) => (
                <View key={index} className="bg-gray-800 border border-gray-700 rounded-3xl p-6">
                  <View className="flex-row items-center mb-3">
                    <View className={cn("w-10 h-10 rounded-xl items-center justify-center mr-3", insightColors[insight.type])}>
                      <Ionicons name={insightIcons[insight.type]} size={20} color="white" />
                    </View>
                    <Text className="text-white font-bold text-lg flex-1">{insight.title}</Text>
                  </View>
                  
                  <Text className="text-gray-300 leading-relaxed mb-3">
                    {insight.description}
                  </Text>

                  {insight.relatedSkills && insight.relatedSkills.length > 0 && (
                    <View className="flex-row flex-wrap gap-2">
                      <Text className="text-gray-400 text-xs font-bold">RELATED:</Text>
                      {insight.relatedSkills.map((skillId, idx) => (
                        <View key={idx} className="bg-gray-700 px-2 py-1 rounded-lg">
                          <Text className="text-gray-300 text-xs">{skillId}</Text>
                        </View>
                      ))}
                    </View>
                  )}
                </View>
              ))}
            </View>
          ) : (
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6 items-center">
              <Ionicons name="sparkles" size={48} color="#6B7280" />
              <Text className="text-gray-400 mt-4 text-center">
                Complete a few more skills to unlock personalized insights!
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}