import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useLessonsStore, useProgressStore, useUIStore } from '../state';
import { useNavigation } from '@react-navigation/native';
import { cn } from '../utils/cn';

const categoryLabels: Record<string, string> = {
  money_mastery: 'Money Mastery',
  career_growth: 'Career Growth',
  home_life: 'Home Life',
  health_wellness: 'Health & Wellness',
  relationships: 'Relationships',
  personal_growth: 'Personal Growth',
  tech_savvy: 'Tech Savvy',
  life_admin: 'Life Admin'
};

const categoryColors: Record<string, string> = {
  money_mastery: 'bg-green-500',
  career_growth: 'bg-blue-500',
  home_life: 'bg-purple-500',
  health_wellness: 'bg-red-500',
  relationships: 'bg-orange-500',
  personal_growth: 'bg-cyan-500',
  tech_savvy: 'bg-indigo-500',
  life_admin: 'bg-gray-600'
};

const categoryIcons: Record<string, any> = {
  money_mastery: 'cash',
  career_growth: 'trending-up',
  home_life: 'home',
  health_wellness: 'fitness',
  relationships: 'people',
  personal_growth: 'leaf',
  tech_savvy: 'laptop',
  life_admin: 'document-text'
};

export default function ProgressScreen() {
  const navigation = useNavigation<any>();
  const { skills, completedSkills, skillProgress } = useLessonsStore();
  const { userProfile } = useUIStore();
  
  // Calculate stats
  const totalLessons = skills?.length || 0;
  const completedLessonsCount = completedSkills?.length || 0;
  const completionRate = totalLessons > 0 ? Math.round((completedLessonsCount / totalLessons) * 100) : 0;
  
  // Calculate total XP earned
  const totalXP = completedSkills.reduce((sum, skillId) => {
    const skill = skills.find(s => s.id === skillId);
    return sum + (skill?.xpReward || 0);
  }, 0);
  
  // Get recently completed lessons (last 5)
  const recentlyCompletedSkills = completedSkills
    .slice(-5)
    .reverse()
    .map(skillId => skills.find(s => s.id === skillId))
    .filter(Boolean)
    .filter((skill, index, self) => 
      skill && index === self.findIndex(s => s && s.id === skill.id)
    );
  
  // Calculate category progress
  const getCategoryProgress = () => {
    const categories = Object.keys(categoryLabels);
    return categories.map(category => {
      const categorySkills = skills.filter(skill => skill.category === category);
      const completedInCategory = categorySkills.filter(skill => 
        completedSkills.includes(skill.id)
      ).length;
      return {
        category,
        label: categoryLabels[category],
        total: categorySkills.length,
        completed: completedInCategory,
        percentage: categorySkills.length > 0 ? Math.round((completedInCategory / categorySkills.length) * 100) : 0,
      };
    }).filter(cat => cat.total > 0).sort((a, b) => b.completed - a.completed);
  };

  const categoryProgress = getCategoryProgress();

  // Calculate learning streak (simplified - days with completed lessons)
  const getLearningStreak = () => {
    // Use userProgress streak or default to 0
    const { userProgress } = useProgressStore.getState();
    return userProgress?.streak || 0;
  };

  const streak = getLearningStreak();

  // Get in-progress lessons (started but not completed)
  // Deduplicate skills first
  const uniqueSkills = skills.filter((skill, index, self) => 
    index === self.findIndex(s => s.id === skill.id)
  );
  
  const inProgressLessons = uniqueSkills.filter(skill => {
    const isStarted = skillProgress[skill.id]?.startedAt;
    const isCompleted = completedSkills.includes(skill.id);
    return isStarted && !isCompleted;
  }).slice(0, 3);

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-8 pb-6">
          <Text className="text-white text-3xl font-black mb-2">Your Progress</Text>
          <Text className="text-gray-400 text-base">
            Keep learning, keep growing! 🌱
          </Text>
        </View>

        {/* Stats Cards */}
        <View className="px-6 mb-6">
          <View className="flex-row space-x-3 mb-3">
            <View className="bg-emerald-500 rounded-3xl p-5 flex-1 items-center">
              <Text className="text-white text-4xl font-black">{completedLessonsCount}</Text>
              <Text className="text-emerald-100 text-xs font-bold mt-1">COMPLETED</Text>
            </View>
            <View className="bg-orange-500 rounded-3xl p-5 flex-1 items-center">
              <Text className="text-white text-4xl font-black">{streak}</Text>
              <Text className="text-orange-100 text-xs font-bold mt-1">DAY STREAK</Text>
            </View>
          </View>

          <View className="flex-row space-x-3">
            <View className="bg-blue-500 rounded-3xl p-5 flex-1 items-center">
              <Text className="text-white text-4xl font-black">{totalXP}</Text>
              <Text className="text-blue-100 text-xs font-bold mt-1">TOTAL XP</Text>
            </View>
            <View className="bg-purple-500 rounded-3xl p-5 flex-1 items-center">
              <Text className="text-white text-4xl font-black">{completionRate}%</Text>
              <Text className="text-purple-100 text-xs font-bold mt-1">PROGRESS</Text>
            </View>
          </View>
        </View>

        {/* In Progress Lessons */}
        {inProgressLessons.length > 0 && (
          <View className="px-6 mb-6">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-white text-xl font-black">Continue Learning</Text>
              <Ionicons name="book-outline" size={24} color="#10B981" />
            </View>
            <View className="space-y-3">
              {inProgressLessons.map(skill => {
                if (!skill) return null;
                return (
                <Pressable
                  key={skill.id}
                  onPress={() => navigation.navigate('SkillDetail', { skillId: skill.id })}
                  className="bg-gray-800 rounded-3xl p-5 border border-gray-700"
                >
                  <View className="flex-row items-center">
                    <View className={cn("w-14 h-14 rounded-2xl items-center justify-center mr-4", categoryColors[skill.category])}>
                      <Ionicons name={categoryIcons[skill.category]} size={28} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white text-lg font-bold" numberOfLines={1}>{skill.title}</Text>
                      <Text className="text-gray-400 text-sm mt-1">{categoryLabels[skill.category]}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={24} color="#6B7280" />
                  </View>
                </Pressable>
                );
              })}
            </View>
          </View>
        )}

        {/* Recently Completed */}
        {recentlyCompletedSkills.length > 0 && (
          <View className="px-6 mb-6">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-white text-xl font-black">Recently Completed</Text>
              <Ionicons name="checkmark-circle" size={24} color="#10B981" />
            </View>
            <View className="space-y-3">
              {recentlyCompletedSkills.map(skill => {
                if (!skill) return null;
                return (
                <Pressable
                  key={skill.id}
                  onPress={() => navigation.navigate('SkillDetail', { skillId: skill.id })}
                  className="bg-gray-800 rounded-3xl p-5 border border-emerald-500/30"
                >
                  <View className="flex-row items-center">
                    <View className={cn("w-14 h-14 rounded-2xl items-center justify-center mr-4", categoryColors[skill.category])}>
                      <Ionicons name={categoryIcons[skill.category]} size={28} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white text-lg font-bold" numberOfLines={1}>{skill.title}</Text>
                      <View className="flex-row items-center mt-1">
                        <Text className="text-gray-400 text-sm">{categoryLabels[skill.category]}</Text>
                        <View className="mx-2 w-1 h-1 rounded-full bg-gray-600" />
                        <Text className="text-emerald-400 text-sm font-bold">+{skill.xpReward} XP</Text>
                      </View>
                    </View>
                    <View className="w-8 h-8 bg-emerald-500 rounded-full items-center justify-center">
                      <Ionicons name="checkmark" size={18} color="white" />
                    </View>
                  </View>
                </Pressable>
                );
              })}
            </View>
          </View>
        )}

        {/* Category Progress */}
        <View className="px-6 mb-8">
          <View className="flex-row items-center justify-between mb-4">
            <Text className="text-white text-xl font-black">Progress by Category</Text>
            <Ionicons name="bar-chart" size={24} color="#10B981" />
          </View>
          
          {categoryProgress.length === 0 ? (
            <View className="bg-gray-800 rounded-3xl p-8 border border-gray-700 items-center">
              <Ionicons name="school-outline" size={64} color="#6B7280" />
              <Text className="text-white text-xl font-bold mt-4">Start Your Journey</Text>
              <Text className="text-gray-400 text-center mt-2">
                Complete lessons to see your progress across different categories
              </Text>
            </View>
          ) : (
            <View className="space-y-4">
              {categoryProgress.map(cat => (
                <View key={cat.category} className="bg-gray-800 rounded-3xl p-5 border border-gray-700">
                  <View className="flex-row items-center mb-3">
                    <View className={cn("w-10 h-10 rounded-xl items-center justify-center mr-3", categoryColors[cat.category])}>
                      <Ionicons name={categoryIcons[cat.category]} size={20} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-bold text-base">{cat.label}</Text>
                      <Text className="text-gray-400 text-sm">
                        {cat.completed} of {cat.total} completed
                      </Text>
                    </View>
                    <Text className="text-emerald-400 font-bold text-lg">{cat.percentage}%</Text>
                  </View>
                  
                  {/* Progress Bar */}
                  <View className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <View 
                      className={cn("h-full rounded-full", categoryColors[cat.category])}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Empty State */}
        {completedLessonsCount === 0 && (
          <View className="px-6 mb-8">
            <View className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 rounded-3xl p-8 border border-emerald-500/30">
              <View className="items-center">
                <View className="w-20 h-20 bg-emerald-500 rounded-full items-center justify-center mb-4">
                  <Ionicons name="rocket" size={40} color="white" />
                </View>
                <Text className="text-white text-2xl font-black text-center mb-2">
                  Ready to Start Learning?
                </Text>
                <Text className="text-gray-300 text-center mb-6">
                  Complete your first lesson to start building your progress and earning XP!
                </Text>
                <Pressable
                  onPress={() => navigation.navigate('Learn')}
                  className="bg-emerald-500 px-8 py-4 rounded-2xl"
                >
                  <Text className="text-white font-bold text-base">Browse Lessons</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
