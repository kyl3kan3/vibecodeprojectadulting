import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { HOW_TO_GUIDES } from "../data/how-to-guides";
import { useNavigation, useRoute } from "@react-navigation/native";
import { useUIStore } from "../state";

export default function GuideDetailScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { guideId } = (route?.params || {}) as { guideId: string };
  const guide = HOW_TO_GUIDES.find(g => g.id === guideId) || HOW_TO_GUIDES[0];
  const total = guide.steps.length;
  const { getGuideProgressPct, toggleStep: toggle, resetGuide: reset, isStepDone } = useUIStore();
  const pct = getGuideProgressPct(guideId);

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Header */}
        <View className="px-6 pt-6 pb-3">
          <View className="flex-row items-center justify-between mb-4">
            <Pressable onPress={() => nav.goBack()} className="w-10 h-10 rounded-full bg-gray-800 border border-gray-700 items-center justify-center">
              <Ionicons name="chevron-back" size={20} color="#9CA3AF" />
            </Pressable>
            <Pressable onPress={() => nav.goBack()} className="w-10 h-10 rounded-full bg-gray-800 border border-gray-700 items-center justify-center">
              <Ionicons name="close" size={18} color="#9CA3AF" />
            </Pressable>
          </View>
          <Text className="text-white text-3xl font-black mb-2">{guide.title}</Text>
          <Text className="text-gray-400 mb-3">{guide.description}</Text>
          <View className="flex-row items-center justify-between">
            <Text className="text-gray-400">⏱️ {guide.estimatedTime}</Text>
            <View className="items-end">
              <Text className="text-emerald-400 font-bold">{pct}%</Text>
              <Text className="text-gray-400 text-xs">complete</Text>
            </View>
          </View>
        </View>

        {/* Prerequisites */}
        {guide.prerequisites && guide.prerequisites.length > 0 && (
          <View className="px-6">
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
              <Text className="text-white font-bold mb-2">Prerequisites</Text>
              {guide.prerequisites.map((p, i) => (
                <View key={i} className="flex-row items-start mb-1">
                  <Text className="text-emerald-400 mr-2">•</Text>
                  <Text className="text-gray-300 flex-1">{p}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Steps */}
        <View className="px-6">
          {guide.steps.map((s) => {
            const done = isStepDone(guide.id, s.id);
            return (
              <View key={s.id} className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
                <View className="flex-row items-start">
                  <Pressable onPress={() => toggle(guide.id, s.id)} className="mr-4 pt-1">
                    <Ionicons name={done ? "checkmark-circle" : "ellipse-outline"} size={24} color={done ? "#10B981" : "#9CA3AF"} />
                  </Pressable>
                  <View className="flex-1">
                    <Text className="text-white font-bold text-lg mb-1">{s.title}</Text>
                    <Text className="text-gray-400 mb-2">{s.description}</Text>
                    {s.warning && (
                      <View className="bg-yellow-500/10 border border-yellow-600 rounded-2xl p-3 mb-2">
                        <Text className="text-yellow-400 text-sm">{s.warning}</Text>
                      </View>
                    )}
                    {s.tip && (
                      <View className="bg-emerald-500/10 border border-emerald-600 rounded-2xl p-3">
                        <Text className="text-emerald-400 text-sm">Pro Tip: {s.tip}</Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        {/* Footer */}
        <View className="px-6 mt-2">
          <Pressable onPress={() => reset(guide.id)} className="bg-gray-800 border border-gray-700 rounded-2xl p-4 items-center mb-3">
            <Text className="text-white font-bold">Reset Guide</Text>
          </Pressable>
          {pct >= 100 && (
            <View className="bg-emerald-600 rounded-2xl p-4 items-center">
              <Text className="text-gray-900 font-bold">Guide Complete</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
