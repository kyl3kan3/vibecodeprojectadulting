import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTipsStore, useProgressStore } from '../state';
import { cn } from '../utils/cn';
import TipDetailModal from '../components/TipDetailModal';

const categoryColors: Record<string, string> = {
  finances: 'bg-green-100 text-green-800',
  health_insurance: 'bg-blue-100 text-blue-800',
  cooking: 'bg-orange-100 text-orange-800',
  laundry: 'bg-purple-100 text-purple-800',
  taxes: 'bg-red-100 text-red-800',
  housing: 'bg-indigo-100 text-indigo-800',
  career: 'bg-gray-100 text-gray-800',
  legal: 'bg-yellow-100 text-yellow-800',
  maintenance: 'bg-pink-100 text-pink-800',
  social: 'bg-cyan-100 text-cyan-800',
  transportation: 'bg-emerald-100 text-emerald-800',
  technology: 'bg-violet-100 text-violet-800',
  fitness: 'bg-rose-100 text-rose-800',
  mental_health: 'bg-teal-100 text-teal-800',
  healthcare: 'bg-sky-100 text-sky-800',
  relationships: 'bg-fuchsia-100 text-fuchsia-800',
  education: 'bg-amber-100 text-amber-800',
  personal_care: 'bg-lime-100 text-lime-800',
  safety: 'bg-red-100 text-red-800',
  travel: 'bg-blue-100 text-blue-800',
  environment: 'bg-green-100 text-green-800',
  consumer_rights: 'bg-purple-100 text-purple-800',
  time_management: 'bg-indigo-100 text-indigo-800',
  communication: 'bg-cyan-100 text-cyan-800',
  nutrition: 'bg-orange-100 text-orange-800',
  shopping: 'bg-pink-100 text-pink-800',
  organization: 'bg-gray-100 text-gray-800',
  goal_setting: 'bg-yellow-100 text-yellow-800',
  networking: 'bg-blue-100 text-blue-800',
  side_hustles: 'bg-green-100 text-green-800',
  credit: 'bg-emerald-100 text-emerald-800',
  insurance: 'bg-blue-100 text-blue-800',
  investing: 'bg-green-100 text-green-800',
};

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career: 'Career',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social',
  transportation: 'Transportation',
  technology: 'Technology',
  fitness: 'Fitness',
  mental_health: 'Mental Health',
  healthcare: 'Healthcare',
  relationships: 'Relationships',
  education: 'Education',
  personal_care: 'Personal Care',
  safety: 'Safety',
  travel: 'Travel',
  environment: 'Environment',
  consumer_rights: 'Consumer Rights',
  time_management: 'Time Management',
  communication: 'Communication',
  nutrition: 'Nutrition',
  shopping: 'Shopping',
  organization: 'Organization',
  goal_setting: 'Goal Setting',
  networking: 'Networking',
  side_hustles: 'Side Hustles',
  credit: 'Credit',
  insurance: 'Insurance',
  investing: 'Investing',
};

const categoryIcons: Record<string, string> = {
  finances: 'card',
  health_insurance: 'medical',
  cooking: 'restaurant',
  laundry: 'shirt',
  taxes: 'document-text',
  housing: 'home',
  career: 'briefcase',
  legal: 'library',
  maintenance: 'construct',
  social: 'people',
};

export default function DailyTipsScreen() {
  const [showTipDetail, setShowTipDetail] = useState(false);
  const { 
    getTodaysTip, 
    markTipCompleted, 
    toggleTipBookmark,
    tips 
  } = useTipsStore();
  
  const {
    addTodoItem,
    userProgress
  } = useProgressStore();

  useEffect(() => {
    // Initialize app data if needed
  }, []);

  const todaysTip = getTodaysTip();
  const isCompleted = todaysTip ? userProgress.completedTips.includes(todaysTip.id) : false;
  const isBookmarked = todaysTip ? userProgress.bookmarkedTips.includes(todaysTip.id) : false;

  const handleMarkCompleted = () => {
    if (todaysTip && !isCompleted) {
      markTipCompleted(todaysTip.id);
      Alert.alert("Awesome! 🎉", "You've completed today's tip. Keep building those life skills!");
    }
  };

  const handleBookmark = () => {
    if (todaysTip) {
      toggleTipBookmark(todaysTip.id);
    }
  };

  const handleAddActionToTodo = (action: string) => {
    if (todaysTip) {
      addTodoItem({
        title: action,
        description: `From tip: ${todaysTip.title}`,
        category: todaysTip.category,
        completed: false,
      });
      Alert.alert("Added! ✅", "This action has been added to your todo list!");
    }
  };

  const getSkillProgress = () => {
    const categories = Object.keys(categoryLabels);
    return categories.map(category => {
      const categoryTips = tips.filter(tip => tip.category === category);
      const completedInCategory = categoryTips.filter(tip => 
        userProgress.completedTips.includes(tip.id)
      ).length;
      return {
        category,
        completed: completedInCategory,
        total: categoryTips.length,
      };
    }).filter(cat => cat.total > 0);
  };

  const skillProgress = getSkillProgress();

  if (!todaysTip) {
    return (
      <SafeAreaView className="flex-1 bg-gray-50">
        <View className="flex-1 justify-center items-center p-6">
          <Ionicons name="bulb-outline" size={80} color="#9CA3AF" />
          <Text className="text-2xl font-bold text-gray-600 mt-4 text-center">
            No tip ready yet
          </Text>
          <Text className="text-gray-500 mt-2 text-center">
            Check back soon for new adulting wisdom!
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Welcome Header */}
        <View className="bg-white px-6 py-8">
          <Text className="text-3xl font-bold text-gray-900">Good morning!</Text>
          <Text className="text-lg text-gray-600 mt-1">
            {userProgress.streak} day streak! Keep it up! 🔥
          </Text>
          
          {/* Stats Cards */}
          <View className="flex-row mt-6 space-x-4">
            <View className="flex-1 bg-purple-100 rounded-2xl p-4">
              <View className="flex-row items-center">
                <Ionicons name="flame" size={24} color="#8B5CF6" />
                <View className="ml-3">
                  <Text className="text-2xl font-bold text-purple-900">{userProgress.streak}</Text>
                  <Text className="text-sm text-purple-700">day</Text>
                </View>
              </View>
              <Text className="text-xs text-purple-600 mt-1">Streak</Text>
            </View>
            
            <View className="flex-1 bg-teal-100 rounded-2xl p-4">
              <View className="flex-row items-center">
                <Ionicons name="trophy" size={24} color="#14B8A6" />
                <View className="ml-3">
                  <Text className="text-2xl font-bold text-teal-900">{userProgress.completedTips.length}</Text>
                  <Text className="text-sm text-teal-700">skills</Text>
                </View>
              </View>
              <Text className="text-xs text-teal-600 mt-1">Learned</Text>
            </View>
          </View>

          <Pressable onPress={() => (require('@react-navigation/native').useNavigation as any)().navigate('NotificationSettings')} className="mt-4 bg-blue-50 rounded-2xl p-4 border border-blue-100">
            <View className="flex-row items-center">
              <Ionicons name="notifications-outline" size={20} color="#1D4ED8" />
              <Text className="ml-2 text-blue-800 font-semibold">Enable or adjust daily reminders</Text>
              <Ionicons name="chevron-forward" size={18} color="#1D4ED8" style={{ marginLeft: 'auto' }} />
            </View>
          </Pressable>
        </View>

        {/* Today's Focus */}
        <View className="px-6 py-4">
          <Text className="text-2xl font-bold text-gray-900 mb-4">Today's Focus</Text>
          
          <Pressable 
            onPress={() => setShowTipDetail(true)}
            className="bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100"
          >
            {/* Category Header */}
            <View className={cn("px-6 py-4 flex-row items-center", categoryColors[todaysTip.category])}>
              <Ionicons 
                name={categoryIcons[todaysTip.category] as any} 
                size={24} 
                color="white" 
              />
              <Text className="text-white font-semibold text-lg ml-3">
                {categoryLabels[todaysTip.category]}
              </Text>
              <View className="ml-auto">
                <Pressable onPress={handleBookmark} className="p-2">
                  <Ionicons 
                    name={isBookmarked ? "bookmark" : "bookmark-outline"} 
                    size={24} 
                    color="white" 
                  />
                </Pressable>
              </View>
            </View>

            {/* Content */}
            <View className="p-6">
              <Text className="text-2xl font-bold text-gray-900 mb-2">
                {todaysTip.title}
              </Text>
              
              {todaysTip.estimatedTime && (
                <View className="flex-row items-center mb-4">
                  <Ionicons name="time-outline" size={16} color="#6B7280" />
                  <Text className="text-gray-500 ml-1">{todaysTip.estimatedTime}</Text>
                </View>
              )}

              <Text className="text-gray-700 text-lg leading-relaxed mb-6">
                {todaysTip.content?.overview || todaysTip.description || 'No description available'}
              </Text>


              {/* Completion Button */}
              <Pressable
                onPress={handleMarkCompleted}
                disabled={isCompleted}
                className={cn(
                  "p-4 rounded-xl flex-row items-center justify-center",
                  isCompleted 
                    ? "bg-green-100" 
                    : "bg-blue-500"
                )}
              >
                <Ionicons 
                  name={isCompleted ? "checkmark-circle" : "checkmark-circle-outline"} 
                  size={20} 
                  color={isCompleted ? "#059669" : "#FFFFFF"} 
                />
                <Text className={cn(
                  "ml-2 font-semibold text-lg",
                  isCompleted ? "text-green-700" : "text-white"
                )}>
                  {isCompleted ? "Completed! 🎉" : "Mark Complete"}
                </Text>
              </Pressable>
            </View>
          </Pressable>

          <Text className="text-center text-gray-500 mt-4 text-sm">
            💡 Tap the tip card above for detailed view and action steps
          </Text>
        </View>

        {/* Explore Skills */}
        <View className="px-6 py-4">
          <Text className="text-2xl font-bold text-gray-900 mb-4">Explore Skills</Text>
          
          <View className="flex-row flex-wrap">
            {skillProgress.slice(0, 6).map((skill, index) => (
              <View key={skill.category} className="w-1/2 p-1">
                <View className={cn("rounded-2xl p-4 h-32", categoryColors[skill.category])}>
                  <Ionicons 
                    name={categoryIcons[skill.category] as any} 
                    size={28} 
                    color="white" 
                  />
                  <Text className="text-white font-bold text-lg mt-2">
                    {categoryLabels[skill.category]}
                  </Text>
                  <Text className="text-white/80 text-sm mt-1">
                    {skill.completed}/{skill.total} completed
                  </Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        <View className="h-8" />
      </ScrollView>

      {/* Tip Detail Modal */}
      <TipDetailModal
        tip={todaysTip}
        isVisible={showTipDetail}
        onClose={() => setShowTipDetail(false)}
      />
    </SafeAreaView>
  );
}