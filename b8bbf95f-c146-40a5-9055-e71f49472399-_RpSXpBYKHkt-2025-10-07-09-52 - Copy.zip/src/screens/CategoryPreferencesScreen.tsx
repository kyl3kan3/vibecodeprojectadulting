import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useUIStore } from '../state';
import { SkillCategory, CategoryPreference } from '../types/app';

const categoryData: Record<SkillCategory, {
  title: string;
  description: string;
  icon: string;
  color: string;
  bgColor: string;
}> = {
  money_mastery: {
    title: 'Money Mastery',
    description: 'Budgeting, saving, investing, and financial planning',
    icon: 'cash',
    color: '#10B981',
    bgColor: '#10B981'
  },
  health_wellness: {
    title: 'Health & Wellness',
    description: 'Physical fitness, mental health, and healthy habits',
    icon: 'fitness',
    color: '#EF4444',
    bgColor: '#EF4444'
  },
  home_life: {
    title: 'Home Life',
    description: 'Cooking, cleaning, home maintenance, and organization',
    icon: 'home',
    color: '#8B5CF6',
    bgColor: '#8B5CF6'
  },
  career_growth: {
    title: 'Career Growth',
    description: 'Job searching, interviewing, networking, and professional skills',
    icon: 'briefcase',
    color: '#3B82F6',
    bgColor: '#3B82F6'
  },
  relationships: {
    title: 'Relationships',
    description: 'Communication, dating, friendships, and family dynamics',
    icon: 'people',
    color: '#F59E0B',
    bgColor: '#F59E0B'
  },
  personal_growth: {
    title: 'Personal Growth',
    description: 'Self-improvement, goal setting, and mindfulness',
    icon: 'leaf',
    color: '#06B6D4',
    bgColor: '#06B6D4'
  },
  tech_savvy: {
    title: 'Tech Savvy',
    description: 'Digital skills, online safety, and productivity tools',
    icon: 'laptop',
    color: '#6366F1',
    bgColor: '#6366F1'
  },
  life_admin: {
    title: 'Life Admin',
    description: 'Taxes, insurance, legal documents, and bureaucracy',
    icon: 'document-text',
    color: '#64748B',
    bgColor: '#64748B'
  }
};

const priorityOptions = [
  { value: 'high' as const, label: 'High', color: '#EF4444' },
  { value: 'medium' as const, label: 'Medium', color: '#F59E0B' },
  { value: 'low' as const, label: 'Low', color: '#6B7280' }
];

export default function CategoryPreferencesScreen() {
  const navigation = useNavigation();
  const { userProfile } = useUIStore();
  
  const [categoryPreferences, setCategoryPreferences] = useState<CategoryPreference[]>(
    userProfile?.preferences?.categoryPreferences || 
    Object.keys(categoryData).map(category => ({
      category: category as SkillCategory,
      isEnabled: true,
      priority: 'medium' as const
    }))
  );

  const updateCategoryEnabled = (category: SkillCategory, isEnabled: boolean) => {
    const newPreferences = categoryPreferences.map(pref =>
      pref.category === category ? { ...pref, isEnabled } : pref
    );
    setCategoryPreferences(newPreferences);
    savePreferences(newPreferences);
  };

  const updateCategoryPriority = (category: SkillCategory, priority: 'high' | 'medium' | 'low') => {
    const newPreferences = categoryPreferences.map(pref =>
      pref.category === category ? { ...pref, priority } : pref
    );
    setCategoryPreferences(newPreferences);
    savePreferences(newPreferences);
  };

  const savePreferences = (preferences: CategoryPreference[]) => {
    if (!userProfile) return;

    const updatedProfile = {
      ...userProfile,
      preferences: {
        ...userProfile.preferences,
        categoryPreferences: preferences,
        focusAreas: preferences.filter(p => p.isEnabled).map(p => p.category)
      }
    };

    // App initialization happens in AuthContext
  };

  const getCategoryPreference = (category: SkillCategory) => {
    return categoryPreferences.find(pref => pref.category === category) || {
      category,
      isEnabled: true,
      priority: 'medium' as const
    };
  };

  const enabledCount = categoryPreferences.filter(pref => pref.isEnabled).length;
  const highPriorityCount = categoryPreferences.filter(pref => pref.isEnabled && pref.priority === 'high').length;
  const mediumPriorityCount = categoryPreferences.filter(pref => pref.isEnabled && pref.priority === 'medium').length;

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Header */}
        <View className="px-6 pt-6 pb-8">
          <View className="flex-row items-center mb-8">
            <Pressable 
              onPress={() => navigation.goBack()}
              className="w-12 h-12 rounded-full bg-gray-800 items-center justify-center mr-4 border border-gray-700"
            >
              <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
            </Pressable>
            <View className="flex-1">
              <Text className="text-gray-400 text-sm font-medium mb-1">
                Personalize Your Experience
              </Text>
              <Text className="text-white text-3xl font-black tracking-tight">
                Skill Categories
              </Text>
            </View>
          </View>
        </View>

        {/* Stats Grid */}
        <View className="px-6 mb-8">
          <Text className="text-white text-2xl font-black mb-6">Your Learning Focus</Text>
          <View className="flex-row space-x-3 mb-3">
            {/* Categories Active */}
            <View className="bg-amber-500 rounded-3xl p-5 flex-1">
              <Text className="text-amber-100 text-xs font-bold mb-2">CATEGORIES ACTIVE</Text>
              <Text className="text-white text-3xl font-black">{enabledCount}</Text>
              <Text className="text-amber-200 text-xs font-medium">enabled</Text>
            </View>
            
            {/* High Priority */}
            <View className="bg-red-500 rounded-3xl p-5 flex-1">
              <Text className="text-red-100 text-xs font-bold mb-2">HIGH PRIORITY</Text>
              <Text className="text-white text-3xl font-black">{highPriorityCount}</Text>
              <Text className="text-red-200 text-xs font-medium">focused</Text>
            </View>
          </View>
          
          <View className="flex-row space-x-3">
            {/* Medium Priority */}
            <View className="bg-green-500 rounded-3xl p-5 flex-1">
              <Text className="text-green-100 text-xs font-bold mb-2">MEDIUM PRIORITY</Text>
              <Text className="text-white text-3xl font-black">{mediumPriorityCount}</Text>
              <Text className="text-green-200 text-xs font-medium">balanced</Text>
            </View>
            
            {/* Total Categories */}
            <View className="bg-blue-500 rounded-3xl p-5 flex-1">
              <Text className="text-blue-100 text-xs font-bold mb-2">TOTAL</Text>
              <Text className="text-white text-3xl font-black">{Object.keys(categoryData).length}</Text>
              <Text className="text-blue-200 text-xs font-medium">categories</Text>
            </View>
          </View>
        </View>

        {/* How It Works */}
        <View className="px-6 mb-8">
          <View className="bg-blue-600 rounded-3xl p-6">
            <View className="flex-row items-center mb-4">
              <View className="w-12 h-12 bg-blue-500 rounded-2xl items-center justify-center mr-4">
                <Ionicons name="information-circle" size={24} color="white" />
              </View>
              <Text className="text-white text-xl font-bold">How It Works</Text>
            </View>
            <Text className="text-blue-100 leading-relaxed">
              Choose which life skill categories you want to focus on. High priority categories will appear more frequently in your recommendations and daily challenges.
            </Text>
          </View>
        </View>

        {/* Categories */}
        <View className="px-6">
          <Text className="text-white text-2xl font-black mb-6">All Categories</Text>
          {Object.entries(categoryData).map(([category, data]) => {
            const preference = getCategoryPreference(category as SkillCategory);
            
            return (
              <View key={category} className="bg-gray-800 rounded-3xl border border-gray-700 mb-4">
                <View className="p-6">
                  {/* Category Header */}
                  <View className="flex-row items-center justify-between mb-6">
                    <View className="flex-row items-center flex-1">
                      <View 
                        className="w-12 h-12 rounded-2xl items-center justify-center mr-4"
                        style={{ backgroundColor: data.color }}
                      >
                        <Ionicons name={data.icon as any} size={24} color="white" />
                      </View>
                      <View className="flex-1">
                        <Text className="text-white text-lg font-bold">
                          {data.title}
                        </Text>
                        <Text className="text-gray-400 text-sm mt-1 leading-relaxed">
                          {data.description}
                        </Text>
                      </View>
                    </View>
                    <Switch
                      value={preference.isEnabled}
                      onValueChange={(enabled) => updateCategoryEnabled(category as SkillCategory, enabled)}
                      trackColor={{ false: '#374151', true: `${data.color}40` }}
                      thumbColor={preference.isEnabled ? data.color : '#9CA3AF'}
                    />
                  </View>

                  {/* Priority Selection */}
                  {preference.isEnabled && (
                    <View>
                      <Text className="text-gray-300 text-sm font-bold mb-3">
                        Priority Level
                      </Text>
                      <View className="flex-row space-x-3">
                        {priorityOptions.map((option) => (
                          <Pressable
                            key={option.value}
                            onPress={() => updateCategoryPriority(category as SkillCategory, option.value)}
                            className={`flex-1 py-3 px-4 rounded-2xl border-2 ${
                              preference.priority === option.value
                                ? 'border-amber-500 bg-amber-500'
                                : 'border-gray-600 bg-gray-700'
                            }`}
                          >
                            <Text className={`text-center font-bold ${
                              preference.priority === option.value ? 'text-gray-900' : 'text-gray-300'
                            }`}>
                              {option.label}
                            </Text>
                          </Pressable>
                        ))}
                      </View>
                    </View>
                  )}
                </View>
              </View>
            );
          })}
        </View>

        {/* Pro Tips */}
        <View className="px-6 mt-4">
          <View className="bg-purple-600 rounded-3xl p-6">
            <View className="flex-row items-center mb-4">
              <View className="w-12 h-12 bg-purple-500 rounded-2xl items-center justify-center mr-4">
                <Ionicons name="bulb" size={24} color="white" />
              </View>
              <Text className="text-white text-xl font-bold">Pro Tips</Text>
            </View>
            <View className="space-y-3">
              <Text className="text-purple-100">
                • Start with 3-5 categories to avoid overwhelm
              </Text>
              <Text className="text-purple-100">
                • Set 1-2 categories as high priority for focused learning
              </Text>
              <Text className="text-purple-100">
                • You can adjust these preferences anytime
              </Text>
              <Text className="text-purple-100">
                • Disabled categories can still be accessed manually
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}