// src/screens/SubscriptionSheet.tsx
import React, { useEffect, useState } from "react";
import { Linking, View, Text, Pressable, StyleSheet, ActivityIndicator, ScrollView } from "react-native";
import * as WebBrowser from "expo-web-browser";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import Constants from "expo-constants";
import { getProduct, purchase, restore, manageSubscriptionsUrl, storekit } from "../services/storekit";
import { useUIStore } from "../state";
import { TERMS_URL, PRIVACY_URL } from "../utils/legal";

export default function SubscriptionSheet() {
  const insets = useSafeAreaInsets();
  const [priceText, setPriceText] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [productLoading, setProductLoading] = useState(true);
  const [buttonEnabled, setButtonEnabled] = useState(true);
  const [feedback, setFeedback] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);

  const isExpo = (Constants?.appOwnership === "expo");

  useEffect(() => {
    (async () => {
      try {
        setProductLoading(true);
        setButtonEnabled(true);
        const p = await getProduct();
        setPriceText(p?.localizedPrice ?? "");
      } catch {
        setPriceText("");
      } finally {
        setProductLoading(false);
      }
    })();
  }, []);

  const onSubscribe = async () => {
    setLoading(true);
    try {
      if (isExpo) {
        try {
          await storekit.openManageSubscriptions();
          setFeedback({ type: "info", text: "Purchases are managed in the App Store on this build." });
        } catch {
          setFeedback({ type: "error", text: "Cannot open Apple Subscriptions here." });
        }
        return;
      }
      const state = await purchase();
      if (state === "purchased") {
        useUIStore.getState().setIsPro(true);
        setFeedback({ type: "success", text: "Thanks for subscribing. Pro features are unlocking." });
      } else if (state === "deferred") {
        setFeedback({ type: "info", text: "Purchase is pending approval." });
      } else if (state === "error") {
        setFeedback({ type: "error", text: "Purchase failed. Please try again." });
      } else {
        setFeedback({ type: "info", text: "Purchase cancelled." });
      }
    } finally {
      setLoading(false);
    }
  };

  const onRestore = async () => {
    setLoading(true);
    try {
      const state = await restore();
      if (state === "restored") {
        useUIStore.getState().setIsPro(true);
        setFeedback({ type: "success", text: "Your Pro access is active." });
      } else if (state === "error") {
        setFeedback({ type: "error", text: "Restore failed." });
      } else {
        setFeedback({ type: "info", text: "Nothing to restore." });
      }
    } finally {
      setLoading(false);
    }
  };

  const onManage = () => Linking.openURL(manageSubscriptionsUrl());

  if (productLoading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: "#111827", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator size="large" color="#10B981" />
        <Text style={styles.loadingText}>Loading subscription details...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#111827" }}>
      <ScrollView
        style={{ flex: 1, backgroundColor: "#111827" }}
        contentContainerStyle={{ padding: 20, paddingBottom: 20 + insets.bottom + 24 }}
        showsVerticalScrollIndicator={false}
        stickyHeaderIndices={[0]}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Upgrade to Pro</Text>
          <Text style={styles.subtitle}>Unlock all features and premium content</Text>
        </View>

        {feedback && (
          <View style={[styles.feedback, feedback.type === "success" ? styles.feedbackSuccess : feedback.type === "error" ? styles.feedbackError : styles.feedbackInfo]}>
            <Text style={styles.feedbackText}>{feedback.text}</Text>
          </View>
        )}

        {/* Subscription Information Banner */}
        <View style={styles.infoBanner}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Subscription Type:</Text>
            <Text style={styles.infoValue}>Monthly Auto-Renewable</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Billing Cycle:</Text>
            <Text style={styles.infoValue}>Monthly</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Cancellation:</Text>
            <Text style={styles.infoValue}>Cancel anytime in Settings</Text>
          </View>
        </View>

        <View style={styles.pricingSection}>
          <Text style={styles.featureTitle}>Pro Monthly</Text>
          <Text style={styles.subscriptionType}>Monthly Auto-Renewable Subscription</Text>
          {priceText ? (
            <Text style={styles.price}>{priceText}/month</Text>
          ) : (
            <Text style={styles.priceUnavailable}>Price unavailable</Text>
          )}
          <Text style={styles.subscriptionDetails}>
            Subscription automatically renews monthly unless cancelled at least 24 hours before the end of the current period.
          </Text>
        </View>

        {isExpo && (
          <View style={{ backgroundColor: "#78350F", borderRadius: 12, padding: 12, marginHorizontal: 20, marginBottom: 12, borderWidth: 1, borderColor: "#A16207" }}>
            <Text style={{ color: "#FDE68A" }}>Purchases are unavailable in Expo Go. Use a development or store build. You can still Restore or Manage subscriptions.</Text>
          </View>
        )}

        {/* Free vs Pro comparison */}
        <View style={{ backgroundColor: "#1F2937", borderRadius: 12, padding: 16, marginBottom: 20 }}>
          <Text style={{ color: "#FFFFFF", fontWeight: "700", marginBottom: 8 }}>What you get</Text>
          <View style={{ flexDirection: "row" }}>
            <View style={{ flex: 1, paddingRight: 8 }}>
              <Text style={{ color: "#9CA3AF", fontWeight: "700", marginBottom: 6 }}>Free</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• 3 AI messages/month</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• 1 message per day</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• 3 starter skills</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• No saves, no Insights</Text>
            </View>
            <View style={{ width: 1, backgroundColor: "#374151" }} />
            <View style={{ flex: 1, paddingLeft: 8 }}>
              <Text style={{ color: "#9CA3AF", fontWeight: "700", marginBottom: 6 }}>Pro</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• Unlimited AI</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• All skills unlocked</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• Save skills, Insights</Text>
              <Text style={{ color: "#D1D5DB", marginBottom: 4 }}>• AI module generation</Text>
            </View>
          </View>
        </View>
 
        <View style={styles.featuresList}>
          <Text style={styles.featureItem}>• Unlimited AI coaching sessions</Text>
          <Text style={styles.featureItem}>• Advanced life skill modules</Text>
          <Text style={styles.featureItem}>• Priority support</Text>
          <Text style={styles.featureItem}>• Ad-free experience</Text>
        </View>

        <View style={styles.buttonContainer}>
          <Pressable
            style={[styles.primaryButton, (loading || !buttonEnabled) && styles.disabledButton]}
            onPress={onSubscribe}
            disabled={loading || !buttonEnabled}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Text style={styles.primaryButtonText}>Subscribe Now</Text>
            )}
          </Pressable>
          
          {/* Fallback button to ensure subscription is always accessible */}
          {!buttonEnabled && (
            <Pressable
              style={[styles.primaryButton, { backgroundColor: "#059669" }]}
              onPress={onSubscribe}
            >
              <Text style={styles.primaryButtonText}>Start Pro Subscription</Text>
            </Pressable>
          )}

          <Pressable
            style={[styles.secondaryButton, loading && styles.disabledButton]}
            onPress={onRestore}
            disabled={loading}
          >
            <Text style={styles.secondaryButtonText}>Restore Purchases</Text>
          </Pressable>

          <Pressable
            style={styles.linkButton}
            onPress={onManage}
          >
            <Text style={styles.linkButtonText}>Manage Subscriptions</Text>
          </Pressable>
        </View>

        {/* Legal Links */}
        <View style={styles.legalSection}>
          <Text style={styles.legalTitle}>Legal Information</Text>
          <View style={styles.legalLinks}>
            <Pressable
              style={styles.legalLink}
              onPress={() => Linking.openURL(TERMS_URL)}
            >
              <Text style={styles.legalLinkText}>Terms of Use (EULA)</Text>
            </Pressable>
            <Text style={styles.legalSeparator}>•</Text>
            <Pressable
              style={styles.legalLink}
              onPress={() => WebBrowser.openBrowserAsync(PRIVACY_URL)}
            >
              <Text style={styles.legalLinkText}>Privacy Policy</Text>
            </Pressable>
          </View>
        </View>

        <Text style={styles.disclaimer}>
          Subscription automatically renews unless auto-renew is turned off at least 24 hours before the end of the current period. 
          You can manage and cancel subscriptions in your App Store account settings at any time after purchase.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#111827",
    padding: 20,
  },
  header: {
    alignItems: "center",
    marginBottom: 20,
  },
  infoBanner: {
    backgroundColor: "#1F2937",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: "#9CA3AF",
    fontWeight: "500",
  },
  infoValue: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#9CA3AF",
    textAlign: "center",
    lineHeight: 22,
  },
  pricingSection: {
    alignItems: "center",
    marginBottom: 30,
    padding: 20,
    backgroundColor: "#1F2937",
    borderRadius: 12,
  },
  featureTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  subscriptionType: {
    fontSize: 14,
    color: "#9CA3AF",
    marginBottom: 8,
    textAlign: "center",
  },
  price: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#10B981",
    marginBottom: 8,
  },
  priceUnavailable: {
    fontSize: 18,
    color: "#9CA3AF",
    fontStyle: "italic",
    marginBottom: 8,
  },
  subscriptionDetails: {
    fontSize: 12,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 16,
    maxWidth: 280,
  },
  featuresList: {
    marginBottom: 30,
  },
  featureItem: {
    fontSize: 16,
    color: "#D1D5DB",
    marginBottom: 12,
    paddingLeft: 20,
  },
  buttonContainer: {
    gap: 12,
    marginBottom: 20,
  },
  primaryButton: {
    backgroundColor: "#10B981",
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    minHeight: 56,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "600",
  },
  secondaryButton: {
    backgroundColor: "transparent",
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#374151",
    minHeight: 56,
  },
  secondaryButtonText: {
    color: "#D1D5DB",
    fontSize: 16,
    fontWeight: "500",
  },
  linkButton: {
    paddingVertical: 12,
    alignItems: "center",
  },
  linkButtonText: {
    color: "#10B981",
    fontSize: 16,
    textDecorationLine: "underline",
  },
  disabledButton: {
    opacity: 0.6,
  },
  disclaimer: {
    fontSize: 12,
    color: "#6B7280",
    textAlign: "center",
    lineHeight: 16,
  },
  loadingText: {
    color: "#9CA3AF",
    marginTop: 16,
    fontSize: 16,
  },
  legalSection: {
    marginBottom: 20,
    alignItems: "center",
  },
  legalTitle: {
    fontSize: 14,
    color: "#9CA3AF",
    marginBottom: 12,
    fontWeight: "500",
  },
  legalLinks: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  legalLink: {
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  legalLinkText: {
    color: "#10B981",
    fontSize: 14,
    textDecorationLine: "underline",
  },
  legalSeparator: {
    color: "#6B7280",
    fontSize: 14,
    marginHorizontal: 8,
  },
  feedback: {
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 16,
  },
  feedbackSuccess: {
    backgroundColor: "#064E3B",
    borderWidth: 1,
    borderColor: "#10B981",
  },
  feedbackError: {
    backgroundColor: "#3F1D1D",
    borderWidth: 1,
    borderColor: "#EF4444",
  },
  feedbackInfo: {
    backgroundColor: "#1F2937",
    borderWidth: 1,
    borderColor: "#374151",
  },
  feedbackText: {
    color: "#FFFFFF",
    textAlign: "center",
  },
});
