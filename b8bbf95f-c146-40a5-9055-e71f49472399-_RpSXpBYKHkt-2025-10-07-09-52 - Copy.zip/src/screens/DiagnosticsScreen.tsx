/**
 * DiagnosticsScreen
 * In-app diagnostics to view migration status and storage data
 * Helps debug data loss issues when console isn't available
 */

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLessonsStore } from '../state/lessons-store';
import { useProgressStore } from '../state/progress-store';
import { useUIStore } from '../state/ui-store';
import { useTipsStore } from '../state/tips-store';
import { useAuthStore, getSessionInfo } from '../state/auth-store';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../contexts/AuthContext';
import { getDisplayName } from '../utils/profile-display';

interface StorageInfo {
  allKeys: string[];
  oldStoreExists: boolean;
  oldStoreData: any;
  newLessonsStore: any;
  newProgressStore: any;
  migrationComplete: boolean;
}

export default function DiagnosticsScreen() {
  const navigation = useNavigation();
  const [storageInfo, setStorageInfo] = useState<StorageInfo | null>(null);
  const [loading, setLoading] = useState(true);
  
  const lessonsStore = useLessonsStore();
  const progressStore = useProgressStore();
  const uiStore = useUIStore();
  const tipsStore = useTipsStore();
  const authStore = useAuthStore();
  const sessionInfo = getSessionInfo();
  
  const handleForceReloadLessons = async () => {
    try {
      Alert.alert(
        'Force Reload Lessons',
        'This will reload all lessons from the database. Continue?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Reload',
            style: 'destructive',
            onPress: async () => {
              if (__DEV__) console.log('🔄 Force reloading lessons from database...');
              await lessonsStore.loadSkillsFromDatabase();
              Alert.alert('Success', 'Lessons reloaded! Check console for resource logs.');
            }
          }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to reload lessons: ' + (error as Error).message);
    }
  };
  const { user, profile, refreshSession } = useAuth();

  const loadStorageInfo = async () => {
    setLoading(true);
    try {
      const allKeys = await AsyncStorage.getAllKeys() as string[];
      
      const oldStoreData = await AsyncStorage.getItem('project-adulting-store');
      const oldStore = oldStoreData ? JSON.parse(oldStoreData) : null;
      
      const lessonsData = await AsyncStorage.getItem('project-adulting-lessons-store');
      const lessonsStoreData = lessonsData ? JSON.parse(lessonsData) : null;
      
      const progressData = await AsyncStorage.getItem('project-adulting-progress-store');
      const progressStoreData = progressData ? JSON.parse(progressData) : null;
      
      const migrationFlag = await AsyncStorage.getItem('phase1-migration-complete');
      
      setStorageInfo({
        allKeys,
        oldStoreExists: !!oldStore,
        oldStoreData: oldStore?.state || null,
        newLessonsStore: lessonsStoreData?.state || null,
        newProgressStore: progressStoreData?.state || null,
        migrationComplete: migrationFlag === 'true'
      });
    } catch (error) {
      if (__DEV__) console.error('Error loading storage info:', error);
      Alert.alert('Error', 'Failed to load storage info');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStorageInfo();
  }, []);

  const handleResetMigration = async () => {
    Alert.alert(
      'Reset Migration',
      'This will reset the migration flag and allow data migration to run again on next app restart. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.removeItem('phase1-migration-complete');
            Alert.alert('Success', 'Migration flag reset. Please restart the app to trigger migration.');
            loadStorageInfo();
          }
        }
      ]
    );
  };

  const handleClearAllData = async () => {
    Alert.alert(
      '⚠️ Clear All Data',
      'This will delete ALL local data. Only use for debugging. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.clear();
            Alert.alert('Cleared', 'All data cleared. Please restart the app.');
            loadStorageInfo();
          }
        }
      ]
    );
  };

  const handleRefreshProfile = async () => {
    Alert.alert(
      '🔄 Refresh Profile',
      'This will reload your profile from the database and clear any cached profile data.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Refresh',
          onPress: async () => {
            try {
              // Clear UI store profile cache (only the user-related data)
              uiStore.setUser(null);
              
              // Refresh session which will reload profile from database
              await refreshSession();
              
              Alert.alert('Success', 'Profile refreshed from database!');
              loadStorageInfo();
            } catch (error: any) {
              Alert.alert('Error', error.message || 'Failed to refresh profile');
            }
          }
        }
      ]
    );
  };

  const handleShowRawAuthStore = async () => {
    try {
      const authData = await AsyncStorage.getItem('project-adulting-auth-store');
      const parsed = authData ? JSON.parse(authData) : null;
      
      Alert.alert(
        'Raw Auth Storage',
        `${JSON.stringify(parsed, null, 2)}`,
        [{ text: 'OK' }],
        { cancelable: true }
      );
    } catch (error: any) {
      Alert.alert('Error', `Failed to read auth store: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 items-center justify-center">
          <Text className="text-white text-lg">Loading diagnostics...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 py-4 border-b border-gray-800">
        <View className="flex-row items-center">
          <Pressable onPress={() => navigation.goBack()} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#FFF" />
          </Pressable>
          <Text className="text-white text-2xl font-bold">Diagnostics</Text>
        </View>
      </View>

      <ScrollView className="flex-1 px-6 py-4">
        {/* Current Store State */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">📊 Current Store State</Text>
          <View className="space-y-2">
            <Text className="text-gray-300">Skills loaded: <Text className="text-white font-bold">{lessonsStore.skills?.length || 0}</Text></Text>
            <Text className="text-gray-300">Completed skills: <Text className="text-white font-bold">{lessonsStore.completedSkills?.length || 0}</Text></Text>
            <Text className="text-gray-300">Total XP: <Text className="text-white font-bold">{progressStore.totalXP || 0}</Text></Text>
            <Text className="text-gray-300">Streak: <Text className="text-white font-bold">{progressStore.userProgress?.streak || 0}</Text> days</Text>
            <Text className="text-gray-300">User name: <Text className="text-white font-bold">{uiStore.userProfile?.name || 'Not set'}</Text></Text>
            <Text className="text-gray-300">Tips loaded: <Text className="text-white font-bold">{tipsStore.tips?.length || 0}</Text></Text>
          </View>
        </View>

        {/* Auth Session Status */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">🔐 Auth Session Status</Text>
          <View className="space-y-2">
            <Text className="text-gray-300">Remember Me: <Text className={`${sessionInfo.rememberMe ? 'text-green-400' : 'text-red-400'} font-bold`}>{sessionInfo.rememberMe ? 'YES' : 'NO'}</Text></Text>
            <Text className="text-gray-300">Is Authenticated: <Text className={`${sessionInfo.isAuthenticated ? 'text-green-400' : 'text-red-400'} font-bold`}>{sessionInfo.isAuthenticated ? 'YES' : 'NO'}</Text></Text>
            <Text className="text-gray-300">Session Expired: <Text className={`${sessionInfo.isExpired ? 'text-red-400' : 'text-green-400'} font-bold`}>{sessionInfo.isExpired ? 'YES' : 'NO'}</Text></Text>
            <Text className="text-gray-300">Auto Restore: <Text className={`${sessionInfo.shouldAutoRestore ? 'text-green-400' : 'text-red-400'} font-bold`}>{sessionInfo.shouldAutoRestore ? 'YES' : 'NO'}</Text></Text>
            <Text className="text-gray-300 text-xs mt-2">Created: {sessionInfo.createdAt || 'Not set'}</Text>
            <Text className="text-gray-300 text-xs">Last Validated: {sessionInfo.lastValidated || 'Never'}</Text>
            {sessionInfo.isAuthenticated && sessionInfo.sessionAge > 0 && (
              <Text className="text-gray-300 text-xs">Session Age: {Math.floor(sessionInfo.sessionAge / (1000 * 60 * 60))} hours</Text>
            )}
          </View>
        </View>

        {/* Profile Data Diagnostics */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">👤 Profile Data</Text>
          <View className="space-y-2">
            <Text className="text-gray-300">Database Username: <Text className="text-white font-bold">{profile?.username || 'Not set'}</Text></Text>
            <Text className="text-gray-300">Database Full Name: <Text className="text-white font-bold">{profile?.full_name || 'Not set'}</Text></Text>
            <Text className="text-gray-300">User Email: <Text className="text-white font-bold">{user?.email || profile?.email || 'Not set'}</Text></Text>
            <Text className="text-gray-300">UI Store Name: <Text className="text-white font-bold">{uiStore.userProfile?.name || 'Not set'}</Text></Text>
            <Text className="text-gray-300">Computed Display Name: <Text className="text-emerald-400 font-bold">{getDisplayName(profile, user, uiStore.userProfile)}</Text></Text>
            <View className="mt-2 pt-2 border-t border-gray-700">
              <Text className="text-gray-400 text-xs">Priority: @username {">"} full_name {">"} email prefix {">"} Friend</Text>
            </View>
          </View>
        </View>

        {/* Migration Status */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">🔄 Migration Status</Text>
          <Text className={`${storageInfo?.migrationComplete ? 'text-green-400' : 'text-yellow-400'} font-bold`}>
            {storageInfo?.migrationComplete ? '✅ Migration Complete' : '⏳ Migration Not Run'}
          </Text>
        </View>

        {/* AsyncStorage Info */}
        <View className="bg-gray-800 rounded-2xl p-4 mb-4 border border-gray-700">
          <Text className="text-white text-lg font-bold mb-3">💾 AsyncStorage Info</Text>
          <View className="space-y-2">
            <Text className="text-gray-300">Total keys: <Text className="text-white font-bold">{storageInfo?.allKeys.length || 0}</Text></Text>
            <Text className={`${storageInfo?.oldStoreExists ? 'text-green-400' : 'text-red-400'} font-bold`}>
              {storageInfo?.oldStoreExists ? '✅ Old store exists' : '❌ Old store not found'}
            </Text>
            
            {storageInfo?.oldStoreExists && (
              <View className="mt-2 pl-4 border-l-2 border-blue-500">
                <Text className="text-blue-300 text-sm mb-1">Old Store Data:</Text>
                <Text className="text-gray-400 text-xs">Skills: {storageInfo.oldStoreData?.skills?.length || 0}</Text>
                <Text className="text-gray-400 text-xs">Completed: {storageInfo.oldStoreData?.completedSkills?.length || 0}</Text>
                <Text className="text-gray-400 text-xs">XP: {storageInfo.oldStoreData?.totalXP || 0}</Text>
                <Text className="text-gray-400 text-xs">Name: {storageInfo.oldStoreData?.userProfile?.name || 'Not set'}</Text>
              </View>
            )}
            
            <Text className={`${storageInfo?.newLessonsStore ? 'text-green-400' : 'text-red-400'} font-bold mt-2`}>
              {storageInfo?.newLessonsStore ? '✅ New lessons store exists' : '❌ New lessons store not found'}
            </Text>
            
            {storageInfo?.newLessonsStore && (
              <View className="mt-2 pl-4 border-l-2 border-green-500">
                <Text className="text-green-300 text-sm mb-1">New Lessons Store:</Text>
                <Text className="text-gray-400 text-xs">Skills: {storageInfo.newLessonsStore?.skills?.length || 0}</Text>
                <Text className="text-gray-400 text-xs">Completed: {storageInfo.newLessonsStore?.completedSkills?.length || 0}</Text>
              </View>
            )}
            
            <Text className={`${storageInfo?.newProgressStore ? 'text-green-400' : 'text-red-400'} font-bold mt-2`}>
              {storageInfo?.newProgressStore ? '✅ New progress store exists' : '❌ New progress store not found'}
            </Text>
            
            {storageInfo?.newProgressStore && (
              <View className="mt-2 pl-4 border-l-2 border-purple-500">
                <Text className="text-purple-300 text-sm mb-1">New Progress Store:</Text>
                <Text className="text-gray-400 text-xs">XP: {storageInfo.newProgressStore?.totalXP || 0}</Text>
                <Text className="text-gray-400 text-xs">Streak: {storageInfo.newProgressStore?.userProgress?.streak || 0}</Text>
              </View>
            )}
          </View>
        </View>

        {/* Action Buttons */}
        <View className="space-y-3">
          <Pressable 
            onPress={loadStorageInfo}
            className="bg-blue-600 rounded-2xl p-4 items-center"
          >
            <Text className="text-white font-bold">🔄 Refresh Data</Text>
          </Pressable>

          <Pressable 
            onPress={handleRefreshProfile}
            className="bg-emerald-600 rounded-2xl p-4 items-center"
          >
            <Text className="text-white font-bold">👤 Clear Cache & Refresh Profile</Text>
          </Pressable>

          <Pressable 
            onPress={handleShowRawAuthStore}
            className="bg-purple-600 rounded-2xl p-4 items-center"
          >
            <Text className="text-white font-bold">🔑 Show Raw Auth Storage</Text>
          </Pressable>

          <Pressable 
            onPress={handleResetMigration}
            className="bg-orange-600 rounded-2xl p-4 items-center"
          >
            <Text className="text-white font-bold">🔄 Reset Migration Flag</Text>
          </Pressable>

          <Pressable 
            onPress={handleForceReloadLessons}
            className="bg-blue-600 rounded-2xl p-4 items-center mb-3"
          >
            <Text className="text-white font-bold">🔄 Force Reload Lessons from Database</Text>
          </Pressable>

          <Pressable 
            onPress={handleClearAllData}
            className="bg-red-600 rounded-2xl p-4 items-center"
          >
            <Text className="text-white font-bold">⚠️ Clear All Data (Debug)</Text>
          </Pressable>
          
          <Pressable 
            onPress={() => (navigation as any).navigate('MigrationDebug')}
            className="bg-gray-700 rounded-2xl p-4 items-center border border-gray-600"
          >
            <Text className="text-white font-bold">🔍 View Old Store Contents</Text>
          </Pressable>
        </View>

        {/* Instructions */}
        <View className="bg-gray-800 rounded-2xl p-4 mt-4 mb-8 border border-gray-700">
          <Text className="text-white text-sm font-bold mb-2">📝 Troubleshooting</Text>
          <Text className="text-gray-400 text-xs leading-5">
            If your progress is missing:{'\n\n'}
            1. Check if "Old store exists" above{'\n'}
            2. Tap "Reset Migration Flag"{'\n'}
            3. Restart the app (close completely){'\n'}
            4. Come back here to verify data was migrated{'\n\n'}
            
            The migration copies data from the old store to the new split stores.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
