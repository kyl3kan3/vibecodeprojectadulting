import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useTipsStore, useProgressStore } from '../state';
import { TipCategory } from '../types/adulting';
import { cn } from '../utils/cn';



const categoryColors: Record<string, string> = {
  finances: '#10B981',
  health_insurance: '#3B82F6',
  cooking: '#F59E0B',
  laundry: '#8B5CF6',
  taxes: '#EF4444',
  housing: '#06B6D4',
  career_work: '#6366F1',
  legal: '#84CC16',
  maintenance: '#F97316',
  social: '#EC4899',
  credit: '#7C3AED',
  fitness: '#EF4444',
  mental_health: '#06B6D4',
  healthcare: '#10B981',
  relationships: '#F59E0B',
  education: '#3B82F6',
  personal_care: '#8B5CF6',
  safety: '#EF4444',
  transportation: '#6366F1',
  technology: '#84CC16',
  nutrition: '#F97316',
  shopping: '#EC4899',
  time_management: '#10B981',
  communication: '#3B82F6',
  organization: '#F59E0B',
  goal_setting: '#8B5CF6',
  networking: '#EF4444',
  side_hustles: '#06B6D4',
  insurance: '#6366F1',
  investing: '#84CC16',
  daily_living: '#F97316',
  personal_development: '#EC4899',
  consumer_rights: '#10B981',
  travel: '#3B82F6',
  environment: '#F59E0B',
};

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career_work: 'Career & Work',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social Skills',
  credit: 'Credit',
  fitness: 'Fitness',
  mental_health: 'Mental Health',
  healthcare: 'Healthcare',
  relationships: 'Relationships',
  education: 'Education',
  personal_care: 'Personal Care',
  safety: 'Safety',
  transportation: 'Transportation',
  technology: 'Technology',
  nutrition: 'Nutrition',
  shopping: 'Shopping',
  time_management: 'Time Management',
  communication: 'Communication',
  organization: 'Organization',
  goal_setting: 'Goal Setting',
  networking: 'Networking',
  side_hustles: 'Side Hustles',
  insurance: 'Insurance',
  investing: 'Investing',
  daily_living: 'Daily Living',
  personal_development: 'Personal Development',
  consumer_rights: 'Consumer Rights',
  travel: 'Travel',
  environment: 'Environment',
};

const categoryIcons: Record<string, string> = {
  finances: 'card',
  health_insurance: 'medical',
  cooking: 'restaurant',
  laundry: 'shirt',
  taxes: 'document-text',
  housing: 'home',
  career_work: 'briefcase',
  legal: 'library',
  maintenance: 'construct',
  social: 'people',
  credit: 'card',
  fitness: 'fitness',
  mental_health: 'heart',
  healthcare: 'medical',
  relationships: 'people',
  education: 'school',
  personal_care: 'body',
  safety: 'shield',
  transportation: 'car',
  technology: 'laptop',
  nutrition: 'nutrition',
  shopping: 'bag',
  time_management: 'time',
  communication: 'chatbubbles',
  organization: 'folder',
  goal_setting: 'flag',
  networking: 'people-circle',
  side_hustles: 'cash',
  insurance: 'shield-checkmark',
  investing: 'trending-up',
  daily_living: 'home',
  personal_development: 'person',
  consumer_rights: 'shield',
  travel: 'airplane',
  environment: 'leaf',
};

const categoryDescriptions: Record<string, string> = {
  finances: 'Master budgeting, saving, and financial planning',
  health_insurance: 'Navigate health insurance and coverage options',
  cooking: 'Learn essential cooking skills and meal planning',
  laundry: 'Master clothing care and fabric maintenance',
  taxes: 'Understand tax basics and filing requirements',
  housing: 'Navigate renting and home maintenance',
  career_work: 'Build professional skills and advance your career',
  legal: 'Understand basic legal concepts and rights',
  maintenance: 'Learn to maintain and repair household items',
  social: 'Develop interpersonal and social skills',
  credit: 'Build and manage your credit score',
  fitness: 'Stay physically active and healthy',
  mental_health: 'Manage stress and maintain mental wellness',
  healthcare: 'Navigate healthcare and medical needs',
  relationships: 'Build and maintain healthy relationships',
  education: 'Continue learning and skill development',
  personal_care: 'Maintain hygiene and self-care routines',
  safety: 'Stay safe and prepared for emergencies',
  transportation: 'Navigate transportation and vehicle needs',
  technology: 'Manage digital life and online security',
  nutrition: 'Eat well and plan healthy meals',
  shopping: 'Shop smart and make informed purchases',
  time_management: 'Organize time and boost productivity',
  communication: 'Communicate effectively in all situations',
  organization: 'Keep your life organized and clutter-free',
  goal_setting: 'Set and achieve meaningful goals',
  networking: 'Build professional and personal connections',
  side_hustles: 'Explore additional income opportunities',
  insurance: 'Understand and manage insurance needs',
  investing: 'Start investing for your future',
  daily_living: 'Master essential daily life skills',
  personal_development: 'Grow personally and build confidence',
  consumer_rights: 'Know your rights as a consumer',
  travel: 'Plan and travel safely and affordably',
  environment: 'Live sustainably and reduce waste',
};

const difficultyColors = {
  beginner: { bg: 'bg-green-500', text: 'text-white' },
  intermediate: { bg: 'bg-yellow-500', text: 'text-gray-900' },
  advanced: { bg: 'bg-red-500', text: 'text-white' },
};

export default function CategoryScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { category } = (route.params || {}) as { category?: string };
  if (!category) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900 items-center justify-center">
        <Ionicons name="alert-circle-outline" size={64} color="#6B7280" />
        <Text className="text-xl font-bold text-white mt-4">Category not found</Text>
      </SafeAreaView>
    );
  }
  
  const { getTipsByCategory } = useTipsStore();
  const { userProgress } = useProgressStore();
  
  const categoryTips = getTipsByCategory(category as TipCategory);
  const completedCount = categoryTips.filter(tip => 
    userProgress.completedTips.includes(tip.id)
  ).length;
  const bookmarkedCount = categoryTips.filter(tip => 
    userProgress.bookmarkedTips.includes(tip.id)
  ).length;
  const progressPercentage = categoryTips.length > 0 ? (completedCount / categoryTips.length) * 100 : 0;

  const categoryColor = categoryColors[category] || '#6B7280';
  const categoryName = categoryLabels[category] || category.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  const categoryIcon = categoryIcons[category] || 'help-circle';
  const categoryDesc = categoryDescriptions[category] || 'Learn essential skills in this category';

  const beginnerTips = categoryTips.filter(tip => tip.difficulty === 'beginner');
  const intermediateTips = categoryTips.filter(tip => tip.difficulty === 'intermediate');
  const advancedTips = categoryTips.filter(tip => tip.difficulty === 'advanced');

  const renderTipCard = ({ item: tip }: { item: any }) => {
    const isCompleted = userProgress.completedTips.includes(tip.id);
    const isBookmarked = userProgress.bookmarkedTips.includes(tip.id);
    const difficultyStyle = difficultyColors[tip.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' };

    return (
      <Pressable
        onPress={() => (navigation as any).navigate('TipDetail', { tipId: tip.id })}
        className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-4"
      >
        <View className="flex-row items-start justify-between mb-4">
          <View className="flex-1">
            <View className="flex-row items-center mb-3">
              <View className={cn("px-3 py-1 rounded-full", difficultyStyle.bg)}>
                <Text className={cn("text-xs font-bold uppercase", difficultyStyle.text)}>
                  {tip.difficulty}
                </Text>
              </View>
              {tip.estimatedTime && (
                <View className="bg-gray-700 rounded-full px-3 py-1 ml-2">
                  <Text className="text-gray-300 text-xs font-bold">
                    {tip.estimatedTime}
                  </Text>
                </View>
              )}
            </View>
            <Text className="text-white text-lg font-bold mb-2 leading-tight">
              {tip.title}
            </Text>
          </View>
          
          <View className="flex-row items-center space-x-2 ml-3">
            {isBookmarked && (
              <View className="w-8 h-8 bg-yellow-500 rounded-full items-center justify-center">
                <Ionicons name="bookmark" size={16} color="#111827" />
              </View>
            )}
            {isCompleted && (
              <View className="w-8 h-8 bg-green-500 rounded-full items-center justify-center">
                <Ionicons name="checkmark" size={16} color="#111827" />
              </View>
            )}
          </View>
        </View>

        <Text className="text-gray-400 leading-relaxed mb-4" numberOfLines={3}>
          {tip.content?.overview || tip.description || 'No description available'}
        </Text>

        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            <Ionicons name="time-outline" size={16} color="#9CA3AF" />
            <Text className="text-gray-500 text-sm ml-1">
              {tip.estimatedTime || 30} min
            </Text>
          </View>
          <Ionicons name="arrow-forward" size={16} color="#6B7280" />
        </View>
      </Pressable>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Header */}
        <View className="px-6 pt-6 pb-8">
          <Pressable 
            onPress={() => navigation.goBack()} 
            className="mb-6 flex-row items-center"
          >
            <Ionicons name="arrow-back" size={24} color="#FFF" />
            <Text className="text-white text-base font-medium ml-2">Back</Text>
          </Pressable>
          
          <View className="flex-row justify-between items-center mb-8">
            <View className="flex-1">
              <Text className="text-gray-400 text-sm font-medium mb-1">
                Skills Category
              </Text>
              <Text className="text-white text-3xl font-black tracking-tight">
                {categoryName}
              </Text>
            </View>
            
            {/* Category Icon */}
            <View 
              className="w-16 h-16 rounded-full items-center justify-center shadow-xl"
              style={{ backgroundColor: categoryColor }}
            >
              <Ionicons name={categoryIcon as any} size={28} color="#FFFFFF" />
            </View>
          </View>

          {/* Progress Bar */}
          <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700 mb-6">
            <View className="flex-row justify-between items-center mb-4">
              <Text className="font-bold text-white text-lg">Progress</Text>
              <Text className="font-bold" style={{ color: categoryColor }}>
                {completedCount}/{categoryTips.length} completed
              </Text>
            </View>
            <View className="bg-gray-700 rounded-full h-4">
              <View 
                className="rounded-full h-4" 
                style={{ 
                  width: `${progressPercentage}%`,
                  backgroundColor: categoryColor
                }}
              />
            </View>
            <Text className="text-gray-400 text-sm mt-2">
              {Math.round(progressPercentage)}% mastered
            </Text>
          </View>

          {/* Description */}
          <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700">
            <Text className="text-white text-base leading-relaxed">
              {categoryDesc}
            </Text>
          </View>
        </View>

        {/* Stats Grid */}
        <View className="px-6 mb-8">
          <View className="flex-row space-x-3 mb-3">
            {/* Total Tips */}
            <View className="rounded-3xl p-5 flex-1" style={{ backgroundColor: categoryColor }}>
              <Text className="text-white/70 text-xs font-bold mb-2">TOTAL TIPS</Text>
              <Text className="text-white text-3xl font-black">{categoryTips.length}</Text>
              <Text className="text-white/80 text-xs font-medium">available</Text>
            </View>
            
            {/* Completed */}
            <View className="bg-green-500 rounded-3xl p-5 flex-1">
              <Text className="text-green-100 text-xs font-bold mb-2">COMPLETED</Text>
              <Text className="text-white text-3xl font-black">{completedCount}</Text>
              <Text className="text-green-200 text-xs font-medium">finished</Text>
            </View>
          </View>
          
          <View className="flex-row space-x-3">
            {/* Bookmarked */}
            <View className="bg-yellow-500 rounded-3xl p-5 flex-1">
              <Text className="text-yellow-100 text-xs font-bold mb-2">BOOKMARKED</Text>
              <Text className="text-white text-3xl font-black">{bookmarkedCount}</Text>
              <Text className="text-yellow-200 text-xs font-medium">saved</Text>
            </View>
            
            {/* Difficulty Breakdown */}
            <View className="bg-purple-500 rounded-3xl p-5 flex-1">
              <Text className="text-purple-100 text-xs font-bold mb-2">DIFFICULTY</Text>
              <View className="flex-row items-center space-x-1">
                <Text className="text-white text-sm font-bold">{beginnerTips.length}</Text>
                <Text className="text-purple-200 text-xs">•</Text>
                <Text className="text-white text-sm font-bold">{intermediateTips.length}</Text>
                <Text className="text-purple-200 text-xs">•</Text>
                <Text className="text-white text-sm font-bold">{advancedTips.length}</Text>
              </View>
              <Text className="text-purple-200 text-xs font-medium">B • I • A</Text>
            </View>
          </View>
        </View>

        {/* Tips List */}
        <View className="px-6">
          <Text className="text-white text-2xl font-black mb-6">All Tips</Text>
          
          {categoryTips.length === 0 ? (
            <View className="bg-gray-800 rounded-3xl p-8 items-center border border-gray-700">
              <Ionicons name="library-outline" size={48} color="#6B7280" />
              <Text className="text-gray-400 text-lg font-bold mt-4">No tips available</Text>
              <Text className="text-gray-500 text-center mt-2">
                Tips for this category are coming soon!
              </Text>
            </View>
          ) : (
            <View className="space-y-4">
              {categoryTips.map((tip) => (
                <View key={tip.id}>
                  {renderTipCard({ item: tip })}
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}