import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { useAuth } from "../contexts/AuthContext";
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import ViewShot from 'react-native-view-shot';
import * as Sharing from 'expo-sharing';
import ProgressShareCard from '../components/ProgressShareCard';
import { useNavigation } from '@react-navigation/native';
import { useLessonsStore, useProgressStore, useUIStore } from '../state';
import * as WebBrowser from "expo-web-browser";
import * as MailComposer from "expo-mail-composer";
import { TERMS_URL, PRIVACY_URL, SUPPORT_EMAIL } from "../utils/legal";
import EditProfileModal from '../components/EditProfileModal';
import { getDisplayName } from '../utils/profile-display';
import { getFullVersionString } from '../utils/app-version';

// Menu items factory function
const getMenuItems = () => [
  {
    id: 'notifications',
    title: 'Daily Reminders',
    subtitle: 'Get notified about new tips',
    icon: 'notifications-outline',
  },
  {
    id: 'categories',
    title: 'Skill Categories',
    subtitle: 'Customize which topics you see',
    icon: 'options-outline',
  },
  {
    id: 'feedback',
    title: 'Send Feedback',
    subtitle: 'Help us improve the app',
    icon: 'chatbubble-outline',
  },
  {
    id: 'about',
    title: 'About Adulting Coach',
    subtitle: `Version ${getFullVersionString()}`,
    icon: 'information-circle-outline',
  },
  {
    id: 'subscriptions',
    title: 'Manage Subscription',
    subtitle: 'Upgrade to Pro for unlimited AI coaching',
    icon: 'card-outline',
  },
  {
    id: 'account',
    title: 'Account Settings',
    subtitle: 'Privacy and deletion',
    icon: 'shield-half-outline',
  },
  {
    id: 'legal_terms',
    title: 'Terms of Use',
    subtitle: 'Apple standard EULA',
    icon: 'document-text-outline',
  },
  {
    id: 'legal_privacy',
    title: 'Privacy Policy',
    subtitle: 'Read how we handle data',
    icon: 'lock-closed-outline',
  },
];

export default function ProfileScreen() {
  const navigation = useNavigation();
  const { skills, completedSkills } = useLessonsStore();
  const { achievements, userProgress, totalXP: storeTotalXP, resetUserData } = useProgressStore();
  const { userProfile, logout } = useUIStore();
  const shareRef = React.useRef<ViewShot>(null);
  const { user, profile, refreshSession } = useAuth();
  const [editModalVisible, setEditModalVisible] = useState(false);

  // Get menu items with dynamic version
  const menuItems = React.useMemo(() => getMenuItems(), []);


  // Calculate stats from correct stores
  const completedSkillsCount = completedSkills?.length || 0;
  const savedSkills = userProfile?.savedSkills?.length || 0;
  const streakDays = userProgress?.streak || userProgress?.streakDays || 0;
  
  // Calculate totalXP from completed skills (same as StatsScreen for consistency)
  const totalXP = completedSkills.reduce((sum, skillId) => {
    const skill = skills.find(s => s.id === skillId);
    return sum + (skill?.xpReward || 0);
  }, 0);
  
  const currentLevel = useProgressStore.getState().getUserLevel();


  const handleLogout = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out? This will reset all your progress and data.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            await logout();
            resetUserData();
          },
        },
      ]
    );
  };

  const handleMenuItemPress = async (itemId: string) => {
    switch (itemId) {
      case 'notifications':
        navigation.navigate('NotificationSettings' as never);
        break;
      case 'categories':
        navigation.navigate('CategoryPreferences' as never);
        break;
      case 'feedback':
        try { await MailComposer.composeAsync({ recipients: [SUPPORT_EMAIL], subject: "Feedback", body: "Hi team,\n\n" }); } catch {}
        break;
      case 'about':
        Alert.alert(
          'About',
          'This app helps you master essential life skills through interactive learning, progress tracking, and coaching.'
        );
        break;
      case 'subscriptions':
        navigation.navigate('SubscriptionSheet' as never);
        break;
      case 'account':
        navigation.navigate('AccountSettings' as never);
        break;
      case 'legal_terms':
        await WebBrowser.openBrowserAsync(TERMS_URL);
        break;
      case 'legal_privacy':
        await WebBrowser.openBrowserAsync(PRIVACY_URL);
        break;
    }
  };

  const calculateCompletionPercentage = () => {
    if (skills.length === 0) return 0;
    return Math.round((completedSkillsCount / skills.length) * 100);
  };

  const getStreakMessage = () => {
    if (streakDays === 0) return "Ready to start your adulting journey? 🌟";
    if (streakDays < 7) return "Great start! Keep building momentum! 💪";
    if (streakDays < 30) return "You're on fire! Amazing consistency! 🔥";
    return "Adulting master! You're crushing it! 🏆";
  };

  const getProfileDisplayName = () => {
    return getDisplayName(profile, user, userProfile);
  };

  const handleProfileSaved = async () => {
    // Refresh session to reload profile data
    await refreshSession();
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 py-8">
             <View className="items-center">
             <View className="w-32 h-32 bg-emerald-500 rounded-full items-center justify-center mb-6 shadow-xl">
               <Ionicons name="person" size={48} color="#111827" />
             </View>
             <View className="flex-row items-center">
               <Text className="text-white text-3xl font-black mb-2">
                 {getProfileDisplayName()}
               </Text>
               <Pressable 
                 onPress={() => setEditModalVisible(true)} 
                 className="ml-3 mb-2"
                 hitSlop={8}
               >
                 <Ionicons name="create-outline" size={24} color="#10B981" />
               </Pressable>
             </View>
             <Text className="text-emerald-400 font-bold text-xl mb-2">Level {currentLevel}</Text>
             <Text className="text-gray-400 text-center mb-2 px-4">{getStreakMessage()}</Text>

             {/* Upgrade or Pro badge */}
             {useUIStore.getState().isPro ? (
               <View className="bg-emerald-600 px-3 py-1 rounded-full">
                 <Text className="text-gray-900 font-bold text-xs">PRO</Text>
               </View>
             ) : (
               <Pressable 
                 onPress={() => navigation.navigate('SubscriptionSheet' as never)} 
                 className="bg-emerald-600 px-4 py-2 rounded-full active:bg-emerald-700"
                 style={({ pressed }) => [
                   { backgroundColor: pressed ? '#059669' : '#10B981' }
                 ]}
               >
                 <Text className="text-gray-900 font-bold">Upgrade to Pro</Text>
               </Pressable>
             )}
             
             {/* Progress Circle */}

            <View className="items-center mb-6">
              <View className="relative w-32 h-32 items-center justify-center">
                <View className="absolute w-32 h-32 rounded-full border-8 border-gray-700" />
                <View 
                  className="absolute w-32 h-32 rounded-full border-8 border-emerald-500"
                  style={{
                    transform: [{ rotate: '-90deg' }],
                    borderColor: completedSkillsCount > 0 ? '#10B981' : '#374151',
                    borderTopColor: 'transparent',
                    borderRightColor: completedSkillsCount >= skills.length * 0.25 ? '#10B981' : '#374151',
                    borderBottomColor: completedSkillsCount >= skills.length * 0.5 ? '#10B981' : '#374151',
                    borderLeftColor: completedSkillsCount >= skills.length * 0.75 ? '#10B981' : '#374151',
                  }}
                />
                <View className="items-center">
                  <Text className="text-2xl font-black text-emerald-400">
                    {calculateCompletionPercentage()}%
                  </Text>
                  <Text className="text-xs text-gray-400 font-bold">COMPLETE</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Stats Grid */}
        <View className="px-6 py-6">
          <Text className="text-white text-2xl font-black mb-6">Your Stats</Text>
          <View className="flex-row space-x-3 mb-3">
            <View className="bg-orange-500 rounded-3xl p-5 flex-1">
              <Text className="text-orange-100 text-xs font-bold mb-2">STREAK</Text>
              <Text className="text-white text-3xl font-black">{streakDays}</Text>
              <Text className="text-orange-200 text-xs font-medium">days strong</Text>
            </View>

            <View className="bg-blue-500 rounded-3xl p-5 flex-1">
              <Text className="text-blue-100 text-xs font-bold mb-2">SKILLS</Text>
              <Text className="text-white text-3xl font-black">{completedSkillsCount}</Text>
              <Text className="text-blue-200 text-xs font-medium">mastered</Text>
            </View>
          </View>

          <View className="flex-row space-x-3">
            <View className="bg-purple-500 rounded-3xl p-5 flex-1">
              <Text className="text-purple-100 text-xs font-bold mb-2">TOTAL XP</Text>
              <Text className="text-white text-3xl font-black">{totalXP}</Text>
              <Text className="text-purple-200 text-xs font-medium">points earned</Text>
            </View>

            <View className="bg-pink-500 rounded-3xl p-5 flex-1">
              <Text className="text-pink-100 text-xs font-bold mb-2">SAVED</Text>
              <Text className="text-white text-3xl font-black">{savedSkills}</Text>
              <Text className="text-pink-200 text-xs font-medium">bookmarks</Text>
            </View>
          </View>

          {/* Share Progress */}
          <View className="mt-4">
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Share your progress"
              onPress={async () => {
                try {
                  const uri = await (shareRef.current as any)?.capture?.({ format: 'png', quality: 0.9 });
                  if (uri) { await Sharing.shareAsync(uri); }
                } catch {}
              }}
              className="bg-emerald-600 rounded-3xl p-4 items-center justify-center mt-2"
            >
              <Text className="text-gray-900 font-bold">Share Progress</Text>
            </Pressable>
            <ViewShot ref={shareRef} options={{ format: 'png', quality: 0.9 }} style={{ position: 'absolute', left: -9999 }}>
              <ProgressShareCard streakDays={streakDays} completedTips={completedSkillsCount} totalTips={skills.length} />
            </ViewShot>
          </View>
        </View>

        {/* Achievements Section */}
        <View className="px-6 py-6">
          <Text className="text-white text-2xl font-black mb-6">Badges Earned</Text>
          <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6">
            <View className="flex-row flex-wrap">
              {achievements.filter((a: any) => a.isUnlocked).map((achievement: any) => (
                <View key={achievement.id} className="w-1/3 items-center mb-4">
                  <View className="w-16 h-16 bg-emerald-500 rounded-2xl items-center justify-center mb-2">
                    <Text className="text-2xl">{achievement.icon}</Text>
                  </View>
                  <Text className="text-xs text-emerald-400 text-center font-bold">{achievement.title}</Text>
                </View>
              ))}
              {achievements.filter((a: any) => a.isUnlocked).length === 0 && (
                <View className="w-full items-center py-8">
                  <Ionicons name="medal-outline" size={48} color="#6B7280" />
                  <Text className="text-gray-400 mt-4 text-center">Complete skills to unlock badges!</Text>
                </View>
              )}
            </View>
          </View>
        </View>


         {/* Settings Menu */}
         <View className="px-6 py-6">
          <Text className="text-white text-2xl font-black mb-6">Settings</Text>
          <Pressable onPress={() => navigation.navigate('Achievements' as never)} className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-3">
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="trophy" size={24} color="#111827" />
                </View>
                <View>
                  <Text className="font-bold text-white text-lg">Achievements</Text>
                  <Text className="text-gray-400 text-sm">View your unlocked badges</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#10B981" />
            </View>
          </Pressable>
          <Pressable onPress={() => navigation.navigate('AIPreferences' as never)} className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-3">
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="options" size={24} color="#111827" />
                </View>
                <View>
                  <Text className="font-bold text-white text-lg">AI Preferences</Text>
                  <Text className="text-gray-400 text-sm">Tone, depth, and safety</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#10B981" />
            </View>
          </Pressable>
          <View className="space-y-3">
            {menuItems.map((item) => (
              <Pressable
                key={item.id}
                onPress={() => handleMenuItemPress(item.id)}
                className="bg-gray-800 border border-gray-700 rounded-3xl p-5"
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center flex-1">
                    <View className="w-12 h-12 bg-emerald-500 rounded-2xl items-center justify-center mr-4">
                      <Ionicons name={item.icon as any} size={24} color="#111827" />
                    </View>
                    <View className="flex-1">
                      <Text className="font-bold text-white text-lg">{item.title}</Text>
                      <Text className="text-gray-400 text-sm">{item.subtitle}</Text>
                    </View>
                  </View>
                  <Ionicons name="chevron-forward" size={24} color="#10B981" />
                </View>
              </Pressable>
            ))}
          </View>

          {/* Export Data */}
          <Pressable
            onPress={async () => {
              try {
                const progressState = useProgressStore.getState();
                const uiState = useUIStore.getState();
                const data = JSON.stringify({ userProgress: progressState.userProgress, appProfile: uiState.userProfile }, null, 2);
                await (await import('expo-clipboard')).default.setStringAsync(data);
                Alert.alert('Copied', 'Your data has been copied to the clipboard. You can paste it to save.');
              } catch {}
            }}
            className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mt-4"
          >
            <View className="flex-row items-center justify-center">
              <Ionicons name="download-outline" size={24} color="#10B981" />
              <Text className="font-bold text-white text-lg ml-3">Export My Data</Text>
            </View>
          </Pressable>

          {/* Logout Button */}
          <Pressable
            onPress={handleLogout}
            className="bg-red-600 border border-red-500 rounded-3xl p-5 mt-4"
          >
            <View className="flex-row items-center justify-center">
              <Ionicons name="log-out-outline" size={24} color="white" />
              <Text className="font-bold text-white text-lg ml-3">Sign Out</Text>
            </View>
          </Pressable>
        </View>

        {/* Motivational Section */}
        <View className="px-6 py-4 pb-8">
          <View className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-6">
            <View className="items-center">
              <Ionicons name="trophy" size={40} color="white" />
              <Text className="text-xl font-bold text-white mt-3 text-center">
                Keep Growing!
              </Text>
              <Text className="text-white/90 text-center mt-2 leading-relaxed">
                Every skill you learn is an investment in your future. You're building the foundation for a successful, independent life!
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
      
      {/* Edit Profile Modal */}
      <EditProfileModal 
        visible={editModalVisible}
        onClose={() => setEditModalVisible(false)}
        onSave={handleProfileSaved}
      />
    </SafeAreaView>
  );
}
