import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useUIStore } from '../state';
import { SkillCategory } from '../types/app';
import { cn } from '../utils/cn';
import { useAuth } from '../contexts/AuthContext';
// onboarding runs right after signup; no auth hooks needed here

// window width not needed

interface OnboardingStep {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to Your Adulting Journey',
    subtitle: 'Master essential life skills at your own pace with personalized guidance and practical lessons.',
    icon: '🎯'
  },
  {
    id: 'learn',
    title: 'Learn by Doing',
    subtitle: 'Step-by-step guides for real-world skills like budgeting, cooking, career growth, and more.',
    icon: '📚'
  },
  {
    id: 'progress', 
    title: 'Track Your Growth',
    subtitle: 'Earn XP, unlock achievements, and build streaks as you develop confidence in adult life.',
    icon: '🏆'
  },
  {
    id: 'assessment',
    title: 'Quick Skill Assessment',
    subtitle: 'Help us understand your current level so we can recommend the perfect starting point.',
    icon: '📊'
  }
];

const focusAreas: { category: SkillCategory; label: string; icon: string; description: string }[] = [
  { category: 'money_mastery', label: 'Money Mastery', icon: '💰', description: 'Budgeting, savings, investing' },
  { category: 'career_growth', label: 'Career Growth', icon: '📈', description: 'Job skills, networking, interviews' },
  { category: 'home_life', label: 'Home Life', icon: '🏠', description: 'Cooking, cleaning, organization' },
  { category: 'health_wellness', label: 'Health & Wellness', icon: '💪', description: 'Physical and mental health' },
  { category: 'relationships', label: 'Relationships', icon: '🤝', description: 'Communication, boundaries, dating' },
  { category: 'personal_growth', label: 'Personal Growth', icon: '🌱', description: 'Confidence, habits, goals' },
  { category: 'tech_savvy', label: 'Tech Savvy', icon: '💻', description: 'Digital skills, security, productivity' },
  { category: 'life_admin', label: 'Life Admin', icon: '📋', description: 'Taxes, insurance, legal basics' }
];

const timeCommitments = [
  { value: 'light', label: '10 min/day', description: 'Quick daily tips', color: '#10B981' },
  { value: 'moderate', label: '20 min/day', description: 'Focused learning', color: '#F59E0B' },
  { value: 'intensive', label: '30+ min/day', description: 'Deep skill building', color: '#EF4444' }
];

const assessmentQuestions = [
  {
    id: 'budget',
    question: 'How comfortable are you with creating and following a budget?',
    category: 'money_mastery',
    options: [
      { level: 'beginner', text: "I've never made a budget", score: 1 },
      { level: 'intermediate', text: "I've tried but struggle to stick to it", score: 2 },
      { level: 'advanced', text: "I successfully manage my budget", score: 3 }
    ]
  },
  {
    id: 'cooking',
    question: 'How would you rate your cooking skills?',
    category: 'home_life',
    options: [
      { level: 'beginner', text: "I mostly eat takeout or simple meals", score: 1 },
      { level: 'intermediate', text: "I can make basic meals but want to improve", score: 2 },
      { level: 'advanced', text: "I'm comfortable cooking various dishes", score: 3 }
    ]
  },
  {
    id: 'career',
    question: 'How confident are you in professional networking?',
    category: 'career_growth',
    options: [
      { level: 'beginner', text: "I avoid networking events", score: 1 },
      { level: 'intermediate', text: "I network occasionally but feel awkward", score: 2 },
      { level: 'advanced', text: "I actively network and build relationships", score: 3 }
    ]
  }
];

export default function OnboardingScreen() {
  // navigation not needed; AppNavigator handles routing after onboarding
  // user is authenticated before onboarding
  const [currentStep, setCurrentStep] = useState(0);
  const [userData, setUserData] = useState({
    name: '',
    username: '',
    age: '',
    focusAreas: [] as SkillCategory[],
    timeCommitment: '' as 'light' | 'moderate' | 'intensive',
    learningStyle: '' as 'visual' | 'reading' | 'hands_on',
    skillLevels: {} as Record<string, number>
  });

  const { setJustSignedUpUserId } = useUIStore();
  const { updateProfile } = useAuth();

  const handleNext = () => {
    if (currentStep < 7) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFinish = async () => {
    if (userData.name && userData.username && userData.age && userData.focusAreas.length > 0 && userData.timeCommitment) {
      // Create default category preferences based on assessment
      const categoryPreferences = focusAreas.map(area => ({
        category: area.category,
        isEnabled: userData.focusAreas.includes(area.category),
        priority: userData.focusAreas.includes(area.category) ? 'high' as const : 'medium' as const
      }));
      
      // Determine user level based on assessment
      const avgScore = Object.values(userData.skillLevels).length > 0 
        ? Object.values(userData.skillLevels).reduce((a, b) => a + b, 0) / Object.values(userData.skillLevels).length
        : 2;
      
      // App initialization happens in AuthContext

      // Save user profile data (username and full name)
      try { 
        await updateProfile({ 
          full_name: userData.name,
          username: userData.username 
        }); 
        if (__DEV__) console.log('[Onboarding] Profile saved:', { name: userData.name, username: userData.username });
      } catch (error) {
        if (__DEV__) console.log('[Onboarding] Failed to save profile:', error);
      }
      setJustSignedUpUserId(null);
    }
  };

  const toggleFocusArea = (category: SkillCategory) => {
    setUserData(prev => ({
      ...prev,
      focusAreas: prev.focusAreas.includes(category)
        ? prev.focusAreas.filter(c => c !== category)
        : [...prev.focusAreas, category]
    }));
  };

  const handleAssessmentAnswer = (questionId: string, score: number) => {
    setUserData(prev => ({
      ...prev,
      skillLevels: { ...prev.skillLevels, [questionId]: score }
    }));
  };

  const renderWelcomeSteps = () => {
    if (currentStep > 3) return null;

    const step = onboardingSteps[currentStep];
    
    return (
      <View className="flex-1 justify-center items-center px-8">
        <Text className="text-6xl mb-8">{step.icon}</Text>
        <Text className="text-3xl font-black text-white text-center mb-4">
          {step.title}
        </Text>
        <Text className="text-lg text-gray-300 text-center leading-relaxed mb-12">
          {step.subtitle}
        </Text>
        
        {/* Progress dots */}
        <View className="flex-row space-x-2 mb-8">
          {onboardingSteps.map((_, index) => (
            <View
              key={index}
              className={cn(
                "w-3 h-3 rounded-full",
                index === currentStep ? "bg-emerald-500" : "bg-gray-600"
              )}
            />
          ))}
        </View>
      </View>
    );
  };

  const renderPersonalInfo = () => {
    if (currentStep !== 4) return null;

    return (
      <View className="flex-1 justify-center px-8">
        <Text className="text-3xl font-black text-white text-center mb-2">
          Let's get to know you
        </Text>
        <Text className="text-lg text-gray-300 text-center mb-8">
          This helps us personalize your learning experience
        </Text>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          <View className="space-y-6">
            <View>
              <Text className="text-lg font-bold text-white mb-3">What's your full name?</Text>
              <TextInput
                value={userData.name}
                onChangeText={(text) => setUserData(prev => ({ ...prev, name: text }))}
                placeholder="Enter your full name"
                placeholderTextColor="#9CA3AF"
                className="bg-gray-800 border border-gray-700 rounded-2xl p-4 text-white text-lg"
                autoFocus={false}
                autoComplete="name"
                returnKeyType="next"
              />
            </View>

            <View>
              <Text className="text-lg font-bold text-white mb-3">Choose a username</Text>
              <View className="flex-row items-center bg-gray-800 border border-gray-700 rounded-2xl">
                <Text className="text-gray-400 pl-4 text-lg">@</Text>
                <TextInput
                  value={userData.username}
                  onChangeText={(text) => {
                    // Auto-sanitize: lowercase, no spaces, alphanumeric + underscore only
                    const sanitized = text.toLowerCase().replace(/[^a-z0-9_]/g, '').substring(0, 20);
                    setUserData(prev => ({ ...prev, username: sanitized }));
                  }}
                  placeholder="username"
                  placeholderTextColor="#9CA3AF"
                  className="flex-1 px-2 py-4 text-white text-lg"
                  autoCapitalize="none"
                  autoCorrect={false}
                  autoComplete="username"
                  returnKeyType="next"
                />
              </View>
              <Text className="text-gray-400 text-xs mt-2">
                3-20 characters, letters, numbers, and underscores only
              </Text>
            </View>

            <View>
              <Text className="text-lg font-bold text-white mb-3">How old are you?</Text>
              <View className="flex-row space-x-3">
                {['18-22', '23-26', '27-30', '30+'].map((range) => (
                  <Pressable
                    key={range}
                    onPress={() => setUserData(prev => ({ ...prev, age: range }))}
                    className={cn(
                      "flex-1 p-3 rounded-2xl border-2",
                      userData.age === range
                        ? "border-emerald-500 bg-emerald-500"
                        : "border-gray-600 bg-gray-800"
                    )}
                  >
                    <Text className={cn(
                      "text-center font-bold",
                      userData.age === range ? "text-gray-900" : "text-white"
                    )}>
                      {range}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  };

  const renderAssessment = () => {
    if (currentStep !== 5) return null;

    return (
      <View className="flex-1 px-8 py-8">
        <Text className="text-3xl font-black text-white text-center mb-2">
          Quick Skill Check
        </Text>
        <Text className="text-lg text-gray-300 text-center mb-8">
          Answer a few questions to personalize your recommendations
        </Text>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {assessmentQuestions.map((q, index) => (
            <View key={q.id} className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
              <Text className="text-white font-bold text-lg mb-4">
                {index + 1}. {q.question}
              </Text>
              
              <View className="space-y-3">
                {q.options.map((option) => (
                  <Pressable
                    key={option.level}
                    onPress={() => handleAssessmentAnswer(q.id, option.score)}
                    className={cn(
                      "p-4 rounded-2xl border-2",
                      userData.skillLevels[q.id] === option.score
                        ? "border-emerald-500 bg-emerald-500"
                        : "border-gray-600 bg-gray-700"
                    )}
                  >
                    <Text className={cn(
                      "font-medium",
                      userData.skillLevels[q.id] === option.score ? "text-gray-900" : "text-white"
                    )}>
                      {option.text}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          ))}
        </ScrollView>
      </View>
    );
  };

  const renderFocusAreas = () => {
    if (currentStep !== 6) return null;

    return (
      <View className="flex-1 px-8 py-8">
        <Text className="text-3xl font-black text-white text-center mb-2">
          What do you want to focus on?
        </Text>
        <Text className="text-lg text-gray-300 text-center mb-8">
          Pick 2-4 areas that matter most to you right now
        </Text>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          <View className="space-y-4">
            {focusAreas.map((area) => (
              <Pressable
                key={area.category}
                onPress={() => toggleFocusArea(area.category)}
                className={cn(
                  "p-6 rounded-3xl border-2",
                  userData.focusAreas.includes(area.category)
                    ? "border-emerald-500 bg-emerald-500"
                    : "border-gray-600 bg-gray-800"
                )}
              >
                <View className="flex-row items-center">
                  <Text className="text-3xl mr-4">{area.icon}</Text>
                  <View className="flex-1">
                    <Text className={cn(
                      "font-bold text-lg mb-1",
                      userData.focusAreas.includes(area.category) ? "text-gray-900" : "text-white"
                    )}>
                      {area.label}
                    </Text>
                    <Text className={cn(
                      "text-sm",
                      userData.focusAreas.includes(area.category) ? "text-gray-800" : "text-gray-300"
                    )}>
                      {area.description}
                    </Text>
                  </View>
                  {userData.focusAreas.includes(area.category) && (
                    <Ionicons name="checkmark-circle" size={28} color="#111827" />
                  )}
                </View>
              </Pressable>
            ))}
          </View>
        </ScrollView>
        
        <Text className="text-emerald-400 text-center mt-4 font-bold">
          {userData.focusAreas.length} of 8 selected
        </Text>
      </View>
    );
  };

  const renderTimeCommitment = () => {
    if (currentStep !== 7) return null;

    return (
      <View className="flex-1 justify-center px-8">
        <Text className="text-3xl font-black text-white text-center mb-2">
          How much time can you commit?
        </Text>
        <Text className="text-lg text-gray-300 text-center mb-8">
          Be honest - consistency beats intensity
        </Text>

        <View className="space-y-4">
          {timeCommitments.map((option) => (
            <Pressable
              key={option.value}
              onPress={() => setUserData(prev => ({ ...prev, timeCommitment: option.value as any }))}
              className={cn(
                "p-6 rounded-3xl border-2",
                userData.timeCommitment === option.value
                  ? "border-emerald-500"
                  : "border-gray-600 bg-gray-800"
              )}
              style={userData.timeCommitment === option.value ? { backgroundColor: option.color } : {}}
            >
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className={cn(
                    "text-xl font-bold mb-1",
                    userData.timeCommitment === option.value ? "text-white" : "text-white"
                  )}>
                    {option.label}
                  </Text>
                  <Text className={cn(
                    "text-base",
                    userData.timeCommitment === option.value ? "text-white/80" : "text-gray-300"
                  )}>
                    {option.description}
                  </Text>
                </View>
                {userData.timeCommitment === option.value && (
                  <Ionicons name="checkmark-circle" size={28} color="white" />
                )}
              </View>
            </Pressable>
          ))}
        </View>
      </View>
    );
  };

  const canProceed = () => {
    switch (currentStep) {
      case 4:
        return userData.name && userData.username && userData.username.length >= 3 && userData.age;
      case 5:
        return Object.keys(userData.skillLevels).length === assessmentQuestions.length;
      case 6:
        return userData.focusAreas.length >= 2;
      case 7:
        return userData.timeCommitment;
      default:
        return true;
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      {renderWelcomeSteps()}
      {renderPersonalInfo()}
      {renderAssessment()}
      {renderFocusAreas()}
      {renderTimeCommitment()}

      {/* Navigation */}
      <View className="px-8 pb-8">
        <View className="flex-row space-x-4">
          {currentStep > 0 && (
            <Pressable
              onPress={handleBack}
              className="flex-1 py-4 bg-gray-800 border border-gray-700 rounded-3xl"
            >
              <Text className="text-center font-bold text-white">Back</Text>
            </Pressable>
          )}
          
          <Pressable
            onPress={currentStep === 7 ? handleFinish : handleNext}
            disabled={!canProceed()}
            className={cn(
              "flex-1 py-4 rounded-3xl",
              canProceed() ? "bg-emerald-500" : "bg-gray-600"
            )}
          >
            <Text className={cn(
              "text-center font-bold text-lg",
              canProceed() ? "text-gray-900" : "text-gray-400"
            )}>
              {currentStep === 7 ? 'Finish' : 'Next' }
            </Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}