import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useLessonsStore, useProgressStore } from '../state';
import { useNavigation } from '@react-navigation/native';
import { cn } from '../utils/cn';

const categoryLabels: Record<string, string> = {
  money_mastery: 'Money Mastery',
  career_growth: 'Career Growth',
  home_life: 'Home Life',
  health_wellness: 'Health & Wellness',
  relationships: 'Relationships',
  personal_growth: 'Personal Growth',
  tech_savvy: 'Tech Savvy',
  life_admin: 'Life Admin'
};

const categoryColors: Record<string, string> = {
  money_mastery: 'bg-green-500',
  career_growth: 'bg-blue-500',
  home_life: 'bg-purple-500',
  health_wellness: 'bg-red-500',
  relationships: 'bg-orange-500',
  personal_growth: 'bg-cyan-500',
  tech_savvy: 'bg-indigo-500',
  life_admin: 'bg-gray-600'
};

const categoryIcons: Record<string, any> = {
  money_mastery: 'cash',
  career_growth: 'trending-up',
  home_life: 'home',
  health_wellness: 'fitness',
  relationships: 'people',
  personal_growth: 'leaf',
  tech_savvy: 'laptop',
  life_admin: 'document-text'
};

export default function StatsScreen() {
  const navigation = useNavigation<any>();
  const { skills, completedSkills } = useLessonsStore();
  const { userProgress, achievements } = useProgressStore();

  const completedCount = completedSkills.length;
  const totalSkills = skills.length;
  const completionRate = totalSkills > 0 ? Math.round((completedCount / totalSkills) * 100) : 0;
  
  // Calculate total XP
  const totalXP = completedSkills.reduce((sum, skillId) => {
    const skill = skills.find(s => s.id === skillId);
    return sum + (skill?.xpReward || 0);
  }, 0);

  // Get streak
  const streak = userProgress?.streak || 0;

  // Calculate category stats
  const getCategoryStats = () => {
    const categories = Object.keys(categoryLabels);
    return categories.map(category => {
      const categorySkills = skills.filter(skill => skill.category === category);
      const completedInCategory = categorySkills.filter(skill => 
        completedSkills.includes(skill.id)
      ).length;
      return {
        category,
        label: categoryLabels[category],
        total: categorySkills.length,
        completed: completedInCategory,
        percentage: categorySkills.length > 0 ? Math.round((completedInCategory / categorySkills.length) * 100) : 0,
      };
    }).filter(cat => cat.total > 0).sort((a, b) => b.percentage - a.percentage);
  };

  const categoryStats = getCategoryStats();

  // Get top categories (most completed)
  const topCategories = categoryStats.slice(0, 3);

  // Recent achievements
  const recentAchievements = achievements?.slice(0, 5) || [];

  // Get recently completed skills
  const recentlyCompleted = completedSkills
    .slice(-3)
    .reverse()
    .map(skillId => skills.find(s => s.id === skillId))
    .filter(Boolean);

  // Calculate milestones
  const milestones = [
    { target: 10, label: 'First 10', icon: 'star', color: 'text-yellow-400' },
    { target: 25, label: 'Quarter Century', icon: 'trophy', color: 'text-orange-400' },
    { target: 50, label: 'Half Century', icon: 'medal', color: 'text-purple-400' },
    { target: 100, label: 'Century Club', icon: 'ribbon', color: 'text-blue-400' },
  ];

  const nextMilestone = milestones.find(m => completedCount < m.target);
  const progressToNext = nextMilestone 
    ? Math.round((completedCount / nextMilestone.target) * 100)
    : 100;

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-8 pb-6">
          <Text className="text-white text-3xl font-black mb-2">Your Stats</Text>
          <Text className="text-gray-400 text-base">
            Track your learning progress
          </Text>
        </View>

        {/* Main Stats Grid */}
        <View className="px-6 mb-6">
          <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700 mb-4">
            <Text className="text-emerald-400 text-5xl font-black text-center mb-2">
              {completedCount}
            </Text>
            <Text className="text-gray-400 text-sm text-center font-medium">
              Completed Skills
            </Text>
          </View>

          <View className="flex-row space-x-3 mb-3">
            <View className="bg-gray-800 rounded-3xl p-5 flex-1 border border-gray-700">
              <Text className="text-cyan-400 text-3xl font-black text-center">
                {totalSkills}
              </Text>
              <Text className="text-gray-400 text-xs text-center mt-1 font-medium">
                Total Skills
              </Text>
            </View>
            <View className="bg-gray-800 rounded-3xl p-5 flex-1 border border-gray-700">
              <Text className="text-emerald-400 text-3xl font-black text-center">
                {completionRate}%
              </Text>
              <Text className="text-gray-400 text-xs text-center mt-1 font-medium">
                Completion Rate
              </Text>
            </View>
          </View>

          <View className="flex-row space-x-3">
            <View className="bg-gray-800 rounded-3xl p-5 flex-1 border border-gray-700">
              <Text className="text-emerald-400 text-3xl font-black text-center">
                {totalXP}
              </Text>
              <Text className="text-gray-400 text-xs text-center mt-1 font-medium">
                Total XP
              </Text>
            </View>
            <View className="bg-gray-800 rounded-3xl p-5 flex-1 border border-gray-700">
              <Text className="text-orange-400 text-3xl font-black text-center">
                {streak}
              </Text>
              <Text className="text-gray-400 text-xs text-center mt-1 font-medium">
                Day Streak
              </Text>
            </View>
          </View>
        </View>

        {/* Next Milestone */}
        {nextMilestone && completedCount > 0 && (
          <View className="px-6 mb-6">
            <Text className="text-white text-xl font-black mb-4">Next Milestone</Text>
            <View className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-3xl p-6 border border-purple-500/30">
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center">
                  <View className="w-12 h-12 bg-purple-500 rounded-full items-center justify-center mr-3">
                    <Ionicons name={nextMilestone.icon as any} size={24} color="white" />
                  </View>
                  <View>
                    <Text className="text-white font-bold text-lg">{nextMilestone.label}</Text>
                    <Text className="text-gray-400 text-sm">
                      {completedCount} / {nextMilestone.target} skills
                    </Text>
                  </View>
                </View>
                <Text className="text-purple-400 font-black text-2xl">{progressToNext}%</Text>
              </View>
              
              {/* Progress Bar */}
              <View className="h-3 bg-gray-700 rounded-full overflow-hidden">
                <View 
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
                  style={{ width: `${progressToNext}%` }}
                />
              </View>
            </View>
          </View>
        )}

        {/* Top Categories */}
        {topCategories.length > 0 && (
          <View className="px-6 mb-6">
            <Text className="text-white text-xl font-black mb-4">Top Categories</Text>
            <View className="space-y-3">
              {topCategories.map((cat, index) => (
                <View key={cat.category} className="bg-gray-800 rounded-3xl p-5 border border-gray-700">
                  <View className="flex-row items-center mb-3">
                    <View className="w-10 h-10 bg-emerald-500 rounded-full items-center justify-center mr-3">
                      <Text className="text-white font-black text-lg">{index + 1}</Text>
                    </View>
                    <View className={cn("w-10 h-10 rounded-xl items-center justify-center mr-3", categoryColors[cat.category])}>
                      <Ionicons name={categoryIcons[cat.category]} size={20} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-bold">{cat.label}</Text>
                      <Text className="text-gray-400 text-sm">
                        {cat.completed} of {cat.total}
                      </Text>
                    </View>
                    <Text className="text-emerald-400 font-bold text-xl">{cat.percentage}%</Text>
                  </View>
                  
                  {/* Progress Bar */}
                  <View className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <View 
                      className={cn("h-full rounded-full", categoryColors[cat.category])}
                      style={{ width: `${cat.percentage}%` }}
                    />
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Recent Achievements */}
        <View className="px-6 mb-6">
          <Text className="text-white text-xl font-black mb-4">Recent Achievements</Text>
          {recentAchievements.length > 0 ? (
            <View className="space-y-3">
              {recentAchievements.map((achievement, index) => (
                <View key={index} className="bg-gray-800 rounded-3xl p-5 border border-yellow-500/30">
                  <View className="flex-row items-center">
                    <View className="w-12 h-12 bg-yellow-500 rounded-full items-center justify-center mr-4">
                      <Ionicons name="trophy" size={24} color="white" />
                    </View>
                    <View className="flex-1">
                      <Text className="text-white font-bold text-base">{achievement.title}</Text>
                      {achievement.description && (
                        <Text className="text-gray-400 text-sm mt-1">{achievement.description}</Text>
                      )}
                    </View>
                  </View>
                </View>
              ))}
            </View>
          ) : (
            <View className="bg-gray-800 rounded-3xl p-8 border border-gray-700">
              <View className="items-center">
                <View className="w-16 h-16 bg-gray-700 rounded-full items-center justify-center mb-4">
                  <Ionicons name="trophy-outline" size={32} color="#6B7280" />
                </View>
                <Text className="text-gray-400 text-center italic">
                  No achievements yet. Keep learning!
                </Text>
              </View>
            </View>
          )}
        </View>

        {/* Recently Completed */}
        {recentlyCompleted.length > 0 && (
          <View className="px-6 mb-8">
            <Text className="text-white text-xl font-black mb-4">Recently Completed</Text>
            <View className="space-y-3">
              {recentlyCompleted.map(skill => {
                if (!skill) return null;
                return (
                  <Pressable
                    key={skill.id}
                    onPress={() => navigation.navigate('SkillDetail', { skillId: skill.id })}
                    className="bg-gray-800 rounded-3xl p-5 border border-emerald-500/30"
                  >
                    <View className="flex-row items-center">
                      <View className={cn("w-12 h-12 rounded-2xl items-center justify-center mr-4", categoryColors[skill.category])}>
                        <Ionicons name={categoryIcons[skill.category]} size={24} color="white" />
                      </View>
                      <View className="flex-1">
                        <Text className="text-white font-bold" numberOfLines={1}>{skill.title}</Text>
                        <Text className="text-emerald-400 text-sm font-bold mt-1">+{skill.xpReward} XP</Text>
                      </View>
                      <View className="w-8 h-8 bg-emerald-500 rounded-full items-center justify-center">
                        <Ionicons name="checkmark" size={16} color="white" />
                      </View>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          </View>
        )}

        {/* Empty State */}
        {completedCount === 0 && (
          <View className="px-6 mb-8">
            <View className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 rounded-3xl p-8 border border-emerald-500/30">
              <View className="items-center">
                <View className="w-20 h-20 bg-emerald-500 rounded-full items-center justify-center mb-4">
                  <Ionicons name="stats-chart" size={40} color="white" />
                </View>
                <Text className="text-white text-2xl font-black text-center mb-2">
                  Start Your Journey
                </Text>
                <Text className="text-gray-300 text-center mb-6">
                  Complete lessons to see your stats come to life!
                </Text>
                <Pressable
                  onPress={() => navigation.navigate('Learn')}
                  className="bg-emerald-500 px-8 py-4 rounded-2xl"
                >
                  <Text className="text-white font-bold text-base">Explore Lessons</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
