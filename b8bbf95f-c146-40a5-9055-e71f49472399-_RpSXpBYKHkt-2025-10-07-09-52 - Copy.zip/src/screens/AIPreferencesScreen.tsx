import React from 'react';
import { View, Text, Pressable, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useUIStore } from '../state';

const tones: Array<{ key: 'friendly' | 'neutral' | 'formal'; label: string }> = [
  { key: 'friendly', label: 'Friendly' },
  { key: 'neutral', label: 'Professional' },
  { key: 'formal', label: 'Formal' },
];
const depths: Array<{ key: 'brief' | 'detailed'; label: string }> = [
  { key: 'brief', label: 'Brief' },
  { key: 'detailed', label: 'Detailed' },
];

export default function AIPreferencesScreen() {
  const navigation = useNavigation();
  const { userProfile, updateUserPreferences } = useUIStore();

  const pref = userProfile?.preferences || {} as any;
  const tone = (pref.aiTone as 'friendly' | 'neutral' | 'formal') || 'friendly';
  const depth = (pref.aiDepth as 'brief' | 'detailed') || 'brief';
  const safety = typeof pref.safetyMode === 'boolean' ? pref.safetyMode : true;

  const setTone = (t: 'friendly' | 'neutral' | 'formal') => updateUserPreferences({ aiTone: t });
  const setDepth = (d: 'brief' | 'detailed') => updateUserPreferences({ aiDepth: d });
  const setSafety = (v: boolean) => updateUserPreferences({ safetyMode: v });

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      {/* Header */}
      <View className="px-6 py-6 border-b border-gray-700">
        <View className="flex-row items-center">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="w-12 h-12 rounded-2xl bg-gray-800 border border-gray-700 items-center justify-center mr-4"
          >
            <Ionicons name="chevron-back" size={20} color="#10B981" />
          </Pressable>
          <Text className="text-white text-2xl font-black">AI Preferences</Text>
        </View>
      </View>

      <View className="flex-1 px-6 py-6">
        {/* Tone */}
        <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
          <Text className="text-white text-lg font-black mb-3">Tone</Text>
          <View className="flex-row">
            {tones.map(opt => (
              <Pressable
                key={opt.key}
                onPress={() => setTone(opt.key)}
                className={`mr-3 px-4 py-2 rounded-xl border-2 ${tone === opt.key ? 'border-emerald-500 bg-emerald-500/20' : 'border-gray-600 bg-gray-700'}`}
              >
                <Text className={`${tone === opt.key ? 'text-emerald-400' : 'text-gray-300'} font-bold`}>{opt.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Depth */}
        <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
          <Text className="text-white text-lg font-black mb-3">Depth</Text>
          <View className="flex-row">
            {depths.map(opt => (
              <Pressable
                key={opt.key}
                onPress={() => setDepth(opt.key)}
                className={`mr-3 px-4 py-2 rounded-xl border-2 ${depth === opt.key ? 'border-emerald-500 bg-emerald-500/20' : 'border-gray-600 bg-gray-700'}`}
              >
                <Text className={`${depth === opt.key ? 'text-emerald-400' : 'text-gray-300'} font-bold`}>{opt.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Safety */}
        <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5">
          <View className="flex-row items-center justify-between">
            <View className="mr-4 flex-1">
              <Text className="text-white text-lg font-black mb-1">Safety mode</Text>
              <Text className="text-gray-400">Avoid sensitive or adult-only topics.</Text>
            </View>
            <Switch
              value={safety}
              onValueChange={setSafety}
              trackColor={{ false: '#374151', true: '#065F46' }}
              thumbColor={safety ? '#10B981' : '#6B7280'}
            />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}
