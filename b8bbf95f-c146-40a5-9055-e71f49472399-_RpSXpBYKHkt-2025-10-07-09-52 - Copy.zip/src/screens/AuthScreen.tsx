import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
} from 'react-native';
import Checkbox from 'expo-checkbox';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';

export const AuthScreen: React.FC<any> = ({ route }) => {
  const greetingName: string | undefined = route?.params?.greetingName;
  const mode: 'signin' | 'signup' | undefined = route?.params?.mode;
  const [isLogin, setIsLogin] = useState(mode === 'signup' ? false : true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [rememberMe, setRememberMe] = useState(true); // Default to TRUE so users stay logged in
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalMessage, setModalMessage] = useState('');

  const { signIn, signUp } = useAuth();

  const showModal = (title: string, message: string) => {
    setModalTitle(title);
    setModalMessage(message);
    setModalVisible(true);
  };

  const handleAuth = async () => {
    if (!email || !password) {
      showModal('Error', 'Please fill in all fields');
      return;
    }

    if (!isLogin && !fullName) {
      showModal('Error', 'Please enter your full name');
      return;
    }

    setLoading(true);

    try {
      if (isLogin) {
        if (__DEV__) console.log('[AuthScreen] Signing in with rememberMe:', rememberMe);
        const { error } = await signIn(email, password, rememberMe);
        if (error) {
          showModal('Login Error', error.message);
        } else {
          if (__DEV__) console.log('[AuthScreen] Sign in successful, rememberMe was:', rememberMe);
        }
      } else {
        const { error } = await signUp(email, password, fullName);
        if (error) {
          showModal('Sign Up Error', error.message);
        } else {
          showModal(
            'Success',
            'Account created successfully! Please check your email to verify your account.'
          );
        }
      }
    } catch (error) {
      showModal('Error', 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const toggleAuthMode = () => {
    setIsLogin(!isLogin);
    setEmail('');
    setPassword('');
    setFullName('');
    setRememberMe(true); // Keep remember me enabled by default
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        <ScrollView className="flex-1 px-6">
          <View className="flex-1 justify-center py-12">
            {/* Header */}
              <View className="items-center mb-8">
                <View className="w-20 h-20 bg-emerald-500 rounded-full items-center justify-center mb-4">
                  <Ionicons name="school" size={32} color="#111827" />
                </View>
                <Text className="text-3xl font-bold text-white mb-2">
                  {isLogin ? 'Welcome Back' : 'Create your free account'}
                </Text>
                <Text className="text-gray-400 text-center">
                  {isLogin
                    ? 'Sign in to continue your adulting journey'
                    : greetingName
                      ? `Welcome, ${greetingName}. Save your progress and sync across devices.`
                      : 'Save your progress and sync across devices'}
                </Text>
              </View>

            {/* Form */}
            <View className="space-y-4">
              {!isLogin && (
                <View>
                  <Text className="text-gray-400 font-medium mb-2">Full Name</Text>
                  <TextInput
                    value={fullName}
                    onChangeText={setFullName}
                    placeholder="Enter your full name"
                    placeholderTextColor="#9CA3AF"
                    className="w-full px-4 py-3 border border-gray-700 rounded-2xl text-white bg-gray-800"
                    autoCapitalize="words"
                    autoComplete="name"
                  />
                </View>
              )}

                <View>
                <Text className="text-gray-400 font-medium mb-2">Email</Text>
                <TextInput
                  value={email}
                  onChangeText={setEmail}
                  placeholder="Enter your email"
                  placeholderTextColor="#9CA3AF"
                  className="w-full px-4 py-3 border border-gray-700 rounded-2xl text-white bg-gray-800"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                />
              </View>

                <View>
                <Text className="text-gray-400 font-medium mb-2">Password</Text>
                <View className="relative">
                  <TextInput
                    value={password}
                    onChangeText={setPassword}
                    placeholder="Enter your password"
                    placeholderTextColor="#9CA3AF"
                    className="w-full px-4 py-3 border border-gray-700 rounded-2xl text-white bg-gray-800 pr-12"
                    secureTextEntry={!showPassword}
                    autoComplete="password"
                  />
                  <Pressable
                    onPress={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-3"
                  >
                    <Ionicons
                      name={showPassword ? 'eye-off' : 'eye'}
                      size={20}
                      color="#9CA3AF"
                    />
                  </Pressable>
                </View>
              </View>

              {/* Stay Logged In checkbox - only show on login */}
              {isLogin && (
                <View>
                  <View className="flex-row items-center space-x-3 mt-2">
                    <Checkbox
                      value={rememberMe}
                      onValueChange={setRememberMe}
                      color={rememberMe ? '#10B981' : undefined}
                      style={{
                        width: 20,
                        height: 20,
                        borderRadius: 4,
                        borderColor: '#6B7280'
                      }}
                    />
                    <Pressable onPress={() => setRememberMe(!rememberMe)} className="flex-1">
                      <Text className="text-gray-400 text-sm">
                        Stay logged in
                      </Text>
                    </Pressable>
                  </View>
                </View>
              )}

              <Pressable
                onPress={handleAuth}
                disabled={loading}
                className={`w-full py-4 rounded-2xl items-center ${
                  loading ? "bg-gray-700" : "bg-emerald-500"
                } ${isLogin ? "mt-6" : "mt-4"}`}
              >
                {loading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text className="text-gray-900 font-black text-lg">
                    {isLogin ? 'Sign In' : 'Sign Up'}
                  </Text>
                )}
              </Pressable>

              <View className="flex-row justify-center items-center mt-6">
                <Text className="text-gray-400">
                  {isLogin ? "Don't have an account? " : 'Already have an account? '}
                </Text>
                <Pressable onPress={toggleAuthMode}>
                  <Text className="text-amber-500 font-semibold">
                    {isLogin ? 'Sign Up' : 'Sign In'}
                  </Text>
                </Pressable>
              </View>

              {/* Session indicator */}
              <View className="items-center mt-8">
                {!!useAuth().user && (
                  <Text className="text-gray-500 text-xs">Signed in as {useAuth().user?.email || useAuth().user?.id}</Text>
                )}
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View className="flex-1 justify-center items-center bg-black/50">
          <View className="bg-gray-800 rounded-lg p-6 mx-6 max-w-sm w-full border border-gray-700">
            <Text className="text-lg font-bold text-white mb-2">
              {modalTitle}
            </Text>
            <Text className="text-gray-300 mb-4">
              {modalMessage}
            </Text>
            <Pressable
              onPress={() => setModalVisible(false)}
              className="bg-emerald-500 py-3 px-6 rounded-2xl items-center"
            >
              <Text className="text-white font-semibold">OK</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}; 