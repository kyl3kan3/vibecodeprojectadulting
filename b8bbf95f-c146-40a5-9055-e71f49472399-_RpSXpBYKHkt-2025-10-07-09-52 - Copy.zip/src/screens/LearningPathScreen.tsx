import React, { useMemo } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { NavigationProp, RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { useLessonsStore, useProgressStore, useUIStore } from '../state';
import { learningPaths } from '../data/learning-paths';
import { cn } from '../utils/cn';

type LearningPathScreenRouteProp = RouteProp<RootStackParamList, 'LearningPath'>;

const difficultyColors = {
  beginner: { bg: 'bg-green-500', text: 'text-green-100', border: 'border-green-400' },
  intermediate: { bg: 'bg-yellow-500', text: 'text-yellow-100', border: 'border-yellow-400' },
  advanced: { bg: 'bg-red-500', text: 'text-red-100', border: 'border-red-400' }
};

const LearningPathScreen = React.memo(function LearningPathScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();
  const route = useRoute<LearningPathScreenRouteProp>();
  const { pathId } = route.params;
  
  const { skills, skillProgress } = useLessonsStore();
  const { 
    activeLearningPaths,
    startLearningPath,
    getLearningPathProgress
  } = useProgressStore();
  const { userProfile } = useUIStore();

  const learningPath = useMemo(() => 
    learningPaths.find(path => path.id === pathId), 
    [pathId]
  );

  const pathSkills = useMemo(() => 
    learningPath ? skills.filter(skill => learningPath.skillIds.includes(skill.id)) : [],
    [learningPath, skills]
  );

  const pathProgress = useMemo(() => 
    getLearningPathProgress(pathId),
    [pathId, getLearningPathProgress]
  );

  const isPathActive = useMemo(() => 
    activeLearningPaths.includes(pathId),
    [activeLearningPaths, pathId]
  );

  const prerequisitesPaths = useMemo(() => {
    if (!learningPath?.prerequisites) return [];
    return learningPaths.filter(path => learningPath.prerequisites!.includes(path.id));
  }, [learningPath]);

  const prerequisitesMet = useMemo(() => {
    if (!learningPath?.prerequisites) return true;
    return learningPath.prerequisites.every(prereqId => 
      activeLearningPaths.includes(prereqId) && 
      getLearningPathProgress(prereqId).completedSkills.length === 
      learningPaths.find(p => p.id === prereqId)?.skillIds.length
    );
  }, [learningPath, activeLearningPaths, getLearningPathProgress]);

  const completedSkillsCount = useMemo(() => 
    pathProgress.completedSkills.length,
    [pathProgress.completedSkills]
  );

  const totalSkillsCount = useMemo(() => 
    learningPath?.skillIds.length || 0,
    [learningPath]
  );

  const progressPercentage = useMemo(() => 
    totalSkillsCount > 0 ? (completedSkillsCount / totalSkillsCount) * 100 : 0,
    [completedSkillsCount, totalSkillsCount]
  );

  if (!learningPath) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 justify-center items-center">
          <Text className="text-white text-xl">Learning path not found</Text>
          <Pressable 
            onPress={() => navigation.goBack()}
            className="mt-4 bg-emerald-500 px-6 py-3 rounded-2xl"
          >
            <Text className="text-gray-900 font-bold">Go Back</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  const handleStartPath = () => {
    if (prerequisitesMet) {
      startLearningPath(pathId);
    }
  };

  const handleSkillPress = (skillId: string) => {
    navigation.navigate('SkillDetail', { skillId });
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Header */}
        <View className="px-6 pt-4 pb-6">
          <View className="flex-row items-center justify-between mb-6">
            <Pressable 
              onPress={() => navigation.goBack()}
              className="w-10 h-10 bg-gray-800 rounded-full items-center justify-center"
            >
              <Ionicons name="chevron-back" size={20} color="#FFFFFF" />
            </Pressable>
            
            <View className={cn(
              "px-3 py-1 rounded-full",
              (difficultyColors[learningPath.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' }).bg
            )}>
              <Text className={cn(
                "text-xs font-bold uppercase",
                (difficultyColors[learningPath.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' }).text
              )}>
                {learningPath.difficulty}
              </Text>
            </View>
          </View>

          {/* Path Info */}
          <View className="mb-6">
            <Text className="text-4xl mb-4">{learningPath.icon}</Text>
            <Text className="text-white text-3xl font-black mb-3 leading-tight">
              {learningPath.title}
            </Text>
            <Text className="text-gray-400 text-lg leading-relaxed mb-6">
              {learningPath.description}
            </Text>
            
            {/* Path Stats */}
            <View className="flex-row space-x-4">
              <View className="bg-gray-800 rounded-2xl px-4 py-3 flex-1">
                <Text className="text-gray-400 text-xs font-bold mb-1">DURATION</Text>
                <Text className="text-white text-lg font-bold">{learningPath.estimatedTime}</Text>
              </View>
              <View className="bg-gray-800 rounded-2xl px-4 py-3 flex-1">
                <Text className="text-gray-400 text-xs font-bold mb-1">SKILLS</Text>
                <Text className="text-white text-lg font-bold">{totalSkillsCount}</Text>
              </View>
            </View>
          </View>

          {/* Progress Bar (if path is active) */}
          {isPathActive && (
            <View className="bg-gray-800 rounded-3xl p-6 mb-6">
              <View className="flex-row justify-between items-center mb-4">
                <Text className="text-white text-lg font-bold">Your Progress</Text>
                <Text className="text-emerald-400 font-bold">
                  {completedSkillsCount}/{totalSkillsCount} skills
                </Text>
              </View>
              <View className="bg-gray-700 rounded-full h-4">
                <View 
                  className="bg-emerald-500 rounded-full h-4" 
                  style={{ width: `${progressPercentage}%` }}
                />
              </View>
              <Text className="text-gray-400 text-sm mt-2">
                {Math.round(progressPercentage)}% complete
              </Text>
            </View>
          )}

          {/* Prerequisites */}
          {prerequisitesPaths.length > 0 && (
            <View className="mb-6">
              <Text className="text-white text-xl font-bold mb-4">Prerequisites</Text>
              {prerequisitesPaths.map((prereqPath) => {
                const prereqProgress = getLearningPathProgress(prereqPath.id);
                const prereqCompleted = prereqProgress.completedSkills.length === prereqPath.skillIds.length;
                
                return (
                  <View 
                    key={prereqPath.id}
                    className={cn(
                      "bg-gray-800 rounded-2xl p-4 mb-3 border-2",
                      prereqCompleted ? "border-emerald-500" : "border-gray-700"
                    )}
                  >
                    <View className="flex-row items-center justify-between">
                      <View className="flex-1">
                        <Text className="text-white font-bold mb-1">{prereqPath.title}</Text>
                        <Text className="text-gray-400 text-sm">{prereqPath.description}</Text>
                      </View>
                      <View className={cn(
                        "w-8 h-8 rounded-full items-center justify-center",
                        prereqCompleted ? "bg-emerald-500" : "bg-gray-600"
                      )}>
                        <Ionicons 
                          name={prereqCompleted ? "checkmark" : "lock-closed"} 
                          size={16} 
                          color={prereqCompleted ? "#111827" : "#9CA3AF"} 
                        />
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          )}
        </View>

        {/* Skills List */}
        <View className="px-6">
          <Text className="text-white text-2xl font-black mb-6">Skills in This Path</Text>
          {pathSkills.map((skill, index) => {
            const isCompleted = userProfile?.completedSkills.includes(skill.id) || false;
            const hasProgress = skillProgress[skill.id];
            const isInProgress = hasProgress && !isCompleted;
            
            return (
              <Pressable
                key={skill.id}
                onPress={() => handleSkillPress(skill.id)}
                className={cn(
                  "bg-gray-800 rounded-3xl p-6 mb-4 border-2",
                  isCompleted ? "border-emerald-500" : 
                  isInProgress ? "border-yellow-500" : "border-gray-700"
                )}
              >
                <View className="flex-row items-center justify-between mb-4">
                  <View className="flex-1">
                    <View className="flex-row items-center mb-2">
                      <Text className="text-gray-400 text-sm font-bold mr-3">
                        SKILL {index + 1}
                      </Text>
                      {isCompleted && (
                        <View className="bg-emerald-500 rounded-full px-2 py-1">
                          <Text className="text-gray-900 text-xs font-bold">COMPLETED</Text>
                        </View>
                      )}
                      {isInProgress && (
                        <View className="bg-yellow-500 rounded-full px-2 py-1">
                          <Text className="text-gray-900 text-xs font-bold">IN PROGRESS</Text>
                        </View>
                      )}
                    </View>
                    <Text className="text-white text-lg font-bold mb-2">{skill.title}</Text>
                    <Text className="text-gray-400 text-sm leading-relaxed" numberOfLines={2}>
                      {skill.description}
                    </Text>
                  </View>
                  <View className={cn(
                    "w-12 h-12 rounded-full items-center justify-center ml-4",
                    isCompleted ? "bg-emerald-500" : 
                    isInProgress ? "bg-yellow-500" : "bg-gray-700"
                  )}>
                    <Ionicons 
                      name={isCompleted ? "checkmark" : isInProgress ? "play" : "chevron-forward"} 
                      size={20} 
                      color={isCompleted || isInProgress ? "#111827" : "#9CA3AF"} 
                    />
                  </View>
                </View>
                
                <View className="flex-row justify-between items-center">
                  <View className="bg-gray-700 rounded-full px-3 py-1">
                    <Text className="text-gray-300 text-xs font-bold">{skill.estimatedTime} MIN</Text>
                  </View>
                  <View className="bg-emerald-500 rounded-full px-3 py-1">
                    <Text className="text-gray-900 text-xs font-black">+{skill.xpReward} XP</Text>
                  </View>
                </View>
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      {/* Bottom Action Button */}
      <View className="px-6 pb-6" style={{ paddingBottom: Math.max(insets.bottom, 24) }}>
        {!isPathActive ? (
          <Pressable
            onPress={handleStartPath}
            disabled={!prerequisitesMet}
            className={cn(
              "rounded-3xl py-6",
              prerequisitesMet 
                ? "bg-emerald-500" 
                : "bg-gray-700"
            )}
          >
            <Text className={cn(
              "text-center text-xl font-black",
              prerequisitesMet 
                ? "text-gray-900" 
                : "text-gray-400"
            )}>
              {prerequisitesMet ? "START LEARNING PATH" : "COMPLETE PREREQUISITES FIRST"}
            </Text>
          </Pressable>
        ) : (
          <View className="bg-gray-800 rounded-3xl p-6">
            <View className="flex-row items-center justify-center">
              <Ionicons name="checkmark-circle" size={24} color="#10B981" />
              <Text className="text-white text-lg font-bold ml-3">
                Path Active - Keep Learning!
              </Text>
            </View>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
});

export default LearningPathScreen;