import React, { useState, useMemo } from 'react';
import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { TipCategory, AdultingTip } from '../types/adulting';
import { cn } from '../utils/cn';
import { shareTip } from '../utils/sharing';
import { useTipsStore, useProgressStore, useUIStore } from '../state';

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career: 'Career',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social',
};

const categoryColors: Record<string, string> = {
  finances: 'bg-green-100 text-green-800 border-green-200',
  health_insurance: 'bg-blue-100 text-blue-800 border-blue-200',
  cooking: 'bg-orange-100 text-orange-800 border-orange-200',
  laundry: 'bg-purple-100 text-purple-800 border-purple-200',
  taxes: 'bg-red-100 text-red-800 border-red-200',
  housing: 'bg-indigo-100 text-indigo-800 border-indigo-200',
  career: 'bg-gray-100 text-gray-800 border-gray-200',
  legal: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  maintenance: 'bg-pink-100 text-pink-800 border-pink-200',
  social: 'bg-cyan-100 text-cyan-800 border-cyan-200',
};

const categoryIcons: Record<string, string> = {
  finances: 'card-outline',
  health_insurance: 'medical-outline',
  cooking: 'restaurant-outline',
  laundry: 'shirt-outline',
  taxes: 'document-text-outline',
  housing: 'home-outline',
  career: 'briefcase-outline',
  legal: 'library-outline',
  maintenance: 'construct-outline',
  social: 'people-outline',
};

const difficultyColors: Record<string, string> = {
  beginner: 'bg-green-50 text-green-700 border-green-200',
  intermediate: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  advanced: 'bg-red-50 text-red-700 border-red-200',
};

export default function CatalogScreen() {
  const [selectedCategory, setSelectedCategory] = useState<TipCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedTip, setExpandedTip] = useState<string | null>(null);
  const navigation = (require('@react-navigation/native').useNavigation as any)();

  const {
    tips, 
    markTipCompleted, 
    toggleTipBookmark
  } = useTipsStore();
  const { userProgress, addTodoItem } = useProgressStore();
  const { isPro, canAccessTip } = useUIStore();

  // Filter tips based on category and search
  const filteredTips = useMemo(() => {
    let filtered = tips;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(tip => tip.category === selectedCategory);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(tip => 
        tip.title.toLowerCase().includes(query) ||
        tip.description.toLowerCase().includes(query) ||
        categoryLabels[tip.category].toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [tips, selectedCategory, searchQuery]);

  // Get category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    Object.keys(categoryLabels).forEach(category => {
      counts[category] = tips.filter(tip => tip.category === category).length;
    });
    return counts;
  }, [tips]);

  const categories = Object.keys(categoryLabels) as TipCategory[];

  const handleTipPress = (tipId: string) => {
    setExpandedTip(expandedTip === tipId ? null : tipId);
  };

  const handleMarkCompleted = (tipId: string) => {
    markTipCompleted(tipId);
  };

  const handleBookmark = (tipId: string) => {
    toggleTipBookmark(tipId);
  };

  const handleAddActionToTodo = (action: string, tip: AdultingTip) => {
    addTodoItem({
      title: action,
      description: `From tip: ${tip.title}`,
      category: tip.category,
      completed: false,
    });
  };

  const handleStartLesson = (tip: AdultingTip) => {
    const canAccess = isPro || (canAccessTip ? canAccessTip(tip.id) : false);
    if (canAccess) {
      navigation.navigate('InteractiveLesson', { tipId: tip.id });
    } else {
      navigation.navigate('SubscriptionSheet');
    }
  };

  const renderTipCard = (tip: AdultingTip) => {
    const isCompleted = userProgress.completedTips.includes(tip.id);
    const isBookmarked = userProgress.bookmarkedTips.includes(tip.id);
    const isExpanded = expandedTip === tip.id;
    const canAccess = isPro || (canAccessTip ? canAccessTip(tip.id) : false);
    const locked = !canAccess;

    return (
      <View key={tip.id} className="bg-white rounded-xl border border-gray-100 mb-3 overflow-hidden">
        {/* Lock overlay */}
        {locked && (
          <View className="absolute inset-0 z-10 bg-black/5" pointerEvents="none" />
        )}
        <Pressable onPress={() => handleTipPress(tip.id)} className="p-4">
          <View className="flex-row justify-between items-start mb-2">
            <View className="flex-1">
              <View className="flex-row items-center mb-2">
                <View className={cn("px-2 py-1 rounded-full border", categoryColors[tip.category])}>
                  <Text className={cn("text-xs font-medium", categoryColors[tip.category])}>
                    {categoryLabels[tip.category]}
                  </Text>
                </View>
                <View className={cn("ml-2 px-2 py-1 rounded-full border", difficultyColors[tip.difficulty] || 'bg-gray-50 text-gray-700 border-gray-200')}>
                  <Text className={cn("text-xs font-medium capitalize", difficultyColors[tip.difficulty] || 'bg-gray-50 text-gray-700 border-gray-200')}>
                    {tip.difficulty}
                  </Text>
                </View>
                {isCompleted && (
                  <View className="ml-2">
                    <Ionicons name="checkmark-circle" size={16} color="#059669" />
                  </View>
                )}
                {locked && (
                  <View className="ml-2 flex-row items-center">
                    <Ionicons name="lock-closed" size={14} color="#6B7280" />
                    <Text className="text-gray-500 text-xs ml-1">Pro</Text>
                  </View>
                )}
              </View>
              <Text className="text-lg font-semibold text-gray-900 mb-1">{tip.title}</Text>
              {tip.estimatedTime && (
                <Text className="text-sm text-gray-500">⏱️ {tip.estimatedTime}</Text>
              )}
            </View>
            <View className="flex-row items-center space-x-2">
              <Pressable onPress={() => handleBookmark(tip.id)}>
                <Ionicons 
                  name={isBookmarked ? "bookmark" : "bookmark-outline"} 
                  size={20} 
                  color={isBookmarked ? "#007AFF" : "#9CA3AF"} 
                />
              </Pressable>
              <Ionicons 
                name={isExpanded ? "chevron-up" : "chevron-down"} 
                size={20} 
                color="#9CA3AF" 
              />
            </View>
          </View>

          {!isExpanded && (
            <Text className="text-gray-700 text-sm" numberOfLines={2}>
              {tip.content?.overview || tip.description || 'No description available'}
            </Text>
          )}
        </Pressable>

        {/* Expanded Content */}
        {isExpanded && (
          <View className="px-4 pb-4">
            <Text className="text-gray-700 text-base leading-relaxed mb-4">
              {tip.content?.overview || tip.description || 'No description available'}
            </Text>

            <View className="mb-4 flex-row space-x-2">
              <Pressable onPress={() => handleStartLesson(tip)} className={cn("px-4 py-3 rounded-2xl", locked ? "bg-gray-200" : "bg-emerald-600")}
              >
                <Text className={cn("font-bold", locked ? "text-gray-600" : "text-gray-900")}>{locked ? "Unlock with Pro" : "Start Skill"}</Text>
              </Pressable>
              <Pressable onPress={() => shareTip(tip)} className="px-4 py-3 rounded-2xl bg-gray-100 border border-gray-200">
                <Text className="font-medium text-gray-700">Share</Text>
              </Pressable>
            </View>

            {/* Completion Button */}
            <Pressable
              onPress={() => handleMarkCompleted(tip.id)}
              disabled={isCompleted}
              className={cn(
                "p-3 rounded-lg flex-row items-center justify-center",
                isCompleted 
                  ? "bg-green-100 border border-green-200" 
                  : "bg-blue-500"
              )}
            >
              <Ionicons 
                name={isCompleted ? "checkmark-circle" : "checkmark-circle-outline"} 
                size={18} 
                color={isCompleted ? "#059669" : "#FFFFFF"} 
              />
              <Text className={cn(
                "ml-2 font-medium",
                isCompleted ? "text-green-700" : "text-white"
              )}>
                {isCompleted ? "Completed!" : "Mark as Completed"}
              </Text>
            </Pressable>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      {/* Search Bar */}
      <View className="bg-white p-4 border-b border-gray-100">
        <View className="flex-row items-center bg-gray-100 rounded-lg px-3 py-2">
          <Ionicons name="search" size={20} color="#9CA3AF" />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search tips..."
            placeholderTextColor="#9CA3AF"
            className="flex-1 ml-2 text-gray-900"
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={20} color="#9CA3AF" />
            </Pressable>
          )}
        </View>
      </View>

      {/* Category Filter */}
      <View className="bg-white border-b border-gray-100 pb-3">
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false} 
          className="px-4 pt-3"
          contentContainerStyle={{ paddingRight: 20 }}
        >
          <Pressable
            onPress={() => setSelectedCategory('all')}
            className={cn(
              "mr-3 px-4 py-2 rounded-full border",
              selectedCategory === 'all' 
                ? "bg-blue-500 border-blue-500" 
                : "bg-white border-gray-200"
            )}
          >
            <Text className={cn(
              "font-medium",
              selectedCategory === 'all' ? "text-white" : "text-gray-700"
            )}>
              All ({tips.length})
            </Text>
          </Pressable>

          {categories.map(category => (
            <Pressable
              key={category}
              onPress={() => setSelectedCategory(category)}
              className={cn(
                "mr-3 px-4 py-2 rounded-full border flex-row items-center",
                selectedCategory === category 
                  ? "bg-blue-500 border-blue-500" 
                  : "bg-white border-gray-200"
              )}
            >
              <Ionicons 
                name={categoryIcons[category] as any} 
                size={16} 
                color={selectedCategory === category ? "#FFFFFF" : "#6B7280"} 
              />
              <Text className={cn(
                "ml-1 font-medium",
                selectedCategory === category ? "text-white" : "text-gray-700"
              )}>
                {categoryLabels[category]} ({categoryCounts[category] || 0})
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {/* Tips List */}
      <ScrollView className="flex-1 p-4" showsVerticalScrollIndicator={false}>
        {filteredTips.length === 0 ? (
          <View className="items-center py-12">
            <Ionicons name="search-outline" size={64} color="#9CA3AF" />
            <Text className="text-xl font-semibold text-gray-600 mt-4">No tips found</Text>
            <Text className="text-gray-500 text-center mt-2">
              {searchQuery ? "Try a different search term" : "No tips in this category yet"}
            </Text>
          </View>
        ) : (
          <>
            <View className="flex-row justify-between items-center mb-4">
              <Text className="text-lg font-semibold text-gray-900">
                {selectedCategory === 'all' 
                  ? `All Tips (${filteredTips.length})` 
                  : `${categoryLabels[selectedCategory]} (${filteredTips.length})`
                }
              </Text>
              <Text className="text-sm text-gray-500">
                {userProgress.completedTips.filter(id => 
                  filteredTips.some(tip => tip.id === id)
                ).length} completed
              </Text>
            </View>

            {filteredTips.map(tip => renderTipCard(tip))}

            <View className="h-8" />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}