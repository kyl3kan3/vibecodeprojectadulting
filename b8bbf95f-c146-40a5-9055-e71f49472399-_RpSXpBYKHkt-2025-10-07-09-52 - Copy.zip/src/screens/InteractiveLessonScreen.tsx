import React, { useState, useCallback } from 'react';
import { View, Text, Pressable, ScrollView, KeyboardAvoidingView, Platform, Alert, useWindowDimensions } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useLessonsStore } from '../state';
import { Ionicons } from '@expo/vector-icons';
import ChecklistStepCard from '../components/lessons/ChecklistStepCard';

export default function InteractiveLessonScreen() {
  const insets = useSafeAreaInsets();
  const { width: windowWidth } = useWindowDimensions();
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const { skillId } = route.params as { skillId?: string };

  // Store access
  const { skills, skillProgress, startSkill, completeSkill } = useLessonsStore();
  
  // Find the skill safely
  const skill = skills?.find((k: any) => k.id === skillId);
  const steps = skill?.content?.stepByStep || [];
  const stepResources = skill?.content?.stepResources || {};
  
  // Debug logging for step resources
  React.useEffect(() => {
    if (skill && __DEV__) {
      if (__DEV__) console.log('📚 Lesson loaded:', skill.title);
      if (__DEV__) console.log('📝 Total steps:', steps.length);
      if (__DEV__) console.log('🔑 stepResources keys:', Object.keys(stepResources));
      if (__DEV__) console.log('📊 Total resources:', Object.values(stepResources).flat().length);
      
      // Log each step ID
      steps.forEach((step: any, index: number) => {
        const resources = stepResources[step.id] || [];
        if (__DEV__) console.log(`   Step ${index + 1}: ID="${step.id}", Resources=${resources.length}`);
      });
    }
  }, [skill, steps, stepResources]);
  
  // State management
  const [currentStep, setCurrentStep] = useState(0);

  // Get current step data early
  const currentStepData = steps[currentStep];

  // Start skill on mount
  React.useEffect(() => {
    if (skillId) {
      startSkill(skillId);
    }
  }, [skillId, startSkill]);

  const handleNext = useCallback(() => {
    // Check if current step is checklist and all items are completed
    const stepData = steps[currentStep];
    if (stepData?.type === 'checklist') {
      const rawItems = (stepData as any).items || (stepData as any).checklist?.items || [];
      const stepChecklist = skillProgress?.[skillId || '']?.stepResults?.[stepData.id]?.checklist || {};
      const completedCount = Object.values(stepChecklist).filter(Boolean).length;
      
      if (completedCount < rawItems.length) {
        Alert.alert(
          'Complete All Items',
          `Please complete all ${rawItems.length} items before moving to the next step.`,
          [{ text: 'OK' }]
        );
        return;
      }
    }
    
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete the lesson
      if (skillId) {
        completeSkill(skillId, 3, '');
        Alert.alert(
          'Lesson Complete! 🎉',
          `You've earned ${skill?.xpReward || 50} XP! Check your achievements.`,
          [{ text: 'Awesome!', onPress: () => navigation.goBack() }]
        );
      } else {
        navigation.goBack();
      }
    }
  }, [currentStep, steps, skillId, completeSkill, navigation, skillProgress, skill]);

  const handleBack = useCallback(() => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      navigation.goBack();
    }
  }, [currentStep, navigation]);

  // Helper function to find resources for current step with fallback logic
  const getStepResources = useCallback((stepData: any, stepIndex: number) => {
    // Try exact match first
    if (stepData.id && stepResources[stepData.id]) {
      if (__DEV__) console.log(`✅ Found resources for step "${stepData.id}":`, stepResources[stepData.id].length);
      return stepResources[stepData.id];
    }
    
    // Try with step-N format as fallback
    const fallbackId = `step-${stepIndex + 1}`;
    if (stepResources[fallbackId]) {
      if (__DEV__) console.log(`⚠️ Using fallback ID "${fallbackId}" for step "${stepData.id}":`, stepResources[fallbackId].length);
      return stepResources[fallbackId];
    }
    
    // Try without prefix if step has prefix
    if (stepData.id && stepData.id.includes('-')) {
      const parts = stepData.id.split('-');
      const lastPart = parts[parts.length - 1];
      const unprefixedId = `step-${lastPart}`;
      if (stepResources[unprefixedId]) {
        if (__DEV__) console.log(`⚠️ Using unprefixed ID "${unprefixedId}" for step "${stepData.id}":`, stepResources[unprefixedId].length);
        return stepResources[unprefixedId];
      }
    }
    
    if (__DEV__) console.log(`❌ No resources found for step "${stepData.id}" or fallback "${fallbackId}"`);
    return [];
  }, [stepResources]);

  // Check if step data is valid
  if (!currentStepData) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 items-center justify-center p-6">
          <Text className="text-white text-lg text-center">Step not found</Text>
          <Pressable onPress={() => navigation.goBack()} className="mt-4 px-6 py-3 bg-blue-600 rounded-lg">
            <Text className="text-white font-semibold">Go Back</Text>
          </Pressable>
      </View>
      </SafeAreaView>
    );
  }

  const isLast = currentStep === steps.length - 1;

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <KeyboardAvoidingView className="flex-1" behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4 bg-gray-900">
          <View className="flex-row items-center justify-between mb-5">
            <Pressable onPress={() => navigation.goBack()} className="w-10 h-10 rounded-full bg-gray-800 items-center justify-center">
              <Ionicons name="close" size={20} color="white" />
            </Pressable>
            <Text className="text-white text-lg font-semibold">Step {currentStep + 1} of {steps.length}</Text>
            <View className="w-10" />
          </View>
          
          {/* Progress Bar */}
          <View className="mb-4 h-2 bg-gray-700 rounded-full overflow-hidden">
            <View 
              className="h-2 rounded-full"
              style={{ 
                width: (windowWidth - 48) * ((currentStep + 1) / (steps.length || 1)),
                backgroundColor: '#10B981' // Emerald-500
              }}
            />
          </View>
          
          <Text className="text-white text-2xl font-bold mb-2">{skill?.title || 'Lesson'}</Text>
          <Text className="text-gray-400 text-sm">{currentStepData.title}</Text>
        </View>
        
        {/* Content */}
        <ScrollView 
          className="flex-1" 
          contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 24 }}
          showsVerticalScrollIndicator={true}
        >
          {/* Render step based on type */}
          {currentStepData.type === 'checklist' && ((currentStepData as any).items || (currentStepData as any).checklist?.items) ? (() => {
            // Support both direct items array and nested checklist.items
            const rawItems = (currentStepData as any).items || (currentStepData as any).checklist?.items || [];
            const checklistItems = rawItems.map((item: any, index: number) => {
              if (typeof item === 'string') {
                return { id: `item-${index}`, text: item };
              } else {
                return { id: item.id || `item-${index}`, text: item.text || item };
              }
            });
            return (
              <ChecklistStepCard
                skillId={skillId || ''}
                stepId={currentStepData.id}
                title={currentStepData.title}
                description={currentStepData.description}
                items={checklistItems}
                stepIndex={currentStep + 1}
                totalSteps={steps.length}
                lessonTitle={skill?.title || ''}
                lessonCategory={skill?.category || ''}
                stepResources={getStepResources(currentStepData, currentStep)}
              />
            );
          })() : (
            /* Display for other/unsupported step types */
            <View className="bg-gray-800 rounded-2xl p-6 mb-4">
              <Text className="text-white text-lg font-bold mb-4">
                {currentStepData.title}
              </Text>
              
              <Text className="text-gray-300 text-base mb-4 leading-relaxed">
                {currentStepData.description}
              </Text>

              {/* Show timer info if it's a timer step */}
              {currentStepData.type === 'timer' && (
                <View className="bg-blue-600 rounded-lg p-6 items-center mt-4">
                  <Ionicons name="timer" size={48} color="white" />
                  <Text className="text-white text-lg font-bold mt-3">
                    Estimated time: {currentStepData.timeEstimate || 15} minutes
                  </Text>
                  <Text className="text-blue-200 text-center mt-2">
                    Take your time to focus on this task
                  </Text>
                </View>
              )}
              
              {/* General message for non-checklist steps */}
              {!currentStepData.type || (currentStepData.type !== 'checklist' && currentStepData.type !== 'timer') && (
                <View className="bg-gray-700 rounded-lg p-4 mt-4">
                  <Text className="text-gray-300 text-sm text-center">
                    Read through the information above, then tap Next to continue
                  </Text>
                </View>
              )}
            </View>
          )}

        </ScrollView>

        {/* Bottom Navigation */}
        <View className="bg-gray-800 border-t border-gray-700 px-6 py-4">
          <View className="flex-row items-center justify-between">
            <Pressable onPress={handleBack} className="px-4 py-3 rounded-2xl bg-gray-700">
              <Text className="text-gray-200 font-semibold">{currentStep === 0 ? 'Back' : 'Previous'}</Text>
            </Pressable>
            <Pressable onPress={handleNext} className="px-4 py-3 rounded-2xl bg-emerald-600">
              <Text className="text-white font-bold">{isLast ? "Complete" : "Next"}</Text>
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}