import React, { useState, useMemo, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, TextInput, FlatList, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { SafeLinearGradient as LinearGradient } from "../components/SafeLinearGradient";
import { useNavigation } from '@react-navigation/native';
import { useLessonsStore, useProgressStore, useUIStore } from '../state';
import { TipCategory } from '../types/adulting';
import { cn } from '../utils/cn';

const categoryColors: Record<string, string> = {
  finances: '#10B981',
  health_insurance: '#3B82F6',
  cooking: '#F59E0B',
  laundry: '#8B5CF6',
  taxes: '#EF4444',
  housing: '#06B6D4',
  career_work: '#6366F1',
  legal: '#84CC16',
  maintenance: '#F97316',
  social: '#EC4899',
  credit: '#7C3AED',
  fitness: '#EF4444',
  mental_health: '#06B6D4',
  healthcare: '#10B981',
  relationships: '#EC4899',
  education: '#3B82F6',
  personal_care: '#8B5CF6',
  safety: '#EF4444',
  transportation: '#6366F1',
  technology: '#84CC16',
  nutrition: '#10B981',
  shopping: '#F59E0B',
  time_management: '#8B5CF6',
  communication: '#3B82F6',
  organization: '#6366F1',
  goal_setting: '#EC4899',
  networking: '#F59E0B',
  side_hustles: '#10B981',
  insurance: '#3B82F6',
  investing: '#7C3AED',
  daily_living: '#06B6D4',
  personal_development: '#8B5CF6',
  consumer_rights: '#EF4444',
  travel: '#F97316',
  environment: '#84CC16',
  // Legacy categories for backward compatibility
  money_mastery: '#10B981',
  home_life: '#F59E0B',
  career_growth: '#6366F1',
  life_admin: '#EF4444',
  personal_growth: '#8B5CF6',
  tech_savvy: '#84CC16',
  career_development: '#6366F1',
  health_wellness: '#10B981',
  life_skills: '#F59E0B',
  // Fallback for unknown categories
  default: '#6B7280',
};

const categoryLabels: Record<string, string> = {
  finances: 'Finances',
  health_insurance: 'Health Insurance',
  cooking: 'Cooking',
  laundry: 'Laundry',
  taxes: 'Taxes',
  housing: 'Housing',
  career_work: 'Career & Work',
  legal: 'Legal',
  maintenance: 'Maintenance',
  social: 'Social Skills',
  credit: 'Credit',
  fitness: 'Fitness',
  mental_health: 'Mental Health',
  healthcare: 'Healthcare',
  relationships: 'Relationships',
  education: 'Education',
  personal_care: 'Personal Care',
  safety: 'Safety',
  transportation: 'Transportation',
  technology: 'Technology',
  nutrition: 'Nutrition',
  shopping: 'Shopping',
  time_management: 'Time Management',
  communication: 'Communication',
  organization: 'Organization',
  goal_setting: 'Goal Setting',
  networking: 'Networking',
  side_hustles: 'Side Hustles',
  insurance: 'Insurance',
  investing: 'Investing',
  daily_living: 'Daily Living',
  personal_development: 'Personal Development',
  consumer_rights: 'Consumer Rights',
  travel: 'Travel',
  environment: 'Environment',
  // Legacy categories for backward compatibility
  money_mastery: 'Money Mastery',
  home_life: 'Home Life',
  career_growth: 'Career Growth',
  life_admin: 'Life Admin',
  personal_growth: 'Personal Growth',
  tech_savvy: 'Tech Savvy',
  career_development: 'Career Development',
  health_wellness: 'Health & Wellness',
  life_skills: 'Life Skills',
};

const difficultyColors = {
  beginner: 'bg-green-100 text-green-700',
  intermediate: 'bg-yellow-100 text-yellow-700',
  advanced: 'bg-red-100 text-red-700',
};

export default function LearnScreen() {
  const navigation = useNavigation();
  
  // Use unified store for skills
  const { 
    skills, 
    completedSkills,
    loadSkillsFromDatabase, 
    isLoadingSkills
  } = useLessonsStore();
  const { userProgress } = useProgressStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TipCategory | 'all'>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<'all' | 'beginner' | 'intermediate' | 'advanced'>('all');
  const [isInitialized, setIsInitialized] = useState(false);

  // Get unique categories from actual skills data, filter out undefined
  const categories = Array.from(new Set(
    skills
      .map(skill => skill?.category)
      .filter(category => category != null && category !== undefined)
  )) as TipCategory[];

  const [isOffline, setIsOffline] = useState(false);

  React.useEffect(() => {
    try {
      const sub = (require('@react-native-community/netinfo').default as any).addEventListener((state: any) => {
        setIsOffline(!(state.isConnected && state.isInternetReachable !== false));
      });
      return () => sub && sub();
    } catch {}
  }, []);

  // Load data on component mount
  React.useEffect(() => {
    const initializeData = async () => {
      try {
        // Load skills from database
        await loadSkillsFromDatabase();
      } catch (error) {
        if (__DEV__) console.error('Error loading data:', error);
      } finally {
        setIsInitialized(true);
      }
    };
    
    initializeData();
  }, [loadSkillsFromDatabase]);

  // Use only skills for display
  const allItems = useMemo(() => {
    // Deduplicate skills by ID to prevent duplicate key errors
    const uniqueSkills = (skills || []).reduce((acc, skill) => {
      if (!acc.find(s => s.id === skill.id)) {
        acc.push(skill);
      }
      return acc;
    }, [] as any[]);
    
    const skillsList = uniqueSkills.map(skill => ({
      ...skill,
      type: 'skill',
      itemId: skill.id,
      isCompleted: completedSkills?.includes(skill.id) || false
    }));
    
    return skillsList;
  }, [skills, completedSkills]);

  const filteredItems = useMemo(() => {
    if (!allItems || !Array.isArray(allItems)) {
      if (__DEV__) console.log('No items available or items is not an array');
      return [];
    }

    const filtered = allItems.filter(item => {
      // Ensure item has required properties
      if (!item || typeof item !== 'object') return false;
      if (!item.title) return false;

      const matchesSearch = searchQuery === '' ||
                           (item.title && typeof item.title === 'string' && item.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
                           (item.content?.overview && typeof item.content.overview === 'string' && item.content.overview.toLowerCase().includes(searchQuery.toLowerCase())) ||
                           (item.description && typeof item.description === 'string' && item.description.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchesDifficulty = selectedDifficulty === 'all' || 
        (selectedDifficulty === 'beginner' && item.difficulty === 'starter') ||
        (selectedDifficulty === 'intermediate' && item.difficulty === 'building') ||
        (selectedDifficulty === 'advanced' && item.difficulty === 'mastery');

      return matchesSearch && matchesCategory && matchesDifficulty;
    });
    
    if (__DEV__) console.log(`Filtered ${filtered.length} items from ${allItems.length} total items`);
    return filtered;
  }, [allItems, searchQuery, selectedCategory, selectedDifficulty]);

  const completedCount = filteredItems.filter(item => item.isCompleted).length;

  const renderItemCard = ({ item }: { item: any }) => {
    // Guard against undefined item
    if (!item || !item.itemId) return null;

    const isCompleted = item.isCompleted || false;
    const isBookmarked = item.type === 'tip' ? (userProgress?.bookmarkedTips?.includes(item.itemId) || false) : false;

    return (
      <Pressable
        onPress={() => {
          if (__DEV__) console.log('🔍 LearnScreen: Navigating to item:', item.type, item.itemId);
          if (__DEV__) console.log('🔍 LearnScreen: Navigation object:', navigation);
          try {
            if (item.type === 'skill') {
              (navigation as any).navigate('SkillDetail', { skillId: item.itemId });
            } else {
              (navigation as any).navigate('TipDetail', { tipId: item.itemId, tip: item });
            }
          } catch (error) {
            if (__DEV__) console.error('❌ LearnScreen: Navigation error:', error);
          }
        }}
        className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-4"
      >
        <View className="flex-row items-start justify-between mb-4">
          <View className="flex-1">
            <View className="flex-row items-center mb-3">
              <View className="bg-emerald-500 px-3 py-1 rounded-full mr-3">
                <Text className="text-xs font-bold text-gray-900">
                  {(categoryLabels[typeof item.category === 'string' ? item.category : ''] || (typeof item.category === 'string' ? item.category : 'General') || 'General').toUpperCase()}
                </Text>
              </View>
              {isCompleted && (
                <View className="w-6 h-6 bg-emerald-500 rounded-full items-center justify-center">
                  <Ionicons name="checkmark" size={14} color="#111827" />
                </View>
              )}
            </View>
            <Text className="text-xl font-black text-white mb-2 leading-tight">
              {typeof item.title === 'string' ? item.title : JSON.stringify(item.title)}
            </Text>
            {item.estimatedTime && (
              <Text className="text-gray-400 text-sm font-medium">⏱️ {typeof item.estimatedTime === 'string' ? item.estimatedTime : JSON.stringify(item.estimatedTime)}</Text>
            )}
          </View>
        </View>

        <Text className="text-gray-400 leading-relaxed mb-4" numberOfLines={2}>
          {item.content?.overview || item.description || item.title || 'No description available'}
        </Text>

        <View className="flex-row items-center justify-between">
          <Text className="text-emerald-400 text-sm font-bold">
            {item.type === 'skill' ? 'TAP TO START LESSON' : 'TAP TO LEARN MORE'}
          </Text>
          <Ionicons name="arrow-forward" size={20} color="#10B981" />
        </View>
      </Pressable>
    );
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      {/* Header */}
      <View className="px-6 pt-6 pb-8">
        <Text className="text-white text-3xl font-black mb-6">Learn Skills</Text>
        
        {/* Personalization Nudge */}
        {(() => {
          try {
            const up = useUIStore.getState()?.userProfile?.preferences;
            const hasPrefs = !!(up && ((up as any).categories?.length || (up as any).focusAreas?.length));
            if (!hasPrefs) {
              return (
                <Pressable onPress={() => (navigation as any).navigate('CategoryPreferences')} className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-4">
                  <Text className="text-blue-900 font-semibold">Tune your interests</Text>
                  <Text className="text-blue-700 mt-1">Pick categories to personalize recommendations</Text>
                </Pressable>
              );
            }
          } catch {}
          return null;
        })()}

        {/* Search Bar with Random + Saved Buttons */}
        <View className="flex-row items-center space-x-3 mb-6">
          <View className="relative flex-1">
            <Ionicons 
              name="search" 
              size={20} 
              color="#6B7280" 
              style={{ position: 'absolute', left: 16, top: 14, zIndex: 1 }}
            />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search skills..."
              placeholderTextColor="#6B7280"
              className="bg-gray-800 border border-gray-700 rounded-3xl pl-12 pr-4 py-4 text-white"
            />
            {searchQuery.length > 0 && (
              <Pressable 
                onPress={() => setSearchQuery('')}
                className="absolute right-4 top-4"
              >
                <Ionicons name="close-circle" size={20} color="#6B7280" />
              </Pressable>
            )}
          </View>
          
          <Pressable
            onPress={() => {
              if (skills.length > 0) {
                const randomSkill = skills[Math.floor(Math.random() * skills.length)];
                if (randomSkill && randomSkill.id) {
                  (navigation as any).navigate('SkillDetail', { skillId: randomSkill.id });
                }
              }
            }}
          >
            <LinearGradient
colors={['#8B5CF6', '#A855F7'] as any}
               style={{ borderRadius: 24, paddingHorizontal: 16, paddingVertical: 16 }}
            >
              <Ionicons name="shuffle" size={20} color="white" />
            </LinearGradient>
          </Pressable>

          <Pressable
            onPress={() => navigation.navigate('SavedTips' as never)}
          >
            <LinearGradient
              colors={["#1F2937", "#111827"] as any}
              style={{ borderRadius: 24, paddingHorizontal: 16, paddingVertical: 16 }}
            >
              <Ionicons name="bookmark" size={20} color="#F9FAFB" />
            </LinearGradient>
          </Pressable>
        </View>

        {/* Filters */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-6">
          <View className="flex-row space-x-3 pr-6">
            {/* Category Filter */}
            <Pressable
              onPress={() => setSelectedCategory('all')}
            >
              {selectedCategory === 'all' ? (
                <LinearGradient
                  colors={['#10B981', '#059669'] as any}
                  style={{ borderRadius: 16, paddingHorizontal: 16, paddingVertical: 12 }}
                >
                  <Text className="font-bold text-sm text-gray-900">
                    ALL CATEGORIES
                  </Text>
                </LinearGradient>
              ) : (
                <View className="px-4 py-3 rounded-2xl bg-gray-800 border border-gray-700">
                  <Text className="font-bold text-sm text-gray-400">
                    ALL CATEGORIES
                  </Text>
                </View>
              )}
            </Pressable>

            {categories
              .filter(category => category != null)
              .map(category => (
              <Pressable
                key={category}
                onPress={() => setSelectedCategory(category)}
              >
                {selectedCategory === category ? (
                  <LinearGradient
                    colors={['#10B981', '#059669'] as any}
                    style={{ borderRadius: 16, paddingHorizontal: 16, paddingVertical: 12 }}
                  >
                    <Text className="font-bold text-sm text-gray-900">
                      {(categoryLabels[category] || category || 'General').toUpperCase()}
                    </Text>
                  </LinearGradient>
                ) : (
                  <View className="px-4 py-3 rounded-2xl bg-gray-800 border border-gray-700">
                    <Text className="font-bold text-sm text-gray-400">
                      {(categoryLabels[category] || category || 'General').toUpperCase()}
                    </Text>
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        </ScrollView>

        {/* Difficulty Filter */}
        <View className="flex-row space-x-2">
          {['all', 'beginner', 'intermediate', 'advanced'].map(difficulty => (
            <Pressable
              key={difficulty}
              onPress={() => setSelectedDifficulty(difficulty as any)}
              className={cn(
                "px-3 py-1.5 rounded-full border",
                selectedDifficulty === difficulty 
                  ? "bg-gray-800 border-gray-800" 
                  : "bg-white border-gray-200"
              )}
            >
              <Text className={cn(
                "font-medium text-xs capitalize",
                selectedDifficulty === difficulty ? "text-white" : "text-gray-600"
              )}>
                {difficulty}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

        {/* Offline banner */}
        {isOffline && (
          <View className="mx-6 mt-2 bg-yellow-100 border border-yellow-300 rounded-2xl p-3">
            <Text className="text-yellow-800 text-sm">Offline mode: browsing works; AI features are limited.</Text>
          </View>
        )}

        {/* Results Header */}
        <View className="px-6 py-4 border-b border-gray-700">
          <View className="flex-row items-center justify-between">
          <Text className="text-gray-400 font-medium">
            {filteredItems.length} ITEMS FOUND
          </Text>
          <Text className="text-emerald-400 font-bold">
            {completedCount} COMPLETED
          </Text>
        </View>
      </View>

      {/* Items List */}
      {!isInitialized || isLoadingSkills ? (
        <View className="flex-1 justify-center items-center">
          <ActivityIndicator size="large" color="#10B981" />
          <Text className="text-white text-lg mt-4">Loading skills...</Text>
        </View>
      ) : filteredItems.length === 0 ? (
        <View className="flex-1 justify-center items-center px-6">
          <Ionicons name="book-outline" size={64} color="#6B7280" />
          <Text className="text-white text-xl font-bold mt-4 text-center">No Skills Available</Text>
          <Text className="text-gray-400 text-center mt-2 mb-6">
            {allItems.length === 0 
              ? "Skills are being loaded from the database. Please wait a moment and try again."
              : "No skills match your current filters. Try adjusting your search or filters."
            }
          </Text>
          {allItems.length === 0 && (
            <Pressable 
              onPress={async () => {
                try {
                  await loadSkillsFromDatabase();
                } catch (error) {
                  if (__DEV__) console.error('Error retrying load:', error);
                }
              }} 
              className="bg-emerald-600 rounded-xl px-6 py-3"
            >
              <Text className="text-white font-bold">Retry Loading</Text>
            </Pressable>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredItems}
          renderItem={renderItemCard}
          keyExtractor={(item, index) => item?.itemId || `fallback-item-${index}`}
          contentContainerStyle={{ padding: 24, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}