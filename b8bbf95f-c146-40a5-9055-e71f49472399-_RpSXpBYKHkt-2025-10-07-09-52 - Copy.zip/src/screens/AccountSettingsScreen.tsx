import React from "react";
import { View, Text, Pressable, TextInput, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView } from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import * as MailComposer from "expo-mail-composer";
import { useProgressStore } from "../state";
import { useAuth } from "../contexts/AuthContext";
import { SUPPORT_EMAIL, PRIVACY_URL } from "../utils/legal";
import * as WebBrowser from "expo-web-browser";
import { useNavigation } from "@react-navigation/native";
import EditProfileModal from "../components/EditProfileModal";
import { getDisplayName } from "../utils/profile-display";

export default function AccountSettingsScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { user, profile, refreshSession } = useAuth();
  const { resetUserData } = useProgressStore();
  
  const isAdmin = user?.email?.toLowerCase() === 'kyl3kan3@gmail.com';

  const [showConfirm, setShowConfirm] = React.useState(false);
  const [confirmText, setConfirmText] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [message, setMessage] = React.useState<string | null>(null);
  const [editModalVisible, setEditModalVisible] = React.useState(false);

  const onRequestDeletion = async () => {
    setMessage(null);
    setSubmitting(true);
    try {
      // 1) Attempt webhook if configured
      const url = process.env.EXPO_PUBLIC_ACCOUNT_DELETION_WEBHOOK_URL;
      if (url) {
        await fetch(url, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ userId: user?.id, email: user?.email })
        }).catch(() => {});
      }
      // 2) Best-effort: remove local user data and sign out
      try { resetUserData(); } catch {}
      try { await useAuth().signOut(); } catch {}
      setMessage("Your deletion request has been submitted. You have been signed out and your local data was removed.");
    } catch {
      setMessage("We could not submit your deletion request. Please try again or use the email option below.");
    } finally {
      setSubmitting(false);
      setShowConfirm(false);
      setConfirmText("");
    }
  };

  const emailDeletion = async () => {
    try {
      await MailComposer.composeAsync({
        subject: "Account deletion request",
        recipients: [SUPPORT_EMAIL],
        body: `Please delete my account and all associated data.\n\nUser ID: ${user?.id || ""}\nEmail: ${user?.email || ""}`
      });
    } catch {}
  };

  const handleProfileSaved = async () => {
    // Refresh session to reload profile data
    await refreshSession();
  };

  const displayName = getDisplayName(profile, user, null);

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
        <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}>
          <View className="px-6 pt-6 pb-4 border-b border-gray-800">
            <View className="flex-row items-center">
              <Pressable 
                onPress={() => navigation.goBack()} 
                className="mr-3 p-2 -ml-2"
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <Ionicons name="arrow-back" size={24} color="#FFF" />
              </Pressable>
              <View className="w-10 h-10 bg-rose-500 rounded-2xl items-center justify-center mr-3">
                <Ionicons name="shield-half-outline" size={20} color="#111827" />
              </View>
              <View>
                <Text className="text-white text-2xl font-black">Account Settings</Text>
                <Text className="text-gray-400 mt-1">Manage your profile, privacy, and account.</Text>
              </View>
            </View>
          </View>

          <View className="px-6 mt-6">
            {/* Profile Information */}
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
              <View className="flex-row items-center justify-between mb-3">
                <Text className="text-white font-bold">Profile Information</Text>
                <Pressable 
                  onPress={() => setEditModalVisible(true)}
                  className="bg-emerald-600 px-3 py-1.5 rounded-xl flex-row items-center"
                >
                  <Ionicons name="create-outline" size={16} color="#111827" />
                  <Text className="text-gray-900 font-bold ml-1.5">Edit</Text>
                </Pressable>
              </View>
              
              <View className="space-y-3">
                <View>
                  <Text className="text-gray-500 text-xs mb-1">Display Name</Text>
                  <Text className="text-white text-base">{displayName}</Text>
                </View>
                
                {profile?.username && (
                  <View>
                    <Text className="text-gray-500 text-xs mb-1">Username</Text>
                    <Text className="text-white text-base">@{profile.username}</Text>
                  </View>
                )}
                
                {profile?.full_name && (
                  <View>
                    <Text className="text-gray-500 text-xs mb-1">Full Name</Text>
                    <Text className="text-white text-base">{profile.full_name}</Text>
                  </View>
                )}
                
                <View>
                  <Text className="text-gray-500 text-xs mb-1">Email</Text>
                  <Text className="text-white text-base">{user?.email || 'Not set'}</Text>
                </View>
              </View>
              
              <Text className="text-gray-500 text-xs mt-3">
                Tap Edit to change your display name and username
              </Text>
            </View>

            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
              <Text className="text-white font-bold mb-2">Privacy</Text>
              <Text className="text-gray-400 mb-3">You can request deletion of your account and all personal data stored by this app. This action is permanent.</Text>
              <Pressable accessibilityLabel="Open privacy policy" onPress={() => WebBrowser.openBrowserAsync(PRIVACY_URL)} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700 self-start">
                <Text className="text-white font-bold">Privacy Policy</Text>
              </Pressable>
            </View>

            {/* Cloud Sync */}
            <View className="bg-gray-800 border border-purple-700 rounded-3xl p-5 mb-4">
              <View className="flex-row items-center mb-3">
                <Ionicons name="cloud-outline" size={24} color="#A855F7" />
                <Text className="text-white font-bold ml-2">Cloud Sync</Text>
              </View>
              <Text className="text-gray-400 mb-3">
                Backup your progress to the cloud and sync across devices. Your progress is automatically saved when you complete lessons.
              </Text>
              <Pressable 
                onPress={() => (navigation as any).navigate('ProgressSync')}
                className="px-3 py-2 rounded-2xl bg-purple-600 self-start"
              >
                <Text className="text-white font-bold">Manage Cloud Sync</Text>
              </Pressable>
            </View>

            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
              <Text className="text-white font-bold mb-3">Delete Account</Text>
              {!showConfirm ? (
                <View>
                  <Text className="text-gray-400 mb-3">To continue, confirm by typing DELETE and submitting your request.</Text>
                  <Pressable accessibilityLabel="Open delete confirmation" onPress={() => setShowConfirm(true)} className="px-3 py-2 rounded-2xl bg-rose-600">
                    <Text className="text-gray-900 font-bold">Delete my account</Text>
                  </Pressable>
                </View>
              ) : (
                <View>
                  <Text className="text-gray-400 mb-2">Type DELETE to confirm.</Text>
                  <TextInput
                    value={confirmText}
                    onChangeText={setConfirmText}
                    autoCapitalize="characters"
                    placeholder="DELETE"
                    placeholderTextColor="#6B7280"
                    className="bg-gray-900 border border-gray-700 rounded-2xl px-3 py-2 text-white mb-3"
                    returnKeyType="done"
                  />
                  <View className="flex-row">
                    <Pressable accessibilityLabel="Cancel delete" onPress={() => { setShowConfirm(false); setConfirmText(""); }} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700 mr-2">
                      <Text className="text-white font-bold">Cancel</Text>
                    </Pressable>
                    <Pressable accessibilityLabel="Confirm delete" onPress={onRequestDeletion} disabled={confirmText !== "DELETE" || submitting} className={confirmText === "DELETE" && !submitting ? "px-3 py-2 rounded-2xl bg-rose-600" : "px-3 py-2 rounded-2xl bg-gray-700"}>
                      {submitting ? <ActivityIndicator color="#111827" /> : <Text className="text-gray-900 font-bold">Confirm</Text>}
                    </Pressable>
                  </View>
                </View>
              )}
            </View>

            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
              <Text className="text-white font-bold mb-2">Prefer email?</Text>
              <Text className="text-gray-400 mb-3">If the in‑app deletion is unavailable, you can email our support to process your request.</Text>
              <Pressable accessibilityLabel="Compose deletion email" onPress={emailDeletion} className="px-3 py-2 rounded-2xl bg-gray-800 border border-gray-700 self-start">
                <Text className="text-white font-bold">Email support</Text>
              </Pressable>
            </View>

            {message && (
              <View className="bg-emerald-500/10 border border-emerald-600 rounded-2xl p-3">
                <Text className="text-emerald-400">{message}</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      
      {/* Edit Profile Modal */}
      <EditProfileModal 
        visible={editModalVisible}
        onClose={() => setEditModalVisible(false)}
        onSave={handleProfileSaved}
      />
    </SafeAreaView>
  );
}
