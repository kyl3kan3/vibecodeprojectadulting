import React from "react";
import { View, Text, FlatList, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useTipsStore } from "../state";
import { useProgressStore } from "../state";
import { shareTip } from "../utils/sharing";

export default function SavedTipsScreen() {
  const navigation = useNavigation();
  const { tips, toggleTipBookmark } = useTipsStore();
  const { userProgress } = useProgressStore();

  const saved = tips.filter((t) => userProgress.bookmarkedTips.includes(t.id));

  const renderItem = ({ item: tip }: { item: any }) => (
    <View className="bg-gray-800 border border-gray-700 rounded-3xl p-5 mb-4">
      <Pressable onPress={() => (navigation as any).navigate("TipDetail", { tipId: tip.id })}>
        <Text className="text-white text-lg font-black mb-1">{tip.title}</Text>
        <Text className="text-gray-400" numberOfLines={2}>{tip.content?.overview || tip.description || 'No description available'}</Text>
      </Pressable>
      <View className="flex-row items-center justify-end mt-4 space-x-4">
        <Pressable onPress={() => shareTip(tip)} className="px-3 py-2 rounded-2xl bg-gray-700">
          <View className="flex-row items-center">
            <Ionicons name="share-social-outline" size={18} color="#E5E7EB" />
            <Text className="text-gray-200 ml-2 text-sm font-medium">Share</Text>
          </View>
        </Pressable>
        <Pressable onPress={() => toggleTipBookmark(tip.id)} className="px-3 py-2 rounded-2xl bg-gray-700">
          <View className="flex-row items-center">
            <Ionicons name="bookmark" size={18} color="#60A5FA" />
            <Text className="text-blue-300 ml-2 text-sm font-medium">Saved</Text>
          </View>
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <View className="px-6 pt-6 pb-4 border-b border-gray-800">
        <View className="flex-row items-center mb-4">
          <Pressable 
            onPress={() => navigation.goBack()}
            className="w-10 h-10 rounded-full bg-gray-800 items-center justify-center mr-4"
          >
            <Ionicons name="arrow-back" size={20} color="white" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-white text-3xl font-black">Saved</Text>
          </View>
        </View>
        <Text className="text-gray-400 mt-2">Your bookmarked tips for quick access</Text>
      </View>

      {saved.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8">
          <Ionicons name="bookmark-outline" size={64} color="#6B7280" />
          <Text className="text-white text-xl font-black mt-4">No saved tips yet</Text>
          <Text className="text-gray-400 text-center mt-2">Tap the bookmark icon on any tip to save it here.</Text>
        </View>
      ) : (
        <FlatList
          data={saved}
          keyExtractor={(i) => i.id}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 24, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}
