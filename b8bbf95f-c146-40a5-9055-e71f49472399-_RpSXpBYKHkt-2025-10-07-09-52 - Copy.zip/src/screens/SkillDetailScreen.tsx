import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Alert, Linking, useWindowDimensions } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { ensureHttpUrl, extractFirstUrl } from '../utils/urls';
import { useRoute, useNavigation } from '@react-navigation/native';
import { useLessonsStore, useUIStore } from '../state';
import { cn } from '../utils/cn';
import { CloseButton } from '../components/CloseButton';

const difficultyColors = {
  starter: { bg: 'bg-green-500', text: 'text-white' },
  building: { bg: 'bg-blue-500', text: 'text-white' },
  mastery: { bg: 'bg-purple-500', text: 'text-white' }
};

const difficultyLabels = {
  starter: 'Starter',
  building: 'Building',
  mastery: 'Mastery'
};

const categoryColors = {
  money_mastery: '#10B981',
  career_growth: '#3B82F6', 
  home_life: '#8B5CF6',
  health_wellness: '#EF4444',
  relationships: '#F59E0B',
  personal_growth: '#06B6D4',
  tech_savvy: '#6366F1',
  life_admin: '#64748B'
};

const categoryIcons = {
  money_mastery: 'cash',
  career_growth: 'trending-up', 
  home_life: 'home',
  health_wellness: 'fitness',
  relationships: 'people',
  personal_growth: 'leaf',
  tech_savvy: 'laptop',
  life_admin: 'document-text'
};

export default function SkillDetailScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { width: windowWidth } = useWindowDimensions();
  const { skillId } = route.params as { skillId: string };
  
  const { 
    skills, 
    skillProgress,
    completedSkills,
    startSkill,
    completeSkillStep,
    completeSkill,
    loadLessonResources,
    getLessonResources,
    isFetchingLesson,
    getLessonResourceError,
    loadSkillsFromDatabase,
    isSkillUnlocked
  } = useLessonsStore();
  const { userProfile } = useUIStore();

  const [activeTab, setActiveTab] = useState<'overview'>('overview');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefreshLesson = async () => {
    setIsRefreshing(true);
    try {
      // Clear the skills array first to force reload
      useLessonsStore.setState({ skills: [] });
      await loadSkillsFromDatabase();
    } catch (error) {
      if (__DEV__) console.error('Error refreshing lesson:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Removed resources tab logic

  const skill = skills.find(s => s.id === skillId);
  const progress = skillProgress[skillId];

  // Debug logging to see what content is actually loaded
  if (skill) {
    if (__DEV__) console.log('🔍 SkillDetailScreen - Loaded skill content:', {
      id: skill.id,
      title: skill.title,
      overview: skill.content.overview,
      keyPointsCount: skill.content.keyPoints?.length || 0,
      stepByStepCount: skill.content.stepByStep?.length || 0,
      tipsCount: skill.content.tips?.length || 0,
      resourcesCount: skill.content.resources?.length || 0,
      commonMistakesCount: skill.content.commonMistakes?.length || 0,
      fullContent: skill.content
    });
  }

  // Debug info for display
  const debugInfo = skill ? {
    keyPoints: skill.content.keyPoints?.length || 0,
    steps: skill.content.stepByStep?.length || 0,
    tips: skill.content.tips?.length || 0,
    resources: skill.content.resources?.length || 0,
    mistakes: skill.content.commonMistakes?.length || 0
  } : null;
  const isPro = useUIStore(s => s.isPro);
  const canAccessSkill = useLessonsStore(s => s.isSkillUnlocked(skillId));
  const canAccess = isPro || canAccessSkill;
  const isSaved = userProfile?.savedSkills?.includes(skillId) || false;
  const isCompleted = completedSkills?.includes(skillId) || false;

  useEffect(() => {
    if (skill && !progress && !isCompleted) {
      startSkill(skillId);
    }
  }, [skill, skillId, progress, isCompleted, startSkill]);

  if (!skill) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <View className="flex-1 justify-center items-center">
          <Ionicons name="alert-circle-outline" size={64} color="#6B7280" />
          <Text className="text-xl font-bold text-white mt-4">Skill not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!canAccess) {
    return (
      <SafeAreaView className="flex-1 bg-gray-900">
        <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}>
          <View className="px-6 py-8">
            <Text className="text-white text-3xl font-black mb-2">Preview Locked Skill</Text>
            <Text className="text-gray-400">Unlock Pro to access this skill.</Text>
          </View>
          <View className="px-6">
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-6">
              <Text className="text-white text-xl font-bold mb-3">What You'll Learn</Text>
              <Text className="text-gray-300 leading-relaxed">{typeof skill.content.overview === 'string' ? skill.content.overview : JSON.stringify(skill.content.overview)}</Text>
            </View>
            <View className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-6">
              <Text className="text-white text-lg font-bold mb-3">First Step Preview</Text>
              <Text className="text-gray-300 leading-relaxed">{(skill.content.stepByStep || [])[0]?.title}: {(skill.content.stepByStep || [])[0]?.description}</Text>
            </View>
            <Pressable onPress={() => (useNavigation() as any).navigate('SubscriptionSheet')} className="bg-emerald-600 rounded-2xl px-4 py-3 items-center">
              <Text className="text-gray-900 font-bold">Upgrade to Pro</Text>
            </Pressable>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Check if lesson is fully completed
  const isLessonCompleted = completedSkills?.includes(skillId) || false;
  
  const completedStepsCount = progress?.completedSteps?.length || 0;
  const totalSteps = skill.content.stepByStep?.length || 0;
  const progressPercentage = isLessonCompleted ? 100 : (totalSteps > 0 ? (completedStepsCount / totalSteps) * 100 : 0);
  const categoryColor = categoryColors[skill.category] || '#6B7280';

  const { toggleSkillBookmark } = useUIStore();
  
  const handleSaveSkill = () => {
    toggleSkillBookmark(skillId);
    Alert.alert(
      isSaved ? "Removed from Saved" : "Saved! ✅", 
      isSaved 
        ? "This skill has been removed from your saved list."
        : "You can find this skill in your saved list anytime!"
    );
  };

  const renderOverview = () => (
    <View className="px-6">
      {/* Description */}
      <View className="bg-gray-800 rounded-3xl p-6 mb-6 border border-gray-700">
        <Text className="text-xl font-bold text-white mb-4">What You'll Learn</Text>
        <Text className="text-gray-300 text-base leading-relaxed mb-6">
          {skill.content.overview}
        </Text>
        
        
        {/* Key Points */}
        <Text className="text-xl font-bold text-white mb-4">Key Points</Text>
        {(skill.content.keyPoints || []).map((point, index) => (
          <View key={index} className="flex-row items-start mb-3">
            <View 
              className="w-3 h-3 rounded-full mt-2 mr-3" 
              style={{ backgroundColor: categoryColor }}
            />
            <Text className="flex-1 text-gray-300 leading-relaxed">{typeof point === 'string' ? point : JSON.stringify(point)}</Text>
          </View>
        ))}
      </View>

      {/* Tips */}
      {(skill.content.tips || []).length > 0 && (
        <View className="bg-blue-600 rounded-3xl p-6 mb-6">
          <View className="flex-row items-center mb-4">
            <View className="w-12 h-12 bg-blue-500 rounded-2xl items-center justify-center mr-4">
              <Ionicons name="bulb" size={24} color="white" />
            </View>
            <Text className="text-white text-xl font-bold">Pro Tips</Text>
          </View>
          {(skill.content.tips || []).map((tip, index) => (
            <Text key={index} className="text-blue-100 mb-2 leading-relaxed">
              • {typeof tip === 'string' ? tip : JSON.stringify(tip)}
            </Text>
          ))}
        </View>
      )}

      {/* Common Mistakes */}
      {(skill.content.commonMistakes || []).length > 0 && (
        <View className="bg-red-600 rounded-3xl p-6 mb-6">
          <View className="flex-row items-center mb-4">
            <View className="w-12 h-12 bg-red-500 rounded-2xl items-center justify-center mr-4">
              <Ionicons name="warning" size={24} color="white" />
            </View>
            <Text className="text-white text-xl font-bold">Common Mistakes</Text>
          </View>
          {(skill.content.commonMistakes || []).map((mistake, index) => (
            <Text key={index} className="text-red-100 mb-2 leading-relaxed">
              • {typeof mistake === 'string' ? mistake : JSON.stringify(mistake)}
            </Text>
          ))}
        </View>
      )}
    </View>
  );

  const renderResources = () => {
    const dynamic = getLessonResources(skillId);
    const loading = isFetchingLesson(skillId);
    const errorMsg = getLessonResourceError(skillId);
    const list = dynamic.length > 0 ? dynamic : (skill?.content.resources || []);

    // Debug logging
    if (__DEV__) console.log(`[SkillDetail] Resources for ${skillId}:`, {
      dynamicCount: dynamic.length,
      staticCount: skill?.content.resources?.length || 0,
      loading,
      errorMsg,
      totalShowing: list.length
    });

    const handleRefreshResources = () => {
      if (__DEV__) console.log(`[SkillDetail] Refreshing resources for ${skillId}`);
      loadLessonResources(skillId);
    };

    return (
    <View className="px-6">
      {/* Header with Refresh Button */}
      <View className="flex-row items-center justify-between mb-4">
        <View className="flex-1">
          <Text className="text-white text-lg font-bold">Learning Resources</Text>
          {dynamic.length > 0 && (
            <View className="flex-row items-center mt-1">
              <View className="w-2 h-2 rounded-full bg-emerald-500 mr-2" />
              <Text className="text-gray-400 text-sm">AI-enhanced resources</Text>
            </View>
          )}
        </View>
        <Pressable 
          onPress={handleRefreshResources}
          disabled={loading}
          className={cn(
            "flex-row items-center px-3 py-2 rounded-xl",
            loading ? "bg-gray-700/50" : "bg-gray-700"
          )}
        >
          <Ionicons 
            name="refresh" 
            size={16} 
            color={loading ? "#6B7280" : "#E5E7EB"} 
          />
          <Text className={cn(
            "ml-2 font-semibold",
            loading ? "text-gray-500" : "text-gray-200"
          )}>
            {loading ? "Refreshing..." : "Refresh"}
          </Text>
        </Pressable>
      </View>
      
      {loading && (
        <View className="bg-gray-800 rounded-3xl p-6 mb-4 border border-gray-700">
          <View className="h-4 bg-gray-700 rounded w-40 mb-3" />
          <View className="h-3 bg-gray-700/80 rounded w-64 mb-2" />
          <View className="h-3 bg-gray-700/80 rounded w-56" />
        </View>
      )}
      {errorMsg && (
        <View className="bg-red-600/20 border border-red-500 rounded-3xl p-4 mb-4">
          <View className="flex-row items-center mb-2">
            <Ionicons name="warning-outline" size={20} color="#FCA5A5" />
            <Text className="text-red-300 font-semibold ml-2">Resource Loading Issue</Text>
          </View>
          <Text className="text-red-300 mb-3">
            {errorMsg === 'fetch_failed' 
              ? 'Failed to fetch AI resources. Showing static resources instead.' 
              : errorMsg === 'fetch_error'
              ? 'Network error while fetching resources. Please check your connection.'
              : `Error: ${errorMsg}`
            }
          </Text>
          <Pressable 
            onPress={handleRefreshResources}
            className="bg-red-600 px-4 py-2 rounded-xl self-start"
          >
            <Text className="text-white font-semibold">Retry</Text>
          </Pressable>
        </View>
      )}
      {list.length > 0 ? (
        list.map((resource: any, index: number) => (
          <View key={index} className="bg-gray-800 rounded-3xl p-6 mb-4 border border-gray-700">
            <View className="flex-row items-start">
              <View 
                className="w-12 h-12 rounded-2xl items-center justify-center mr-4"
                style={{ backgroundColor: categoryColor }}
              >
                <Ionicons 
                  name={
                    resource.type === 'link' ? 'link' :
                    resource.type === 'tool' ? 'construct' :
                    resource.type === 'template' ? 'document-text' :
                    'calculator'
                  } 
                  size={24} 
                  color="white" 
                />
              </View>
              <View className="flex-1">
                <Text className="font-bold text-white text-lg mb-2">
                  {resource.title}
                </Text>
                <Text className="text-gray-300 leading-relaxed">
                  {resource.description}
                </Text>
                {/* Inline link from description if present */}
                {(() => {
                  const match = resource.description?.match(/https?:\/\/\S+/);
                  const linkFromDesc = match && match[0];
                  return linkFromDesc ? (
                    <Pressable className="mt-2" onPress={async () => { try { await Linking.openURL(linkFromDesc); } catch {} }}>
                      <Text className="text-blue-300">{linkFromDesc}</Text>
                    </Pressable>
                  ) : null;
                })()}
                <Pressable className="mt-3" onPress={async () => {
                  if (resource.url) {
                    try {
                      await Linking.openURL(resource.url);
                    } catch (error) {
                      Alert.alert('Error', 'Could not open resource');
                    }
                  }
                }}>
                  <Text className="font-bold" style={{ color: categoryColor }}>
                    {resource.url ? 'Open Resource →' : 'View Details →'}
                  </Text>
                </Pressable>
                {/* Actions */}
                <View className="mt-3 flex-row items-center justify-between">
                  {(() => {
                      const directUrl = ensureHttpUrl(resource.url) || extractFirstUrl(resource.description || "");
                      const disabled = !directUrl;
                      return (
                         <Pressable disabled={disabled} onPress={async () => { if (!directUrl) return; await Linking.openURL(directUrl); }} className={disabled ? "px-3 py-2 rounded-xl bg-gray-700/50" : "px-3 py-2 rounded-xl bg-gray-700"}>
                        <Text className={disabled ? "text-gray-500" : "text-gray-200"}>Open in Browser</Text>
                      </Pressable>
                    );
                  })()}
                  <Pressable onPress={async () => { try { await (require('expo-clipboard') as any).setStringAsync(resource.url || resource.description || resource.title); } catch {} }} className="px-3 py-2 rounded-xl bg-gray-700">
                    <Text className="text-gray-200">Copy</Text>
                  </Pressable>
                  <Pressable onPress={async () => { try { const message = resource.url ? `${resource.title}\n${resource.url}` : `${resource.title}${resource.description ? `\n\n${resource.description}` : ''}`; await (require('react-native').Share).share({ message }); } catch {} }} className="px-3 py-2 rounded-xl" style={{ backgroundColor: categoryColor }}>
                    <Text className="text-gray-900 font-bold">Share</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          </View>
        ))
      ) : (
        <View className="bg-gray-800 rounded-3xl p-8 items-center border border-gray-700">
          <Ionicons name="library-outline" size={48} color="#6B7280" />
          <Text className="text-gray-400 text-center mt-4">
            No additional resources for this skill
          </Text>
        </View>
      )}
    </View>
  );
  };
 
  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Header */}
        <View className="px-6 pt-6 pb-8">
          <View className="flex-row items-center justify-between mb-8">
            <Pressable 
              onPress={() => navigation.goBack()}
              className="w-12 h-12 rounded-full bg-gray-800 items-center justify-center border border-gray-700"
            >
              <Ionicons name="chevron-back" size={24} color="#FFFFFF" />
            </Pressable>
            
            <View className="flex-1 mx-4">
              <Text className="text-gray-400 text-sm font-medium mb-1">
                Skill Details
              </Text>
              <Text className="text-white text-lg font-bold">
                {skill.title}
              </Text>
            </View>
            
            <View className="flex-row items-center">
              <Pressable
                onPress={handleRefreshLesson}
                disabled={isRefreshing}
                className="mr-3 p-2 bg-blue-600 rounded-lg"
                accessibilityLabel="Refresh skill data"
              >
                <Ionicons 
                  name="refresh" 
                  size={20} 
                  color={isRefreshing ? "#9CA3AF" : "#FFFFFF"} 
                />
              </Pressable>
              
              <CloseButton
                onPress={() => navigation.goBack()}
                variant="minimal"
                size="medium"
                showText={false}
                testId="skill-detail-close"
                accessibilityLabel="Close skill details"
              />
            </View>
          </View>


          {/* Skill Info Card */}
          <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700 mb-6">
            <View className="flex-row items-start justify-between mb-4">
              <View className="flex-1">
                <View className="flex-row items-center mb-3">
                  <View 
                    className="w-12 h-12 rounded-2xl items-center justify-center mr-4"
                    style={{ backgroundColor: categoryColor }}
                  >
                    <Ionicons name={categoryIcons[skill.category] as any} size={24} color="white" />
                  </View>
                  <View className={cn("px-3 py-1 rounded-full", (difficultyColors[skill.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' }).bg)}>
                    <Text className={cn("text-xs font-bold uppercase", (difficultyColors[skill.difficulty as keyof typeof difficultyColors] || { bg: 'bg-gray-500', text: 'text-white' }).text)}>
                      {difficultyLabels[skill.difficulty]}
                    </Text>
                  </View>
                </View>
                
                <Text className="text-white text-2xl font-black leading-tight mb-3">
                  {skill.title}
                </Text>
                
                <View className="flex-row items-center space-x-4">
                  <View className="flex-row items-center">
                    <Ionicons name="time-outline" size={16} color="#9CA3AF" />
                    <Text className="text-gray-400 text-sm ml-1">
                      {skill.estimatedTime} min
                    </Text>
                  </View>
                  <View className="flex-row items-center">
                    <Ionicons name="trophy-outline" size={16} color={categoryColor} />
                    <Text className="text-sm ml-1 font-bold" style={{ color: categoryColor }}>
                      +{skill.xpReward} XP
                    </Text>
                  </View>
                </View>
              </View>
              
              <Pressable onPress={handleSaveSkill} className="p-2">
                <Ionicons 
                  name={isSaved ? "bookmark" : "bookmark-outline"} 
                  size={24} 
                  color={isSaved ? categoryColor : "#9CA3AF"} 
                />
              </Pressable>
            </View>

            {/* Progress Bar */}
            {!isCompleted && (
              <View>
                <View className="flex-row justify-between items-center mb-3">
                  <Text className="text-gray-300 font-bold">Progress</Text>
                  <Text className="text-gray-400 text-sm">
                    {completedStepsCount}/{totalSteps} steps
                  </Text>
                </View>
                <View className="bg-gray-700 rounded-full h-3 overflow-hidden">
                  <View 
                    className="rounded-full h-3" 
                    style={{ 
                      width: (windowWidth - 48) * (progressPercentage / 100), // 48 = padding (24px each side)
                      backgroundColor: categoryColor
                    }}
                  />
                </View>
              </View>
            )}

            {isCompleted && (
              <View className="bg-green-600 rounded-2xl p-4 flex-row items-center">
                <Ionicons name="checkmark-circle" size={24} color="white" />
                <Text className="text-white font-bold ml-3">Skill Completed!</Text>
              </View>
            )}
          </View>

          {/* Start Skill CTA */}
          {!isCompleted && (
            <>
              <Pressable onPress={() => (navigation as any).navigate('InteractiveLesson', { skillId })} className="mt-2 bg-emerald-600 rounded-2xl px-4 py-3 items-center">
                <Text className="text-gray-900 font-bold">Start Skill</Text>
              </Pressable>
            </>
          )}
        </View>


        {/* Tab Navigation */}

        <View className="px-6 mb-6">
          <View className="bg-gray-800 rounded-3xl p-2 border border-gray-700">
            <View className="flex-row">
              {[
                { key: 'overview', label: 'Overview' }
              ].map((tab) => (
                <Pressable
                  key={tab.key}
                  onPress={() => setActiveTab(tab.key as any)}
                  className={cn(
                    "flex-1 py-3 rounded-2xl items-center",
                    activeTab === tab.key ? "bg-gray-700" : ""
                  )}
                  style={activeTab === tab.key ? { backgroundColor: categoryColor } : {}}
                >
                  <Text className={cn(
                    "font-bold",
                    activeTab === tab.key ? "text-white" : "text-gray-400"
                  )}>
                    {tab.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>

        {/* Content */}
        <View>
          {activeTab === 'overview' && renderOverview()}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}