import React, { useEffect, useMemo } from 'react';
import { View, Text, ScrollView, Pressable, Dimensions } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import type { NavigationProp } from '@react-navigation/native';
import type { RootStackParamList } from '../navigation/AppNavigator';
import { useLessonsStore, useProgressStore, useUIStore } from '../state';
import { learningPaths } from '../data/learning-paths';
import { cn } from '../utils/cn';

const { width } = Dimensions.get('window');
const cardWidth = width - 32; // Account for padding

const categoryIcons = {
  money_mastery: '💰',
  career_growth: '📈', 
  home_life: '🏠',
  health_wellness: '💪',
  relationships: '🤝',
  personal_growth: '🌱',
  tech_savvy: '💻',
  life_admin: '📋'
};



const HomeScreen = React.memo(function HomeScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();
  
  // Add safety checks for potential null objects
  if (!insets) {
    if (__DEV__) console.error('HomeScreen: insets is null');
    return (
      <View className="flex-1 bg-gray-50 justify-center items-center">
        <Text className="text-xl text-gray-600">Loading...</Text>
      </View>
    );
  }
  
  if (!navigation) {
    if (__DEV__) console.error('HomeScreen: navigation is null');
    return (
      <View className="flex-1 bg-gray-50 justify-center items-center">
        <Text className="text-xl text-gray-600">Loading...</Text>
      </View>
    );
  }
  
  // Add debugging to isolate the issue
  const { 
    skills,
    completedSkills,
    skillProgress,
    currentSkill,
    isLoadingSkills,
    skillsError,
    failedLessonsCount,
    failedLessonsDetails,
    getRecommendedSkills
  } = useLessonsStore();
  
  const {
    updateStreak,
    getTodaysChallenge,
    generateTodaysChallenge,
    getUserLevel,
    getActiveLearningPaths,
    getLearningPathProgress,
    userProgress,  // Get userProgress for streak
    totalXP,       // Get totalXP
  } = useProgressStore();
  
  const { userProfile } = useUIStore();

  // Regenerate challenge and update streak every time screen comes into focus
  // This ensures the challenge updates when the date changes
  useFocusEffect(
    React.useCallback(() => {
      try {
        if (__DEV__) console.log('[HomeScreen] Screen focused - checking streak and daily challenge');
        updateStreak();
        generateTodaysChallenge();
      } catch (error) {
        if (__DEV__) console.warn('Error in HomeScreen useFocusEffect:', error);
      }
    }, [updateStreak, generateTodaysChallenge])
  );

  // For now, let's remove the userProfile dependency to fix the loading issue
  // TODO: Properly implement user authentication and profile management
  // if (!userProfile) {
  //   return (
  //     <SafeAreaView className="flex-1 bg-gray-50">
  //       <View className="flex-1 justify-center items-center">
  //         <Text className="text-xl text-gray-600">Loading...</Text>
  //       </View>
  //     </SafeAreaView>
  //   );
  // }

  const recommendedSkills = useMemo(() => {
    try {
      const result = getRecommendedSkills();
      if (__DEV__) console.log('[HomeScreen] Recommended skills result:', { 
        resultExists: !!result, 
        resultLength: result?.length || 0,
        resultType: typeof result,
        result: result 
      });
      return result || [];
    } catch (error) {
      if (__DEV__) console.error('Error getting recommended skills:', error);
      return [];
    }
  }, [getRecommendedSkills, skills]);
  
  const todaysChallengeData = useMemo(() => {
    try {
      const challenge = getTodaysChallenge();
      if (__DEV__) console.log('[HomeScreen] Today\'s challenge:', challenge);
      return challenge;
    } catch (error) {
      if (__DEV__) console.error('Error getting today\'s challenge:', error);
      return null;
    }
  }, [getTodaysChallenge]);
  
  const userLevel = useMemo(() => {
    try {
      return getUserLevel();
    } catch (error) {
      if (__DEV__) console.error('Error getting user level:', error);
      return 1;
    }
  }, [getUserLevel, userProfile]);
  
  // Get data from correct stores after Phase 1 migration
  const streakDays = userProgress?.streak || userProgress?.streakDays || 0;
  
  // Calculate totalXP from completed skills (same as StatsScreen for consistency)
  const totalXPValue = completedSkills.reduce((sum, skillId) => {
    const skill = skills.find(s => s.id === skillId);
    return sum + (skill?.xpReward || 0);
  }, 0);
  
  const xpProgress = (totalXPValue % 300) / 300;
  const currentLevelXP = totalXPValue % 300;
  const nextLevelXP = 300;

  if (__DEV__) console.log('[HomeScreen] User profile data:', { 
    userProfileExists: !!userProfile,
    completedSkillsExists: !!userProfile?.completedSkills,
    completedSkillsLength: userProfile?.completedSkills?.length || 0,
    savedSkillsExists: !!userProfile?.savedSkills,
    savedSkillsLength: userProfile?.savedSkills?.length || 0,
    preferencesExists: !!userProfile?.preferences,
    userProfile: userProfile 
  });

  const currentSkillData = currentSkill;
  const currentProgress = currentSkill ? skillProgress[currentSkill.id] : null;

  const getTimeOfDayGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const getMotivationalMessage = () => {
    const messages = [
      "Every expert was once a beginner 🌟",
      "Small progress is still progress 💪",
      "You're building skills for life 🚀",
      "Consistency beats perfection ⭐",
      "Your future self will thank you 🙏"
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  const getNextReminderInfo = () => {
    if (!userProfile?.preferences?.notificationsEnabled) {
      return null;
    }
    
    const reminderTime = userProfile.preferences.reminderTime || '19:00';
    const reminderDays = userProfile.preferences.reminderDays || [];
    
    if (__DEV__) console.log('[HomeScreen] Reminder info:', { 
      reminderDaysExists: !!reminderDays, 
      reminderDaysLength: reminderDays?.length || 0,
      reminderDaysType: typeof reminderDays,
      reminderDays: reminderDays 
    });
    
    return {
      time: reminderTime,
      daysCount: (reminderDays || []).length,
      nextDay: (reminderDays || []).length > 0 ? 'Today' : 'None'
    };
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-900">
      <ScrollView 
        className="flex-1" 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* Header */}
        <View className="px-6 pt-6 pb-8">
          <View className="flex-row justify-between items-center mb-8">
            <View className="flex-1">
              <Text className="text-gray-400 text-sm font-medium mb-1">
                {getTimeOfDayGreeting()}, {userProfile?.name || 'Friend'}
              </Text>
              <Text className="text-white text-3xl font-black tracking-tight">
                Ready to level up?
              </Text>
            </View>
            
            {/* Level Badge */}
            <View className="bg-emerald-500 rounded-full w-16 h-16 items-center justify-center shadow-xl">
              <Text className="text-gray-900 font-black text-lg">{userLevel}</Text>
              <Text className="text-gray-900 text-xs font-bold -mt-1">LVL</Text>
            </View>
          </View>

          {/* XP Progress Bar */}
          <View className="bg-gray-800 rounded-3xl p-6 border border-gray-700">
            <View className="flex-row justify-between items-center mb-4">
              <Text className="font-bold text-white text-lg">Progress</Text>
              <Text className="text-emerald-400 font-bold">
                {currentLevelXP}/{nextLevelXP} XP
              </Text>
            </View>
            <View className="bg-gray-700 rounded-full h-4">
              <View 
                className="bg-emerald-500 rounded-full h-4" 
                style={{ width: `${xpProgress * 100}%` }}
              />
            </View>
          </View>
        </View>

        {/* Stats Grid */}
        <View className="px-6 mb-8">
          <View className="flex-row space-x-3 mb-3">
            {/* Streak Card */}
            <View className="bg-orange-500 rounded-3xl p-5 flex-1">
              <Text className="text-orange-100 text-xs font-bold mb-2">STREAK</Text>
              <Text className="text-white text-3xl font-black">{streakDays}</Text>
              <Text className="text-orange-200 text-xs font-medium">days strong</Text>
            </View>
            
            {/* Skills Card */}
            <View className="bg-blue-500 rounded-3xl p-5 flex-1">
              <Text className="text-blue-100 text-xs font-bold mb-2">SKILLS</Text>
              <Text className="text-white text-3xl font-black">{(userProfile?.completedSkills || []).length}</Text>
              <Text className="text-blue-200 text-xs font-medium">mastered</Text>
            </View>
          </View>
          
          <View className="flex-row space-x-3">
            {/* XP Card */}
            <View className="bg-purple-500 rounded-3xl p-5 flex-1">
              <Text className="text-purple-100 text-xs font-bold mb-2">CURRENT XP</Text>
              <Text className="text-white text-3xl font-black">{currentLevelXP}</Text>
              <Text className="text-purple-200 text-xs font-medium">toward level {userLevel + 1}</Text>
            </View>
            
            {/* Saved Card */}
            <View className="bg-pink-500 rounded-3xl p-5 flex-1">
              <Text className="text-pink-100 text-xs font-bold mb-2">SAVED</Text>
              <Text className="text-white text-3xl font-black">{(userProfile?.savedSkills || []).length}</Text>
              <Text className="text-pink-200 text-xs font-medium">bookmarks</Text>
            </View>
          </View>
        </View>

        {/* Continue Learning Card */}
        {currentSkillData && currentProgress && (
          <View className="px-6 mb-8">
            <Text className="text-white text-2xl font-black mb-4">Continue Learning</Text>
            <Pressable
              onPress={() => navigation.navigate('SkillDetail', { skillId: currentSkill!.id })}
              className="bg-gray-800 border-2 border-gray-700 rounded-3xl p-6"
            >
              <View className="flex-row items-center justify-between mb-6">
                <View className="flex-1">
                  <Text className="text-white text-xl font-bold mb-2">{currentSkillData.title}</Text>
                  <Text className="text-gray-400 text-sm">
                    {(currentProgress.completedSteps || []).length} of {(currentSkillData.content.stepByStep || []).length} steps
                  </Text>
                </View>
                <View className="w-12 h-12 bg-emerald-500 rounded-full items-center justify-center">
                  <Ionicons name="play" size={20} color="#111827" />
                </View>
              </View>
              
              {/* Progress bar */}
              <View className="bg-gray-700 rounded-full h-3">
                <View 
                  className="bg-emerald-500 rounded-full h-3" 
                  style={{ 
                    width: `${((currentProgress.completedSteps || []).length / (currentSkillData.content.stepByStep || []).length) * 100}%` 
                  }}
                />
              </View>
            </Pressable>
          </View>
        )}

        {/* Active Learning Paths */}
        {(() => {
          try {
            const activePaths = getActiveLearningPaths();
            if (__DEV__) console.log('[HomeScreen] Active learning paths:', { 
              activePathsExists: !!activePaths, 
              activePathsLength: activePaths?.length || 0,
              activePathsType: typeof activePaths,
              activePaths: activePaths 
            });
            return (activePaths || []).length > 0 ? (
            <View className="px-6 mb-8">
              <Text className="text-white text-2xl font-black mb-4">Your Learning Paths</Text>
              {(activePaths || []).map((path) => {
                const progress = getLearningPathProgress(path.id);
                const completedSkills = (progress.completedSkills || []).length;
                const totalSkills = (path.skillIds || []).length;
                const progressPercentage = (completedSkills / totalSkills) * 100;
                
                return (
                  <Pressable
                    key={path.id}
                    onPress={() => navigation.navigate('LearningPath', { pathId: path.id })}
                    className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mb-4"
                  >
                    <View className="flex-row items-center justify-between mb-4">
                      <View className="flex-1">
                        <View className="flex-row items-center mb-2">
                          <Text className="text-3xl mr-3">{path.icon}</Text>
                          <View className="flex-1">
                            <Text className="text-white text-lg font-bold mb-1">{path.title}</Text>
                            <Text className="text-gray-400 text-sm">
                              {completedSkills}/{totalSkills} skills completed
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View className="w-12 h-12 bg-emerald-500 rounded-full items-center justify-center">
                        <Ionicons name="chevron-forward" size={20} color="#111827" />
                      </View>
                    </View>
                    
                    {/* Progress bar */}
                    <View className="bg-gray-700 rounded-full h-3">
                      <View 
                        className="bg-emerald-500 rounded-full h-3" 
                        style={{ width: `${progressPercentage}%` }}
                      />
                    </View>
                    <Text className="text-gray-400 text-xs mt-2">
                      {Math.round(progressPercentage)}% complete
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          ) : null;
          } catch (error) {
            if (__DEV__) console.error('Error getting active learning paths:', error);
            return null;
          }
        })()}

        {/* Daily Challenge */}
        {todaysChallengeData && (
          <View className="px-6 mb-8">
            <Text className="text-white text-2xl font-black mb-4">Today's Challenge</Text>
            <View className="bg-yellow-500 rounded-3xl p-6">
              <View className="mb-6">
                <Text className="text-yellow-900 text-xl font-black mb-2">
                  {todaysChallengeData.title}
                </Text>
                <Text className="text-yellow-800 text-sm leading-relaxed mb-4">
                  {todaysChallengeData.description}
                </Text>
                <View className="flex-row items-center space-x-3">
                  <View className="bg-yellow-400 rounded-full px-3 py-1">
                    <Text className="text-yellow-900 text-xs font-bold">
                      {todaysChallengeData.timeEstimate} MIN
                    </Text>
                  </View>
                  <View className="bg-yellow-400 rounded-full px-3 py-1">
                    <Text className="text-yellow-900 text-xs font-bold">
                      +{todaysChallengeData.xpReward} XP
                    </Text>
                  </View>
                </View>
              </View>
              
              {!todaysChallengeData.isCompleted && (
                <Pressable 
                  onPress={() => {
                    // Mark challenge as completed and add XP
                    useProgressStore.setState(state => ({
                      todaysChallenge: state.todaysChallenge ? {
                        ...state.todaysChallenge,
                        isCompleted: true
                      } : null
                    }));
                    useUIStore.setState(state => ({
                      userProfile: state.userProfile ? {
                        ...state.userProfile,
                        totalXP: (state.userProfile.totalXP || 0) + todaysChallengeData.xpReward
                      } : state.userProfile
                    }));
                  }}
                  className="bg-gray-900 rounded-2xl py-4"
                >
                  <Text className="text-center font-black text-white text-lg">COMPLETE</Text>
                </Pressable>
              )}
              
              {todaysChallengeData.isCompleted && (
                <View className="bg-gray-800 rounded-2xl py-4">
                  <Text className="text-center font-bold text-emerald-400 text-lg">✓ COMPLETED</Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Learning Path Recommendation */}
        {(() => {
          try {
            const completedSkills = userProfile?.completedSkills || [];
            if (__DEV__) console.log('[HomeScreen] Getting next recommended path:', { 
              completedSkillsExists: !!completedSkills, 
              completedSkillsLength: completedSkills?.length || 0,
              completedSkillsType: typeof completedSkills,
              completedSkills: completedSkills 
            });
            // Simple fallback - return first learning path if any completed skills
            const nextPath = completedSkills.length > 0 ? learningPaths[0] : null;
            if (__DEV__) console.log('[HomeScreen] Next recommended path result:', { 
              nextPathExists: !!nextPath, 
              nextPath: nextPath 
            });
            return nextPath ? (
            <View className="px-6 mb-8">
              <Text className="text-white text-2xl font-black mb-4">Recommended Learning Path</Text>
              <Pressable 
                onPress={() => navigation.navigate('LearningPath', { pathId: nextPath.id })}
                className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-6"
              >
                <View className="flex-row items-center mb-4">
                  <Text className="text-4xl mr-4">{nextPath.icon}</Text>
                  <View className="flex-1">
                    <Text className="text-white text-xl font-black mb-1">{nextPath.title}</Text>
                    <Text className="text-white/80">{nextPath.description}</Text>
                  </View>
                </View>
                <View className="flex-row justify-between items-center">
                  <Text className="text-white/60 text-sm">{nextPath.estimatedTime} • {(nextPath.skillIds || []).length} skills</Text>
                  <Text className="text-white font-bold">START PATH →</Text>
                </View>
              </Pressable>
            </View>
          ) : null;
          } catch (error) {
            if (__DEV__) console.error('Error getting next recommended path:', error);
            return null;
          }
        })()}

        {/* Recommended Skills */}
        <View className="px-6 mb-8">
          <View className="flex-row justify-between items-center mb-6">
            <Text className="text-white text-2xl font-black">Explore Skills</Text>
            <Pressable onPress={() => navigation.navigate('MainTabs', { screen: 'Learn' } as never)}>
              <Text className="text-emerald-400 font-bold">VIEW ALL</Text>
            </Pressable>
          </View>
          
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="space-x-4">
            {(recommendedSkills || [])
              .filter((skill, index, self) => index === self.findIndex(s => s.id === skill.id))
              .map((skill) => (
              <Pressable
                key={skill.id}
                onPress={() => navigation.navigate('SkillDetail', { skillId: skill.id })}
                className="bg-gray-800 border border-gray-700 rounded-3xl p-6 mr-4"
                style={{ width: cardWidth * 0.8 }}
              >
                <View className="mb-4">
                  <Text className="text-white text-lg font-bold mb-2 leading-tight">
                    {skill.title}
                  </Text>
                  <Text className="text-gray-400 text-sm leading-relaxed" numberOfLines={2}>
                    {skill.description}
                  </Text>
                </View>
                
                <View className="flex-row justify-between items-center">
                  <View className="bg-gray-700 rounded-full px-3 py-1">
                    <Text className="text-gray-300 text-xs font-bold">{skill.estimatedTime} MIN</Text>
                  </View>
                  <View className="bg-emerald-500 rounded-full px-3 py-1">
                    <Text className="text-gray-900 text-xs font-black">+{skill.xpReward} XP</Text>
                  </View>
                </View>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Quick Actions */}
        <View className="px-6">
          <Text className="text-white text-2xl font-black mb-6">Quick Actions</Text>
          <View className="space-y-4">
            <Pressable 
              onPress={() => navigation.navigate('MainTabs', { screen: 'Learn' } as never)}
              className="bg-blue-600 rounded-3xl p-6 flex-row items-center justify-between"
            >
              <View className="flex-row items-center">
                <View className="w-12 h-12 bg-blue-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="library" size={24} color="white" />
                </View>
                <View>
                  <Text className="text-white text-xl font-bold">Browse Skills</Text>
                  <Text className="text-blue-200 text-sm">Discover new abilities</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="white" />
            </Pressable>
            
            <Pressable 
              onPress={() => navigation.navigate('MainTabs', { screen: 'Coach' } as never)}
              className="bg-green-600 rounded-3xl p-6 flex-row items-center justify-between"
            >
              <View className="flex-row items-center">
                <View className="w-12 h-12 bg-green-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="chatbubble-ellipses" size={24} color="white" />
                </View>
                <View>
                  <Text className="text-white text-xl font-bold">Ask Coach</Text>
                  <Text className="text-green-200 text-sm">Get personalized advice</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="white" />
            </Pressable>
            
            <Pressable 
              onPress={() => navigation.navigate('Stats' as never)}
              className="bg-purple-600 rounded-3xl p-6 flex-row items-center justify-between"
            >
              <View className="flex-row items-center">
                <View className="w-12 h-12 bg-purple-500 rounded-2xl items-center justify-center mr-4">
                  <Ionicons name="trophy" size={24} color="white" />
                </View>
                <View>
                  <Text className="text-white text-xl font-bold">View Stats</Text>
                  <Text className="text-purple-200 text-sm">Track your journey</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="white" />
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
});

export default HomeScreen;