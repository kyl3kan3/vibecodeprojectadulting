import React, { useState, useRef } from 'react';
import { View, Text, ScrollView, TextInput, Pressable, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from "../contexts/AuthContext";
import { getCoachAIResponse } from '../api/chat-service';
import type { AIMessage } from '../types/ai';
import { cn } from '../utils/cn';
import { useProgressStore, useUIStore } from "../state";
import { TipCategory } from '../types/adulting';
import { useNavigation } from '@react-navigation/native';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const quickQuestions = [
  "How do I get renter's insurance?",
  "What's the difference between a W-2 and 1099?",
  "How do I build credit?",
  "What should I look for in health insurance?",
  "How do I negotiate salary?",
];

export default function AskAIScreen() {
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your ProjectAdulting Coach. I'm here to help you navigate life's practical challenges. Ask me anything about finances, health insurance, taxes, cooking, career advice, and more! 🚀",
      timestamp: new Date(),
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const { user } = useAuth();
  const canSeeDiagnostics = ((user?.email || "").toLowerCase() === "kyl3kan3@gmail.com");
  const navigation = useNavigation<any>();
  const { isPro } = useUIStore();
  const { aiUsage, getAiRemaining, getAiCooldownRemaining, incrementAIUsage, resetAIUsageMonthlyIfNeeded } = useProgressStore();
  const freeLimit = 3;
  const remaining = getAiRemaining();
  const cooldownMs = getAiCooldownRemaining();
  
  // Todo functionality
  const { addTodoItem } = useProgressStore();

  const isGeneric = (s: string) => {
    const t = s.trim().toLowerCase();
    if (t.length < 40) return true;
    const phrases = [
      "how can i help",
      "how can i assist",
      "what can i help",
      "how may i assist",
      "how may i help",
      "how can we help",
      "how can i support",
      "happy to help",
      "let me know how i can",
      "how can i be of assistance",
    ];
    return phrases.some(p => t.includes(p));
  };

  const isVagueInput = (s: string) => {
    const t = s.trim().toLowerCase();
    if (!t) return true;
    const words = t.split(/\s+/).filter(Boolean).length;
    const greetings = ["hi", "hello", "hey", "help", "yo", "sup", "good morning", "good evening"];
    if (greetings.includes(t)) return true;
    return words <= 3 && !/[?]/.test(t);
  };

  const isGreetingMessage = (m: ChatMessage) => m.role === 'assistant' && (m.id === '1' || m.content.toLowerCase().includes("projectadulting coach") || m.content.toLowerCase().includes("ask me anything"));

  // Action parsing and todo functionality
  const parseActionItems = (content: string): string[] => {
    // First try to find explicit "ACTION ITEMS:" section
    const actionItemsRegex = /ACTION ITEMS?:\s*((?:\d+\..*(?:\n|$))+)/i;
    const actionMatch = content.match(actionItemsRegex);
    
    if (actionMatch) {
      const items = actionMatch[1]
        .split('\n')
        .map(line => line.replace(/^\d+\.\s*/, '').trim())
        .filter(item => item.length > 0);
      return items.slice(0, 3); // Limit to 3 items
    }

    // Look for numbered lists
    const numberedRegex = /^\d+\.\s*(.+)$/gm;
    const numberedMatches = [...content.matchAll(numberedRegex)];
    
    if (numberedMatches.length > 0) {
      const potentialActions = numberedMatches
        .map(match => match[1].trim())
        .filter(item => {
          const actionVerbs = ['start', 'create', 'set up', 'contact', 'apply', 'research', 'call', 'visit', 'download', 'open', 'check', 'review', 'compare', 'gather', 'schedule', 'practice', 'learn', 'find', 'get', 'make', 'build', 'track', 'organize', 'update', 'sign up', 'register'];
          return actionVerbs.some(verb => item.toLowerCase().includes(verb));
        });
      
      return potentialActions.slice(0, 3); // Limit to 3 items
    }

    // Look for bullet points
    const bulletRegex = /^[-•*]\s*(.+)$/gm;
    const bulletMatches = [...content.matchAll(bulletRegex)];
    
    if (bulletMatches.length > 0) {
      const potentialActions = bulletMatches
        .map(match => match[1].trim())
        .filter(item => {
          const actionVerbs = ['start', 'create', 'set up', 'contact', 'apply', 'research', 'call', 'visit', 'download', 'open', 'check', 'review', 'compare', 'gather', 'schedule', 'practice', 'learn', 'find', 'get', 'make', 'build', 'track', 'organize', 'update', 'sign up', 'register'];
          return actionVerbs.some(verb => item.toLowerCase().includes(verb));
        });
      
      return potentialActions.slice(0, 3); // Limit to 3 items for bullet points
    }
    
    return [];
  };

  const addActionToTodo = (action: string, messageId: string) => {
    const category = determineCategory(action);
    addTodoItem({
      title: action,
      description: `From AI Coach conversation`,
      category: category,
      completed: false,
    });
    
    Alert.alert("Added to Todo! ✅", "This action has been added to your todo list.");
  };

  const determineCategory = (action: string): TipCategory => {
    const actionLower = action.toLowerCase();
    if (actionLower.includes('budget') || actionLower.includes('money') || actionLower.includes('save') || actionLower.includes('invest') || actionLower.includes('credit') || actionLower.includes('debt')) {
      return 'finances';
    } else if (actionLower.includes('cook') || actionLower.includes('meal') || actionLower.includes('food') || actionLower.includes('recipe')) {
      return 'cooking';
    } else if (actionLower.includes('job') || actionLower.includes('career') || actionLower.includes('interview') || actionLower.includes('resume') || actionLower.includes('work')) {
      return 'career_work';
    } else if (actionLower.includes('health') || actionLower.includes('doctor') || actionLower.includes('exercise') || actionLower.includes('fitness')) {
      return 'healthcare';
    } else if (actionLower.includes('insurance') || actionLower.includes('policy') || actionLower.includes('coverage')) {
      return 'health_insurance';
    } else if (actionLower.includes('tax') || actionLower.includes('filing') || actionLower.includes('w-2') || actionLower.includes('1099')) {
      return 'taxes';
    } else if (actionLower.includes('house') || actionLower.includes('apartment') || actionLower.includes('rent') || actionLower.includes('lease')) {
      return 'housing';
    } else if (actionLower.includes('legal') || actionLower.includes('contract') || actionLower.includes('law') || actionLower.includes('court')) {
      return 'legal';
    } else if (actionLower.includes('maintenance') || actionLower.includes('repair') || actionLower.includes('fix') || actionLower.includes('clean')) {
      return 'maintenance';
    } else if (actionLower.includes('social') || actionLower.includes('friend') || actionLower.includes('relationship') || actionLower.includes('network')) {
      return 'social';
    } else {
      return 'personal_development';
    }
  };

  React.useEffect(() => { resetAIUsageMonthlyIfNeeded(); }, [resetAIUsageMonthlyIfNeeded]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    // Free plan strict limits
    if (!isPro) {
      // Check if daily limit reached
      if (remaining <= 0) {
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "You've reached your daily limit of 3 messages. Your limit resets at midnight. Upgrade to Pro for unlimited AI coaching!",
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMessage]);
        return;
      }
      
      const gate = useUIStore.getState().canSendAI?.();
      if (gate && gate.ok === false) {
        if (gate.reason === "cooldown") {
          const mins = Math.ceil((gate.remainingMs ?? 0) / 60000);
          const assistantMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: "assistant",
            content: `Free plan cooldown: please wait ${mins} minute${mins === 1 ? "" : "s"} before your next message. Upgrade to Pro for no limits.`,
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, assistantMessage]);
          return;
        }
        navigation.navigate("SubscriptionSheet");
        return;
      }
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date(),
    };

    if (!isPro) { incrementAIUsage(); }
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      // Vague input handler: suggest examples without calling AI
      if (isVagueInput(text)) {
        const assistantMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: `Try one of these to get started:\n• How do I build credit from zero?\n• Steps to get renter insurance\n• First budget setup in a week\n• Pick a health insurance plan\n• Negotiate my first salary` ,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMessage]);
        return;
      }

      const systemPrompt = `You are an expert ProjectAdulting Coach AI assistant helping young adults (18-30) navigate practical life skills.
Provide helpful, practical advice that is:
- Specific and actionable
- Age-appropriate for young adults
- Easy to understand and implement
- Focused on US-based advice (unless otherwise specified)
- Encouraging and supportive in tone
Always answer directly with 2-3 concise paragraphs followed by 3-5 numbered steps.
Do not ask how you can help. Do not reply with a generic greeting.
For complex topics, break down your response into clear steps. If the question involves financial advice, legal matters, or health decisions, remind them to consult with professionals when needed.

IMPORTANT: Always provide specific, actionable steps that can be added to the user's todo list. Format action items as numbered lists (1. 2. 3.) that will be automatically parsed and added to their todo list. Focus on concrete next steps they can take immediately.`;

      const fewShot: AIMessage[] = [
        { role: "user", content: "How do I build credit from zero?" },
        { role: "assistant", content: "Start with tools that report to the bureaus and keep things simple. Use a secured card or become an authorized user to create a clean history, then graduate.\n\nSteps:\n1. Apply for a secured credit card with a small deposit (for example 200) and a low limit.\n2. Put 1–2 small recurring bills on it (like 10–30) and pay the statement in full, on time, every month.\n3. Keep utilization under 10 percent (for example 15 on a 150 limit).\n4. After 6–9 months, ask for graduation to unsecured or add a second no annual fee card.\n5. Set payment autopay and freeze your credit if you will not apply for loans soon." },
        { role: "user", content: "What are the steps to get renter insurance?" },
        { role: "assistant", content: "You can buy renter insurance online in minutes. Focus on coverage amount and liability.\n\nSteps:\n1. Estimate coverage (for example 20k belongings, 100k–300k liability).\n2. Get 2–3 quotes from major carriers or your auto insurer bundle.\n3. Choose a deductible (for example 500) and list any high value items if required.\n4. Buy the policy for your address and set the start date to your move in date.\n5. Save the proof of insurance and add landlord as interested party if asked." }
      ];

      const cleanedHistory: AIMessage[] = messages
        .filter(m => !isGreetingMessage(m) && !(m.role === 'assistant' && isGeneric(m.content)))
        .slice(-4)
        .map(m => ({ role: m.role, content: m.content }));

      const aiMessages: AIMessage[] = [
        { role: "system", content: systemPrompt },
        ...fewShot,
        ...cleanedHistory,
        { role: "user", content: text.trim() }
      ];

      let response = await getCoachAIResponse(aiMessages, { model: "gpt-4o-mini", temperature: 0.2, maxTokens: 700 });

      // Anti-generic guard: retry once with stricter instruction if needed
      if (isGeneric(response.content)) {
        const stricter: AIMessage[] = [
          { role: "system", content: systemPrompt + "\nDo not ask how you can help. Provide concrete, step-by-step guidance immediately." },
          ...cleanedHistory,
          { role: "user", content: text.trim() }
        ];
        try { response = await getCoachAIResponse(stricter, { model: "gpt-4o-mini", temperature: 0.2, maxTokens: 700 }); } catch {}
        if (isGeneric(response.content)) {
          // Retry with OpenAI only
        }
      }

      if (isGeneric(response.content)) {
        response.content = `Here is a practical plan you can start now for \"${text.trim()}\":\n1. Define a clear next step you can do in 20 minutes.\n2. Gather any info or documents you will need.\n3. Take that step today and set a reminder for the next step.\n4. Tell me your situation (age, state, budget) and I will tailor exact steps.`;
      }

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Parse and add action items to todo list
      const actionItems = parseActionItems(response.content);
      if (actionItems.length > 0) {
        // Add a small delay to let the message render first
        setTimeout(() => {
          actionItems.forEach((action, index) => {
            setTimeout(() => {
              addActionToTodo(action, assistantMessage.id);
            }, index * 500); // Stagger the alerts
          });
        }, 1000);
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `I am having trouble connecting right now. ${msg ? `Error: ${msg}. ` : ""}Please try again in a moment.`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    } finally {
      setIsLoading(false);
    }

    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const handleQuickQuestion = (question: string) => {
    sendMessage(question);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <KeyboardAvoidingView 
        className="flex-1" 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Header */}
        <View className="bg-white px-6 py-6 border-b border-gray-100">
          <View className="flex-row items-center justify-between">
            <View>
              <Text className="text-2xl font-bold text-gray-900">Ask Your Coach</Text>
              <Text className="text-gray-600 mt-1">Get personalized adulting advice • Free: {remaining === Infinity ? "Unlimited" : `${remaining}`} messages/month</Text>
            </View>
            <View className="flex-row items-center space-x-2">
              {!isPro && (
                <Pressable onPress={() => navigation.navigate('SubscriptionSheet' as never)} className="px-3 py-2 rounded-2xl bg-emerald-600">
                  <Text className="text-gray-900 font-bold">Upgrade</Text>
                </Pressable>
              )}
            </View>
          </View>
        </View>

        {/* Free quota banner */}
        {!isPro && (
          <View className="bg-yellow-50 px-6 py-3 border-b border-yellow-100">
            <Text className="text-yellow-800 text-sm">Free plan: {remaining} of 3 messages today • Resets at midnight</Text>
          </View>
        )}

        {/* Quick Questions */}
        {messages.length <= 1 && (
          <View className="bg-white px-6 py-4 border-b border-gray-100">
            <Text className="text-lg font-semibold text-gray-900 mb-3">Popular Questions</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View className="flex-row space-x-3">
                {quickQuestions.map((question, index) => (
                  <Pressable
                    key={index}
                    onPress={() => handleQuickQuestion(question)}
                    className="bg-indigo-50 border border-indigo-100 rounded-2xl px-4 py-3"
                  >
                    <Text className="text-indigo-700 font-medium text-sm">{question}</Text>
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          </View>
        )}

        {/* Messages */}
        <ScrollView 
          ref={scrollViewRef}
          className="flex-1 px-6 py-4"
          showsVerticalScrollIndicator={false}
        >
          {messages.map((message) => (
            <View
              key={message.id}
              className={cn(
                "mb-6 max-w-[85%]",
                message.role === 'user' ? "self-end" : "self-start"
              )}
            >
              <View
                className={cn(
                  "rounded-3xl p-4",
                  message.role === 'user'
                    ? "bg-indigo-500 rounded-br-lg"
                    : "bg-white border border-gray-100 rounded-bl-lg shadow-sm"
                )}
              >
                <Text
                  className={cn(
                    "text-base leading-relaxed",
                    message.role === 'user' ? "text-white" : "text-gray-900"
                  )}
                >
                  {message.content}
                </Text>
              </View>
              <Text
                className={cn(
                  "text-xs text-gray-500 mt-2",
                  message.role === 'user' ? "text-right" : "text-left"
                )}
              >
                {formatTime(message.timestamp)}
              </Text>
            </View>
          ))}

          {/* Loading indicator */}
          {isLoading && (
            <View className="mb-6 max-w-[85%] self-start">
              <View className="bg-white border border-gray-100 rounded-3xl rounded-bl-lg p-4 shadow-sm">
                <View className="flex-row items-center">
                  <View className="flex-row space-x-1">
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                    <View className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" />
                  </View>
                  <Text className="text-gray-500 text-sm ml-3">Coach is thinking...</Text>
                </View>
              </View>
            </View>
          )}
        </ScrollView>
  
        {/* Input Area */}
        <View className="bg-white border-t border-gray-100 px-6 py-4" style={{ paddingBottom: insets.bottom + 16 }}>


          <View className="flex-row items-end space-x-3">
            <View className="flex-1 bg-gray-100 rounded-3xl px-5 py-3">
              <TextInput
                value={inputText}
                onChangeText={setInputText}
                placeholder="Ask your adulting question..."
                placeholderTextColor="#9CA3AF"
                multiline
                maxLength={500}
                className="text-gray-900 text-base max-h-24"
                onSubmitEditing={() => sendMessage(inputText)}
                blurOnSubmit={false}
              />
            </View>
            <Pressable
              onPress={() => sendMessage(inputText)}
              disabled={!inputText.trim() || isLoading}
              className={cn(
                "w-12 h-12 rounded-full items-center justify-center",
                inputText.trim() && !isLoading ? "bg-indigo-500" : "bg-gray-300"
              )}
            >
              <Ionicons 
                name="send" 
                size={20} 
                color={inputText.trim() && !isLoading ? "#FFFFFF" : "#9CA3AF"} 
              />
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}