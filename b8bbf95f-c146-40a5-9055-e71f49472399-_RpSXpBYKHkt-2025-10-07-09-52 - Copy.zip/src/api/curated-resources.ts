/**
 * Curated Resource Database
 * High-quality, tested resource URLs organized by category and type
 */

import { Resource } from '../types/app';

export interface CuratedResource extends Resource {
  domain: string;
  quality: 'high' | 'medium' | 'low';
  lastVerified: string;
  tags: string[];
  searchTerms: string[];
}

export interface ResourceTemplate {
  domain: string;
  urlTemplate: string; // Use {topic} as placeholder
  quality: 'high' | 'medium' | 'low';
  type: Resource['type'];
  description: string;
}

/**
 * High-quality curated resources by category
 */
export const CURATED_RESOURCES: Record<string, CuratedResource[]> = {
  money_mastery: [
    {
      type: 'link',
      title: 'Personal Finance Basics',
      description: 'Comprehensive guide to budgeting, saving, and financial planning',
      url: 'https://www.investopedia.com/personal-finance-4427760',
      domain: 'investopedia.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['budgeting', 'savings', 'financial planning'],
      searchTerms: ['budget', 'money management', 'personal finance', 'savings']
    },
    {
      type: 'tool',
      title: 'Mint Budget Tracker',
      description: 'Free budgeting and expense tracking tool',
      url: 'https://www.mint.com',
      domain: 'mint.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['budgeting', 'expense tracking', 'financial tools'],
      searchTerms: ['budget tracker', 'expense tracking', 'financial app']
    },
    {
      type: 'link',
      title: 'Emergency Fund Calculator',
      description: 'Calculate how much you need in your emergency fund',
      url: 'https://www.investopedia.com/terms/e/emergency_fund.asp',
      domain: 'investopedia.com',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['emergency fund', 'savings calculator'],
      searchTerms: ['emergency fund', 'savings calculator', 'financial calculator']
    },
    {
      type: 'link',
      title: 'Credit Score Guide',
      description: 'Understanding and improving your credit score',
      url: 'https://www.consumerfinance.gov/consumer-tools/credit-reports-and-scores/',
      domain: 'consumerfinance.gov',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['credit score', 'credit report', 'financial health'],
      searchTerms: ['credit score', 'credit report', 'credit improvement']
    }
  ],

  health_wellness: [
    {
      type: 'link',
      title: 'Nutrition Guidelines',
      description: 'Evidence-based nutrition and healthy eating guidelines',
      url: 'https://www.nutrition.gov/topics/basic-nutrition',
      domain: 'nutrition.gov',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['nutrition', 'healthy eating', 'diet'],
      searchTerms: ['nutrition', 'healthy eating', 'diet guidelines', 'food']
    },
    {
      type: 'tool',
      title: 'MyFitnessPal',
      description: 'Track calories, nutrition, and exercise',
      url: 'https://www.myfitnesspal.com',
      domain: 'myfitnesspal.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['fitness tracking', 'calorie counting', 'nutrition'],
      searchTerms: ['calorie tracker', 'fitness app', 'nutrition tracking']
    },
    {
      type: 'link',
      title: 'Exercise Guidelines',
      description: 'Physical activity guidelines for adults',
      url: 'https://health.gov/our-work/nutrition-physical-activity/physical-activity-guidelines',
      domain: 'health.gov',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['exercise', 'physical activity', 'fitness'],
      searchTerms: ['exercise guidelines', 'physical activity', 'fitness', 'workout']
    },
    {
      type: 'link',
      title: 'Mental Health Resources',
      description: 'Mental health information and resources',
      url: 'https://www.mentalhealth.gov',
      domain: 'mentalhealth.gov',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['mental health', 'wellness', 'self-care'],
      searchTerms: ['mental health', 'wellness', 'self-care', 'stress management']
    }
  ],

  home_life: [
    {
      type: 'link',
      title: 'Home Organization Guide',
      description: 'Practical tips for organizing and decluttering your home',
      url: 'https://www.realsimple.com/home-organizing',
      domain: 'realsimple.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['organization', 'decluttering', 'home management'],
      searchTerms: ['home organization', 'decluttering', 'cleaning', 'organizing']
    },
    {
      type: 'link',
      title: 'Cooking Basics',
      description: 'Essential cooking skills and techniques for beginners',
      url: 'https://en.wikipedia.org/wiki/Cooking',
      domain: 'wikipedia.org',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['cooking', 'kitchen skills', 'meal prep'],
      searchTerms: ['cooking basics', 'cooking skills', 'meal prep', 'kitchen']
    },
    {
      type: 'template',
      title: 'Cleaning Schedule Template',
      description: 'Printable cleaning schedule to maintain your home',
      url: 'https://www.goodhousekeeping.com/home/cleaning/a37462/how-often-you-should-clean-everything/',
      domain: 'goodhousekeeping.com',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['cleaning', 'schedule', 'home maintenance'],
      searchTerms: ['cleaning schedule', 'house cleaning', 'home maintenance']
    },
    {
      type: 'link',
      title: 'Laundry Guide',
      description: 'Complete guide to washing, drying, and caring for clothes',
      url: 'https://www.goodhousekeeping.com/home/cleaning/tips/a24885/how-to-do-laundry/',
      domain: 'goodhousekeeping.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['laundry', 'clothing care', 'home skills'],
      searchTerms: ['laundry', 'washing clothes', 'clothing care', 'fabric care']
    }
  ],

  life_admin: [
    {
      type: 'link',
      title: 'Tax Filing Guide',
      description: 'Official IRS guide to filing your taxes',
      url: 'https://www.irs.gov/filing',
      domain: 'irs.gov',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['taxes', 'tax filing', 'IRS'],
      searchTerms: ['tax filing', 'taxes', 'IRS', 'tax return']
    },
    {
      type: 'link',
      title: 'Insurance Basics',
      description: 'Understanding different types of insurance and coverage',
      url: 'https://www.iii.org/insurance-basics',
      domain: 'iii.org',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['insurance', 'coverage', 'protection'],
      searchTerms: ['insurance', 'health insurance', 'auto insurance', 'coverage']
    },
    {
      type: 'link',
      title: 'Important Documents Checklist',
      description: 'Checklist of important documents to keep organized',
      url: 'https://www.consumerfinance.gov/ask-cfpb/',
      domain: 'consumerfinance.gov',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['documents', 'organization', 'records'],
      searchTerms: ['important documents', 'financial records', 'document organization']
    },
    {
      type: 'link',
      title: 'Consumer Rights Guide',
      description: 'Know your rights as a consumer',
      url: 'https://consumer.ftc.gov/',
      domain: 'ftc.gov',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['consumer rights', 'protection', 'legal'],
      searchTerms: ['consumer rights', 'consumer protection', 'legal rights']
    }
  ],

  personal_growth: [
    {
      type: 'link',
      title: 'Goal Setting Guide',
      description: 'Science-based approach to setting and achieving goals',
      url: 'https://www.mindtools.com/pages/article/newHTE_90.htm',
      domain: 'mindtools.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['goal setting', 'productivity', 'self-improvement'],
      searchTerms: ['goal setting', 'goals', 'productivity', 'self-improvement']
    },
    {
      type: 'tool',
      title: 'Coursera Online Learning',
      description: 'Access thousands of courses from top universities',
      url: 'https://www.coursera.org',
      domain: 'coursera.org',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['online learning', 'education', 'skills'],
      searchTerms: ['online courses', 'learning', 'education', 'skills development']
    },
    {
      type: 'link',
      title: 'Time Management Techniques',
      description: 'Proven strategies for better time management',
      url: 'https://www.mindtools.com/pages/main/newMN_HTE.htm',
      domain: 'mindtools.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['time management', 'productivity', 'efficiency'],
      searchTerms: ['time management', 'productivity', 'efficiency', 'organization']
    },
    {
      type: 'link',
      title: 'TED Talks',
      description: 'Inspiring talks on personal and professional development',
      url: 'https://www.ted.com/talks',
      domain: 'ted.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['inspiration', 'learning', 'ideas'],
      searchTerms: ['TED talks', 'inspiration', 'learning', 'ideas', 'motivation']
    }
  ],

  relationships: [
    {
      type: 'link',
      title: 'Communication Skills Guide',
      description: 'Improve your communication in personal and professional relationships',
      url: 'https://www.skillsyouneed.com/ips/communication-skills.html',
      domain: 'skillsyouneed.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['communication', 'relationships', 'social skills'],
      searchTerms: ['communication skills', 'relationships', 'social skills', 'interpersonal']
    },
    {
      type: 'link',
      title: 'Conflict Resolution',
      description: 'Healthy ways to resolve conflicts in relationships',
      url: 'https://www.gottman.com/about/research/',
      domain: 'gottman.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['conflict resolution', 'relationships', 'communication'],
      searchTerms: ['conflict resolution', 'relationship advice', 'communication', 'relationships']
    },
    {
      type: 'link',
      title: 'Networking Guide',
      description: 'Build professional and personal networks effectively',
      url: 'https://www.mindtools.com/pages/article/newCDV_85.htm',
      domain: 'mindtools.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['networking', 'professional development', 'relationships'],
      searchTerms: ['networking', 'professional networking', 'career development']
    }
  ],

  tech_savvy: [
    {
      type: 'link',
      title: 'Digital Literacy Guide',
      description: 'Essential digital skills for the modern world',
      url: 'https://www.digitallearn.org',
      domain: 'digitallearn.org',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['digital literacy', 'technology', 'computer skills'],
      searchTerms: ['digital literacy', 'computer skills', 'technology', 'digital skills']
    },
    {
      type: 'tool',
      title: 'Codecademy',
      description: 'Learn programming and technical skills interactively',
      url: 'https://www.codecademy.com',
      domain: 'codecademy.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['programming', 'coding', 'technical skills'],
      searchTerms: ['programming', 'coding', 'learn to code', 'technical skills']
    },
    {
      type: 'link',
      title: 'Cybersecurity Basics',
      description: 'Protect yourself online with basic cybersecurity practices',
      url: 'https://www.cisa.gov/topics/cybersecurity-best-practices',
      domain: 'cisa.gov',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['cybersecurity', 'online safety', 'privacy'],
      searchTerms: ['cybersecurity', 'online safety', 'internet security', 'privacy']
    }
  ],

  career_growth: [
    {
      type: 'link',
      title: 'Resume Writing Guide',
      description: 'Create a compelling resume that gets noticed',
      url: 'https://en.wikipedia.org/wiki/R%C3%A9sum%C3%A9',
      domain: 'wikipedia.org',
      quality: 'medium',
      lastVerified: '2025-09-30',
      tags: ['resume', 'job search', 'career'],
      searchTerms: ['resume writing', 'job search', 'career advice', 'CV']
    },
    {
      type: 'tool',
      title: 'LinkedIn Professional Network',
      description: 'Build your professional network and find opportunities',
      url: 'https://www.linkedin.com',
      domain: 'linkedin.com',
      quality: 'high',
      lastVerified: '2024-01-01',
      tags: ['networking', 'professional development', 'job search'],
      searchTerms: ['professional networking', 'LinkedIn', 'career development', 'job search']
    },
    {
      type: 'link',
      title: 'Interview Preparation',
      description: 'Prepare for job interviews with confidence',
      url: 'https://www.themuse.com/advice/interview-questions-and-answers',
      domain: 'themuse.com',
      quality: 'high',
      lastVerified: '2025-09-30',
      tags: ['interviews', 'job search', 'career'],
      searchTerms: ['job interview', 'interview tips', 'interview preparation', 'career']
    }
  ]
};

/**
 * URL templates for dynamic resource generation
 */
export const RESOURCE_TEMPLATES: Record<string, ResourceTemplate[]> = {
  money_mastery: [
    {
      domain: 'investopedia.com',
      urlTemplate: 'https://www.investopedia.com/search?q={topic}',
      quality: 'high',
      type: 'link',
      description: 'Comprehensive financial education and definitions'
    },
    {
      domain: 'nerdwallet.com',
      urlTemplate: 'https://www.nerdwallet.com/blog/search/?q={topic}',
      quality: 'high',
      type: 'tool',
      description: 'Personal finance tools and calculators'
    }
  ],
  health_wellness: [
    {
      domain: 'healthline.com',
      urlTemplate: 'https://www.healthline.com/search?q1={topic}',
      quality: 'high',
      type: 'link',
      description: 'Evidence-based health information'
    },
    {
      domain: 'mayoclinic.org',
      urlTemplate: 'https://www.mayoclinic.org/search/search-results?q={topic}',
      quality: 'high',
      type: 'link',
      description: 'Medical information from Mayo Clinic'
    }
  ],
  // Add more templates for other categories as needed
};

/**
 * Find curated resources by category and search terms
 */
export function findCuratedResources(
  category: string, 
  searchTerms: string[], 
  maxResults: number = 4
): CuratedResource[] {
  const categoryResources = CURATED_RESOURCES[category] || [];
  
  // Score resources based on search term matches
  const scoredResources = categoryResources.map(resource => {
    let score = 0;
    const allTerms = [...resource.searchTerms, ...resource.tags, resource.title.toLowerCase()];
    
    for (const searchTerm of searchTerms) {
      for (const term of allTerms) {
        if (term.toLowerCase().includes(searchTerm.toLowerCase())) {
          score += resource.quality === 'high' ? 3 : resource.quality === 'medium' ? 2 : 1;
        }
      }
    }
    
    return { resource, score };
  });
  
  // Sort by score and return top results
  return scoredResources
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, maxResults)
    .map(item => item.resource);
}

/**
 * Generate URL from template
 */
export function generateURLFromTemplate(template: ResourceTemplate, topic: string): string {
  return template.urlTemplate.replace('{topic}', encodeURIComponent(topic.toLowerCase()));
}