/**
 * AI-Powered Substep Research
 * Generates contextual help and resources for specific lesson substeps
 */

import { proxyChat } from './proxy';

export interface SubstepResearchResult {
  explanation: string;
  tips: string[];
  commonMistakes: string[];
  resources: {
    title: string;
    description: string;
    searchQuery: string;
  }[];
  estimatedTime?: string;
}

export async function generateSubstepResearch(
  lessonTitle: string,
  lessonCategory: string,
  stepTitle: string,
  substepText: string
): Promise<SubstepResearchResult> {
  const prompt = `You are a helpful life skills coach. A user is learning "${lessonTitle}" (category: ${lessonCategory}).

They are on the step: "${stepTitle}"
Specific substep: "${substepText}"

Provide comprehensive, practical guidance for this specific substep. Format your response as JSON with this exact structure:

{
  "explanation": "A clear, encouraging 2-3 sentence explanation of what this substep involves and why it matters",
  "tips": ["3-4 specific, actionable tips for completing this substep successfully"],
  "commonMistakes": ["2-3 common mistakes people make with this substep and how to avoid them"],
  "resources": [
    {
      "title": "Resource name",
      "description": "What this resource provides",
      "searchQuery": "Specific Google/YouTube search query that will find helpful content"
    }
  ],
  "estimatedTime": "X minutes" (optional, only if relevant)
}

Be specific, practical, and encouraging. Focus on actionable advice the user can apply immediately.`;

  try {
    const response = await proxyChat({
      provider: 'openai',
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a helpful life skills coach providing practical guidance. Always respond with valid JSON only, no markdown formatting.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 1000
    });

    const content = response.choices?.[0]?.message?.content || '{}';
    
    // Clean up the response (remove markdown code blocks if present)
    const cleanedContent = content
      .replace(/```json\n?/g, '')
      .replace(/```\n?/g, '')
      .trim();
    
    const result = JSON.parse(cleanedContent) as SubstepResearchResult;
    
    // Validate required fields
    if (!result.explanation || !result.tips || !result.commonMistakes || !result.resources) {
      throw new Error('Invalid response format from AI');
    }
    
    return result;
  } catch (error) {
    if (__DEV__) console.error('Error generating substep research:', error);
    
    // Fallback response
    return {
      explanation: `This step is about ${substepText.toLowerCase()}. Take your time and follow the guidance provided.`,
      tips: [
        'Break this down into smaller actions',
        'Don\'t rush - quality over speed',
        'Ask for help if you need it'
      ],
      commonMistakes: [
        'Trying to do everything at once',
        'Not reading instructions carefully'
      ],
      resources: [
        {
          title: 'General Guide',
          description: 'Search for tutorials and guides',
          searchQuery: `${substepText} how to tutorial`
        }
      ]
    };
  }
}