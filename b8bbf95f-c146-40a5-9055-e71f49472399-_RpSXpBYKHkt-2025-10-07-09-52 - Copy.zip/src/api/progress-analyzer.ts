import { UserProfile, SkillProgress, LifeSkill } from '../types/app';
import { UserProgress, TodoItem, Goal } from '../types/adulting';

export interface LearningPattern {
  preferredTimeOfDay?: 'morning' | 'afternoon' | 'evening';
  averageSessionLength: number;
  completionVelocity: number; // skills per week
  difficultyProgression: 'too_fast' | 'appropriate' | 'too_slow';
  engagementTrend: 'increasing' | 'stable' | 'decreasing';
  strugglingCategories: string[];
  strongCategories: string[];
}

export interface PerformanceMetrics {
  completionRate: number;
  averageRating: number;
  timeEfficiency: number; // actual vs estimated time ratio
  retentionRate: number;
  goalAchievementRate: number;
  streakConsistency: number;
}

export interface LearningBehavior {
  procrastinationTendency: 'low' | 'medium' | 'high';
  preferredSkillLength: 'short' | 'medium' | 'long';
  weeklyActivityPattern: number[]; // 7 days, activity levels 0-1
  motivationFactors: string[];
  challengePreference: 'easy' | 'moderate' | 'difficult';
}

export class ProgressAnalyzer {
  private static instance: ProgressAnalyzer;

  static getInstance(): ProgressAnalyzer {
    if (!ProgressAnalyzer.instance) {
      ProgressAnalyzer.instance = new ProgressAnalyzer();
    }
    return ProgressAnalyzer.instance;
  }

  /**
   * Analyze user's learning patterns from their progress data
   */
  analyzeLearningPatterns(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    skills: LifeSkill[]
  ): LearningPattern {
    const completedSkills = Object.values(skillProgress).filter(p => p.completedAt);
    
    return {
      averageSessionLength: this.calculateAverageSessionLength(skillProgress),
      completionVelocity: this.calculateCompletionVelocity(completedSkills),
      difficultyProgression: this.analyzeDifficultyProgression(skillProgress, skills),
      engagementTrend: this.analyzeEngagementTrend(userProfile, completedSkills),
      strugglingCategories: this.identifyStrugglingCategories(skillProgress, skills),
      strongCategories: this.identifyStrongCategories(skillProgress, skills)
    };
  }

  /**
   * Calculate detailed performance metrics
   */
  calculatePerformanceMetrics(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    adultingProgress: UserProgress
  ): PerformanceMetrics {
    const completedSkillsProgress = Object.values(skillProgress).filter(p => p.completedAt);
    
    return {
      completionRate: this.calculateCompletionRate(skillProgress),
      averageRating: this.calculateAverageRating(completedSkillsProgress),
      timeEfficiency: this.calculateTimeEfficiency(skillProgress),
      retentionRate: this.calculateRetentionRate(userProfile, adultingProgress),
      goalAchievementRate: this.calculateGoalAchievementRate(adultingProgress.goals),
      streakConsistency: this.calculateStreakConsistency(userProfile)
    };
  }

  /**
   * Analyze learning behavior patterns
   */
  analyzeLearningBehavior(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    recentActivity: any[]
  ): LearningBehavior {
    return {
      procrastinationTendency: this.analyzeProcrastination(skillProgress),
      preferredSkillLength: this.analyzeSkillLengthPreference(skillProgress),
      weeklyActivityPattern: this.analyzeWeeklyPattern(recentActivity),
      motivationFactors: this.identifyMotivationFactors(userProfile, skillProgress),
      challengePreference: this.analyzeChallengePreference(skillProgress)
    };
  }

  /**
   * Identify skills where user is struggling
   */
  identifyStrugglingSkills(
    skillProgress: Record<string, SkillProgress>,
    skills: LifeSkill[]
  ): Array<{ skillId: string; reason: string; confidence: number }> {
    const struggling: Array<{ skillId: string; reason: string; confidence: number }> = [];
    
    Object.entries(skillProgress).forEach(([skillId, progress]) => {
      const skill = (skills || []).find(s => s.id === skillId);
      if (!skill) return;

      // High time spent without completion
      if (progress.timeSpent && progress.timeSpent > skill.estimatedTime * 2 && !progress.completedAt) {
        struggling.push({
          skillId,
          reason: 'Taking significantly longer than estimated',
          confidence: 0.8
        });
      }

      // Started but abandoned (no recent activity)
      if (progress.startedAt && !progress.completedAt) {
        const daysSinceStart = (Date.now() - new Date(progress.startedAt).getTime()) / (1000 * 60 * 60 * 24);
        if (daysSinceStart > 7) {
          struggling.push({
            skillId,
            reason: 'Started but not completed for over a week',
            confidence: 0.7
          });
        }
      }

      // Low rating if completed
      if (progress.completedAt && progress.rating && progress.rating < 3) {
        struggling.push({
          skillId,
          reason: 'Completed with low satisfaction rating',
          confidence: 0.6
        });
      }
    });

    return struggling;
  }

  /**
   * Get insights for skill recommendation optimization
   */
  getRecommendationInsights(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    availableSkills: LifeSkill[]
  ): {
    preferredDifficulty: 'starter' | 'building' | 'advanced';
    avoidCategories: string[];
    priorityCategories: string[];
    optimalSkillLength: number;
    confidenceLevel: number;
  } {
    const patterns = this.analyzeLearningPatterns(userProfile, skillProgress, availableSkills);
    const performance = this.calculatePerformanceMetrics(userProfile, skillProgress, {
      totalXP: userProfile.totalXP || 0,
      totalTipsCompleted: 0,
      completedTips: [],
      bookmarkedTips: [],
      todoItems: [],
      goals: [],
      streak: userProfile.streak,
      streakDays: userProfile.streak,
      lastVisit: userProfile.lastActiveDate,
      achievements: [],
      tipRatings: {},
      preferences: {
        categories: [],
        difficulty: 'beginner',
        notifications: true,
        reminderTime: '09:00'
      }
    });

    const preferredDifficulty = this.determineDifficultyPreference(skillProgress, availableSkills);
    
    return {
      preferredDifficulty,
      avoidCategories: patterns.strugglingCategories,
      priorityCategories: (patterns.strongCategories || []).length > 0 
        ? patterns.strongCategories 
        : (userProfile.preferences.focusAreas || []),
      optimalSkillLength: patterns.averageSessionLength,
      confidenceLevel: Math.min(performance.completionRate / 100, 1.0)
    };
  }

  private calculateAverageSessionLength(skillProgress: Record<string, SkillProgress>): number {
    const progressEntries = Object.values(skillProgress || {});
    if (progressEntries.length === 0) return 30; // default 30 minutes

    const totalTime = progressEntries.reduce((sum, progress) => sum + (progress.timeSpent || 0), 0);
    return Math.round(totalTime / progressEntries.length);
  }

  private calculateCompletionVelocity(completedSkills: SkillProgress[]): number {
    if ((completedSkills || []).length === 0) return 0;

    const now = Date.now();
    const oneWeekAgo = now - (7 * 24 * 60 * 60 * 1000);
    
    const recentCompletions = (completedSkills || []).filter(skill => 
      skill.completedAt && new Date(skill.completedAt).getTime() > oneWeekAgo
    );

    return recentCompletions.length;
  }

  private analyzeDifficultyProgression(
    skillProgress: Record<string, SkillProgress>,
    skills: LifeSkill[]
  ): 'too_fast' | 'appropriate' | 'too_slow' {
    const completedProgress = Object.values(skillProgress || {}).filter(p => p.completedAt);
    if (completedProgress.length < 3) return 'appropriate';

    const recentCompletions = completedProgress
      .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
      .slice(0, 5);

    const difficulties = recentCompletions.map(progress => {
      const skill = (skills || []).find(s => s.id === progress.skillId);
      return skill?.difficulty;
    }).filter(Boolean);

    const starterCount = difficulties.filter(d => d === 'starter').length;
    const advancedCount = difficulties.filter(d => d === 'mastery').length;

    if (starterCount > difficulties.length * 0.7) return 'too_slow';
    if (advancedCount > difficulties.length * 0.6) return 'too_fast';
    return 'appropriate';
  }

  private analyzeEngagementTrend(userProfile: UserProfile, completedSkills: SkillProgress[]): 'increasing' | 'stable' | 'decreasing' {
    if ((completedSkills || []).length < 4) return 'stable';

    const now = Date.now();
    const twoWeeksAgo = now - (14 * 24 * 60 * 60 * 1000);
    const oneWeekAgo = now - (7 * 24 * 60 * 60 * 1000);

    const recentWeek = (completedSkills || []).filter(skill => 
      skill.completedAt && new Date(skill.completedAt).getTime() > oneWeekAgo
    ).length;

    const previousWeek = (completedSkills || []).filter(skill => 
      skill.completedAt && 
      new Date(skill.completedAt).getTime() > twoWeeksAgo &&
      new Date(skill.completedAt).getTime() <= oneWeekAgo
    ).length;

    if (recentWeek > previousWeek) return 'increasing';
    if (recentWeek < previousWeek) return 'decreasing';
    return 'stable';
  }

  private identifyStrugglingCategories(skillProgress: Record<string, SkillProgress>, skills: LifeSkill[]): string[] {
    const categoryPerformance: Record<string, { total: number; completed: number; avgTime: number }> = {};

    Object.values(skillProgress).forEach(progress => {
      const skill = skills.find(s => s.id === progress.skillId);
      if (!skill) return;

      if (!categoryPerformance[skill.category]) {
        categoryPerformance[skill.category] = { total: 0, completed: 0, avgTime: 0 };
      }

      categoryPerformance[skill.category].total++;
      if (progress.completedAt) {
        categoryPerformance[skill.category].completed++;
      }
      categoryPerformance[skill.category].avgTime += progress.timeSpent || 0;
    });

    return Object.entries(categoryPerformance)
      .filter(([_, perf]) => {
        const completionRate = perf.completed / perf.total;
        const avgTime = perf.avgTime / perf.total;
        return completionRate < 0.6 || avgTime > 60; // struggling if completion < 60% or avg time > 60min
      })
      .map(([category]) => category);
  }

  private identifyStrongCategories(skillProgress: Record<string, SkillProgress>, skills: LifeSkill[]): string[] {
    const categoryPerformance: Record<string, { total: number; completed: number; avgRating: number }> = {};

    Object.values(skillProgress).forEach(progress => {
      const skill = skills.find(s => s.id === progress.skillId);
      if (!skill) return;

      if (!categoryPerformance[skill.category]) {
        categoryPerformance[skill.category] = { total: 0, completed: 0, avgRating: 0 };
      }

      categoryPerformance[skill.category].total++;
      if (progress.completedAt) {
        categoryPerformance[skill.category].completed++;
        categoryPerformance[skill.category].avgRating += progress.rating || 0;
      }
    });

    return Object.entries(categoryPerformance)
      .filter(([_, perf]) => {
        const completionRate = perf.completed / perf.total;
        const avgRating = perf.completed > 0 ? perf.avgRating / perf.completed : 0;
        return completionRate >= 0.8 && avgRating >= 4; // strong if completion >= 80% and rating >= 4
      })
      .map(([category]) => category);
  }

  private calculateCompletionRate(skillProgress: Record<string, SkillProgress>): number {
    const progressEntries = Object.values(skillProgress || {});
    if (progressEntries.length === 0) return 0;
    
    const completed = progressEntries.filter(p => p.completedAt).length;
    return Math.round((completed / progressEntries.length) * 100);
  }

  private calculateAverageRating(completedSkills: SkillProgress[]): number {
    const ratingsSkills = (completedSkills || []).filter(s => s.rating);
    if (ratingsSkills.length === 0) return 0;

    const totalRating = ratingsSkills.reduce((sum, skill) => sum + (skill.rating || 0), 0);
    return Math.round((totalRating / ratingsSkills.length) * 10) / 10;
  }

  private calculateTimeEfficiency(skillProgress: Record<string, SkillProgress>): number {
    // This would need access to skill estimated times to calculate properly
    // For now, return a placeholder value
    return 1.0;
  }

  private calculateRetentionRate(userProfile: UserProfile, adultingProgress: UserProgress): number {
    // Calculate based on recurring skill practice and tip application
    const practiceIndicators = adultingProgress.todoItems.filter(todo => 
      todo.description?.includes('practice') || todo.title.includes('practice')
    );
    
    return Math.min(practiceIndicators.length / Math.max((userProfile.completedSkills || []).length, 1), 1) * 100;
  }

  private calculateGoalAchievementRate(goals: Goal[]): number {
    if ((goals || []).length === 0) return 0;
    const completed = (goals || []).filter(g => g.completed).length;
    return Math.round((completed / (goals || []).length) * 100);
  }

  private calculateStreakConsistency(userProfile: UserProfile): number {
    // This is a simplified calculation - in reality would need historical streak data
    const daysActive = Math.min(userProfile.streak, 30); // cap at 30 days for calculation
    return Math.round((daysActive / 30) * 100);
  }

  private analyzeProcrastination(skillProgress: Record<string, SkillProgress>): 'low' | 'medium' | 'high' {
    const startedNotCompleted = Object.values(skillProgress || {}).filter(p => p.startedAt && !p.completedAt);
    const total = Object.values(skillProgress || {}).length;
    
    if (total === 0) return 'low';
    const procrastinationRate = startedNotCompleted.length / total;
    
    if (procrastinationRate > 0.5) return 'high';
    if (procrastinationRate > 0.25) return 'medium';
    return 'low';
  }

  private analyzeSkillLengthPreference(skillProgress: Record<string, SkillProgress>): 'short' | 'medium' | 'long' {
    const avgTime = this.calculateAverageSessionLength(skillProgress);
    
    if (avgTime < 20) return 'short';
    if (avgTime > 45) return 'long';
    return 'medium';
  }

  private analyzeWeeklyPattern(recentActivity: any[]): number[] {
    // Return weekly activity pattern (simplified implementation)
    return [0.8, 0.9, 0.7, 0.8, 0.6, 0.3, 0.4]; // Mon-Sun activity levels
  }

  private identifyMotivationFactors(userProfile: UserProfile, skillProgress: Record<string, SkillProgress>): string[] {
    const factors: string[] = [];
    
    if (userProfile.streak > 7) factors.push('consistency');
    if (userProfile.totalXP > 500) factors.push('achievement');
    if ((userProfile.preferences.focusAreas || []).length > 3) factors.push('variety');
    
    const avgRating = this.calculateAverageRating(Object.values(skillProgress || {}).filter(p => p.completedAt));
    if (avgRating > 4) factors.push('satisfaction');
    
    return factors;
  }

  private analyzeChallengePreference(skillProgress: Record<string, SkillProgress>): 'easy' | 'moderate' | 'difficult' {
    const completedSkills = Object.values(skillProgress || {}).filter(p => p.completedAt && p.rating);
    if (completedSkills.length === 0) return 'moderate';

    const avgRating = this.calculateAverageRating(completedSkills);
    const completionRate = this.calculateCompletionRate(skillProgress);

    if (avgRating >= 4.5 && completionRate > 80) return 'difficult';
    if (avgRating < 3.5 || completionRate < 50) return 'easy';
    return 'moderate';
  }

  private determineDifficultyPreference(
    skillProgress: Record<string, SkillProgress>,
    skills: LifeSkill[]
  ): 'starter' | 'building' | 'advanced' {
    const difficultyProgression = this.analyzeDifficultyProgression(skillProgress, skills);
    const challengePreference = this.analyzeChallengePreference(skillProgress);

    if (difficultyProgression === 'too_slow' || challengePreference === 'difficult') {
      return 'advanced';
    }
    if (difficultyProgression === 'too_fast' || challengePreference === 'easy') {
      return 'starter';
    }
    return 'building';
  }
}

export const progressAnalyzer = ProgressAnalyzer.getInstance();