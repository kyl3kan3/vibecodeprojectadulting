import { storekit } from "../services/storekit";
import { supabaseMCP } from "../lib/supabase-mcp";

export type ProviderStatus = {
  name: string;
  status: "connected" | "unreachable" | "not_configured" | "unavailable_in_build";
  detail?: string;
  error?: string;
  statusCode?: number;
  latencyMs?: number;
  lastAttemptAt?: string;
};

const withTimeout = async <T>(p: Promise<T>, ms = 3000): Promise<T> => {
  return await Promise.race([
    p,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error("timeout")), ms)) as any,
  ]);
};

const nowIso = () => new Date().toISOString();
const redact = (s?: string) => s ? s.replace(/(sk-[A-Za-z0-9-_]{10,})/g, "sk-REDACTED").replace(/[A-Za-z0-9_\-]{24,}/g, "REDACTED") : "";
const timed = async <T>(fn: () => Promise<T>) => {
  const t0 = Date.now();
  try {
    const data = await fn();
    return { data, latencyMs: Date.now() - t0 } as const;
  } catch (error: any) {
    return { error, latencyMs: Date.now() - t0 } as const;
  }
};

// Proxy-only architecture: Test providers through Vercel proxy
async function pingProviderThroughProxy(provider: string, model: string = "auto"): Promise<ProviderStatus> {
  const url = process.env.EXPO_PUBLIC_AI_PROXY_URL;
  if (!url) return { name: provider, status: "not_configured", detail: "No proxy URL configured", lastAttemptAt: nowIso() } as any;
  
  const { data, error, latencyMs } = await timed(async () => {
    const headers: any = { "content-type": "application/json" };
    const bypass = process.env.EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS;
    const secret = process.env.EXPO_PUBLIC_PROXY_SECRET;
    if (bypass) headers["x-vercel-protection-bypass"] = bypass;
    if (secret) headers["x-proxy-secret"] = secret;

    const res = await withTimeout(
      fetch(url.replace(/\/$/, "") + "/api/ai", {
        method: "POST",
        headers,
        body: JSON.stringify({ 
          provider: provider.toLowerCase(), 
          task: "chat", 
          model, 
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 5
        })
      }),
      5000
    );
    
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw Object.assign(new Error(redact(txt || "bad_status")), { status: res.status });
    }
    return true;
  });
  
  if (error) return { name: provider, status: "unreachable", error: redact(error?.message || String(error)), statusCode: (error as any)?.status, latencyMs, lastAttemptAt: nowIso() } as any;
  return { name: provider, status: "connected", latencyMs, lastAttemptAt: nowIso() } as any;
}

export async function pingOpenAI(): Promise<ProviderStatus> {
  return await pingProviderThroughProxy("OpenAI");
}


export async function pingGrok(): Promise<ProviderStatus> {
  return await pingProviderThroughProxy("Grok");
}

export async function pingGemini(): Promise<ProviderStatus> {
  return await pingProviderThroughProxy("Gemini");
}

export async function pingStoreKit(): Promise<ProviderStatus & { productsCount?: number; configuredIds?: string[]; active?: boolean; appOwnership?: string; groupId?: string; sampleProduct?: { id?: string; priceString?: string; period?: string } }> {
  let ownership: string | undefined = undefined;
  let configuredIds: string[] = [];
  let groupId: string | undefined = undefined;
  let active = false;
  
  try { 
    const Constants = require("expo-constants").default; 
    ownership = Constants?.appOwnership || undefined; 
  } catch {}
  
  try { 
    configuredIds = storekit.getConfiguredIds() || []; 
  } catch {}
  
  try { 
    groupId = process.env.EXPO_PUBLIC_IAP_GROUP_ID; 
  } catch {}
  
  // Initialize StoreKit with proper error handling
  try { 
    await storekit.init(); 
  } catch (initError: any) {
    return { 
      name: "StoreKit", 
      status: "unavailable_in_build", 
      error: redact(`Init failed: ${initError?.message || String(initError)}`), 
      lastAttemptAt: nowIso(), 
      configuredIds, 
      active: false, 
      appOwnership: ownership, 
      groupId 
    } as any;
  }
  
  // Test getProducts with proper error handling
  const { data, error, latencyMs } = await timed(async () => {
    try {
      return await withTimeout(storekit.getProducts(), 5000);
    } catch (prodError: any) {
      // Handle specific "getitems of null" error
      if (prodError?.message?.includes('getitems') || prodError?.message?.includes('null')) {
        throw new Error('StoreKit not properly initialized or no products configured');
      }
      throw prodError;
    }
  });
  
  // Test active subscription status
  try { 
    const activeResult = await storekit.getActive();
    active = !!(activeResult?.active); 
  } catch {}
  
  if (error) {
    return { 
      name: "StoreKit", 
      status: "unavailable_in_build", 
      error: redact(error?.message || String(error)), 
      latencyMs, 
      lastAttemptAt: nowIso(), 
      configuredIds, 
      active, 
      appOwnership: ownership, 
      groupId 
    } as any;
  }
  
  const prods = (data as any) || [];
  const count = Array.isArray(prods) ? prods.length : 0;
  const sample = count > 0 ? prods[0] : null;
  const status: ProviderStatus["status"] = ownership === "expo" ? "unavailable_in_build" : (count > 0 ? "connected" : "unavailable_in_build");
  
  return { 
    name: "StoreKit", 
    status, 
    productsCount: count, 
    latencyMs, 
    lastAttemptAt: nowIso(), 
    configuredIds, 
    active, 
    appOwnership: ownership, 
    groupId, 
    sampleProduct: sample ? { 
      id: sample.id || sample.productId, 
      priceString: sample.priceString || sample.displayPrice, 
      period: sample.subscriptionPeriod || sample.period 
    } : undefined 
  } as any;
}

export async function pingProxy(): Promise<ProviderStatus & { url?: string }> {
  const url = process.env.EXPO_PUBLIC_AI_PROXY_URL;
  if (!url) return { name: "AI Proxy", status: "not_configured", lastAttemptAt: nowIso() } as any;
  const { data, error, latencyMs } = await timed(async () => {
    const headers: any = { "content-type": "application/json" };
    const bypass = process.env.EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS;
    const secret = process.env.EXPO_PUBLIC_PROXY_SECRET;
    if (bypass) headers["x-vercel-protection-bypass"] = bypass;
    if (secret) headers["x-proxy-secret"] = secret;

    const res = await withTimeout(
      fetch(url.replace(/\/$/, "") + "/api/ai", {
        method: "POST",
        headers,
        body: JSON.stringify({ provider: "openai", task: "chat", model: "auto", messages: [
          { role: "system", content: "You are a status checker. Reply with a single word: pong." },
          { role: "user", content: "ping" }
        ] })
      }),
      3000
    );
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw Object.assign(new Error(redact(txt || "bad_status")), { status: res.status });
    }
    return true as any;
  });
  if (error) return { name: "AI Proxy", status: "unreachable", url, error: redact(error?.message || String(error)), statusCode: (error as any)?.status, latencyMs, lastAttemptAt: nowIso() } as any;
  return { name: "AI Proxy", status: "connected", url, latencyMs, lastAttemptAt: nowIso() } as any;
}

export async function pingDatabase(): Promise<ProviderStatus & { tablesCount?: number; lessonsCount?: number; profilesCount?: number }> {
  const { data, error, latencyMs } = await timed(async () => {
    // Test basic connectivity with a simple query via proxy
    const lessons = await withTimeout(
      supabaseMCP.query('lessons', { select: 'id', limit: 1 }),
      5000
    );
    const profiles = await withTimeout(
      supabaseMCP.query('profiles', { select: 'id', limit: 1 }),
      5000
    );
    return {
      lessonsCount: Array.isArray(lessons?.data) ? lessons.data.length : 0,
      profilesCount: Array.isArray(profiles?.data) ? profiles.data.length : 0,
      tablesCount: 2
    } as any;
  });
  
  if (error) {
    return { 
      name: "Database", 
      status: "unreachable", 
      error: redact(error?.message || String(error)), 
      latencyMs, 
      lastAttemptAt: nowIso() 
    } as any;
  }
  
  if (!data) {
    return { 
      name: "Database", 
      status: "unreachable", 
      error: "No data returned from database", 
      latencyMs, 
      lastAttemptAt: nowIso() 
    } as any;
  }
  
  return { 
    name: "Database", 
    status: "connected", 
    latencyMs, 
    lastAttemptAt: nowIso(),
    tablesCount: data.tablesCount,
    lessonsCount: data.lessonsCount,
    profilesCount: data.profilesCount
  } as any;
}

export async function runDiagnostics() {
  const [sk, proxy, database, openai, grok, gemini] = await Promise.all([
    pingStoreKit(),
    pingProxy(),
    pingDatabase(),
    pingOpenAI(),
    pingGrok(),
    pingGemini(),
  ]);
  return { storekit: sk, proxy, database, openai, grok, gemini } as any;
}
