/*
IMPORTANT NOTICE: DO NOT REMOVE
This is a custom asset generation service that uses a custom API endpoint maintained by Vibecode. If the user wants to build an app that generates images, assets, icons, or anything else, you must use this internal endpoint. Do not attempt to use replicate or chatgpt.
You may update this service, but you should not need to.
This endpoint uses openai's latest image generation API, AKA gpt4o, AKA gpt-image-1, so if the user is asking for that, this is the right service to use.
Does not support video and audio generation.
*/

import { proxyImage } from "./proxy";

/**
 * Generate an image using the custom API endpoint
 * @param prompt The text prompt to generate an image from
 * @param options Optional parameters for image generation
 * @returns URL of the generated image, usable to render in the app directly.
 */
export async function generateImage(
  prompt: string,
  options?: {
    size?: "1024x1024" | "1536x1024" | "1024x1536" | "auto";
    quality?: "low" | "medium" | "high" | "auto";
    format?: "png" | "jpeg" | "webp";
    background?: undefined | "transparent";
  }
): Promise<string> {
  const res = await proxyImage({ prompt, options });
  // tolerant parsing
  if (res?.data?.url) return res.data.url;
  if (res?.data?.imageUrl) return res.data.imageUrl;
  if (typeof res?.url === "string") return res.url;
  if (typeof res?.content === "string") return res.content;
  throw new Error("Image URL not found in proxy response");
}

/**
 * Convert aspect ratio to size format
 * @param aspectRatio The aspect ratio to convert
 * @returns The corresponding size format
 */
export function convertAspectRatioToSize(aspectRatio: string): "1024x1024" | "1536x1024" | "1024x1536" | "auto" {
  switch (aspectRatio) {
    case "1:1":
      return "1024x1024";
    case "3:2":
      return "1536x1024";
    case "2:3":
      return "1024x1536";
    default:
      return "auto";
  }
}
