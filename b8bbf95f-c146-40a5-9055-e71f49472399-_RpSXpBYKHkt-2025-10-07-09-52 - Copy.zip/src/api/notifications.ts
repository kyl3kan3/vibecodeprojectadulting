import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export interface NotificationSettings {
  enabled: boolean;
  time: string; // Format: "HH:mm"
  days: number[]; // 0-6, where 0 is Sunday
}

export const requestNotificationPermissions = async (): Promise<boolean> => {
  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      return false;
    }

    // For Android, create notification channel
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('daily-tips', {
        name: 'Daily Tips',
        importance: Notifications.AndroidImportance.DEFAULT,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#007AFF',
        description: 'Daily adulting tips and reminders',
      });
    }

    return true;
  } catch (error) {
    if (__DEV__) console.error('Error requesting notification permissions:', error);
    return false;
  }
};

export const scheduleDailyNotifications = async (settings: NotificationSettings): Promise<void> => {
  try {
    // Cancel existing notifications
    await Notifications.cancelAllScheduledNotificationsAsync();

    if (!settings.enabled) {
      return;
    }

    const [hours, minutes] = settings.time.split(':').map(Number);

    // Schedule for each selected day
    for (const dayOfWeek of settings.days) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "🌟 Your Daily Adulting Tip is Ready!",
          body: "Learn something new today to level up your life skills.",
          data: { 
            type: 'daily-tip',
            dayOfWeek 
          },
          sound: true,
        },
        trigger: {
          weekday: dayOfWeek === 0 ? 1 : dayOfWeek + 1, // Expo uses 1-7 (Mon-Sun)
          hour: hours,
          minute: minutes,
          repeats: true,
        } as any,
      });
    }

    // Daily notifications scheduled successfully
  } catch (error) {
    if (__DEV__) console.error('Error scheduling notifications:', error);
    throw error;
  }
};

export const cancelAllNotifications = async (): Promise<void> => {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    if (__DEV__) console.log('All notifications canceled');
  } catch (error) {
    if (__DEV__) console.error('Error canceling notifications:', error);
  }
};

export const getScheduledNotifications = async () => {
  try {
    return await Notifications.getAllScheduledNotificationsAsync();
  } catch (error) {
    if (__DEV__) console.error('Error getting scheduled notifications:', error);
    return [];
  }
};

// Notification response handler
export const addNotificationResponseListener = (handler: (response: Notifications.NotificationResponse) => void) => {
  return Notifications.addNotificationResponseReceivedListener(handler);
};

// Default notification settings
export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  enabled: false,
  time: '09:00', // 9 AM
  days: [1, 2, 3, 4, 5], // Monday to Friday
};