// src/api/proxy.ts
// RN/Expo client → your Vercel proxy (no provider keys in app)

type Json = Record<string, any>;

export type ProxyChatPayload = {
  provider?: "openai" | "gemini" | "xai" | "elevenlabs" | "ebay";
  task?: "chat" | "complete" | "image" | "transcribe" | "tts" | "tts.stream";
  model?: string | null;
  messages?: Array<{ role: string; content: string }>;
  prompt?: string;
  temperature?: number;
  max_tokens?: number;

  // image
  size?: "256x256" | "512x512" | "1024x1024";
  options?: Json;

  // transcribe
  fileUrl?: string;
  language?: string;

  // tts
  text?: string;
  voice?: string;
  format?: "mp3" | "wav" | "pcm";
  sample_rate?: number;
  stability?: number;
  similarity_boost?: number;
};

export type ProxyOptions = {
  timeoutMs?: number; // default 25000
  retries?: number;   // default 1
  headers?: Record<string, string>;
};

// 🔒 Hard-code your proxy base URL (as requested)
const RAW_BASE_URL = "https://vercel-multi-ai-proxy.vercel.app/";
const BASE_URL = RAW_BASE_URL.replace(/\/+$/, "");

let authTokenProvider: null | (() => Promise<string | null>) = null;

/** Plug in your JWT source (e.g., Supabase) from App.tsx */
export function setAuthTokenProvider(fn: () => Promise<string | null>) {
  authTokenProvider = fn;
}

async function getJwt(): Promise<string | null> {
  try {
    if (authTokenProvider) {
      const t = await authTokenProvider();
      if (__DEV__) {
        if (__DEV__) console.log('[Proxy] JWT from provider:', t ? `${t.substring(0, 20)}...` : 'null');
      }
      if (t && t.length > 10) return t;
    } else {
      if (__DEV__) {
        if (__DEV__) console.log('[Proxy] No authTokenProvider set');
      }
    }
  } catch (err) {
    if (__DEV__) {
      if (__DEV__) console.error('[Proxy] Error getting JWT:', err);
    }
  }
  return null;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchWithControls(
  url: string,
  init: RequestInit,
  { timeoutMs = 25_000, retries = 1 }: ProxyOptions = {}
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let lastErr: any = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(url, { ...init, signal: controller.signal });
        if (res.ok) return res;

        if ([502, 503, 504].includes(res.status) && attempt < retries) {
          await sleep(300 * (attempt + 1));
          continue;
        }
        return res;
      } catch (err: any) {
        lastErr = err;
        if (attempt < retries && (err?.name === "TypeError" || err?.message?.includes?.("Network"))) {
          await sleep(300 * (attempt + 1));
          continue;
        }
        throw err;
      }
    }
    throw lastErr ?? new Error("Unknown network error");
  } finally {
    clearTimeout(timer);
  }
}

async function postJSON<T = any>(
  path: string,
  body: Json,
  opts?: ProxyOptions
): Promise<T> {
  const url = `${BASE_URL}${path.startsWith("/") ? path : `/${path}`}`;
  const token = await getJwt();

  const headers: Record<string, string> = {
    "content-type": "application/json",
    ...(opts?.headers || {}),
  };
  if (token) headers.authorization = `Bearer ${token}`;

  const res = await fetchWithControls(
    url,
    { method: "POST", headers, body: JSON.stringify(body) },
    opts
  );

  const text = await res.text().catch(() => "");
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {}

  if (!res.ok) {
    const details = (data && (data.error || data.message || data.details)) || text || `HTTP ${res.status}`;
    const err: any = new Error(`Proxy error ${res.status}: ${details}`);
    err.status = res.status;
    err.body = data ?? text;
    throw err;
  }
  return (data ?? (text as any)) as T;
}

/** High-level helper used by chat-service.ts */
export async function proxyChat(payload: ProxyChatPayload, opts?: ProxyOptions) {
  // Debug logging
  if (__DEV__) {
    if (__DEV__) console.log('[Proxy] proxyChat called with:', {
      provider: payload.provider,
      task: payload.task,
      model: payload.model,
      hasMessages: !!payload.messages,
      messageCount: payload.messages?.length,
      hasPrompt: !!payload.prompt
    });
  }

  // Basic guard for chat/complete
  if (
    (payload.task === "chat" || !payload.task || payload.task === "complete") &&
    (!payload.messages || payload.messages.length === 0) &&
    !payload.prompt
  ) {
    const err: any = new Error(
      "Invalid 'messages': include at least one item with non-empty text, or provide 'prompt'."
    );
    err.status = 400;
    throw err;
  }

  const body: any = {
    provider: payload.provider ?? "openai",   // ⬅ direct to provider
    task: payload.task ?? "chat",
    model: payload.model ?? "gpt-4o-mini",    // ⬅ OpenAI model id
  };

  if (body.task === "chat" || body.task === "complete") {
    Object.assign(body, {
      messages: payload.messages,
      prompt: payload.prompt,
      temperature: payload.temperature ?? 0.3,
      max_tokens: payload.max_tokens ?? 600,
    });
  }

  if (body.task === "image") {
    Object.assign(body, {
      prompt: payload.prompt,
      size: payload.size ?? "1024x1024",
      options: payload.options,
    });
  }

  if (body.task === "transcribe") {
    Object.assign(body, { fileUrl: payload.fileUrl, language: payload.language });
  }

  if (body.task === "tts" || body.task === "tts.stream") {
    Object.assign(body, {
      text: payload.text,
      voice: payload.voice,
      format: payload.format,
      sample_rate: payload.sample_rate,
      stability: payload.stability,
      similarity_boost: payload.similarity_boost,
    });
  }

  if (__DEV__) {
    if (__DEV__) console.log('[Proxy] Sending request to:', BASE_URL + '/api/ai');
    if (__DEV__) console.log('[Proxy] Request body:', JSON.stringify(body, null, 2));
  }

  const result = await postJSON("/api/ai", body, opts);
  
  if (__DEV__) {
    if (__DEV__) console.log('[Proxy] Response received:', result);
  }

  return result;
}

/** Image generation */
export async function proxyImage(payload: {
  provider?: string;
  prompt: string;
  size?: string;
  model?: string;
  options?: Json;
}, opts?: ProxyOptions) {
  return proxyChat({
    provider: (payload.provider as any) ?? "openai",
    task: "image",
    prompt: payload.prompt,
    size: payload.size as any,
    model: payload.model,
    options: payload.options,
  }, opts);
}

/** Audio transcription */
export async function proxyTranscribe(payload: {
  fileUrl?: string;
  provider?: string;
  model?: string;
  language?: string;
}, opts?: ProxyOptions) {
  return proxyChat({
    provider: (payload.provider as any) ?? "openai",
    task: "transcribe",
    fileUrl: payload.fileUrl,
    model: payload.model,
    language: payload.language,
  }, opts);
}

/** Text-to-speech */
export async function proxyTTS(payload: {
  text: string;
  voice?: string;
  provider?: string;
  model?: string;
  format?: string;
  sample_rate?: number;
  stability?: number;
  similarity_boost?: number;
}, opts?: ProxyOptions) {
  return proxyChat({
    provider: (payload.provider as any) ?? "openai",
    task: "tts",
    text: payload.text,
    voice: payload.voice,
    model: payload.model,
    format: payload.format as any,
    sample_rate: payload.sample_rate,
    stability: payload.stability,
    similarity_boost: payload.similarity_boost,
  }, opts);
}

// Legacy compatibility exports
export const getProxyBase = () => BASE_URL;
export const proxyRequest = postJSON;
