/*
IMPORTANT NOTICE: DO NOT REMOVE
This is a custom audio transcription service that uses a custom API endpoint maintained by Vibecode.
You can use this function to transcribe audio files, and it will return the text of the audio file.
*/

/**
 * Transcribe an audio file
 * @param localAudioUri - The local URI of the audio file to transcribe. Obtained via the expo-av library.
 * @returns The text of the audio file
 */
import { proxyTranscribe } from "./proxy";

export const transcribeAudio = async (localAudioUri: string) => {
  try {
    const formData = new FormData();
    formData.append("file", {
      uri: localAudioUri,
      type: "audio/m4a",
      name: "recording.m4a",
    } as any);
    formData.append("language", "en");
    const result = await proxyTranscribe(formData);
    return result?.text || "";
  } catch (error) {
    throw error;
  }
};
