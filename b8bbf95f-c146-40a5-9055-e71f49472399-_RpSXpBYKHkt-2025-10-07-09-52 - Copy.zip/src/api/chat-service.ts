/*
Direct provider chat service (via Vercel proxy)
Routes: App → Vercel Proxy → OpenAI directly
Exports:
  - getOpenAITextResponse(messages, options?)
  - getOpenAIChatResponse(prompt)
  - getCoachAIResponse(messages, options?)
*/

import { AIMessage, AIRequestOptions, AIResponse } from "../types/ai";
import { proxyChat } from "./proxy";

const DEFAULT_SYSTEM_PROMPT =
  "You are a helpful, concise assistant. Keep answers clear and actionable.";

const extractContent = (data: any): string => {
  return (
    data?.choices?.[0]?.message?.content ||
    data?.content ||
    data?.output?.content ||
    data?.message?.content ||
    ""
  );
};

const normalizeMessages = (
  messages: AIMessage[] = [],
  systemPrompt?: string,
  userFallback: string = "Please provide concise, concrete guidance."
): AIMessage[] => {
  const safe = (messages || [])
    .map(m => ({ role: m.role, content: (m.content || "").toString().trim() }))
    .filter(m => !!m.content);

  const sysIndex = safe.findIndex(m => m.role === "system");
  const existingSystem = sysIndex >= 0 ? safe[sysIndex] : null;
  const withoutSystems = safe.filter((_, i) => i !== sysIndex);

  const hasUser = withoutSystems.some(m => m.role === "user");
  const ensuredUserTail = hasUser
    ? withoutSystems
    : [...withoutSystems, { role: "user", content: userFallback } as AIMessage];

  const system = existingSystem || {
    role: "system",
    content: (systemPrompt || DEFAULT_SYSTEM_PROMPT),
  } as AIMessage;

  return [system, ...ensuredUserTail];
};

/** OpenAI text response via proxy */
export const getOpenAITextResponse = async (
  messages: AIMessage[],
  options?: AIRequestOptions,
): Promise<AIResponse> => {
  if (__DEV__) {
    if (__DEV__) console.log('[chat-service] getOpenAITextResponse called, normalizing messages...');
  }
  const msgs = normalizeMessages(messages, options?.systemPrompt);
  if (__DEV__) {
    if (__DEV__) console.log('[chat-service] Calling proxyChat with provider: openai, model:', options?.model || "gpt-4o-mini");
  }
  const data = await proxyChat({
    provider: "openai",
    messages: msgs as any,
    temperature: options?.temperature ?? 0.2,
    max_tokens: options?.maxTokens ?? 600,
    model: options?.model || "gpt-4o-mini",
  });
  if (__DEV__) {
    if (__DEV__) console.log('[chat-service] proxyChat returned data');
  }
  const content: string = extractContent(data);
  const usage = data?.usage || { promptTokens: 0, completionTokens: 0, totalTokens: 0 };
  return { content, usage };
};

/** Convenience: one-shot chat */
export const getOpenAIChatResponse = async (prompt: string): Promise<AIResponse> => {
  return await getOpenAITextResponse([{ role: "user", content: prompt }]);
};

/**
 * ProjectAdulting Coach helper: messages-based with gateway routing
 */
export const getCoachAIResponse = async (
  messages: AIMessage[],
  options?: { model?: string; temperature?: number; maxTokens?: number; systemPrompt?: string }
): Promise<AIResponse> => {
  if (__DEV__) {
    if (__DEV__) console.log('[chat-service] getCoachAIResponse called with options:', options);
  }
  const model = options?.model || "gpt-4o-mini";
  const temperature = options?.temperature ?? 0.2;
  const maxTokens = options?.maxTokens ?? 600;
  const msgs = normalizeMessages(messages, options?.systemPrompt);
  
  if (__DEV__) {
    if (__DEV__) console.log('[chat-service] Normalized to', msgs.length, 'messages, calling getOpenAITextResponse...');
  }
  
  return await getOpenAITextResponse(msgs, { model, temperature, maxTokens, systemPrompt: options?.systemPrompt });
};
