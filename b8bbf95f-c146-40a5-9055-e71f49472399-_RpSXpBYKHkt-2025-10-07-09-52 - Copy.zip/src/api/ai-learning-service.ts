import { getOpenAIChatResponse } from './chat-service';
import { LifeSkill, UserProfile, SkillProgress } from '../types/app';
import { AdultingTip, UserProgress, TipCategory } from '../types/adulting';

export interface LearningAnalysis {
  strengths: string[];
  weaknesses: string[];
  recommendedFocusAreas: string[];
  difficultyAdjustment: 'easier' | 'maintain' | 'harder';
  learningVelocity: 'slow' | 'normal' | 'fast';
  motivationalMessage: string;
  nextBestSkills: string[];
}

export interface PersonalizedRecommendation {
  skillId: string;
  reason: string;
  confidence: number;
  estimatedDifficulty: 'starter' | 'building' | 'advanced';
  prerequisites?: string[];
}

export interface LearningInsight {
  type: 'strength' | 'improvement' | 'milestone' | 'suggestion';
  title: string;
  description: string;
  actionable: boolean;
  relatedSkills?: string[];
}

export class AILearningService {
  private static instance: AILearningService;

  static getInstance(): AILearningService {
    if (!AILearningService.instance) {
      AILearningService.instance = new AILearningService();
    }
    return AILearningService.instance;
  }

  /**
   * Analyze user's learning progress and generate personalized insights
   */
  async analyzeLearningProgress(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    completedSkills: LifeSkill[],
    adultingProgress: UserProgress
  ): Promise<LearningAnalysis> {
    const prompt = this.buildAnalysisPrompt(userProfile, skillProgress, completedSkills, adultingProgress);
    
    try {
      const response = await getOpenAIChatResponse(prompt);
      return this.parseAnalysisResponse(response.content);
    } catch (error) {
      if (__DEV__) console.error('AI Learning Analysis Error:', error);
      return this.getFallbackAnalysis(userProfile, completedSkills);
    }
  }

  /**
   * Generate personalized skill recommendations using AI
   */
  async getPersonalizedRecommendations(
    userProfile: UserProfile,
    availableSkills: LifeSkill[],
    skillProgress: Record<string, SkillProgress>,
    recentActivity: any[]
  ): Promise<PersonalizedRecommendation[]> {
    const prompt = this.buildRecommendationPrompt(userProfile, availableSkills, skillProgress, recentActivity);
    
    try {
      const response = await getOpenAIChatResponse(prompt);
      return this.parseRecommendationResponse(response.content, availableSkills);
    } catch (error) {
      if (__DEV__) console.error('AI Recommendation Error:', error);
      return this.getFallbackRecommendations(userProfile, availableSkills);
    }
  }

  /**
   * Generate learning insights and coaching tips
   */
  async generateLearningInsights(
    userProfile: UserProfile,
    recentProgress: any[],
    strugglingAreas: string[]
  ): Promise<LearningInsight[]> {
    const prompt = this.buildInsightsPrompt(userProfile, recentProgress, strugglingAreas);
    
    try {
      const response = await getOpenAIChatResponse(prompt);
      return this.parseInsightsResponse(response.content);
    } catch (error) {
      if (__DEV__) console.error('AI Insights Error:', error);
      return this.getFallbackInsights(userProfile);
    }
  }

  /**
   * Determine optimal difficulty for next skills
   */
  async adaptDifficulty(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    performanceMetrics: any
  ): Promise<'starter' | 'building' | 'advanced'> {
    const completionRate = this.calculateCompletionRate(skillProgress);
    const averageTimeSpent = this.calculateAverageTimeSpent(skillProgress);
    const strugglingCount = this.calculateStrugglingSkills(skillProgress);

    // AI-driven difficulty analysis
    const prompt = `
Analyze this user's learning performance and recommend optimal difficulty level for their next skills:

User Profile:
- Age: ${userProfile.age}
- Time Commitment: ${userProfile.preferences.timeCommitment}
- Learning Style: ${userProfile.preferences.learningStyle}
- Focus Areas: ${userProfile.preferences.focusAreas.join(', ')}

Performance Metrics:
- Skill Completion Rate: ${completionRate}%
- Average Time per Skill: ${averageTimeSpent} minutes
- Skills with Struggles: ${strugglingCount}
- Total XP: ${userProfile.totalXP}
- Current Level: ${Math.floor(userProfile.totalXP / 300) + 1}

Based on this data, recommend ONE difficulty level: "starter", "building", or "advanced"

Consider:
- If completion rate < 60% → recommend "starter"
- If completion rate 60-85% and low struggle → recommend "building" 
- If completion rate > 85% and minimal struggles → recommend "advanced"
- Factor in time commitment and learning style preferences

Respond with ONLY the difficulty level word: starter, building, or advanced`;

    try {
      const response = await getOpenAIChatResponse(prompt);
      const difficulty = response.content.toLowerCase().trim();
      if (['starter', 'building', 'advanced'].includes(difficulty)) {
        return difficulty as 'starter' | 'building' | 'advanced';
      }
    } catch (error) {
      if (__DEV__) console.error('AI Difficulty Adaptation Error:', error);
    }

    // Fallback logic
    if (completionRate < 60) return 'starter';
    if (completionRate > 85 && strugglingCount < 2) return 'advanced';
    return 'building';
  }

  private buildAnalysisPrompt(
    userProfile: UserProfile,
    skillProgress: Record<string, SkillProgress>,
    completedSkills: LifeSkill[],
    adultingProgress: UserProgress
  ): string {
    const completionRate = this.calculateCompletionRate(skillProgress);
    const focusAreas = userProfile.preferences.focusAreas.join(', ');
    const completedCategories = this.getCategoryCounts(completedSkills);

    return `
Analyze this young adult's learning progress and provide personalized insights:

USER PROFILE:
- Age: ${userProfile.age}
- Learning Style: ${userProfile.preferences.learningStyle}
- Time Commitment: ${userProfile.preferences.timeCommitment}
- Focus Areas: ${focusAreas}
- Current Streak: ${userProfile.streak} days
- Total XP: ${userProfile.totalXP}

PROGRESS DATA:
- Skills Completed: ${completedSkills.length}
- Completion Rate: ${completionRate}%
- Completed by Category: ${JSON.stringify(completedCategories)}
- Active Todo Items: ${adultingProgress.todoItems.filter(t => !t.completed).length}
- Goals Set: ${adultingProgress.goals.length}

Please analyze this data and respond in this EXACT JSON format:
{
  "strengths": ["strength1", "strength2"],
  "weaknesses": ["weakness1", "weakness2"],
  "recommendedFocusAreas": ["area1", "area2"],
  "difficultyAdjustment": "maintain",
  "learningVelocity": "normal",
  "motivationalMessage": "personalized message",
  "nextBestSkills": ["skillId1", "skillId2", "skillId3"]
}

Base analysis on:
- Learning patterns and consistency
- Category performance vs focus areas
- Difficulty progression appropriateness
- Engagement indicators (streak, todo completion)

Keep motivational message encouraging and specific to their progress.`;
  }

  private buildRecommendationPrompt(
    userProfile: UserProfile,
    availableSkills: LifeSkill[],
    skillProgress: Record<string, SkillProgress>,
    recentActivity: any[]
  ): string {
    const skillSummary = availableSkills.slice(0, 10).map(skill => 
      `${skill.id}: ${skill.title} (${skill.category}, ${skill.difficulty})`
    ).join('\n');

    return `
Generate personalized skill recommendations for this user:

USER CONTEXT:
- Age: ${userProfile.age}
- Focus Areas: ${userProfile.preferences.focusAreas.join(', ')}
- Learning Style: ${userProfile.preferences.learningStyle}
- Time Commitment: ${userProfile.preferences.timeCommitment}
- Current Level: ${Math.floor(userProfile.totalXP / 300) + 1}

AVAILABLE SKILLS (sample):
${skillSummary}

RECENT ACTIVITY:
- Completed Skills: ${userProfile.completedSkills.length}
- Current Streak: ${userProfile.streak} days

Recommend 3-5 skills that would be most beneficial for this user right now.

Respond in this EXACT JSON format:
{
  "recommendations": [
    {
      "skillId": "skill-id",
      "reason": "why this skill is recommended",
      "confidence": 0.85,
      "estimatedDifficulty": "building"
    }
  ]
}

Consider:
- User's stated focus areas and current skill gaps
- Logical skill progression and prerequisites
- Time commitment and learning style preferences
- Skills that complement their completed work
- Practical value for their age group

Confidence should be 0.1-1.0 based on how well the skill matches their profile.`;
  }

  private buildInsightsPrompt(
    userProfile: UserProfile,
    recentProgress: any[],
    strugglingAreas: string[]
  ): string {
    return `
Generate 3-4 personalized learning insights for this user:

USER PROFILE:
- Age: ${userProfile.age}
- Streak: ${userProfile.streak} days
- Focus Areas: ${userProfile.preferences.focusAreas.join(', ')}
- Total XP: ${userProfile.totalXP}

STRUGGLING AREAS: ${strugglingAreas.join(', ') || 'None identified'}

Create insights that help them improve their learning journey.

Respond in this EXACT JSON format:
{
  "insights": [
    {
      "type": "strength",
      "title": "Insight Title",
      "description": "Detailed description",
      "actionable": true,
      "relatedSkills": ["skill1", "skill2"]
    }
  ]
}

Types: "strength", "improvement", "milestone", "suggestion"
Make insights specific, encouraging, and actionable.`;
  }

  private parseAnalysisResponse(content: string): LearningAnalysis {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          strengths: parsed.strengths || [],
          weaknesses: parsed.weaknesses || [],
          recommendedFocusAreas: parsed.recommendedFocusAreas || [],
          difficultyAdjustment: parsed.difficultyAdjustment || 'maintain',
          learningVelocity: parsed.learningVelocity || 'normal',
          motivationalMessage: parsed.motivationalMessage || 'Keep up the great work!',
          nextBestSkills: parsed.nextBestSkills || []
        };
      }
    } catch (error) {
      if (__DEV__) console.error('Failed to parse analysis response:', error);
    }

    return this.getFallbackAnalysis({} as UserProfile, []);
  }

  private parseRecommendationResponse(content: string, availableSkills: LifeSkill[]): PersonalizedRecommendation[] {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return parsed.recommendations || [];
      }
    } catch (error) {
      if (__DEV__) console.error('Failed to parse recommendation response:', error);
    }

    return this.getFallbackRecommendations({} as UserProfile, availableSkills);
  }

  private parseInsightsResponse(content: string): LearningInsight[] {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return parsed.insights || [];
      }
    } catch (error) {
      if (__DEV__) console.error('Failed to parse insights response:', error);
    }

    return this.getFallbackInsights({} as UserProfile);
  }

  private calculateCompletionRate(skillProgress: Record<string, SkillProgress>): number {
    const progressEntries = Object.values(skillProgress);
    if (progressEntries.length === 0) return 0;
    
    const completed = progressEntries.filter(p => p.completedAt).length;
    return Math.round((completed / progressEntries.length) * 100);
  }

  private calculateAverageTimeSpent(skillProgress: Record<string, SkillProgress>): number {
    const progressEntries = Object.values(skillProgress);
    if (progressEntries.length === 0) return 0;
    
    const totalTime = progressEntries.reduce((sum, p) => sum + (p.timeSpent || 0), 0);
    return Math.round(totalTime / progressEntries.length);
  }

  private calculateStrugglingSkills(skillProgress: Record<string, SkillProgress>): number {
    return Object.values(skillProgress).filter(p => 
      p.timeSpent && p.timeSpent > 60 && !p.completedAt
    ).length;
  }

  private getCategoryCounts(skills: LifeSkill[]): Record<string, number> {
    return skills.reduce((counts, skill) => {
      counts[skill.category] = (counts[skill.category] || 0) + 1;
      return counts;
    }, {} as Record<string, number>);
  }

  private getFallbackAnalysis(userProfile: UserProfile, completedSkills: LifeSkill[]): LearningAnalysis {
    return {
      strengths: ['Consistent learning', 'Goal-oriented approach'],
      weaknesses: ['Could benefit from more practice time'],
      recommendedFocusAreas: ['money_mastery', 'career_growth'],
      difficultyAdjustment: 'maintain',
      learningVelocity: 'normal',
      motivationalMessage: 'You\'re making steady progress! Keep building on your strengths.',
      nextBestSkills: []
    };
  }

  private getFallbackRecommendations(userProfile: UserProfile, availableSkills: LifeSkill[]): PersonalizedRecommendation[] {
    return availableSkills.slice(0, 3).map(skill => ({
      skillId: skill.id,
      reason: 'This skill aligns with your focus areas and current level',
      confidence: 0.7,
      estimatedDifficulty: (skill.difficulty === 'mastery' ? 'advanced' : skill.difficulty)
    }));
  }

  private getFallbackInsights(userProfile: UserProfile): LearningInsight[] {
    return [
      {
        type: 'strength',
        title: 'Learning Momentum',
        description: 'You\'re consistently engaging with new skills and making progress.',
        actionable: false
      },
      {
        type: 'suggestion',
        title: 'Practice Consistency',
        description: 'Try setting aside 15 minutes daily for skill practice to build momentum.',
        actionable: true
      }
    ];
  }
}

export const aiLearningService = AILearningService.getInstance();