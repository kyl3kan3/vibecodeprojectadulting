/**
 * URL Validation and Health Checking Service
 * Validates URLs, checks accessibility, and provides quality scoring
 */

export interface URLValidationResult {
  url: string;
  isValid: boolean;
  isAccessible: boolean;
  statusCode?: number;
  contentType?: string;
  title?: string;
  description?: string;
  score: number; // 0-100 quality score
  error?: string;
}

export interface URLHealthCheck {
  url: string;
  lastChecked: string;
  isHealthy: boolean;
  responseTime?: number;
  error?: string;
}

/**
 * Validate URL format and basic accessibility
 */
export async function validateURL(url: string): Promise<URLValidationResult> {
  const result: URLValidationResult = {
    url,
    isValid: false,
    isAccessible: false,
    score: 0
  };

  // Basic URL format validation
  try {
    const urlObj = new URL(url);
    result.isValid = ['http:', 'https:'].includes(urlObj.protocol);
    
    if (!result.isValid) {
      result.error = 'Invalid protocol - must be http or https';
      return result;
    }
  } catch (error) {
    result.error = 'Invalid URL format';
    return result;
  }

  // Check accessibility (simplified for React Native environment)
  try {
    // Track response time for scoring
    // const startTime = Date.now();
    
    // Use fetch with timeout for basic accessibility check
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
    
    const response = await fetch(url, {
      method: 'HEAD', // Use HEAD to avoid downloading content
      signal: controller.signal,
      headers: {
        'User-Agent': 'AdultingApp/1.0 (Resource Validator)'
      }
    });
    
    clearTimeout(timeoutId);
    
    result.isAccessible = response.ok;
    result.statusCode = response.status;
    result.contentType = response.headers.get('content-type') || undefined;
    
    // Calculate quality score based on various factors
    result.score = calculateURLScore(url, response);
    
    // If it's an HTML page, try to get title (optional enhancement)
    if (result.contentType?.includes('text/html') && response.ok) {
      try {
        // For now, we'll skip content parsing to keep it simple
        // In a full implementation, you might parse the HTML for title/description
      } catch {}
    }
    
  } catch (error) {
    result.error = error instanceof Error ? error.message : 'Network error';
    result.isAccessible = false;
  }

  return result;
}

/**
 * Calculate URL quality score based on various factors
 */
function calculateURLScore(url: string, response: Response): number {
  let score = 0;
  
  // Base score for accessibility
  if (response.ok) {
    score += 40;
  }
  
  // Domain reputation scoring
  const domain = new URL(url).hostname.toLowerCase();
  const trustedDomains = [
    'gov', 'edu', 'org', // TLD scoring
    'wikipedia.org', 'coursera.org', 'edx.org', 'khanacademy.org',
    'mint.com', 'nerdwallet.com', 'investopedia.com',
    'mayoclinic.org', 'webmd.com', 'healthline.com',
    'irs.gov', 'consumerfinance.gov', 'ftc.gov',
    'github.com', 'stackoverflow.com', 'mozilla.org'
  ];
  
  for (const trusted of trustedDomains) {
    if (domain.includes(trusted)) {
      score += 30;
      break;
    }
  }
  
  // HTTPS bonus
  if (url.startsWith('https://')) {
    score += 10;
  }
  
  // Content type scoring
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('text/html')) {
    score += 10; // Web pages are good for learning resources
  } else if (contentType.includes('application/pdf')) {
    score += 15; // PDFs often contain detailed guides
  }
  
  // Response time bonus (faster is better)
  // Note: We'd need to measure this in the calling function
  
  return Math.min(100, score);
}

/**
 * Batch validate multiple URLs
 */
export async function validateURLs(urls: string[]): Promise<URLValidationResult[]> {
  const results = await Promise.allSettled(
    urls.map(url => validateURL(url))
  );
  
  return results.map((result, index) => 
    result.status === 'fulfilled' 
      ? result.value 
      : {
          url: urls[index],
          isValid: false,
          isAccessible: false,
          score: 0,
          error: 'Validation failed'
        }
  );
}

/**
 * Check if a URL is likely to be educational/helpful
 */
export function isEducationalURL(url: string): boolean {
  const domain = new URL(url).hostname.toLowerCase();
  const path = new URL(url).pathname.toLowerCase();
  
  // Educational domains
  const educationalDomains = [
    '.edu', '.gov', '.org',
    'wikipedia.org', 'coursera.org', 'edx.org', 'khanacademy.org',
    'investopedia.com', 'nerdwallet.com', 'mint.com',
    'mayoclinic.org', 'webmd.com', 'healthline.com',
    'irs.gov', 'consumerfinance.gov', 'ftc.gov'
  ];
  
  for (const eduDomain of educationalDomains) {
    if (domain.includes(eduDomain)) {
      return true;
    }
  }
  
  // Educational path patterns
  const educationalPaths = [
    '/guide', '/tutorial', '/how-to', '/learn', '/education',
    '/help', '/support', '/docs', '/documentation', '/wiki'
  ];
  
  for (const eduPath of educationalPaths) {
    if (path.includes(eduPath)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Generate alternative URLs for a topic if the primary URL fails
 */
export function generateAlternativeURLs(topic: string, category: string): string[] {
  const searchTopic = encodeURIComponent(topic.toLowerCase().replace(/\s+/g, '+'));
  
  const alternatives: string[] = [];
  
  // Category-specific alternatives
  switch (category) {
    case 'money_mastery':
      alternatives.push(
        `https://www.investopedia.com/search?q=${searchTopic}`,
        `https://www.nerdwallet.com/blog/search/?q=${searchTopic}`,
        `https://www.mint.com/blog/search/?q=${searchTopic}`
      );
      break;
      
    case 'health_wellness':
      alternatives.push(
        `https://www.healthline.com/search?q1=${searchTopic}`,
        `https://www.mayoclinic.org/search/search-results?q=${searchTopic}`,
        `https://medlineplus.gov/search/?query=${searchTopic}`
      );
      break;
      
    case 'home_life':
      alternatives.push(
        `https://www.apartmenttherapy.com/search?q=${searchTopic}`,
        `https://www.bhg.com/search/?q=${searchTopic}`,
        `https://www.realsimple.com/search?q=${searchTopic}`
      );
      break;
      
    case 'life_admin':
      alternatives.push(
        `https://www.irs.gov/search?query=${searchTopic}`,
        `https://www.consumerfinance.gov/search/?q=${searchTopic}`,
        `https://www.ftc.gov/search?query=${searchTopic}`
      );
      break;
      
    case 'personal_growth':
      alternatives.push(
        `https://www.coursera.org/search?query=${searchTopic}`,
        `https://www.edx.org/search?q=${searchTopic}`,
        `https://www.khanacademy.org/search?page_search_query=${searchTopic}`
      );
      break;
      
    case 'tech_savvy':
      alternatives.push(
        `https://developer.mozilla.org/en-US/search?q=${searchTopic}`,
        `https://stackoverflow.com/search?q=${searchTopic}`,
        `https://www.codecademy.com/search?query=${searchTopic}`
      );
      break;
      
    default:
      alternatives.push(
        `https://en.wikipedia.org/wiki/Special:Search?search=${searchTopic}`,
        `https://www.wikihow.com/wikiHowTo?search=${searchTopic}`
      );
  }
  
  // Generic educational alternatives
  alternatives.push(
    `https://en.wikipedia.org/wiki/Special:Search?search=${searchTopic}`,
    `https://www.wikihow.com/wikiHowTo?search=${searchTopic}`,
    `https://www.youtube.com/results?search_query=${searchTopic}+tutorial`
  );
  
  return alternatives;
}