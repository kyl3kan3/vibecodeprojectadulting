/**
 * Cloud Storage Service
 * Handles secure file uploads/downloads through Vercel proxy with signed URLs
 * No Supabase credentials in the app - all secured server-side
 */

import * as FileSystem from 'expo-file-system';

const PROXY_URL = process.env.EXPO_PUBLIC_AI_PROXY_URL || '';
const BYPASS_TOKEN = process.env.EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS || '';

interface UploadUrlResponse {
  uploadUrl: string;
  headers: Record<string, string>;
  method: string;
  path: string;
}

interface DownloadUrlResponse {
  url: string;
  expiresAt: string;
}

export interface UploadOptions {
  bucket: string;
  path: string;
  contentType: string;
  upsert?: boolean;
}

export interface DownloadOptions {
  bucket: string;
  path: string;
  expiresIn?: number; // seconds, default 300 (5 minutes)
}

/**
 * Get a signed upload URL from the proxy
 */
async function getUploadUrl(options: UploadOptions): Promise<UploadUrlResponse> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-vercel-protection-bypass': BYPASS_TOKEN,
  };

  // Add auth token if available
  const token = (global as any).__AUTH_TOKEN__;
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${PROXY_URL}/api/storage/upload-url`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      bucket: options.bucket,
      path: options.path,
      upsert: options.upsert !== false, // Default to true
      contentType: options.contentType,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => response.statusText);
    throw new Error(`Failed to get upload URL: ${response.status} ${errorText}`);
  }

  return await response.json();
}

/**
 * Upload a file using the signed URL
 */
async function uploadFile(
  uploadUrl: string,
  method: string,
  headers: Record<string, string>,
  fileData: Blob | ArrayBuffer | Uint8Array
): Promise<void> {
  const response = await fetch(uploadUrl, {
    method,
    headers,
    body: fileData,
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => response.statusText);
    throw new Error(`File upload failed: ${response.status} ${errorText}`);
  }
}

/**
 * Get a signed download URL from the proxy
 */
async function getDownloadUrl(options: DownloadOptions): Promise<string> {
  const headers: Record<string, string> = {
    'x-vercel-protection-bypass': BYPASS_TOKEN,
  };

  // Add auth token if available
  const token = (global as any).__AUTH_TOKEN__;
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const params = new URLSearchParams({
    bucket: options.bucket,
    path: options.path,
    expiresIn: (options.expiresIn || 300).toString(),
  });

  const response = await fetch(`${PROXY_URL}/api/storage/download-url?${params}`, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => response.statusText);
    throw new Error(`Failed to get download URL: ${response.status} ${errorText}`);
  }

  const data: DownloadUrlResponse = await response.json();
  return data.url;
}

/**
 * Upload a file from local URI (React Native)
 * Handles reading the file and converting to proper format
 */
export async function uploadFromUri(
  localUri: string,
  options: UploadOptions
): Promise<{ success: boolean; path: string; error?: string }> {
  try {
    if (__DEV__) console.log('[CloudStorage] Starting upload...', { path: options.path });

    // Step 1: Get signed upload URL from proxy
    const { uploadUrl, headers, method, path } = await getUploadUrl(options);
    if (__DEV__) console.log('[CloudStorage] Got signed URL');

    // Step 2: Read file as base64
    const fileData = await FileSystem.readAsStringAsync(localUri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    // Step 3: Convert base64 to binary
    // For fetch API, we can use base64 directly by creating a blob
    const byteCharacters = atob(fileData);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: options.contentType });

    // Step 4: Upload to signed URL
    await uploadFile(uploadUrl, method, headers, blob);

    if (__DEV__) console.log('[CloudStorage] ✅ Upload successful');
    return { success: true, path };
  } catch (error: any) {
    if (__DEV__) console.error('[CloudStorage] ❌ Upload failed:', error.message);
    return { success: false, path: options.path, error: error.message };
  }
}

/**
 * Upload a blob directly (useful for generated images, canvas, etc.)
 */
export async function uploadBlob(
  blob: Blob,
  options: UploadOptions
): Promise<{ success: boolean; path: string; error?: string }> {
  try {
    if (__DEV__) console.log('[CloudStorage] Starting blob upload...', { path: options.path });

    // Step 1: Get signed upload URL from proxy
    const { uploadUrl, headers, method, path } = await getUploadUrl(options);
    if (__DEV__) console.log('[CloudStorage] Got signed URL');

    // Step 2: Upload blob directly
    await uploadFile(uploadUrl, method, headers, blob);

    if (__DEV__) console.log('[CloudStorage] ✅ Blob upload successful');
    return { success: true, path };
  } catch (error: any) {
    if (__DEV__) console.error('[CloudStorage] ❌ Blob upload failed:', error.message);
    return { success: false, path: options.path, error: error.message };
  }
}

/**
 * Get a temporary download URL for a file
 * Use this URL in <Image source={{ uri: url }} /> or for downloads
 */
export async function getFileUrl(
  bucket: string,
  path: string,
  expiresIn: number = 300
): Promise<string | null> {
  try {
    if (__DEV__) console.log('[CloudStorage] Getting download URL...', { bucket, path });

    const url = await getDownloadUrl({ bucket, path, expiresIn });

    if (__DEV__) console.log('[CloudStorage] ✅ Got download URL');
    return url;
  } catch (error: any) {
    if (__DEV__) console.error('[CloudStorage] ❌ Failed to get download URL:', error.message);
    return null;
  }
}

/**
 * Delete a file from storage
 */
export async function deleteFile(
  bucket: string,
  path: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'x-vercel-protection-bypass': BYPASS_TOKEN,
    };

    // Add auth token if available
    const token = (global as any).__AUTH_TOKEN__;
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${PROXY_URL}/api/storage/delete`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ bucket, path }),
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      throw new Error(`Delete failed: ${response.status} ${errorText}`);
    }

    if (__DEV__) console.log('[CloudStorage] ✅ File deleted');
    return { success: true };
  } catch (error: any) {
    if (__DEV__) console.error('[CloudStorage] ❌ Delete failed:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * List files in a storage path
 */
export async function listFiles(
  bucket: string,
  path: string,
  options?: {
    limit?: number;
    offset?: number;
    sortBy?: { column: string; order: 'asc' | 'desc' };
  }
): Promise<{ success: boolean; files?: any[]; error?: string }> {
  try {
    const headers: Record<string, string> = {
      'x-vercel-protection-bypass': BYPASS_TOKEN,
    };

    // Add auth token if available
    const token = (global as any).__AUTH_TOKEN__;
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const params = new URLSearchParams({
      bucket,
      path,
      ...(options?.limit && { limit: options.limit.toString() }),
      ...(options?.offset && { offset: options.offset.toString() }),
      ...(options?.sortBy && {
        sortBy: JSON.stringify(options.sortBy),
      }),
    });

    const response = await fetch(`${PROXY_URL}/api/storage/list?${params}`, {
      method: 'GET',
      headers,
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      throw new Error(`List failed: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return { success: true, files: data.files };
  } catch (error: any) {
    if (__DEV__) console.error('[CloudStorage] ❌ List failed:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Helper: Generate a unique file path for user content
 */
export function generateUserFilePath(
  userId: string,
  category: 'photos' | 'documents' | 'avatars' | 'achievements',
  fileExtension: string
): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 9);
  return `users/${userId}/${category}/${timestamp}-${random}.${fileExtension}`;
}

/**
 * Helper: Get file extension from content type
 */
export function getExtensionFromContentType(contentType: string): string {
  const map: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'image/webp': 'webp',
    'image/svg+xml': 'svg',
    'application/pdf': 'pdf',
    'text/plain': 'txt',
    'application/json': 'json',
  };
  return map[contentType] || 'bin';
}

/**
 * Helper: Get content type from file extension
 */
export function getContentTypeFromExtension(extension: string): string {
  const ext = extension.toLowerCase().replace('.', '');
  const map: Record<string, string> = {
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    gif: 'image/gif',
    webp: 'image/webp',
    svg: 'image/svg+xml',
    pdf: 'application/pdf',
    txt: 'text/plain',
    json: 'application/json',
  };
  return map[ext] || 'application/octet-stream';
}

// Export convenience functions
export default {
  uploadFromUri,
  uploadBlob,
  getFileUrl,
  deleteFile,
  listFiles,
  generateUserFilePath,
  getExtensionFromContentType,
  getContentTypeFromExtension,
};
