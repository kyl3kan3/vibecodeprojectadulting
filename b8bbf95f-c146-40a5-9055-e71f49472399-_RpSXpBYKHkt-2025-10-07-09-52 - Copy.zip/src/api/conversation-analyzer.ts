import { ChatConversation, GeneratedModule, dynamicModuleGenerator } from './dynamic-module-generator';
import { UserProfile, LifeSkill } from '../types/app';

export interface ConversationSession {
  id: string;
  messages: Array<{
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
    actionItems?: string[];
  }>;
  startTime: Date;
  endTime?: Date;
  totalMessages: number;
  userEngagement: 'low' | 'medium' | 'high';
  topicsDiscussed: string[];
}

export interface ModuleSuggestion {
  module: GeneratedModule;
  reasoning: string;
  confidence: number;
  urgency: 'immediate' | 'soon' | 'later';
  userPrompted: boolean;
  processed: boolean;
}

export class ConversationAnalyzer {
  private static instance: ConversationAnalyzer;
  private conversationSessions: Map<string, ConversationSession> = new Map();
  private pendingSuggestions: ModuleSuggestion[] = [];

  static getInstance(): ConversationAnalyzer {
    if (!ConversationAnalyzer.instance) {
      ConversationAnalyzer.instance = new ConversationAnalyzer();
    }
    return ConversationAnalyzer.instance;
  }

  /**
   * Start tracking a new conversation session
   */
  startConversationSession(sessionId: string): void {
    const session: ConversationSession = {
      id: sessionId,
      messages: [],
      startTime: new Date(),
      totalMessages: 0,
      userEngagement: 'low',
      topicsDiscussed: []
    };
    
    this.conversationSessions.set(sessionId, session);
  }

  /**
   * Add a message to the current conversation session
   */
  addMessageToSession(
    sessionId: string,
    message: {
      id: string;
      role: 'user' | 'assistant';
      content: string;
      timestamp: Date;
      actionItems?: string[];
    }
  ): void {
    const session = this.conversationSessions.get(sessionId);
    if (!session) return;

    session.messages.push(message);
    session.totalMessages = session.messages.length;
    
    // Update engagement level based on conversation length and user responses
    if (session.totalMessages >= 10) {
      session.userEngagement = 'high';
    } else if (session.totalMessages >= 6) {
      session.userEngagement = 'medium';
    }

    // Extract topics from user messages
    if (message.role === 'user') {
      session.topicsDiscussed = this.extractTopicsFromMessage(message.content, session.topicsDiscussed);
    }
  }

  /**
   * End a conversation session and analyze for module opportunities
   */
  async endConversationSession(
    sessionId: string,
    userProfile: UserProfile,
    existingSkills: LifeSkill[]
  ): Promise<ModuleSuggestion[]> {
    const session = this.conversationSessions.get(sessionId);
    if (!session || session.messages.length < 4) {
      return [];
    }

    session.endTime = new Date();

    // Convert to ChatConversation format for analysis
    const conversation: ChatConversation = {
      messages: session.messages.map(msg => ({
        role: msg.role,
        content: msg.content,
        timestamp: msg.timestamp.toISOString()
      })),
      sessionId: sessionId,
      startTime: session.startTime.toISOString(),
      endTime: session.endTime.toISOString()
    };

    try {
      // Generate modules based on conversation
      const generatedModules = await dynamicModuleGenerator.processConversationForModules(
        conversation,
        userProfile,
        existingSkills
      );

      // Create suggestions from generated modules
      const suggestions = generatedModules.map(module => this.createModuleSuggestion(
        module,
        conversation,
        session
      ));

      // Add to pending suggestions
      this.pendingSuggestions.push(...suggestions);

      return suggestions;
    } catch (error) {
      if (__DEV__) console.error('Error analyzing conversation for modules:', error);
      return [];
    }
  }

  /**
   * Get pending module suggestions for user
   */
  getPendingSuggestions(): ModuleSuggestion[] {
    return this.pendingSuggestions.filter(suggestion => !suggestion.userPrompted);
  }

  /**
   * Mark a suggestion as prompted to user
   */
  markSuggestionPrompted(moduleId: string): void {
    const suggestion = this.pendingSuggestions.find(s => s.module.id === moduleId);
    if (suggestion) {
      suggestion.userPrompted = true;
    }
  }

  /**
   * Remove a suggestion (user declined or accepted)
   */
  removeSuggestion(moduleId: string): void {
    this.pendingSuggestions = this.pendingSuggestions.filter(s => s.module.id !== moduleId);
  }

  /**
   * Check if a conversation warrants immediate module generation
   */
  shouldGenerateModuleImmediately(sessionId: string): boolean {
    const session = this.conversationSessions.get(sessionId);
    if (!session) return false;

    // Generate immediately if:
    // - High engagement conversation (10+ messages)
    // - User asked multiple related questions
    // - User expressed frustration or confusion
    const userMessages = session.messages.filter(m => m.role === 'user');
    const hasRepeatedQuestions = this.hasRepeatedQuestions(userMessages);
    const hasConfusionIndicators = this.hasConfusionIndicators(userMessages);

    return (
      session.userEngagement === 'high' ||
      hasRepeatedQuestions ||
      hasConfusionIndicators
    );
  }

  /**
   * Get conversation insights for debugging/analysis
   */
  getConversationInsights(sessionId: string): {
    messageCount: number;
    userEngagement: string;
    topicsDiscussed: string[];
    duration: number;
    keyUserQuestions: string[];
  } | null {
    const session = this.conversationSessions.get(sessionId);
    if (!session) return null;

    const duration = session.endTime 
      ? session.endTime.getTime() - session.startTime.getTime()
      : Date.now() - session.startTime.getTime();

    const userMessages = session.messages.filter(m => m.role === 'user');
    const keyQuestions = userMessages
      .filter(msg => msg.content.includes('?'))
      .slice(0, 5)
      .map(msg => msg.content);

    return {
      messageCount: session.totalMessages,
      userEngagement: session.userEngagement,
      topicsDiscussed: session.topicsDiscussed,
      duration: Math.round(duration / 1000 / 60), // minutes
      keyUserQuestions: keyQuestions
    };
  }

  /**
   * Clean up old conversation sessions
   */
  cleanupOldSessions(): void {
    const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
    
    for (const [sessionId, session] of this.conversationSessions.entries()) {
      if (session.startTime < threeDaysAgo) {
        this.conversationSessions.delete(sessionId);
      }
    }

    // Clean up old suggestions too
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    this.pendingSuggestions = this.pendingSuggestions.filter(
      suggestion => new Date(suggestion.module.createdAt) > oneDayAgo
    );
  }

  private extractTopicsFromMessage(content: string, existingTopics: string[]): string[] {
    const topics = [...existingTopics];
    
    // Simple keyword extraction (could be enhanced with NLP)
    const topicKeywords = [
      'budget', 'money', 'finance', 'savings', 'debt', 'credit',
      'job', 'career', 'interview', 'resume', 'networking',
      'cooking', 'food', 'meal', 'recipe',
      'health', 'insurance', 'doctor', 'medical',
      'rent', 'apartment', 'housing', 'landlord',
      'tax', 'taxes', 'filing', 'deduction',
      'relationship', 'dating', 'friends', 'family'
    ];

    const contentLower = content.toLowerCase();
    topicKeywords.forEach(keyword => {
      if (contentLower.includes(keyword) && !topics.includes(keyword)) {
        topics.push(keyword);
      }
    });

    return topics;
  }

  private createModuleSuggestion(
    module: GeneratedModule,
    conversation: ChatConversation,
    session: ConversationSession
  ): ModuleSuggestion {
    // Calculate confidence based on conversation quality and user engagement
    let confidence = 0.7;
    
    if (session.userEngagement === 'high') confidence += 0.2;
    if (session.totalMessages >= 8) confidence += 0.1;
    if (module.generatedFrom.userQuestions.length >= 3) confidence += 0.1;

    // Determine urgency based on user behavior
    let urgency: 'immediate' | 'soon' | 'later' = 'later';
    if (session.userEngagement === 'high' && session.totalMessages >= 10) {
      urgency = 'immediate';
    } else if (session.totalMessages >= 6) {
      urgency = 'soon';
    }

    return {
      module,
      reasoning: `Based on your ${session.totalMessages}-message conversation about ${session.topicsDiscussed.join(', ')}, you seem interested in learning more about ${module.title}.`,
      confidence: Math.min(confidence, 1.0),
      urgency,
      userPrompted: false,
      processed: false
    };
  }

  private hasRepeatedQuestions(userMessages: any[]): boolean {
    const questions = userMessages
      .filter(msg => msg.content.includes('?'))
      .map(msg => msg.content.toLowerCase());
    
    // Simple check for similar questions
    for (let i = 0; i < questions.length; i++) {
      for (let j = i + 1; j < questions.length; j++) {
        const similarity = this.calculateSimilarity(questions[i], questions[j]);
        if (similarity > 0.6) return true;
      }
    }
    
    return false;
  }

  private hasConfusionIndicators(userMessages: any[]): boolean {
    const confusionWords = ['confused', 'don\'t understand', 'not sure', 'help', 'stuck', 'frustrated'];
    
    return userMessages.some(msg => 
      confusionWords.some(word => msg.content.toLowerCase().includes(word))
    );
  }

  private calculateSimilarity(str1: string, str2: string): number {
    const words1 = str1.split(' ');
    const words2 = str2.split(' ');
    const commonWords = words1.filter(word => words2.includes(word));
    
    return commonWords.length / Math.max(words1.length, words2.length);
  }
}

export const conversationAnalyzer = ConversationAnalyzer.getInstance();