import { getOpenAIChatResponse } from './chat-service';
import { LifeSkill, UserProfile } from '../types/app';

export interface ChatConversation {
  messages: Array<{
    role: 'user' | 'assistant';
    content: string;
    timestamp: string;
  }>;
  sessionId: string;
  startTime: string;
  endTime?: string;
}

export interface LearningGap {
  topic: string;
  category: string;
  urgency: 'low' | 'medium' | 'high';
  complexity: 'starter' | 'building' | 'advanced';
  confidence: number;
  userQuestions: string[];
  suggestedActions: string[];
}

export interface GeneratedModule {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: 'starter' | 'building' | 'advanced';
  estimatedTime: number;
  xpReward: number;
  tags: string[];
  source: 'ai_generated';
  generatedFrom: {
    conversationId: string;
    userQuestions: string[];
    identifiedGaps: string[];
  };
  content: {
    overview: string;
    keyPoints: string[];
    stepByStep: Array<{
      id: string;
      title: string;
      description: string;
      timeEstimate: number;
    }>;
    tips: string[];
    commonMistakes: string[];
    resources: Array<{
      type: 'tool' | 'template' | 'guide' | 'external';
      title: string;
      description: string;
      url?: string;
    }>;
  };
  userApproved: boolean;
  createdAt: string;
}

export interface ModuleGenerationRequest {
  conversation: ChatConversation;
  userProfile: UserProfile;
  existingSkills: LifeSkill[];
  priority: 'immediate' | 'soon' | 'later';
}

export class DynamicModuleGenerator {
  private static instance: DynamicModuleGenerator;

  static getInstance(): DynamicModuleGenerator {
    if (!DynamicModuleGenerator.instance) {
      DynamicModuleGenerator.instance = new DynamicModuleGenerator();
    }
    return DynamicModuleGenerator.instance;
  }

  /**
   * Analyze a conversation to identify learning gaps and opportunities
   */
  async analyzeConversationForLearningGaps(
    conversation: ChatConversation,
    userProfile: UserProfile
  ): Promise<LearningGap[]> {
    const conversationText = this.extractConversationText(conversation);
    
    const prompt = `
Analyze this conversation between a user and an AI coach to identify specific learning gaps and module opportunities:

USER PROFILE:
- Age: ${userProfile.age}
- Focus Areas: ${userProfile.preferences.focusAreas.join(', ')}
- Learning Style: ${userProfile.preferences.learningStyle}
- Completed Skills: ${userProfile.completedSkills.length}

CONVERSATION:
${conversationText}

Identify 1-3 specific learning gaps or topics that could benefit from a dedicated learning module. Look for:
- Repeated questions or confusion
- Topics the user struggled with
- Specific skills they want to develop
- Areas where they need step-by-step guidance
- Practical applications they're interested in

Respond in this EXACT JSON format:
{
  "learningGaps": [
    {
      "topic": "Specific topic name",
      "category": "category_name",
      "urgency": "high",
      "complexity": "building", 
      "confidence": 0.85,
      "userQuestions": ["Question 1", "Question 2"],
      "suggestedActions": ["Action 1", "Action 2"]
    }
  ]
}

Categories: money_mastery, career_growth, home_life, health_wellness, relationships, personal_growth, tech_savvy, life_admin

Focus on actionable, specific topics that would genuinely help this user based on their conversation.`;

    try {
      const response = await getOpenAIChatResponse(prompt);
      return this.parseLearningGapsResponse(response.content);
    } catch (error) {
      if (__DEV__) console.error('Learning Gap Analysis Error:', error);
      return this.generateFallbackGaps(conversation, userProfile);
    }
  }

  /**
   * Generate a complete learning module based on identified gaps
   */
  async generateLearningModule(
    learningGap: LearningGap,
    userProfile: UserProfile,
    conversationContext: ChatConversation
  ): Promise<GeneratedModule> {
    const prompt = this.buildModuleGenerationPrompt(learningGap, userProfile, conversationContext);

    try {
      const response = await getOpenAIChatResponse(prompt);
      const moduleData = this.parseModuleResponse(response.content);
      return this.createModuleFromData(moduleData, learningGap, conversationContext);
    } catch (error) {
      if (__DEV__) console.error('Module Generation Error:', error);
      return this.createFallbackModule(learningGap, conversationContext);
    }
  }

  /**
   * Process a conversation and generate modules if gaps are found
   */
  async processConversationForModules(
    conversation: ChatConversation,
    userProfile: UserProfile,
    existingSkills: LifeSkill[]
  ): Promise<GeneratedModule[]> {
    // Only process conversations with substantial content
    if (conversation.messages.length < 4) return [];

    const learningGaps = await this.analyzeConversationForLearningGaps(conversation, userProfile);
    
    if (learningGaps.length === 0) return [];

    // Filter out gaps that are already covered by existing skills
    const novelGaps = this.filterNovelLearningGaps(learningGaps, existingSkills);
    
    if (novelGaps.length === 0) return [];

    // Generate modules for high-priority gaps
    const highPriorityGaps = novelGaps.filter(gap => 
      gap.urgency === 'high' || (gap.urgency === 'medium' && gap.confidence > 0.8)
    );

    const modules: GeneratedModule[] = [];
    
    for (const gap of highPriorityGaps.slice(0, 2)) { // Limit to 2 modules per conversation
      try {
        const module = await this.generateLearningModule(gap, userProfile, conversation);
        modules.push(module);
      } catch (error) {
        if (__DEV__) console.error(`Failed to generate module for gap: ${gap.topic}`, error);
      }
    }

    return modules;
  }

  /**
   * Create a module suggestion for user approval
   */
  createModuleSuggestion(
    module: GeneratedModule,
    conversation: ChatConversation
  ): {
    title: string;
    description: string;
    reasoning: string;
    previewSteps: string[];
  } {
    const userQuestions = conversation.messages
      .filter(m => m.role === 'user')
      .map(m => m.content)
      .slice(0, 3);

    return {
      title: module.title,
      description: module.description,
      reasoning: `Based on your questions about ${module.generatedFrom.identifiedGaps.join(' and ')}, I've created a personalized learning module to help you master this topic step-by-step.`,
      previewSteps: module.content.stepByStep.slice(0, 3).map(step => step.title)
    };
  }

  private extractConversationText(conversation: ChatConversation): string {
    return conversation.messages
      .map(msg => `${msg.role.toUpperCase()}: ${msg.content}`)
      .join('\n\n');
  }

  private buildModuleGenerationPrompt(
    learningGap: LearningGap,
    userProfile: UserProfile,
    conversation: ChatConversation
  ): string {
    const userQuestions = learningGap.userQuestions.slice(0, 3);
    
    return `
Create a comprehensive learning module based on this identified learning gap:

LEARNING GAP:
- Topic: ${learningGap.topic}
- Category: ${learningGap.category}
- Complexity: ${learningGap.complexity}
- User Questions: ${userQuestions.join('; ')}

USER PROFILE:
- Age: ${userProfile.age}
- Learning Style: ${userProfile.preferences.learningStyle}
- Time Commitment: ${userProfile.preferences.timeCommitment}
- Focus Areas: ${userProfile.preferences.focusAreas.join(', ')}

Create a practical, actionable learning module that directly addresses this user's specific needs and questions.

Respond in this EXACT JSON format:
{
  "title": "Module Title (40 chars max)",
  "description": "Brief description of what the user will learn",
  "estimatedTime": 30,
  "overview": "Comprehensive overview explaining why this skill matters",
  "keyPoints": [
    "Key point 1",
    "Key point 2",
    "Key point 3",
    "Key point 4"
  ],
  "steps": [
    {
      "title": "Step Title",
      "description": "Detailed description of what to do",
      "timeEstimate": 10
    }
  ],
  "tips": [
    "Practical tip 1",
    "Practical tip 2",
    "Practical tip 3"
  ],
  "commonMistakes": [
    "Common mistake to avoid",
    "Another mistake to watch for"
  ],
  "resources": [
    {
      "type": "tool",
      "title": "Resource Title",
      "description": "What this resource helps with"
    }
  ]
}

Requirements:
- 4-6 actionable steps that can be completed in ${userProfile.preferences.timeCommitment} sessions
- Practical, specific advice targeted to their age group (${userProfile.age})
- Steps should directly address their specific questions: ${userQuestions.join(', ')}
- Include real-world applications and examples
- Make it engaging for ${userProfile.preferences.learningStyle} learners`;
  }

  private parseLearningGapsResponse(content: string): LearningGap[] {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return parsed.learningGaps || [];
      }
    } catch (error) {
      if (__DEV__) console.error('Failed to parse learning gaps response:', error);
    }
    return [];
  }

  private parseModuleResponse(content: string): any {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (error) {
      if (__DEV__) console.error('Failed to parse module response:', error);
    }
    return null;
  }

  private createModuleFromData(
    moduleData: any,
    learningGap: LearningGap,
    conversation: ChatConversation
  ): GeneratedModule {
    const moduleId = `ai-generated-${Date.now()}`;
    
    return {
      id: moduleId,
      title: moduleData.title || learningGap.topic,
      description: moduleData.description || `Learn about ${learningGap.topic}`,
      category: learningGap.category as any,
      difficulty: learningGap.complexity,
      estimatedTime: moduleData.estimatedTime || 30,
      xpReward: this.calculateXPReward(learningGap.complexity, moduleData.estimatedTime || 30),
      tags: [learningGap.topic.toLowerCase(), 'ai-generated', 'personalized'],
      source: 'ai_generated',
      generatedFrom: {
        conversationId: conversation.sessionId,
        userQuestions: learningGap.userQuestions,
        identifiedGaps: [learningGap.topic]
      },
      content: {
        overview: moduleData.overview || `This module will help you understand ${learningGap.topic}.`,
        keyPoints: moduleData.keyPoints || [],
        stepByStep: (moduleData.steps || []).map((step: any, index: number) => ({
          id: `step-${index + 1}`,
          title: step.title,
          description: step.description,
          timeEstimate: step.timeEstimate || 5
        })),
        tips: moduleData.tips || [],
        commonMistakes: moduleData.commonMistakes || [],
        resources: moduleData.resources || []
      },
      userApproved: false,
      createdAt: new Date().toISOString()
    };
  }

  private calculateXPReward(difficulty: string, estimatedTime: number): number {
    const baseXP = estimatedTime * 2; // 2 XP per minute
    const difficultyMultiplier = {
      starter: 1.0,
      building: 1.5,
      advanced: 2.0
    };
    
    return Math.round(baseXP * (difficultyMultiplier[difficulty as keyof typeof difficultyMultiplier] || 1.0));
  }

  private filterNovelLearningGaps(gaps: LearningGap[], existingSkills: LifeSkill[]): LearningGap[] {
    return gaps.filter(gap => {
      // Check if this topic is already covered by existing skills
      const isDuplicate = existingSkills.some(skill => 
        skill.title.toLowerCase().includes(gap.topic.toLowerCase()) ||
        gap.topic.toLowerCase().includes(skill.title.toLowerCase()) ||
        skill.tags.some(tag => gap.topic.toLowerCase().includes(tag.toLowerCase()))
      );
      return !isDuplicate;
    });
  }

  private generateFallbackGaps(
    conversation: ChatConversation,
    userProfile: UserProfile
  ): LearningGap[] {
    const userQuestions = conversation.messages
      .filter(m => m.role === 'user')
      .map(m => m.content);

    return [{
      topic: 'Personal Development',
      category: 'personal_growth',
      urgency: 'medium',
      complexity: 'building',
      confidence: 0.6,
      userQuestions: userQuestions.slice(0, 2),
      suggestedActions: ['Set learning goals', 'Track progress']
    }];
  }

  private createFallbackModule(
    learningGap: LearningGap,
    conversation: ChatConversation
  ): GeneratedModule {
    return {
      id: `fallback-${Date.now()}`,
      title: `Mastering ${learningGap.topic}`,
      description: `A personalized guide to help you with ${learningGap.topic}`,
      category: learningGap.category as any,
      difficulty: learningGap.complexity,
      estimatedTime: 25,
      xpReward: 50,
      tags: ['ai-generated', 'personalized'],
      source: 'ai_generated',
      generatedFrom: {
        conversationId: conversation.sessionId,
        userQuestions: learningGap.userQuestions,
        identifiedGaps: [learningGap.topic]
      },
      content: {
        overview: `This module addresses your questions about ${learningGap.topic}.`,
        keyPoints: ['Understanding the basics', 'Practical applications', 'Common challenges'],
        stepByStep: [
          {
            id: 'step-1',
            title: 'Research and Learn',
            description: `Study the fundamentals of ${learningGap.topic}`,
            timeEstimate: 10
          },
          {
            id: 'step-2', 
            title: 'Practice',
            description: 'Apply what you\'ve learned in a real situation',
            timeEstimate: 15
          }
        ],
        tips: ['Start small and build confidence', 'Don\'t be afraid to ask for help'],
        commonMistakes: ['Trying to learn everything at once'],
        resources: []
      },
      userApproved: false,
      createdAt: new Date().toISOString()
    };
  }
}

export const dynamicModuleGenerator = DynamicModuleGenerator.getInstance();