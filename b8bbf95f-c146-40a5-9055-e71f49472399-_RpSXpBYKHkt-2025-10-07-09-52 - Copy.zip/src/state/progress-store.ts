/**
 * Progress Store  
 * Manages user progress, achievements, XP, and daily challenges
 * Extracted from unified-store.ts during Phase 1 migration
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { UserProgress, Goal, TodoItem } from '../types/adulting';
import type { Achievement, DailyChallenge, PersonalGoal } from '../types/app';
import type { LearningPath } from '../data/learning-paths';
import { learningPaths } from '../data/learning-paths';

interface ProgressState {
  // === STATE ===
  userProgress: UserProgress;
  achievements: Achievement[];
  totalXP: number;
  aiUsage: number;
  aiLastUsedAt: string | null;
  lastFreeChallengeAt: string | null;
  
  // Daily challenges
  dailyChallenges: DailyChallenge[];
  todaysChallenge: DailyChallenge | null;
  
  // Goals & Todos
  personalGoals: PersonalGoal[];
  todoItems: TodoItem[];
  goals: Goal[];
  
  // Learning paths
  activeLearningPaths: string[];
  completedLearningPaths: string[];
  
  // === ACTIONS ===
  // Progress actions
  updateUserProgress: (progress: Partial<UserProgress>) => void;
  addAchievement: (achievement: Achievement) => void;
  checkAndUnlockAchievements: () => void;
  updateTotalXP: (xp: number) => void;
  updateAIUsage: (usage: number) => void;
  setAILastUsedAt: (timestamp: string) => void;
  setLastFreeChallengeAt: (timestamp: string) => void;
  incrementAIUsage: () => void;
  resetAIUsageMonthlyIfNeeded: () => void;
  getAiRemaining: () => number;
  getAiCooldownRemaining: () => number;
  
  // Daily challenge actions
  setDailyChallenges: (challenges: DailyChallenge[]) => void;
  setTodaysChallenge: (challenge: DailyChallenge | null) => void;
  getTodaysChallenge: () => DailyChallenge | null;
  generateTodaysChallenge: () => void;
  
  // Goal & Todo actions
  addPersonalGoal: (goal: PersonalGoal) => void;
  updatePersonalGoal: (goalId: string, updates: Partial<PersonalGoal>) => void;
  deletePersonalGoal: (goalId: string) => void;
  addTodoItem: (item: Omit<TodoItem, 'id' | 'createdAt'>) => void;
  toggleTodoCompleted: (todoId: string) => void;
  deleteTodoItem: (todoId: string) => void;
  addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => void;
  toggleGoalCompleted: (goalId: string) => void;
  deleteGoal: (goalId: string) => void;
  updateGoal: (goalId: string, updates: Partial<Goal>) => void;
  
  // Learning path actions
  setActiveLearningPaths: (paths: string[]) => void;
  addCompletedLearningPath: (pathId: string) => void;
  getActiveLearningPaths: () => LearningPath[];
  getLearningPathProgress: (pathId: string) => { startedAt: string; completedSkills: string[] };
  startLearningPath: (pathId: string) => void;
  
  // Utility actions
  updateStreak: () => void;
  getUserLevel: () => number;
  importUserProgress: (data: Partial<UserProgress>) => void;
  updateLastVisit: () => void;
  resetUserData: () => void;
}

// Free tier AI limits - 3 messages per day with daily reset
const AI_DAILY_LIMIT = 3;
const AI_COOLDOWN_MINUTES = 0; // No cooldown within the day

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      // === INITIAL STATE ===
      userProgress: {
        totalXP: 0,
        totalTipsCompleted: 0,
        streak: 0,
        streakDays: 0,
        lastVisit: "",
        completedTips: [],
        bookmarkedTips: [],
        tipRatings: {},
        tipNotes: {},
        tipPhotos: {},
        todoItems: [],
        goals: [],
        achievements: [],
        preferences: {
          categories: [],
          difficulty: 'beginner',
          notifications: true,
          reminderTime: '09:00'
        }
      },
      achievements: [],
      totalXP: 0,
      aiUsage: 0,
      aiLastUsedAt: null,
      lastFreeChallengeAt: null,
      dailyChallenges: [],
      todaysChallenge: null,
      personalGoals: [],
      todoItems: [],
      goals: [],
      activeLearningPaths: [],
      completedLearningPaths: [],

      // === ACTIONS ===
      updateUserProgress: (progress: Partial<UserProgress>) => {
        set((state) => ({
          userProgress: { ...state.userProgress, ...progress }
        }));
      },

      addAchievement: (achievement: Achievement) => {
        set((state) => ({
          achievements: [...state.achievements, achievement],
          userProgress: {
            ...state.userProgress,
            achievements: [...state.userProgress.achievements, achievement] as any
          }
        }));
      },

      checkAndUnlockAchievements: () => {
        const state = get();
        
        // Import achievements list and lessons store
        const { achievements: allAchievements } = require('../types/achievements');
        const { useLessonsStore } = require('./lessons-store');
        const lessonsStore = useLessonsStore.getState();
        
        const completedCount = lessonsStore.completedSkills.length;
        const currentStreak = state.userProgress.streak || 0;
        
        // Check for skill completion achievements
        const skillAchievements = allAchievements.filter((a: Achievement) => a.type === 'tips_completed');
        
        for (const achievement of skillAchievements) {
          const alreadyUnlocked = state.achievements.some(a => a.id === achievement.id);
          if (!alreadyUnlocked && completedCount >= achievement.requirement) {
            if (__DEV__) console.log(`🏆 [Achievements] Unlocked: ${achievement.title}`);
            get().addAchievement({
              ...achievement,
              unlocked: true,
              unlockedAt: new Date().toISOString()
            });
          }
        }
        
        // Check for streak achievements
        const streakAchievements = allAchievements.filter((a: Achievement) => a.type === 'streak_days');
        
        for (const achievement of streakAchievements) {
          const alreadyUnlocked = state.achievements.some(a => a.id === achievement.id);
          if (!alreadyUnlocked && currentStreak >= achievement.requirement) {
            if (__DEV__) console.log(`🔥 [Achievements] Unlocked: ${achievement.title}`);
            get().addAchievement({
              ...achievement,
              unlocked: true,
              unlockedAt: new Date().toISOString()
            });
          }
        }
      },

      updateTotalXP: (xp: number) => {
        set({ totalXP: xp });
      },

      updateAIUsage: (usage: number) => {
        set({ aiUsage: usage });
      },

      setAILastUsedAt: (timestamp: string) => {
        set({ aiLastUsedAt: timestamp });
      },

      setLastFreeChallengeAt: (timestamp: string) => {
        set({ lastFreeChallengeAt: timestamp });
      },

      incrementAIUsage: () => {
        set((state) => ({
          aiUsage: state.aiUsage + 1,
          aiLastUsedAt: new Date().toISOString()
        }));
      },

      resetAIUsageMonthlyIfNeeded: () => {
        const state = get();
        if (!state.aiLastUsedAt) return;
        
        const lastUsed = new Date(state.aiLastUsedAt);
        const now = new Date();
        
        // Reset daily instead of monthly
        if (lastUsed.getDate() !== now.getDate() || 
            lastUsed.getMonth() !== now.getMonth() || 
            lastUsed.getFullYear() !== now.getFullYear()) {
          set({ aiUsage: 0 });
        }
      },

      getAiRemaining: () => {
        const state = get();
        return Math.max(0, AI_DAILY_LIMIT - state.aiUsage);
      },

      getAiCooldownRemaining: () => {
        const state = get();
        if (!state.aiLastUsedAt) return 0;
        
        const lastUsed = new Date(state.aiLastUsedAt).getTime();
        const now = Date.now();
        const cooldownMs = AI_COOLDOWN_MINUTES * 60 * 1000;
        const remaining = cooldownMs - (now - lastUsed);
        
        return Math.max(0, remaining);
      },

      setDailyChallenges: (challenges: DailyChallenge[]) => {
        set({ dailyChallenges: challenges });
      },

      setTodaysChallenge: (challenge: DailyChallenge | null) => {
        set({ todaysChallenge: challenge });
      },

      getTodaysChallenge: (): DailyChallenge | null => {
        return get().todaysChallenge;
      },

      generateTodaysChallenge: () => {
        const state = get();
        const today = new Date().toDateString();
        
        if (__DEV__) console.log('[ProgressStore] generateTodaysChallenge called:', {
          hasExistingChallenge: !!state.todaysChallenge,
          existingDate: state.todaysChallenge?.date,
          todayDate: today,
          matches: state.todaysChallenge?.date === today
        });
        
        // Check if already generated today
        if (state.todaysChallenge && state.todaysChallenge.date === today) {
          if (__DEV__) console.log('[ProgressStore] Challenge already exists for today, skipping generation');
          return;
        }
        
        // Generate a simple challenge (can be enhanced)
        const challenge: DailyChallenge = {
          id: `challenge-${Date.now()}`,
          date: today,
          title: 'Complete 3 tasks today',
          description: 'Stay productive by completing at least 3 tasks',
          category: 'general' as any,
          timeEstimate: 30,
          xpReward: 25,
          isCompleted: false
        };
        
        if (__DEV__) console.log('[ProgressStore] ✅ Generated new challenge:', challenge);
        set({ todaysChallenge: challenge });
      },

      addPersonalGoal: (goal: PersonalGoal) => {
        set((state) => ({
          personalGoals: [...state.personalGoals, goal]
        }));
      },

      updatePersonalGoal: (goalId: string, updates: Partial<PersonalGoal>) => {
        set((state) => ({
          personalGoals: state.personalGoals.map(goal =>
            goal.id === goalId ? { ...goal, ...updates } : goal
          )
        }));
      },

      deletePersonalGoal: (goalId: string) => {
        set((state) => ({
          personalGoals: state.personalGoals.filter(goal => goal.id !== goalId)
        }));
      },

      addTodoItem: (item: Omit<TodoItem, 'id' | 'createdAt'>) => {
        const newItem: TodoItem = {
          ...item,
          id: `todo-${Date.now()}`,
          createdAt: new Date().toISOString()
        };
        
        set((state) => ({
          todoItems: [...state.todoItems, newItem],
          userProgress: {
            ...state.userProgress,
            todoItems: [...state.userProgress.todoItems, newItem]
          }
        }));
      },

      toggleTodoCompleted: (todoId: string) => {
        set((state) => ({
          todoItems: state.todoItems.map(todo =>
            todo.id === todoId ? { ...todo, completed: !todo.completed } : todo
          ),
          userProgress: {
            ...state.userProgress,
            todoItems: state.userProgress.todoItems.map(todo =>
              todo.id === todoId ? { ...todo, completed: !todo.completed } : todo
            )
          }
        }));
      },

      deleteTodoItem: (todoId: string) => {
        set((state) => ({
          todoItems: state.todoItems.filter(todo => todo.id !== todoId),
          userProgress: {
            ...state.userProgress,
            todoItems: state.userProgress.todoItems.filter(todo => todo.id !== todoId)
          }
        }));
      },

      addGoal: (goal: Omit<Goal, 'id' | 'createdAt'>) => {
        const newGoal: Goal = {
          ...goal,
          id: `goal-${Date.now()}`,
          createdAt: new Date().toISOString()
        };
        
        set((state) => ({
          goals: [...state.goals, newGoal],
          userProgress: {
            ...state.userProgress,
            goals: [...state.userProgress.goals, newGoal]
          }
        }));
      },

      toggleGoalCompleted: (goalId: string) => {
        set((state) => ({
          goals: state.goals.map(goal =>
            goal.id === goalId ? { ...goal, completed: !goal.completed } : goal
          ),
          userProgress: {
            ...state.userProgress,
            goals: state.userProgress.goals.map(goal =>
              goal.id === goalId ? { ...goal, completed: !goal.completed } : goal
            )
          }
        }));
      },

      deleteGoal: (goalId: string) => {
        set((state) => ({
          goals: state.goals.filter(goal => goal.id !== goalId),
          userProgress: {
            ...state.userProgress,
            goals: state.userProgress.goals.filter(goal => goal.id !== goalId)
          }
        }));
      },

      updateGoal: (goalId: string, updates: Partial<Goal>) => {
        set((state) => ({
          goals: state.goals.map(goal =>
            goal.id === goalId ? { ...goal, ...updates } : goal
          ),
          userProgress: {
            ...state.userProgress,
            goals: state.userProgress.goals.map(goal =>
              goal.id === goalId ? { ...goal, ...updates } : goal
            )
          }
        }));
      },

      setActiveLearningPaths: (paths: string[]) => {
        set({ activeLearningPaths: paths });
      },

      addCompletedLearningPath: (pathId: string) => {
        set((state) => ({
          completedLearningPaths: [...state.completedLearningPaths, pathId]
        }));
      },

      getActiveLearningPaths: (): LearningPath[] => {
        const state = get();
        return learningPaths.filter(path => state.activeLearningPaths.includes(path.id));
      },

      getLearningPathProgress: (pathId: string) => {
        // Simplified - full implementation would check actual skill completion
        return {
          startedAt: new Date().toISOString(),
          completedSkills: []
        };
      },

      startLearningPath: (pathId: string) => {
        set((state) => ({
          activeLearningPaths: state.activeLearningPaths.includes(pathId)
            ? state.activeLearningPaths
            : [...state.activeLearningPaths, pathId]
        }));
      },

      updateStreak: () => {
        const state = get();
        const lastVisit = state.userProgress.lastVisit;
        const now = new Date();
        
        if (!lastVisit) {
          set((state) => ({
            userProgress: {
              ...state.userProgress,
              streak: 1,
              streakDays: 1,
              lastVisit: now.toISOString()
            }
          }));
          return;
        }
        
        const lastVisitDate = new Date(lastVisit);
        const daysDiff = Math.floor((now.getTime() - lastVisitDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDiff === 0) {
          // Same day, no change
          return;
        } else if (daysDiff === 1) {
          // Consecutive day, increment streak
          set((state) => ({
            userProgress: {
              ...state.userProgress,
              streak: state.userProgress.streak + 1,
              streakDays: state.userProgress.streakDays + 1,
              lastVisit: now.toISOString()
            }
          }));
        } else {
          // Streak broken, reset to 1
          set((state) => ({
            userProgress: {
              ...state.userProgress,
              streak: 1,
              streakDays: 1,
              lastVisit: now.toISOString()
            }
          }));
        }
      },

      getUserLevel: (): number => {
        const xp = get().totalXP;
        return Math.floor(xp / 1000) + 1; // Simple level calculation
      },

      importUserProgress: (data: Partial<UserProgress>) => {
        set((state) => ({
          userProgress: { ...state.userProgress, ...data }
        }));
      },

      updateLastVisit: () => {
        set((state) => ({
          userProgress: {
            ...state.userProgress,
            lastVisit: new Date().toISOString()
          }
        }));
      },

      resetUserData: () => {
        set({
          userProgress: {
            totalXP: 0,
            totalTipsCompleted: 0,
            streak: 0,
            streakDays: 0,
            lastVisit: "",
            completedTips: [],
            bookmarkedTips: [],
            tipRatings: {},
            tipNotes: {},
            tipPhotos: {},
            todoItems: [],
            goals: [],
            achievements: [],
            preferences: {
              categories: [],
              difficulty: 'beginner',
              notifications: true,
              reminderTime: '09:00'
            }
          },
          achievements: [],
          totalXP: 0,
          personalGoals: [],
          todoItems: [],
          goals: [],
          activeLearningPaths: [],
          completedLearningPaths: []
        });
      },
    }),
    {
      name: 'project-adulting-progress-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        userProgress: state.userProgress,
        achievements: state.achievements,
        totalXP: state.totalXP,
        personalGoals: state.personalGoals,
        todoItems: state.todoItems,
        goals: state.goals,
        activeLearningPaths: state.activeLearningPaths,
        completedLearningPaths: state.completedLearningPaths,
        aiUsage: state.aiUsage,
        aiLastUsedAt: state.aiLastUsedAt,
        todaysChallenge: state.todaysChallenge,
        dailyChallenges: state.dailyChallenges,
      }),
    }
  )
);

// Convenience selectors
export const useUserProgress = () => useProgressStore((state) => state.userProgress);
export const useAchievements = () => useProgressStore((state) => state.achievements);
export const useTotalXP = () => useProgressStore((state) => state.totalXP);
export const useTodaysChallenge = () => useProgressStore((state) => state.todaysChallenge);
export const usePersonalGoals = () => useProgressStore((state) => state.personalGoals);
export const useTodoItems = () => useProgressStore((state) => state.todoItems);
