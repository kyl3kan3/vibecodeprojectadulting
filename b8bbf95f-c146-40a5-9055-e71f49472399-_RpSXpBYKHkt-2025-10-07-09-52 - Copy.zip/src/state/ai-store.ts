/**
 * AI Store
 * Manages AI-powered features, learning analysis, insights, and recommendations
 * Extracted from unified-store.ts during Phase 1 migration
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  PersonalizedRecommendation,
  LearningAnalysis,
  LearningInsight
} from '../api/ai-learning-service';
import type { ModuleSuggestion } from '../api/conversation-analyzer';
import type { LearningPattern, PerformanceMetrics } from '../api/progress-analyzer';
import { progressAnalyzer } from '../api/progress-analyzer';
import { conversationAnalyzer } from '../api/conversation-analyzer';

interface AIState {
  // === STATE ===
  learningAnalysis: LearningAnalysis | null;
  learningInsights: LearningInsight[] | null;
  personalizedRecommendations: PersonalizedRecommendation[];
  conversationHistory: any[];
  moduleSuggestions: ModuleSuggestion[];
  conversationSessions: Record<string, any>;

  // === ACTIONS ===
  setLearningAnalysis: (analysis: LearningAnalysis | null) => void;
  updateAIInsights: (insights: LearningInsight[]) => void;
  getLearningPattern: () => LearningPattern | null;
  getPerformanceMetrics: () => PerformanceMetrics | null;
  getOptimalDifficulty: (category: string) => string;
  setPersonalizedRecommendations: (recommendations: PersonalizedRecommendation[]) => void;
  addConversationHistory: (conversation: any) => void;
  setModuleSuggestions: (suggestions: ModuleSuggestion[]) => void;
  startConversationTracking: () => string;
  addConversationMessage: (sessionId: string, message: any) => void;
  endConversationAndGenerateModules: (sessionId: string) => Promise<ModuleSuggestion[]>;
  getPendingModuleSuggestions: () => ModuleSuggestion[];
}

export const useAIStore = create<AIState>()(
  persist(
    (set, get) => ({
      // === INITIAL STATE ===
      learningAnalysis: null,
      learningInsights: null,
      personalizedRecommendations: [],
      conversationHistory: [],
      moduleSuggestions: [],
      conversationSessions: {},

      // === ACTIONS ===
      setLearningAnalysis: (analysis: LearningAnalysis | null) => {
        set({ learningAnalysis: analysis });
      },

      updateAIInsights: (insights: LearningInsight[]) => {
        set({ learningInsights: insights });
      },

      getLearningPattern: (): LearningPattern | null => {
        // Simplified - would integrate with progress analyzer
        return null;
      },

      getPerformanceMetrics: (): PerformanceMetrics | null => {
        // Simplified - would calculate from learning analysis
        return null;
      },

      getOptimalDifficulty: (category: string): string => {
        // Simplified - would analyze learning pattern
        return 'medium';
      },

      setPersonalizedRecommendations: (recommendations: PersonalizedRecommendation[]) => {
        set({ personalizedRecommendations: recommendations });
      },

      addConversationHistory: (conversation: any) => {
        set((state) => ({
          conversationHistory: [...state.conversationHistory, conversation]
        }));
      },

      setModuleSuggestions: (suggestions: ModuleSuggestion[]) => {
        set({ moduleSuggestions: suggestions });
      },

      startConversationTracking: (): string => {
        const sessionId = `session-${Date.now()}`;
        set((state) => ({
          conversationSessions: {
            ...state.conversationSessions,
            [sessionId]: {
              messages: [],
              startedAt: new Date().toISOString()
            }
          }
        }));
        return sessionId;
      },

      addConversationMessage: (sessionId: string, message: any) => {
        set((state) => {
          const session = state.conversationSessions[sessionId];
          if (!session) return state;

          return {
            conversationSessions: {
              ...state.conversationSessions,
              [sessionId]: {
                ...session,
                messages: [...session.messages, message]
              }
            }
          };
        });
      },

      endConversationAndGenerateModules: async (sessionId: string): Promise<ModuleSuggestion[]> => {
        const session = get().conversationSessions[sessionId];
        if (!session || !session.messages.length) return [];

        try {
          // Simplified - would call conversation analyzer
          const suggestions: ModuleSuggestion[] = [];
          set((state) => ({
            moduleSuggestions: [...state.moduleSuggestions, ...suggestions]
          }));
          return suggestions;
        } catch (error) {
          if (__DEV__) console.error('Error generating modules from conversation:', error);
          return [];
        }
      },

      getPendingModuleSuggestions: (): ModuleSuggestion[] => {
        // Simplified - would filter by status if property exists
        return get().moduleSuggestions;
      },
    }),
    {
      name: 'project-adulting-ai-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        // Don't persist full conversation history - too large
        learningAnalysis: state.learningAnalysis,
        learningInsights: state.learningInsights,
        personalizedRecommendations: state.personalizedRecommendations.slice(0, 10), // Keep recent only
        moduleSuggestions: state.moduleSuggestions.slice(0, 10), // Keep recent only
      }),
    }
  )
);

// Convenience selectors
export const useLearningAnalysis = () => useAIStore((state) => state.learningAnalysis);
export const useLearningInsights = () => useAIStore((state) => state.learningInsights);
export const usePersonalizedRecommendations = () => useAIStore((state) => state.personalizedRecommendations);
export const useModuleSuggestions = () => useAIStore((state) => state.moduleSuggestions);
