/**
 * Tips Store
 * Manages daily tips, bookmarks, ratings, notes, and photos
 * Extracted from unified-store.ts during Phase 1 migration
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AdultingTip, DailyTipSchedule, TipCategory } from '../types/adulting';
import { supabaseMCP } from '../lib/supabase-mcp';

interface TipsState {
  // === STATE ===
  tips: AdultingTip[];
  dailyTipSchedule: DailyTipSchedule[];
  isLoadingTips: boolean;

  // === ACTIONS ===
  mapDifficulty: (dbDifficulty: string) => string;
  loadTipsFromDatabase: () => Promise<void>;
  markTipCompleted: (tipId: string) => void;
  toggleTipBookmark: (tipId: string) => void;
  setTipRating: (tipId: string, rating: number) => void;
  setTipNote: (tipId: string, note: string) => void;
  addTipPhoto: (tipId: string, uri: string) => void;
  removeTipPhoto: (tipId: string, uri: string) => void;
  getTodaysTip: () => AdultingTip | null;
  getTipsByCategory: (category: TipCategory) => AdultingTip[];
}

export const useTipsStore = create<TipsState>()(
  persist(
    (set, get) => ({
      // === INITIAL STATE ===
      tips: [],
      dailyTipSchedule: [],
      isLoadingTips: false,

      // === ACTIONS ===
      mapDifficulty: (dbDifficulty: string): string => {
        const difficultyMap: Record<string, string> = {
          'starter': 'beginner',
          'building': 'intermediate',
          'mastery': 'advanced'
        };
        return difficultyMap[dbDifficulty] || dbDifficulty;
      },

      loadTipsFromDatabase: async () => {
        if (__DEV__) console.log('💡 [TipsStore] Loading tips from database...');
        set({ isLoadingTips: true });

        try {
          // Tips are stored in the 'lessons' table, not a separate 'tips' table
          const { data, error } = await supabaseMCP.query('lessons', {
            select: '*',
            order: { column: 'created_at', direction: 'asc' }
          });

          if (error) {
            if (__DEV__) console.error('❌ [TipsStore] Error loading tips:', error);
            set({ isLoadingTips: false });
            return;
          }

          if (!data || data.length === 0) {
            if (__DEV__) console.warn('⚠️  [TipsStore] No tips found in database');
            set({ isLoadingTips: false, tips: [] });
            return;
          }

          if (__DEV__) console.log(`✅ [TipsStore] Loaded ${data.length} tips from database`);

          // Map database tips to AdultingTip type
          const mappedTips: AdultingTip[] = data.map((tip: any) => ({
            id: tip.id,
            title: tip.title,
            description: tip.description,
            category: tip.category,
            difficulty: get().mapDifficulty(tip.difficulty || 'starter'),
            estimatedTime: tip.estimated_time || 5,
            tags: tip.tags || [],
            completed: false,
            bookmarked: false,
          }));

          set({
            tips: mappedTips,
            isLoadingTips: false
          });
        } catch (error: any) {
          if (__DEV__) console.error('❌ [TipsStore] Exception loading tips:', error);
          set({ isLoadingTips: false });
        }
      },

      markTipCompleted: (tipId: string) => {
        set((state) => ({
          tips: state.tips.map(tip =>
            tip.id === tipId ? { ...tip, completed: true } : tip
          )
        }));
      },

      toggleTipBookmark: (tipId: string) => {
        set((state) => ({
          tips: state.tips.map(tip =>
            tip.id === tipId ? { ...tip, isBookmarked: !tip.isBookmarked } : tip
          )
        }));
      },

      setTipRating: (tipId: string, rating: number) => {
        set((state) => ({
          tips: state.tips.map(tip =>
            tip.id === tipId ? { ...tip, rating } : tip
          )
        }));
      },

      setTipNote: (tipId: string, note: string) => {
        set((state) => ({
          tips: state.tips.map(tip =>
            tip.id === tipId ? { ...tip, note } : tip
          )
        }));
      },

      addTipPhoto: (tipId: string, uri: string) => {
        set((state) => ({
          tips: state.tips.map(tip => {
            if (tip.id === tipId) {
              const photos = tip.photos || [];
              return { ...tip, photos: [...photos, uri] };
            }
            return tip;
          })
        }));
      },

      removeTipPhoto: (tipId: string, uri: string) => {
        set((state) => ({
          tips: state.tips.map(tip => {
            if (tip.id === tipId && tip.photos) {
              return { ...tip, photos: tip.photos.filter(photo => photo !== uri) };
            }
            return tip;
          })
        }));
      },

      getTodaysTip: (): AdultingTip | null => {
        const tips = get().tips;
        const today = new Date().toDateString();
        
        // Simple logic: return first uncompleted tip
        const uncompletedTip = tips.find(tip => !tip.isCompleted);
        return uncompletedTip || (tips.length > 0 ? tips[0] : null);
      },

      getTipsByCategory: (category: TipCategory): AdultingTip[] => {
        return get().tips.filter(tip => tip.category === category);
      },
    }),
    {
      name: 'project-adulting-tips-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        tips: state.tips,
        dailyTipSchedule: state.dailyTipSchedule,
      }),
    }
  )
);

// Convenience selectors
export const useTips = () => useTipsStore((state) => state.tips);
export const useIsLoadingTips = () => useTipsStore((state) => state.isLoadingTips);
export const useTodaysTip = () => useTipsStore((state) => state.getTodaysTip());
export const useBookmarkedTips = () => useTipsStore((state) => 
  state.tips.filter(tip => tip.isBookmarked)
);
export const useCompletedTips = () => useTipsStore((state) => 
  state.tips.filter(tip => tip.isCompleted)
);
