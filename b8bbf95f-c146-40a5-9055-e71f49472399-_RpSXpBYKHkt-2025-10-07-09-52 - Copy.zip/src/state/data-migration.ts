/**
 * Data Migration Utility
 * Migrates data from old unified-store to new split stores
 * Run once on app startup after Phase 1 migration
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { useLessonsStore } from './lessons-store';
import { useProgressStore } from './progress-store';
import { useUIStore } from './ui-store';

const OLD_STORE_KEY = 'project-adulting-store';
const MIGRATION_COMPLETE_KEY = 'phase1-migration-complete';

export async function migrateStoreData() {
  try {
    // Check if migration already done
    const migrationComplete = await AsyncStorage.getItem(MIGRATION_COMPLETE_KEY);
    if (migrationComplete === 'true') {
      if (__DEV__) console.log('✅ [Migration] Data migration already completed');
      return;
    }

    if (__DEV__) console.log('🔄 [Migration] Starting data migration from old store...');

    // Get old store data
    const oldStoreData = await AsyncStorage.getItem(OLD_STORE_KEY);
    if (!oldStoreData) {
      if (__DEV__) console.log('⚠️  [Migration] No old store data found, skipping migration');
      await AsyncStorage.setItem(MIGRATION_COMPLETE_KEY, 'true');
      return;
    }

    const oldStore = JSON.parse(oldStoreData);
    const state = oldStore.state || {};

    if (__DEV__) console.log('📦 [Migration] Found old store data:', {
      hasSkills: !!state.skills,
      skillCount: state.skills?.length || 0,
      hasUserProgress: !!state.userProgress,
      hasCompletedSkills: !!state.completedSkills,
      completedCount: state.completedSkills?.length || 0,
      hasTotalXP: !!state.totalXP,
      totalXP: state.totalXP,
      hasUserProfile: !!state.userProfile,
      userName: state.userProfile?.name || state.user?.name,
    });

    // Migrate to lessons store - USE setState to trigger persistence!
    if (state.skills || state.completedSkills || state.skillProgress) {
      const update: any = {};
      
      if (state.skills && state.skills.length > 0) {
        update.skills = state.skills;
      }
      if (state.completedSkills) {
        update.completedSkills = state.completedSkills;
      }
      if (state.skillProgress) {
        update.skillProgress = state.skillProgress;
      }
      
      useLessonsStore.setState(update);
      if (__DEV__) console.log('✅ [Migration] Migrated lessons data:', {
        skills: update.skills?.length,
        completed: update.completedSkills?.length,
      });
    }

    // Migrate to progress store - USE setState to trigger persistence!
    if (state.userProgress || state.achievements || state.totalXP !== undefined) {
      const update: any = {};
      
      if (state.userProgress) {
        update.userProgress = state.userProgress;
      }
      if (state.achievements) {
        update.achievements = state.achievements;
      }
      if (state.totalXP !== undefined) {
        update.totalXP = state.totalXP;
      }
      if (state.personalGoals) {
        update.personalGoals = state.personalGoals;
      }
      if (state.todoItems) {
        update.todoItems = state.todoItems;
      }
      if (state.goals) {
        update.goals = state.goals;
      }
      
      useProgressStore.setState(update);
      if (__DEV__) console.log('✅ [Migration] Migrated progress data:', {
        totalXP: update.totalXP,
        achievements: update.achievements?.length,
        streak: update.userProgress?.streak || update.userProgress?.streakDays,
      });
    }

    // Migrate to UI store - USE setState to trigger persistence!
    if (state.userProfile || state.user || state.isPro !== undefined) {
      const update: any = {};
      
      if (state.userProfile) {
        update.userProfile = state.userProfile;
        update.user = state.userProfile;
      } else if (state.user) {
        update.user = state.user;
        update.userProfile = state.user;
      }
      
      if (state.isPro !== undefined) {
        update.isPro = state.isPro;
      }
      if (state.isAdmin !== undefined) {
        update.isAdmin = state.isAdmin;
      }
      if (state.isOnboarded !== undefined) {
        update.isOnboarded = state.isOnboarded;
      }
      
      useUIStore.setState(update);
      if (__DEV__) console.log('✅ [Migration] Migrated UI/profile data:', {
        userName: update.userProfile?.name || update.user?.name,
        isPro: update.isPro,
      });
      
      // If we have a name in the old store, update the database
      const userName = update.userProfile?.name || update.user?.name;
      if (userName && userName !== 'Friend') {
        try {
          const { supabaseMCP } = await import('../lib/supabase-mcp');
          const user = (global as any).__AUTH_USER__;
          if (user?.id) {
            await supabaseMCP.update('profiles', {
              id: user.id,
              full_name: userName,
              updated_at: new Date().toISOString()
            }, { onConflict: 'id' });
            if (__DEV__) console.log('✅ [Migration] Updated database profile name to:', userName);
          }
        } catch (error) {
          if (__DEV__) console.warn('⚠️  [Migration] Could not update database profile name:', error);
        }
      }
    }

    // Mark migration as complete
    await AsyncStorage.setItem(MIGRATION_COMPLETE_KEY, 'true');
    if (__DEV__) console.log('✅ [Migration] Data migration complete!');

  } catch (error) {
    if (__DEV__) console.error('❌ [Migration] Error during data migration:', error);
  }
}

export async function resetMigration() {
  await AsyncStorage.removeItem(MIGRATION_COMPLETE_KEY);
  if (__DEV__) console.log('🔄 [Migration] Migration flag reset');
}
