import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface PersistentAuthData {
  token: string | null;
  refreshToken: string | null;
  user: {
    id: string;
    email?: string;
  } | null;
  rememberMe: boolean;
  lastValidated: number;
  createdAt: number;
}

interface AuthStore {
  // State
  token: string | null;
  refreshToken: string | null;
  user: { id: string; email?: string } | null;
  rememberMe: boolean;
  lastValidated: number;
  createdAt: number;
  hydrated: boolean;

  // Actions
  setAuth: (token: string, user: { id: string; email?: string }, remember: boolean, refreshToken?: string) => void;
  clearAuth: () => void;
  updateLastValidated: () => void;
  setRememberMe: (remember: boolean) => void;
  setHydrated: () => void;

  // Selectors
  isAuthenticated: () => boolean;
  shouldAutoRestore: () => boolean;
  isExpired: () => boolean;
  getSessionAge: () => number;
}

// Constants
const MAX_SESSION_AGE_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const VALIDATION_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 hours

if (__DEV__) console.log('🔐 Auth Store initializing...');

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      // Initial state
      token: null,
      refreshToken: null,
      user: null,
      rememberMe: false,
      lastValidated: 0,
      createdAt: 0,
      hydrated: false,

      // Actions
      setAuth: (token, user, remember, refreshToken) => {
        const now = Date.now();
        set({
          token,
          refreshToken: refreshToken || null,
          user,
          rememberMe: remember,
          lastValidated: now,
          createdAt: now
        });

        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Auth data saved:', {
            userId: user.id,
            email: user.email,
            rememberMe: remember,
            hasToken: !!token,
            hasRefreshToken: !!refreshToken,
            createdAt: now,
            willExpireAt: new Date(now + MAX_SESSION_AGE_MS).toISOString()
          });
        }
      },

      clearAuth: () => {
        set({
          token: null,
          refreshToken: null,
          user: null,
          rememberMe: false,
          lastValidated: 0,
          createdAt: 0
        });

        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Auth data cleared');
        }
      },

      updateLastValidated: () => {
        set({ lastValidated: Date.now() });
        
        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Last validated timestamp updated');
        }
      },

      setRememberMe: (remember) => {
        set({ rememberMe: remember });
        
        // If turning off remember me, clear auth data
        if (!remember) {
          get().clearAuth();
        }

        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Remember me preference updated:', remember);
        }
      },

      setHydrated: () => {
        set({ hydrated: true });
        
        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Hydration complete');
        }
      },

      // Selectors
      isAuthenticated: () => {
        const { token, user } = get();
        return !!(token && user && user.id);
      },

      shouldAutoRestore: () => {
        const { rememberMe, token, user } = get();
        // Don't check expiration here - let AuthContext/API calls handle token validity
        // The 30-day expiration is too strict for tokens that expire sooner
        return rememberMe && !!token && !!user;
      },

      isExpired: () => {
        const { createdAt } = get();
        if (!createdAt) return true;
        
        const age = Date.now() - createdAt;
        return age > MAX_SESSION_AGE_MS;
      },

      getSessionAge: () => {
        const { createdAt } = get();
        if (!createdAt) return 0;
        return Date.now() - createdAt;
      }
    }),
    {
      name: 'project-adulting-auth-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        token: state.token,
        refreshToken: state.refreshToken,
        user: state.user,
        rememberMe: state.rememberMe,
        lastValidated: state.lastValidated,
        createdAt: state.createdAt
      }),
      onRehydrateStorage: () => (state) => {
        if (__DEV__) {
          if (__DEV__) console.log('[AuthStore] Rehydration completed:', {
            hasToken: !!state?.token,
            hasUser: !!state?.user,
            rememberMe: state?.rememberMe,
            createdAt: state?.createdAt,
            sessionAge: state?.getSessionAge?.(),
            maxAge: MAX_SESSION_AGE_MS,
            isExpired: state?.isExpired?.()
          });
        }
        
        // Mark as hydrated
        if (state) {
          state.setHydrated();
          
          // Don't automatically clear expired sessions during rehydration
          // Let AuthContext handle restoration logic - it will validate on first API call
          if (state.isExpired() && __DEV__) {
            if (__DEV__) console.log('[AuthStore] Session appears expired (age check), but not clearing automatically - AuthContext will handle validation');
          }
        }
      }
    }
  )
);

// Convenience selectors to prevent unnecessary re-renders
export const useAuthToken = () => useAuthStore((state) => state.token);
export const useAuthUser = () => useAuthStore((state) => state.user);
export const useRememberMe = () => useAuthStore((state) => state.rememberMe);
export const useAuthHydrated = () => useAuthStore((state) => state.hydrated);

// Utility functions
export const getAuthState = () => useAuthStore.getState();
export const shouldValidateSession = () => {
  const { lastValidated } = getAuthState();
  return Date.now() - lastValidated > VALIDATION_INTERVAL_MS;
};

export const getSessionInfo = () => {
  const state = getAuthState();
  return {
    isAuthenticated: state.isAuthenticated(),
    shouldAutoRestore: state.shouldAutoRestore(),
    isExpired: state.isExpired(),
    sessionAge: state.getSessionAge(),
    needsValidation: shouldValidateSession(),
    rememberMe: state.rememberMe,
    lastValidated: state.lastValidated ? new Date(state.lastValidated).toISOString() : null,
    createdAt: state.createdAt ? new Date(state.createdAt).toISOString() : null
  };
};

if (__DEV__) {
  if (__DEV__) console.log('🔐 Auth Store initialized successfully');
}