/**
 * Shared State Type Definitions
 * Extracted from unified-store.ts for Phase 1 migration
 */

import type {
  UserProfile,
  LifeSkill,
  DailyChallenge,
  SkillProgress,
  Achievement,
  PersonalGoal,
  Resource,
} from '../types/app';
import type {
  AdultingTip,
  UserProgress,
  TodoItem,
  DailyTipSchedule,
  TipCategory,
  Goal,
} from '../types/adulting';
import type {
  PersonalizedRecommendation,
  LearningAnalysis,
  LearningInsight,
} from '../api/ai-learning-service';
import type { ModuleSuggestion } from '../api/conversation-analyzer';

/**
 * Database lesson structure
 */
export interface DatabaseLesson {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: string;
  estimated_time?: number;
  xp_reward?: number;
  tags?: string[];
  content?: {
    overview?: string;
    keyPoints?: string[];
    stepByStep?: any[];
    tips?: string[];
    resources?: any[];
    commonMistakes?: string[];
    stepResources?: Record<string, any[]>;
  };
  is_unlocked?: boolean;
  created_at: string;
}

/**
 * Result type for lesson loading operations
 */
export interface LessonLoadResult {
  success: boolean;
  skills?: LifeSkill[];
  error?: string;
}

/**
 * Legacy unified store interface (for backward compatibility)
 * This will be deprecated after migration
 */
export interface UnifiedStore {
  // === AUTH & USER STATE ===
  user: UserProfile | null;
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  authCompleted: boolean;
  onboardingByUser: Record<string, boolean>;
  justSignedUpUserId: string | null;
  isOnboarded: boolean;

  // === LEARNING DATA (Skills/Lessons) ===
  skills: LifeSkill[];
  completedSkills: string[];
  skillProgress: Record<string, SkillProgress>;
  isLoadingSkills: boolean;
  skillsError: string | null;
  failedLessonsCount: number;
  failedLessonsDetails: Array<{
    index: number;
    lessonId: string;
    lessonTitle: string;
    error: string;
    lessonStructure: any;
  }>;
  currentSkill: LifeSkill | null;

  // === DAILY TIPS DATA ===
  tips: AdultingTip[];
  dailyTipSchedule: DailyTipSchedule[];
  isLoadingTips: boolean;

  // === USER PROGRESS & ACHIEVEMENTS ===
  userProgress: UserProgress;
  achievements: Achievement[];
  totalXP: number;
  aiUsage: number;
  aiLastUsedAt: string | null;
  lastFreeChallengeAt: string | null;

  // === SUBSCRIPTION & FEATURES ===
  isPro: boolean;
  isAdmin: boolean;
  freeLimit: number;
  freeLimits: { aiMonthly: number; aiCooldownMin: number; unlockedSkillIds: string[] };

  // === LEARNING PATHS ===
  activeLearningPaths: string[];
  completedLearningPaths: string[];

  // === AI & ANALYTICS ===
  learningAnalysis: LearningAnalysis | null;
  learningInsights: LearningInsight[] | null;
  personalizedRecommendations: PersonalizedRecommendation[];
  conversationHistory: any[];
  moduleSuggestions: ModuleSuggestion[];
  conversationSessions: Record<string, any>;

  // === DAILY CHALLENGES ===
  dailyChallenges: DailyChallenge[];
  todaysChallenge: DailyChallenge | null;

  // === GOALS & TODOS ===
  personalGoals: PersonalGoal[];
  todoItems: TodoItem[];
  goals: Goal[];

  // === LESSON RESOURCES ===
  lessonResources: Record<string, { items: Resource[]; lastFetched: number }>;
  isFetchingLessonResources: Record<string, boolean>;
  lessonResourceErrors: Record<string, string | null>;

  // === ACTIONS ===
  // (Actions will be extracted to individual stores)
  [key: string]: any;
}
