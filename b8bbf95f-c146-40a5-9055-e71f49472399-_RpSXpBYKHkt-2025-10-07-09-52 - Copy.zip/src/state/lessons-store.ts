/**
 * Lessons Store
 * Manages all lesson/skill related state and actions
 * Extracted from unified-store.ts during Phase 1 migration
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { LifeSkill, SkillProgress, SkillCategory, StepResult, Resource } from '../types/app';
import type { DatabaseLesson, LessonLoadResult } from './types';
import { supabaseMCP } from '../lib/supabase-mcp';
import { convertDatabaseLessonToLifeSkill } from './lesson-converters';

interface LessonsState {
  // === STATE ===
  skills: LifeSkill[];
  completedSkills: string[];
  skillProgress: Record<string, SkillProgress>;
  isLoadingSkills: boolean;
  skillsError: string | null;
  failedLessonsCount: number;
  failedLessonsDetails: Array<{
    index: number;
    lessonId: string;
    lessonTitle: string;
    error: string;
    lessonStructure: any;
  }>;
  currentSkill: LifeSkill | null;
  
  // Lesson resources
  lessonResources: Record<string, { items: Resource[]; lastFetched: number }>;
  isFetchingLessonResources: Record<string, boolean>;
  lessonResourceErrors: Record<string, string | null>;

  // === ACTIONS ===
  // Loading actions
  loadSkillsFromDatabase: () => Promise<LessonLoadResult>;
  
  // Cloud sync actions
  syncProgressToCloud: (skillId: string) => Promise<void>;
  loadProgressFromCloud: () => Promise<void>;
  uploadLocalProgressToCloud: () => Promise<{ succeeded: number; failed: number }>;
  
  // Skill completion actions
  markSkillCompleted: (skillId: string) => void;
  updateSkillProgress: (skillId: string, progress: Partial<SkillProgress>) => void;
  unlockSkill: (skillId: string) => void;
  
  // Skill interaction actions
  startSkill: (skillId: string) => void;
  completeSkill: (skillId: string, rating: number, notes: string) => void;
  completeSkillStep: (skillId: string, stepId: string) => void;
  updateStepResult: (skillId: string, stepId: string, patch: any) => void;
  getStepStatus: (skillId: string, stepId: string) => StepResult | null;
  
  // Lesson resources actions
  loadLessonResources: (lessonId: string) => Promise<void>;
  getLessonResources: (lessonId: string) => Resource[];
  isFetchingLesson: (lessonId: string) => boolean;
  getLessonResourceError: (lessonId: string) => string | null;
  
  // Utility actions
  getRecommendedSkills: () => LifeSkill[];
  isSkillUnlocked: (skillId: string) => boolean;
  
  // Checklist and timer actions
  toggleChecklistItem: (skillId: string, stepId: string, itemId: string) => void;
  startTimerForStep: (skillId: string, stepId: string, duration: number) => void;
  completeTimerForStep: (skillId: string, stepId: string) => void;
  getTimerRemaining: (skillId: string, stepId: string) => number | null;
}

export const useLessonsStore = create<LessonsState>()(
  persist(
    (set, get) => ({
      // === INITIAL STATE ===
      skills: [],
      completedSkills: [],
      skillProgress: {},
      isLoadingSkills: false,
      skillsError: null,
      failedLessonsCount: 0,
      failedLessonsDetails: [],
      currentSkill: null,
      lessonResources: {},
      isFetchingLessonResources: {},
      lessonResourceErrors: {},

      // === ACTIONS ===
      loadSkillsFromDatabase: async (): Promise<LessonLoadResult> => {
        if (__DEV__) console.log('📚 [LessonsStore] Loading skills from database...');
        set({ isLoadingSkills: true, skillsError: null });

        try {
          // Note: This uses the full lesson loading logic from unified-store
          // We'll need to import or replicate the conversion functions
          const { data, error } = await supabaseMCP.query('lessons', {
            select: '*',
            order: { column: 'created_at', direction: 'asc' },
            limit: 200  // Explicit high limit to get all lessons (database has 132)
          });

          if (error) {
            if (__DEV__) console.error('❌ [LessonsStore] Error loading lessons:', error);
            set({ 
              isLoadingSkills: false, 
              skillsError: 'Failed to load lessons from database',
              failedLessonsCount: 1
            });
            return { success: false, error: error.message };
          }

          if (!data || data.length === 0) {
            if (__DEV__) console.warn('⚠️  [LessonsStore] No lessons found in database');
            set({ 
              isLoadingSkills: false,
              skills: [],
              skillsError: 'No lessons available'
            });
            return { success: true, skills: [] };
          }

          if (__DEV__) console.log(`✅ [LessonsStore] Loaded ${data.length} lessons from database`);
          
          // Use full conversion logic to preserve all lesson features including stepResources
          const lessons = data as DatabaseLesson[];
          let failureCount = 0;
          const failedLessons: Array<{
            index: number;
            lessonId: string;
            lessonTitle: string;
            error: string;
            lessonStructure: any;
          }> = [];
          
          const skills: LifeSkill[] = await Promise.all(lessons.map(async (lesson, index) => {
            try {
              return await convertDatabaseLessonToLifeSkill(lesson);
            } catch (error) {
              failureCount++;
              const errorMessage = error instanceof Error ? error.message : 'Unknown error';
              failedLessons.push({
                index,
                lessonId: lesson?.id || 'No ID',
                lessonTitle: lesson?.title || 'No Title',
                error: errorMessage,
                lessonStructure: {
                  id: lesson?.id,
                  title: lesson?.title,
                  category: lesson?.category
                }
              });
              if (__DEV__) console.warn(`Failed to convert lesson ${index}:`, errorMessage);
              return null;
            }
          })).then(results => results.filter(Boolean) as LifeSkill[]);

          if (__DEV__) console.log(`📊 [LessonsStore] Loaded ${lessons.length} lessons from DB, converted ${skills.length}, ${failureCount} failed`);
          if (failureCount > 0) {
            if (__DEV__) console.warn(`⚠️ [LessonsStore] Failed lessons:`, failedLessons.map(f => `${f.lessonTitle} (${f.error})`));
          }

          // CRITICAL FIX: Don't overwrite completedSkills or skillProgress when loading lessons
          // These are user progress data that should persist
          const currentState = get();
          
          set({ 
            skills,
            // Preserve existing completedSkills and skillProgress (user progress data)
            // Only the 'skills' array should be refreshed from database
            isLoadingSkills: false,
            skillsError: null,
            failedLessonsCount: failureCount,
            failedLessonsDetails: failedLessons
          });

          if (__DEV__) console.log(`💾 [LessonsStore] Preserved user progress:`, {
            completedSkills: currentState.completedSkills.length,
            skillProgressKeys: Object.keys(currentState.skillProgress).length
          });

          return { success: true, skills };
        } catch (error: any) {
          if (__DEV__) console.error('❌ [LessonsStore] Exception loading lessons:', error);
          set({ 
            isLoadingSkills: false,
            skillsError: error.message || 'Unknown error loading lessons'
          });
          return { success: false, error: error.message };
        }
      },

      // Cloud sync methods - RE-ENABLED (proxy is now fixed!)
      syncProgressToCloud: async (skillId: string) => {
        try {
          const state = get();
          const progress = state.skillProgress[skillId];
          
          if (!progress) {
            if (__DEV__) console.log('[LessonsStore] No progress to sync for:', skillId);
            return;
          }

          const { lessonProgressService } = require('../services/database');
          await lessonProgressService.saveProgress(skillId, progress);
          
          if (__DEV__) console.log('[LessonsStore] ✅ Synced progress to cloud:', skillId);
        } catch (error: any) {
          if (__DEV__) console.error('[LessonsStore] Failed to sync progress:', error.message);
          throw error;
        }
      },

      loadProgressFromCloud: async () => {
        try {
          if (__DEV__) console.log('[LessonsStore] Loading progress from cloud...');
          
          const { lessonProgressService } = require('../services/database');
          const result = await lessonProgressService.getAllProgress();
          
          if (!result.success || !result.data) {
            if (__DEV__) console.warn('[LessonsStore] No cloud progress found');
            return;
          }

          const cloudProgress: Record<string, SkillProgress> = {};
          const completedSkillIds: string[] = [];

          result.data.forEach((record: any) => {
            const progress = lessonProgressService.constructor.toSkillProgress(record);
            cloudProgress[record.skill_id] = progress;
            
            if (record.completed) {
              completedSkillIds.push(record.skill_id);
            }
          });

          set({
            skillProgress: cloudProgress,
            completedSkills: completedSkillIds,
          });

          if (__DEV__) console.log('[LessonsStore] ✅ Loaded progress from cloud:', result.data.length, 'records');
        } catch (error: any) {
          if (__DEV__) console.error('[LessonsStore] Failed to load progress from cloud:', error.message);
        }
      },

      uploadLocalProgressToCloud: async (): Promise<{ succeeded: number; failed: number }> => {
        try {
          const state = get();
          const progressRecords = Object.entries(state.skillProgress).map(([skillId, progress]) => ({
            skillId,
            progress,
          }));

          if (progressRecords.length === 0) {
            if (__DEV__) console.log('[LessonsStore] No local progress to upload');
            return { succeeded: 0, failed: 0 };
          }

          const { lessonProgressService } = require('../services/database');
          const result = await lessonProgressService.batchUpload(progressRecords);
          
          if (__DEV__) {
            if (__DEV__) console.log('[LessonsStore] ✅ Upload complete:', result.succeeded, 'succeeded,', result.failed, 'failed');
          }

          return { succeeded: result.succeeded, failed: result.failed };
        } catch (error: any) {
          if (__DEV__) console.error('[LessonsStore] Failed to upload progress:', error.message);
          return { succeeded: 0, failed: 0 };
        }
      },

      markSkillCompleted: (skillId: string) => {
        set((state) => ({
          completedSkills: [...state.completedSkills, skillId]
        }));
        // Sync to cloud asynchronously (catch to prevent crashes)
        get().syncProgressToCloud(skillId).catch((e) => {
          if (__DEV__) console.warn('[LessonsStore] Sync failed for markSkillCompleted:', e);
        });
      },

      updateSkillProgress: (skillId: string, progress: Partial<SkillProgress>) => {
        set((state) => ({
          skillProgress: {
            ...state.skillProgress,
            [skillId]: { ...state.skillProgress[skillId], ...progress }
          }
        }));
        // Sync to cloud asynchronously (catch to prevent crashes)
        get().syncProgressToCloud(skillId).catch((e) => {
          if (__DEV__) console.warn('[LessonsStore] Sync failed for updateSkillProgress:', e);
        });
      },

      unlockSkill: (skillId: string) => {
        set((state) => ({
          skills: state.skills.map(skill => 
            skill.id === skillId ? { ...skill, isUnlocked: true } : skill
          )
        }));
      },

      startSkill: (skillId: string) => {
        set((state) => {
          const existingProgress = state.skillProgress[skillId] || {};
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...existingProgress,
                startedAt: existingProgress.startedAt || new Date().toISOString(),
                isStarted: true,
                completedSteps: existingProgress.completedSteps || [],
                stepResults: existingProgress.stepResults || {},
                rating: existingProgress.rating,
                notes: existingProgress.notes,
                completedAt: existingProgress.completedAt
              }
            },
            currentSkill: state.skills.find(s => s.id === skillId) || null
          };
        });
        // Sync to cloud asynchronously
        get().syncProgressToCloud(skillId).catch(console.error);
      },

      completeSkill: (skillId: string, rating: number, notes: string) => {
        const skill = get().skills.find(s => s.id === skillId);
        const xpReward = skill?.xpReward || 50;
        
        // Check if already completed to avoid duplicates
        const alreadyCompleted = get().completedSkills.includes(skillId);
        
        if (alreadyCompleted) {
          if (__DEV__) console.log(`ℹ️ [LessonsStore] Skill "${skill?.title}" already completed`);
          return;
        }
        
        set((state) => ({
          completedSkills: [...state.completedSkills, skillId],
          skillProgress: {
            ...state.skillProgress,
            [skillId]: {
              ...state.skillProgress[skillId],
              completedAt: new Date().toISOString(),
              completed: true,
              rating,
              notes,
              isCompleted: true
            }
          }
        }));
        
        // Sync to cloud asynchronously
        get().syncProgressToCloud(skillId).catch(console.error);
        
        // Update progress store with XP and check achievements
        const { useProgressStore } = require('./progress-store');
        const progressStore = useProgressStore.getState();
        
        // Add XP
        const newTotalXP = progressStore.totalXP + xpReward;
        progressStore.updateTotalXP(newTotalXP);
        
        // Check and unlock achievements
        progressStore.checkAndUnlockAchievements();
        
        // Update streak
        progressStore.updateStreak();
        
        // Auto-complete today's challenge if it matches this lesson
        const todaysChallenge = progressStore.todaysChallenge;
        if (todaysChallenge && !todaysChallenge.isCompleted) {
          // Check if this lesson completion satisfies the challenge
          const challengeType = todaysChallenge.type;
          if (challengeType === 'complete_lesson' || challengeType === 'complete_skill') {
            progressStore.setTodaysChallenge({
              ...todaysChallenge,
              isCompleted: true
            });
            if (__DEV__) console.log(`🎯 [Auto] Completed today's challenge by finishing lesson!`);
          }
        }
        
        if (__DEV__) {
          if (__DEV__) console.log(`✅ [LessonsStore] Completed skill "${skill?.title}" +${xpReward} XP`);
          if (__DEV__) console.log(`📊 Total completed: ${get().completedSkills.length}, Total XP: ${newTotalXP}`);
        }
      },

      completeSkillStep: (skillId: string, stepId: string) => {
        set((state) => {
          const progress = state.skillProgress[skillId] || {};
          const completedSteps = progress.completedSteps || [];
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...progress,
                completedSteps: [...completedSteps, stepId]
              }
            }
          };
        });
        // Sync to cloud asynchronously
        get().syncProgressToCloud(skillId).catch(console.error);
      },

      updateStepResult: (skillId: string, stepId: string, patch: any) => {
        set((state) => {
          const progress = state.skillProgress[skillId] || {};
          const stepResults = progress.stepResults || {};
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...progress,
                stepResults: {
                  ...stepResults,
                  [stepId]: { ...stepResults[stepId], ...patch }
                }
              }
            }
          };
        });
        // Sync to cloud asynchronously
        get().syncProgressToCloud(skillId).catch(console.error);
      },

      getStepStatus: (skillId: string, stepId: string): StepResult | null => {
        const progress = get().skillProgress[skillId];
        return progress?.stepResults?.[stepId] || null;
      },

      loadLessonResources: async (lessonId: string) => {
        // Placeholder - will implement resource loading
        set((state) => ({
          isFetchingLessonResources: {
            ...state.isFetchingLessonResources,
            [lessonId]: true
          }
        }));
        
        // Simulate async operation
        await new Promise(resolve => setTimeout(resolve, 100));
        
        set((state) => ({
          isFetchingLessonResources: {
            ...state.isFetchingLessonResources,
            [lessonId]: false
          },
          lessonResources: {
            ...state.lessonResources,
            [lessonId]: { items: [], lastFetched: Date.now() }
          }
        }));
      },

      getLessonResources: (lessonId: string): Resource[] => {
        return get().lessonResources[lessonId]?.items || [];
      },

      isFetchingLesson: (lessonId: string): boolean => {
        return get().isFetchingLessonResources[lessonId] || false;
      },

      getLessonResourceError: (lessonId: string): string | null => {
        return get().lessonResourceErrors[lessonId] || null;
      },

      getRecommendedSkills: (): LifeSkill[] => {
        const state = get();
        return state.skills.filter(skill => !state.completedSkills.includes(skill.id)).slice(0, 5);
      },

      isSkillUnlocked: (skillId: string): boolean => {
        const state = get();
        const skill = state.skills.find(s => s.id === skillId);
        
        if (!skill) return false;
        
        // Import isPro from ui-store
        const { isPro, freeLimits } = require('./ui-store').useUIStore.getState();
        
        // Pro users get everything
        if (isPro) return true;
        
        // Skill already started or completed
        if (state.completedSkills.includes(skillId) || !!state.skillProgress[skillId]) {
          return true;
        }
        
        // Check if skill is in explicit free list
        if (freeLimits.unlockedSkillIds && freeLimits.unlockedSkillIds.includes(skillId)) {
          return true;
        }
        
        // Free tier: Unlock first 3 "starter" difficulty skills per category
        if (skill.difficulty === 'starter') {
          const categorySkills = state.skills
            .filter(s => s.category === skill.category && s.difficulty === 'starter');
          const skillIndex = categorySkills.findIndex(s => s.id === skillId);
          return skillIndex >= 0 && skillIndex < 3;
        }
        
        return false;
      },

      toggleChecklistItem: (skillId: string, stepId: string, itemId: string) => {
        set((state) => {
          const progress = state.skillProgress[skillId] || {};
          const stepResults = progress.stepResults || {};
          const stepResult = stepResults[stepId] || {} as any;
          const checklist = (stepResult as any).checklist || {};
          
          // Toggle the item - if it exists, remove it (set to false), otherwise add it (set to true)
          const newChecklist = {
            ...checklist,
            [itemId]: !checklist[itemId]
          };
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...progress,
                stepResults: {
                  ...stepResults,
                  [stepId]: {
                    ...stepResult,
                    status: 'in_progress' as const,
                    checklist: newChecklist
                  }
                }
              }
            }
          };
        });
        // Sync to cloud asynchronously
        get().syncProgressToCloud(skillId).catch(console.error);
      },

      startTimerForStep: (skillId: string, stepId: string, duration: number) => {
        set((state) => {
          const progress = state.skillProgress[skillId] || {} as any;
          const stepResults = (progress as any).stepResults || {};
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...progress,
                stepResults: {
                  ...stepResults,
                  [stepId]: {
                    ...(stepResults[stepId] || {}),
                    timerStartedAt: Date.now(),
                    timerDuration: duration * 60 * 1000 // Convert to ms
                  }
                }
              } as any
            }
          };
        });
      },

      completeTimerForStep: (skillId: string, stepId: string) => {
        set((state) => {
          const progress = state.skillProgress[skillId] || {};
          const stepResults = progress.stepResults || {};
          
          return {
            skillProgress: {
              ...state.skillProgress,
              [skillId]: {
                ...progress,
                stepResults: {
                  ...stepResults,
                  [stepId]: {
                    ...stepResults[stepId],
                    timerCompleted: true
                  }
                }
              }
            }
          };
        });
      },

      getTimerRemaining: (skillId: string, stepId: string): number | null => {
        const stepResult = get().skillProgress[skillId]?.stepResults?.[stepId] as any;
        if (!stepResult?.timerStartedAt || !stepResult?.timerDuration) return null;
        
        const elapsed = Date.now() - Number(stepResult.timerStartedAt);
        const remaining = Number(stepResult.timerDuration) - elapsed;
        
        return remaining > 0 ? remaining : 0;
      },
    }),
    {
      name: 'project-adulting-lessons-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        // Only persist necessary data - not the full lesson content
        skills: state.skills,
        completedSkills: state.completedSkills,
        skillProgress: state.skillProgress,
        currentSkill: state.currentSkill,
      }),
    }
  )
);

// Convenience selectors
export const useSkills = () => useLessonsStore((state) => state.skills);
export const useCompletedSkills = () => useLessonsStore((state) => state.completedSkills);
export const useSkillProgress = (skillId?: string) => 
  useLessonsStore((state) => skillId ? state.skillProgress[skillId] : state.skillProgress);
export const useIsLoadingSkills = () => useLessonsStore((state) => state.isLoadingSkills);
export const useCurrentSkill = () => useLessonsStore((state) => state.currentSkill);
