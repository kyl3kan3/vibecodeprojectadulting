/**
 * Lesson Conversion Functions
 * Helper functions to convert database lessons to LifeSkill format
 * Extracted from unified-store during Phase 1 migration
 */

import type { LifeSkill, SkillCategory, Resource } from '../types/app';
import type { DatabaseLesson } from './types';

// Constants
const DEFAULT_ESTIMATED_TIME = 30;
const DEFAULT_XP_REWARD = 50;

// Import from utils - these already exist in the codebase
export { generateContentAwareSteps } from '../utils/ai-step-generator';

/**
 * Convert database lesson to LifeSkill format with full processing
 * This is the CRITICAL function that ensures stepResources are included
 */
export const convertDatabaseLessonToLifeSkill = async (lesson: DatabaseLesson): Promise<LifeSkill> => {
  try {
    // Validate lesson object
    if (!lesson || !lesson.id) {
      throw new Error('Invalid lesson object');
    }
    
    // Clean up the lesson ID
    const cleanLessonId = lesson.id.toString().replace(/[^a-zA-Z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    const safeLessonId = cleanLessonId || 'lesson';
    
    // Extract content from JSONB field
    const content = lesson.content || {};
    
    if (__DEV__) console.log(`🔍 Converting lesson: ${lesson.title}`, {
      hasStepResources: !!content.stepResources,
      stepResourceKeys: content.stepResources ? Object.keys(content.stepResources).length : 0,
      stepByStepLength: content.stepByStep?.length || 0,
      rawStepResources: content.stepResources
    });
    
    // CRITICAL: Include stepResources - this is what contains AI-generated substep resources!
    const stepResources = content.stepResources || {};
    
    if (Object.keys(stepResources).length > 0) {
      if (__DEV__) console.log(`✨ [RESOURCES] ${lesson.title} has ${Object.keys(stepResources).length} steps with resources!`);
      Object.entries(stepResources).forEach(([stepId, resources]) => {
        if (__DEV__) console.log(`   → ${stepId}: ${(resources as any[]).length} resources`);
      });
    } else {
      if (__DEV__) console.log(`⚠️ [NO RESOURCES] ${lesson.title} has no stepResources`);
    }
    
    return {
      id: safeLessonId,
      title: lesson.title,
      description: lesson.description,
      category: lesson.category as SkillCategory,
      difficulty: (lesson.difficulty === 'starter' || lesson.difficulty === 'building' || lesson.difficulty === 'mastery')
        ? lesson.difficulty as 'starter' | 'building' | 'mastery'
        : 'starter',
      estimatedTime: lesson.estimated_time || DEFAULT_ESTIMATED_TIME,
      xpReward: lesson.xp_reward || DEFAULT_XP_REWARD,
      tags: lesson.tags || [],
      content: {
        overview: content.overview || lesson.description,
        keyPoints: content.keyPoints || [],
        stepByStep: content.stepByStep || [],
        tips: content.tips || [],
        resources: content.resources || [],
        commonMistakes: content.commonMistakes || [],
        stepResources: stepResources  // ← CRITICAL: This contains AI-generated resources!
      }
    };
  } catch (error) {
    if (__DEV__) console.error(`Error converting lesson ${lesson?.title}:`, error);
    
    // Return minimal fallback
    return {
      id: lesson?.id || 'fallback-lesson',
      title: lesson?.title || 'Untitled Lesson',
      description: lesson?.description || 'A lesson to help you learn new skills',
      category: 'personal_growth' as SkillCategory,
      difficulty: 'starter' as 'starter' | 'building' | 'mastery',
      estimatedTime: 30,
      xpReward: 50,
      tags: [],
      content: {
        overview: lesson.description || 'Learn new skills step by step',
        keyPoints: ['Get started', 'Practice regularly', 'Track your progress'],
        stepByStep: [],
        tips: [],
        resources: [],
        commonMistakes: [],
        stepResources: {}  // Empty but must exist
      }
    };
  }
};
