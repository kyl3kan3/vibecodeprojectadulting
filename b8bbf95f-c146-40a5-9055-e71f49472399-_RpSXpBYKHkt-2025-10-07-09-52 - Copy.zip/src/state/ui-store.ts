/**
 * UI Store
 * Manages UI state, onboarding, modals, and navigation state
 * Extracted from unified-store.ts during Phase 1 migration
 */

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { UserProfile } from '../types/app';

interface UIState {
  // === STATE ===
  user: UserProfile | null;
  userProfile: UserProfile | null;
  isAuthenticated: boolean;
  authCompleted: boolean;
  onboardingByUser: Record<string, boolean>;
  justSignedUpUserId: string | null;
  isOnboarded: boolean;

  // Subscription state
  isPro: boolean;
  isAdmin: boolean;
  freeLimit: number;
  freeLimits: {
    aiMonthly: number;
    aiCooldownMin: number;
    unlockedSkillIds: string[];
  };

  // === ACTIONS ===
  // Auth actions
  setUser: (user: UserProfile | null) => void;
  setAuthCompleted: (completed: boolean) => void;
  setOnboardingByUser: (userId: string, completed: boolean) => void;
  setJustSignedUpUserId: (userId: string | null) => void;
  setIsOnboarded: (onboarded: boolean) => void;

  // Subscription actions
  setIsPro: (isPro: boolean) => void;
  setIsAdmin: (isAdmin: boolean) => void;

  // Profile actions
  ensureLocalProfile: () => Promise<void>;
  updateUserPreferences: (preferences: any) => void;

  // Feature access
  canSendAI: () => { ok: boolean; reason?: string; remainingMs?: number } | null;
  canAccessTip: (tipId: string) => boolean;

  // Skill bookmarking
  toggleSkillBookmark: (skillId: string) => void;

  // Guide progress
  getGuideProgressPct: (guideId: string) => number;
  toggleStep: (guideId: string, stepId: string) => void;
  resetGuide: (guideId: string) => void;
  isStepDone: (guideId: string, stepId: string) => boolean;

  // Logout
  logout: () => Promise<void>;
}

export const useUIStore = create<UIState>()(
  persist(
    (set, get) => ({
      // === INITIAL STATE ===
      user: null,
      userProfile: null,
      isAuthenticated: false,
      authCompleted: false,
      onboardingByUser: {},
      justSignedUpUserId: null,
      isOnboarded: false,
      isPro: false,
      isAdmin: false,
      freeLimit: 3,
      freeLimits: {
        aiMonthly: 3, // 3 messages per day (simple and clear)
        aiCooldownMin: 0, // No cooldown - just daily reset
        unlockedSkillIds: [] // Will be populated when skills load
      },

      // === ACTIONS ===
      setUser: (user: UserProfile | null) => {
        set({ 
          user, 
          userProfile: user,
          isAuthenticated: !!user 
        });
      },

      setAuthCompleted: (completed: boolean) => {
        set({ authCompleted: completed });
      },

      setOnboardingByUser: (userId: string, completed: boolean) => {
        set((state) => ({
          onboardingByUser: {
            ...state.onboardingByUser,
            [userId]: completed
          }
        }));
      },

      setJustSignedUpUserId: (userId: string | null) => {
        set({ justSignedUpUserId: userId });
      },

      setIsOnboarded: (onboarded: boolean) => {
        set({ isOnboarded: onboarded });
      },

      setIsPro: (isPro: boolean) => {
        set({ isPro });
      },

      setIsAdmin: (isAdmin: boolean) => {
        set({ isAdmin });
      },

      ensureLocalProfile: async () => {
        const state = get();
        if (state.userProfile) return;
        
        // Create a minimal local profile
        const localProfile: Partial<UserProfile> = {
          id: 'local-user',
          totalXP: 0,
          completedSkills: [],
          achievements: []
        };
        
        set({ userProfile: localProfile as UserProfile });
      },

      updateUserPreferences: (preferences: any) => {
        set((state) => ({
          userProfile: state.userProfile ? {
            ...state.userProfile,
            preferences: {
              ...(state.userProfile as any).preferences,
              ...preferences
            }
          } : null
        }));
      },

      canSendAI: () => {
        const state = get();
        
        // Pro users have no limits
        if (state.isPro) {
          return { ok: true };
        }
        
        // Get AI usage from progress store
        const progressStore = require('./progress-store').useProgressStore.getState();
        const remaining = progressStore.getAiRemaining();
        
        // Check daily limit (3 messages per day)
        if (remaining <= 0) {
          return { 
            ok: false, 
            reason: 'limit',
            remainingMs: 0 
          };
        }
        
        return { ok: true };
      },

      canAccessTip: (tipId: string) => {
        // All tips accessible by default
        return true;
      },

      toggleSkillBookmark: (skillId: string) => {
        set((state) => {
          const currentSaved = state.userProfile?.savedSkills || [];
          const isSaved = currentSaved.includes(skillId);
          
          const newSavedSkills = isSaved
            ? currentSaved.filter(id => id !== skillId)
            : [...currentSaved, skillId];
          
          return {
            userProfile: state.userProfile ? {
              ...state.userProfile,
              savedSkills: newSavedSkills
            } : null
          };
        });
      },

      getGuideProgressPct: (guideId: string) => {
        // Simplified - would calculate actual progress
        return 0;
      },

      toggleStep: (guideId: string, stepId: string) => {
        // Simplified - would track guide step completion
        if (__DEV__) console.log(`Toggle step ${stepId} in guide ${guideId}`);
      },

      resetGuide: (guideId: string) => {
        // Simplified - would reset guide progress
        if (__DEV__) console.log(`Reset guide ${guideId}`);
      },

      isStepDone: (guideId: string, stepId: string) => {
        // Simplified - would check step completion
        return false;
      },

      logout: async () => {
        set({
          user: null,
          userProfile: null,
          isAuthenticated: false,
          authCompleted: false,
          isOnboarded: false,
          isPro: false,
          isAdmin: false
        });
      },
    }),
    {
      name: 'project-adulting-ui-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        authCompleted: state.authCompleted,
        onboardingByUser: state.onboardingByUser,
        isOnboarded: state.isOnboarded,
        isPro: state.isPro,
        isAdmin: state.isAdmin,
        freeLimits: state.freeLimits,
        userProfile: state.userProfile ? {
          ...state.userProfile,
          savedSkills: state.userProfile.savedSkills || []
        } : null,
      }),
    }
  )
);

// Convenience selectors
export const useUser = () => useUIStore((state) => state.user);
export const useUserProfile = () => useUIStore((state) => state.userProfile);
export const useIsAuthenticated = () => useUIStore((state) => state.isAuthenticated);
export const useIsPro = () => useUIStore((state) => state.isPro);
export const useIsOnboarded = () => useUIStore((state) => state.isOnboarded);
