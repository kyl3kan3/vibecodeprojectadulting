/**
 * State Store Index
 * Barrel exports for all stores and backward compatibility layer
 * Created during Phase 1 migration
 */

// Export individual stores
export { useLessonsStore, useSkills, useCompletedSkills, useSkillProgress, useIsLoadingSkills, useCurrentSkill } from './lessons-store';
export { useProgressStore, useUserProgress, useAchievements, useTotalXP, useTodaysChallenge, usePersonalGoals, useTodoItems } from './progress-store';
export { useAIStore, useLearningAnalysis, useLearningInsights, usePersonalizedRecommendations, useModuleSuggestions } from './ai-store';
export { useUIStore, useUser, useUserProfile, useIsAuthenticated, useIsPro, useIsOnboarded } from './ui-store';
export { useTipsStore, useTips, useIsLoadingTips, useTodaysTip, useBookmarkedTips, useCompletedTips } from './tips-store';

// Export types
export type * from './types';

// Re-export store getters for direct access (advanced usage)
import { useLessonsStore } from './lessons-store';
import { useProgressStore } from './progress-store';
import { useAIStore } from './ai-store';
import { useUIStore } from './ui-store';
import { useTipsStore } from './tips-store';

export const getLessonsState = () => useLessonsStore.getState();
export const getProgressState = () => useProgressStore.getState();
export const getAIState = () => useAIStore.getState();
export const getUIState = () => useUIStore.getState();
export const getTipsState = () => useTipsStore.getState();

/**
 * Unified Store Compatibility Layer
 * 
 * This provides backward compatibility with the old unified store pattern.
 * Components can use this during migration, but should eventually migrate
 * to using individual stores for better performance.
 * 
 * @deprecated Use individual stores instead for better performance:
 * - useLessonsStore
 * - useProgressStore
 * - useAIStore  
 * - useUIStore
 * - useTipsStore
 */
export const useUnifiedStore = () => {
  const lessons = useLessonsStore();
  const progress = useProgressStore();
  const ai = useAIStore();
  const ui = useUIStore();
  const tips = useTipsStore();
  
  return {
    // Spread all store properties and actions
    ...lessons,
    ...progress,
    ...ai,
    ...ui,
    ...tips,
  };
};

/**
 * Legacy store aliases for backward compatibility
 * @deprecated Use useUnifiedStore or individual stores instead
 */
export const useAppStore = useUnifiedStore;
export const useAdultingStore = useUnifiedStore;
export const useGuidesStore = useUnifiedStore;
