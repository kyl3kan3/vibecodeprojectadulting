/**
 * Validation Schemas Index
 * Barrel export for all Zod schemas
 */

// Lesson schemas
export {
  ResourceSchema,
  StepSchema,
  SkillContentSchema,
  LifeSkillSchema,
  DatabaseLessonSchema,
  LessonArraySchema,
} from './lessonSchemas';

export type {
  ValidatedLifeSkill,
  ValidatedDatabaseLesson,
  ValidatedResource,
} from './lessonSchemas';

// Progress schemas
export {
  UserProgressEntrySchema,
  UserStreakSchema,
  AchievementSchema,
  ProgressStatsSchema,
  StreakStatsSchema,
} from './progressSchemas';

export type {
  ValidatedUserProgress,
  ValidatedUserStreak,
  ValidatedAchievement,
  ValidatedProgressStats,
  ValidatedStreakStats,
} from './progressSchemas';

// User schemas
export {
  UserPreferencesSchema,
  UserProfileSchema,
  DatabaseProfileSchema,
} from './userSchemas';

export type {
  ValidatedUserProfile,
  ValidatedUserPreferences,
  ValidatedDatabaseProfile,
} from './userSchemas';
