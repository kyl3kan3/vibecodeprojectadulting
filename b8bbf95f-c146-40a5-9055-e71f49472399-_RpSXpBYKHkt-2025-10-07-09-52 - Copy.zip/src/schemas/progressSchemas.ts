/**
 * Progress Validation Schemas
 * Zod schemas for user progress and achievements
 */

import { z } from 'zod';

// User progress entry schema (from database)
export const UserProgressEntrySchema = z.object({
  id: z.string().uuid(),
  user_id: z.string().uuid(),
  tip_id: z.string(),
  completed_at: z.string().datetime(),
  difficulty_rating: z.number().min(1).max(5).nullable(),
  notes: z.string().nullable(),
  created_at: z.string().datetime(),
});

// User streak schema
export const UserStreakSchema = z.object({
  id: z.string().uuid(),
  user_id: z.string().uuid(),
  current_streak: z.number().min(0),
  longest_streak: z.number().min(0),
  last_activity_date: z.string().datetime(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

// Achievement schema
export const AchievementSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  icon: z.string().optional(),
  unlockedAt: z.string().datetime().optional(),
  progress: z.number().min(0).max(100).optional(),
  isUnlocked: z.boolean().optional(),
});

// Progress stats schema
export const ProgressStatsSchema = z.object({
  totalCompleted: z.number().min(0),
  completedToday: z.number().min(0),
  completedThisWeek: z.number().min(0),
  completedThisMonth: z.number().min(0),
  categoryCounts: z.record(z.number()),
  difficultyBreakdown: z.record(z.number()),
  averageDifficulty: z.number(),
});

// Streak stats schema
export const StreakStatsSchema = z.object({
  currentStreak: z.number().min(0),
  longestStreak: z.number().min(0),
  totalActiveDays: z.number().min(0),
  lastActivityDate: z.string().datetime(),
  streakStartDate: z.string().datetime().optional(),
});

// Type exports
export type ValidatedUserProgress = z.infer<typeof UserProgressEntrySchema>;
export type ValidatedUserStreak = z.infer<typeof UserStreakSchema>;
export type ValidatedAchievement = z.infer<typeof AchievementSchema>;
export type ValidatedProgressStats = z.infer<typeof ProgressStatsSchema>;
export type ValidatedStreakStats = z.infer<typeof StreakStatsSchema>;
