/**
 * Lesson Validation Schemas
 * Zod schemas for runtime validation of lesson data
 */

import { z } from 'zod';

// Resource schema
export const ResourceSchema = z.object({
  type: z.enum(['link', 'video', 'article', 'tool', 'template']),
  title: z.string(),
  description: z.string().optional(),
  url: z.string().url().optional(),
  searchTopic: z.string().optional(),
});

// Step schema
export const StepSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  timeEstimate: z.number().optional(),
  type: z.string().optional(),
  checklist: z.object({
    items: z.array(z.object({
      id: z.string(),
      text: z.string(),
    })),
  }).optional(),
});

// Skill content schema
export const SkillContentSchema = z.object({
  overview: z.string(),
  keyPoints: z.array(z.string()),
  stepByStep: z.array(StepSchema),
  tips: z.array(z.string()),
  commonMistakes: z.array(z.string()),
  resources: z.array(ResourceSchema),
  stepResources: z.record(z.array(ResourceSchema)).optional(),
});

// LifeSkill schema
export const LifeSkillSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  category: z.enum([
    'money_mastery',
    'career_growth',
    'personal_growth',
    'life_skills',
    'health_wellness',
    'relationships',
    'home_living',
    'life_admin',
  ]),
  difficulty: z.enum(['starter', 'building', 'mastery']),
  estimatedTime: z.number(),
  xpReward: z.number(),
  tags: z.array(z.string()),
  content: SkillContentSchema,
  isUnlocked: z.boolean().optional(),
});

// Database lesson schema (from Supabase)
export const DatabaseLessonSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  category: z.string(),
  difficulty: z.string(),
  estimated_time: z.number().optional(),
  xp_reward: z.number().optional(),
  tags: z.array(z.string()).optional(),
  content: z.object({
    overview: z.string().optional(),
    keyPoints: z.array(z.string()).optional(),
    stepByStep: z.array(z.any()).optional(),
    tips: z.array(z.string()).optional(),
    resources: z.array(z.any()).optional(),
    commonMistakes: z.array(z.string()).optional(),
    stepResources: z.record(z.array(z.any())).optional(),
  }).optional(),
  is_unlocked: z.boolean().optional(),
  created_at: z.string(),
});

// Lesson array schema
export const LessonArraySchema = z.array(LifeSkillSchema);

// Type exports
export type ValidatedLifeSkill = z.infer<typeof LifeSkillSchema>;
export type ValidatedDatabaseLesson = z.infer<typeof DatabaseLessonSchema>;
export type ValidatedResource = z.infer<typeof ResourceSchema>;
