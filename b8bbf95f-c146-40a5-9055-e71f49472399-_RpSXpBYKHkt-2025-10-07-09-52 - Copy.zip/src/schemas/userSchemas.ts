/**
 * User Validation Schemas
 * Zod schemas for user profiles and preferences
 */

import { z } from 'zod';

// User preferences schema
export const UserPreferencesSchema = z.object({
  focusAreas: z.array(z.string()),
  learningStyle: z.enum(['visual', 'reading', 'hands_on']),
  timeCommitment: z.enum(['light', 'moderate', 'intensive']),
  reminderTime: z.string(),
  categories: z.array(z.string()).optional(),
  difficulty: z.string().optional(),
  notifications: z.boolean().optional(),
  aiTone: z.enum(['friendly', 'neutral', 'formal']).optional(),
  aiDepth: z.enum(['brief', 'detailed', 'comprehensive']).optional(),
  safetyMode: z.boolean().optional(),
});

// User profile schema
export const UserProfileSchema = z.object({
  id: z.string(),
  name: z.string(),
  age: z.number().min(18).max(100),
  currentLevel: z.number().min(1),
  totalXP: z.number().min(0),
  streak: z.number().min(0),
  lastActiveDate: z.string(),
  preferences: UserPreferencesSchema,
  completedSkills: z.array(z.string()),
  inProgressSkills: z.array(z.string()),
  savedSkills: z.array(z.string()),
  achievements: z.array(z.string()),
  goals: z.array(z.any()),
});

// Database profile schema
export const DatabaseProfileSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  username: z.string().nullable(),
  full_name: z.string().nullable(),
  avatar_url: z.string().url().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

// Type exports
export type ValidatedUserProfile = z.infer<typeof UserProfileSchema>;
export type ValidatedUserPreferences = z.infer<typeof UserPreferencesSchema>;
export type ValidatedDatabaseProfile = z.infer<typeof DatabaseProfileSchema>;
