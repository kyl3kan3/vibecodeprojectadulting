import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import type { UserProgress, UserStreak } from '../types/db';
import { AdultingTip } from '../types/adulting';
import { 
  userProgressService, 
  userStreakService, 
  realtimeService,
  type ProgressStats,
  type StreakStats,
  type ProgressChangePayload,
  type StreakChangePayload,
} from '../services/database';

export interface EnhancedProgressHook {
  // Basic data
  userProgress: UserProgress[];
  userStreak: UserStreak | null;
  loading: boolean;
  error: string | null;

  // Enhanced stats
  progressStats: ProgressStats | null;
  streakStats: StreakStats | null;

  // Actions
  markTipComplete: (tip: AdultingTip, difficultyRating?: number, notes?: string) => Promise<{ error: any }>;
  markMultipleTipsComplete: (tipIds: string[], notes?: string) => Promise<{ error: any }>;
  updateProgress: (progressId: string, updates: { notes?: string; difficulty_rating?: number }) => Promise<{ error: any }>;
  deleteProgress: (progressId: string) => Promise<{ error: any }>;
  resetStreak: () => Promise<{ error: any }>;

  // Utility functions
  getCompletedTipIds: () => string[];
  getTipProgress: (tipId: string) => UserProgress | undefined;
  getProgressStats: () => {
    completedTips: number;
    currentStreak: number;
    longestStreak: number;
  };
  
  // Data management
  refreshData: () => Promise<void>;
  exportProgress: () => Promise<{ data: any; error: any }>;
}

export const useSupabaseProgress = (): EnhancedProgressHook => {
  const { user } = useAuth();
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [userStreak, setUserStreak] = useState<UserStreak | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progressStats, setProgressStats] = useState<ProgressStats | null>(null);
  const [streakStats, setStreakStats] = useState<StreakStats | null>(null);

  // Keep track of realtime subscriptions
  const unsubscribeRef = useRef<(() => void) | null>(null);

  // Load all user data
  const loadUserData = useCallback(async () => {
    if (!user) {
      setUserProgress([]);
      setUserStreak(null);
      setProgressStats(null);
      setStreakStats(null);
      setLoading(false);
      setError(null);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Load progress data
      const progressResult = await userProgressService.getProgressHistory();
      if (progressResult.success && progressResult.data) {
        setUserProgress(progressResult.data.data);
      } else if (progressResult.error) {
        if (__DEV__) console.error('Error loading progress:', progressResult.error);
        setError(progressResult.error.message);
      }

      // Load streak data
      const streakResult = await userStreakService.getUserStreak();
      if (streakResult.success) {
        setUserStreak(streakResult.data);
      } else if (streakResult.error) {
        if (__DEV__) console.error('Error loading streak:', streakResult.error);
      }

      // Load progress statistics
      const statsResult = await userProgressService.getProgressStats();
      if (statsResult.success) {
        setProgressStats(statsResult.data);
      } else if (statsResult.error) {
        if (__DEV__) console.error('Error loading progress stats:', statsResult.error);
      }

      // Load streak statistics
      const streakStatsResult = await userStreakService.getStreakStats();
      if (streakStatsResult.success) {
        setStreakStats(streakStatsResult.data);
      } else if (streakStatsResult.error) {
        if (__DEV__) console.error('Error loading streak stats:', streakStatsResult.error);
      }

    } catch (error: any) {
      if (__DEV__) console.error('Error loading user data:', error);
      setError(error.message || 'Failed to load user data');
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Set up real-time subscriptions
  const setupRealtimeSubscriptions = useCallback(() => {
    if (!user) return;

    // Clean up existing subscriptions
    if (unsubscribeRef.current) {
      unsubscribeRef.current();
    }

    // Subscribe to all user data changes
    const unsubscribe = (realtimeService as any).subscribeToAllUserData(user.id, {
      onProgressChange: async (payload: ProgressChangePayload) => {
        if (__DEV__) console.log('Progress changed:', payload);
        
        if (payload.eventType === 'INSERT' && payload.new) {
          // Add new progress optimistically
          setUserProgress(prev => [payload.new, ...prev]);
          
          // Refresh stats
          const statsResult = await userProgressService.getProgressStats();
          if (statsResult.success) {
            setProgressStats(statsResult.data);
          }
        } else if (payload.eventType === 'UPDATE' && payload.new) {
          // Update existing progress
          setUserProgress(prev => 
            prev.map(p => p.id === payload.new.id ? payload.new : p)
          );
        } else if (payload.eventType === 'DELETE' && payload.old) {
          // Remove deleted progress
          setUserProgress(prev => 
            prev.filter(p => p.id !== payload.old.id)
          );
        }
      },

      onStreakChange: async (payload: StreakChangePayload) => {
        if (__DEV__) console.log('Streak changed:', payload);
        
        if (payload.new) {
          setUserStreak(payload.new);
          
          // Refresh streak stats
          const streakStatsResult = await userStreakService.getStreakStats();
          if (streakStatsResult.success) {
            setStreakStats(streakStatsResult.data);
          }
        }
      },
    });

    unsubscribeRef.current = unsubscribe;
  }, [user]);

  // Initialize data and subscriptions
  useEffect(() => {
    loadUserData();
    setupRealtimeSubscriptions();

    // Cleanup on unmount
    return () => {
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
    };
  }, [loadUserData, setupRealtimeSubscriptions]);

  // Mark tip as complete
  const markTipComplete = useCallback(async (
    tip: AdultingTip,
    difficultyRating?: number,
    notes?: string
  ) => {
    if (!user) return { error: new Error('User not authenticated') };

    try {
      // Optimistic update
      const optimisticProgress: UserProgress = {
        id: `temp-${Date.now()}`,
        user_id: user.id,
        tip_id: tip.id,
        completed_at: new Date().toISOString(),
        difficulty_rating: difficultyRating || null,
        notes: notes || null,
        created_at: new Date().toISOString(),
      };
      
      setUserProgress(prev => [optimisticProgress, ...prev]);

      // Make actual request
      const result = await userProgressService.markTipComplete(tip.id, difficultyRating, notes);
      
      if (result.success && result.data) {
        // Replace optimistic update with real data
        setUserProgress(prev => 
          prev.map(p => p.id === optimisticProgress.id ? result.data! : p)
        );

        // Update streak
        const streakResult = await userStreakService.updateStreakAfterCompletion();
        if (streakResult.success) {
          setUserStreak(streakResult.data);
        }

        return { error: null };
      } else {
        // Revert optimistic update
        setUserProgress(prev => 
          prev.filter(p => p.id !== optimisticProgress.id)
        );
        
        return { error: result.error };
      }
    } catch (error: any) {
      if (__DEV__) console.error('Error marking tip complete:', error);
      return { error };
    }
  }, [user]);

  // Mark multiple tips complete
  const markMultipleTipsComplete = useCallback(async (
    tipIds: string[],
    notes?: string
  ) => {
    if (!user) return { error: new Error('User not authenticated') };

    const result = await userProgressService.markMultipleTipsComplete(tipIds, notes);
    
    if (result.success) {
      // Refresh all data
      await loadUserData();
      return { error: null };
    }
    
    return { error: result.error };
  }, [user, loadUserData]);

  // Update existing progress
  const updateProgress = useCallback(async (
    progressId: string, 
    updates: { notes?: string; difficulty_rating?: number }
  ) => {
    const result = await userProgressService.updateProgress(progressId, updates);
    
    if (result.success && result.data) {
      // Update local state
      setUserProgress(prev => 
        prev.map(p => p.id === progressId ? result.data! : p)
      );
      return { error: null };
    }
    
    return { error: result.error };
  }, []);

  // Delete progress entry
  const deleteProgress = useCallback(async (progressId: string) => {
    const result = await userProgressService.deleteProgress(progressId);
    
    if (result.success) {
      // Remove from local state
      setUserProgress(prev => prev.filter(p => p.id !== progressId));
      return { error: null };
    }
    
    return { error: result.error };
  }, []);

  // Reset streak
  const resetStreak = useCallback(async () => {
    const result = await userStreakService.resetStreak();
    
    if (result.success) {
      setUserStreak(result.data);
      
      // Refresh streak stats
      const streakStatsResult = await userStreakService.getStreakStats();
      if (streakStatsResult.success) {
        setStreakStats(streakStatsResult.data);
      }
      
      return { error: null };
    }
    
    return { error: result.error };
  }, []);

  // Get completed tip IDs
  const getCompletedTipIds = useCallback((): string[] => {
    return (userProgress || []).map(progress => progress.tip_id);
  }, [userProgress]);

  // Get progress for specific tip
  const getTipProgress = useCallback((tipId: string): UserProgress | undefined => {
    return (userProgress || []).find(progress => progress.tip_id === tipId);
  }, [userProgress]);

  // Get basic progress stats (legacy compatibility)
  const getProgressStats = useCallback(() => {
    const completedTips = (userProgress || []).length;
    const currentStreak = userStreak?.current_streak || 0;
    const longestStreak = userStreak?.longest_streak || 0;

    return {
      completedTips,
      currentStreak,
      longestStreak,
    };
  }, [userProgress, userStreak]);

  // Export user progress data
  const exportProgress = useCallback(async () => {
    try {
      const result = await userProgressService.getProgressHistory({ limit: 1000 });
      
      if (result.success) {
        return {
          data: {
            progress: result.data?.data || [],
            streak: userStreak,
            stats: progressStats,
            exportedAt: new Date().toISOString(),
          },
          error: null,
        };
      }
      
      return { data: null, error: result.error };
    } catch (error: any) {
      return { data: null, error };
    }
  }, [userStreak, progressStats]);

  return {
    // Basic data
    userProgress,
    userStreak,
    loading,
    error,

    // Enhanced stats
    progressStats,
    streakStats,

    // Actions
    markTipComplete,
    markMultipleTipsComplete,
    updateProgress,
    deleteProgress,
    resetStreak,

    // Utility functions
    getCompletedTipIds,
    getTipProgress,
    getProgressStats,

    // Data management
    refreshData: loadUserData,
    exportProgress,
  };
};