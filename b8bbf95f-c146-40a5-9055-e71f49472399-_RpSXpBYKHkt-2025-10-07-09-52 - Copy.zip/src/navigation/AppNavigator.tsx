import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { Platform, View } from 'react-native';
import { Text } from 'react-native';
import { useUIStore } from '../state';
import { useAuth } from '../contexts/AuthContext';

// Import screens
import OnboardingScreen from '../screens/OnboardingScreen';
import HomeScreen from '../screens/HomeScreen';
import LearnScreen from '../screens/LearnScreen';
import CoachScreen from '../screens/CoachScreen';
import ProfileScreen from '../screens/ProfileScreen';
import SkillDetailScreen from '../screens/SkillDetailScreen';
import ProgressScreen from '../screens/ProgressScreen';
import StatsScreen from '../screens/StatsScreen';
import TipDetailScreen from '../screens/TipDetailScreen';

// Wrapper component for TipDetailScreen to handle navigation props
const TipDetailScreenWrapper = ({ route, navigation }: { route: any; navigation: any }) => {
  // Safe access to route params and navigation
  const tipId = route?.params?.tipId || null;
  const tip = route?.params?.tip || null;
  const onClose = () => {
    try {
      if (navigation && typeof navigation.goBack === 'function') {
        navigation.goBack();
      }
    } catch (error) {
      if (__DEV__) console.error('Navigation error:', error);
    }
  };
  
  return (
    <TipDetailScreen 
      tipId={tipId} 
      tip={tip}
      onClose={onClose} 
    />
  );
};
import CategoryScreen from '../screens/CategoryScreen';
import NotificationSettingsScreen from '../screens/NotificationSettingsScreen';
import CategoryPreferencesScreen from '../screens/CategoryPreferencesScreen';
import SavedTipsScreen from '../screens/SavedTipsScreen';
import SubscriptionSheet from '../screens/SubscriptionSheet';
import AccountSettingsScreen from '../screens/AccountSettingsScreen';
import DiagnosticsScreen from '../screens/DiagnosticsScreen';
import MigrationDebugScreen from '../screens/MigrationDebugScreen';
 import { AuthScreen } from '../screens/AuthScreen';
 import InteractiveLessonScreen from '../screens/InteractiveLessonScreen';
 import AchievementsScreen from '../screens/AchievementsScreen';
 import AIPreferencesScreen from '../screens/AIPreferencesScreen';
 import LearningPathScreen from '../screens/LearningPathScreen';
 import ProgressSyncScreen from '../screens/ProgressSyncScreen';
 
  export type RootStackParamList = {
  Auth: { greetingName?: string; mode?: "signin" | "signup" } | undefined;
  MainTabs: undefined;
  Onboarding: undefined;
  SkillDetail: { skillId: string };
  InteractiveLesson: { skillId?: string; tipId?: string; openResources?: boolean };
  TipDetail: { tipId: string };
  Category: { category: string };
  NotificationSettings: undefined;
  CategoryPreferences: undefined;
  SubscriptionSheet: undefined;
  AccountSettings: undefined;
  // Diagnostics: undefined; // Removed from production
  // MigrationDebug: undefined; // Removed from production
  SavedTips: undefined;
  Achievements: undefined;
  AIPreferences: undefined;
  LearningPath: { pathId: string };
  Progress: undefined;
  ProgressSync: undefined;
 };




export type TabParamList = {
  Home: undefined;
  Learn: undefined;
  Stats: undefined;
  Coach: undefined;
  Profile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Home':
              iconName = focused ? 'home' : 'home-outline';
              break;
            case 'Learn':
              iconName = focused ? 'library' : 'library-outline';
              break;
            case 'Stats':
              iconName = focused ? 'stats-chart' : 'stats-chart-outline';
              break;
            case 'Coach':
              iconName = focused ? 'chatbubble-ellipses' : 'chatbubble-ellipses-outline';
              break;
            case 'Profile':
              iconName = focused ? 'person-circle' : 'person-circle-outline';
              break;
            default:
              iconName = 'help-outline';
          }

          return (
            <View className="items-center justify-center">
              <Ionicons name={iconName} size={size} color={color} />
              {focused && (
                <View className="w-2 h-2 bg-emerald-500 rounded-full mt-1" />
              )}
            </View>
          );
        },
        tabBarActiveTintColor: '#10B981',
        tabBarInactiveTintColor: '#6B7280',
        tabBarStyle: {
          backgroundColor: '#111827',
          borderTopWidth: 1,
          borderTopColor: '#374151',
          paddingBottom: Platform.OS === 'ios' ? 25 : 8,
          paddingTop: 8,
          height: Platform.OS === 'ios' ? 90 : 65,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.3,
          shadowRadius: 10,
          elevation: 10,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
          marginTop: 2,
        },
        headerShown: false,
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeScreen}
      />
      <Tab.Screen 
        name="Learn" 
        component={LearnScreen}
      />
      <Tab.Screen 
        name="Stats" 
        component={StatsScreen}
      />
      <Tab.Screen 
        name="Coach" 
        component={CoachScreen}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
      />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { authCompleted, justSignedUpUserId } = useUIStore();
  const { user, loading } = useAuth();

  // Wait for session restoration to complete before making navigation decisions
  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#111827', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: '#10B981', fontSize: 18 }}>Loading...</Text>
      </View>
    );
  }

  // Gate: auth must complete at least once on device
  if (!authCompleted) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Auth" component={AuthScreen} />
      </Stack.Navigator>
    );
  }

  // If no active session, show Auth screen
  if (!user) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Auth" component={AuthScreen} />
      </Stack.Navigator>
    );
  }

  const shouldShowOnboarding = (justSignedUpUserId === user.id);

  // After auth, only show onboarding immediately after signup
  if (shouldShowOnboarding) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen 
          name="Onboarding" 
          component={OnboardingScreen}
          options={{ gestureEnabled: false }}
        />
      </Stack.Navigator>
    );
  }

  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        gestureEnabled: true,
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen name="MainTabs" component={TabNavigator} />
      <Stack.Screen 
        name="SkillDetail" 
        component={SkillDetailScreen}
        options={{
          presentation: 'modal',
          headerShown: false,
          gestureEnabled: true,
          animation: 'slide_from_bottom',
        }}
      />
      <Stack.Screen 
        name="InteractiveLesson" 
        component={InteractiveLessonScreen}
        options={{
          headerShown: false,
          gestureEnabled: true,
          animation: 'slide_from_right',
        }}
      />
      <Stack.Screen 
        name="TipDetail" 
        component={TipDetailScreenWrapper}
        options={{
          headerShown: true,
          headerTitle: '',
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerTintColor: '#374151',
          headerShadowVisible: false,
        }}
      />
      <Stack.Screen 
        name="Category" 
        component={CategoryScreen}
        options={{
          headerShown: true,
          headerTitle: '',
          headerStyle: {
            backgroundColor: 'transparent',
          },
          headerTintColor: '#374151',
          headerShadowVisible: false,
        }}
      />
      <Stack.Screen 
        name="NotificationSettings" 
        component={NotificationSettingsScreen}
        options={{
          headerShown: false,
          gestureEnabled: true,
        }}
      />
       <Stack.Screen 
        name="CategoryPreferences" 
        component={CategoryPreferencesScreen}
        options={{
          headerShown: false,
          gestureEnabled: true,
        }}
      />
      <Stack.Screen
        name="SubscriptionSheet"
        component={SubscriptionSheet}
        options={() =>
          Platform.OS === 'ios'
            ? {
                headerShown: false,
                presentation: 'formSheet',
                sheetAllowedDetents: [0.5, 0.9, 1],
                sheetInitialDetentIndex: 'last',
                sheetExpandsWhenScrolledToEdge: true,
                sheetGrabberVisible: true,
                contentStyle: { backgroundColor: '#111827' },
              }
            : {
                headerShown: false,
                presentation: 'modal',
                animation: 'slide_from_bottom',
                contentStyle: { backgroundColor: '#111827' },
              }
        }
      />
      <Stack.Screen 
        name="AccountSettings" 
        component={AccountSettingsScreen}
        options={{
          headerShown: true,
          headerTitle: "Account",
          headerTintColor: '#374151',
          headerStyle: { backgroundColor: 'transparent' },
          headerShadowVisible: false,
        }}
      />
      {/* Diagnostics screens removed from production */}
      {/* <Stack.Screen
        name="Diagnostics"
        component={DiagnosticsScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="MigrationDebug"
        component={MigrationDebugScreen}
      /> */}
      <Stack.Screen
        name="SavedTips"
        component={SavedTipsScreen}
        options={{ headerShown: false, presentation: 'card' }}
      />
       <Stack.Screen
        name="Achievements"
        component={AchievementsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="AIPreferences"
        component={AIPreferencesScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="LearningPath"
        component={LearningPathScreen}
        options={{
          headerShown: false,
          presentation: 'modal',
          animation: 'slide_from_bottom',
        }}
      />
      <Stack.Screen
        name="ProgressSync"
        component={ProgressSyncScreen}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
 }

