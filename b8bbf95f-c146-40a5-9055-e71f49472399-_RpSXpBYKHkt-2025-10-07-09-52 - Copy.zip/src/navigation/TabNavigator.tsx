import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { Platform } from 'react-native';

import DailyTipsScreen from '../screens/DailyTipsScreen';
import CatalogScreen from '../screens/CatalogScreen';
import ProgressScreen from '../screens/ProgressScreen';
import AskAIScreen from '../screens/AskAIScreen';
import ProfileScreen from '../screens/ProfileScreen';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === 'Daily Tips') {
            iconName = focused ? 'bulb' : 'bulb-outline';
          } else if (route.name === 'Catalog') {
            iconName = focused ? 'library' : 'library-outline';
          } else if (route.name === 'Progress') {
            iconName = focused ? 'checkmark-circle' : 'checkmark-circle-outline';
          } else if (route.name === 'Ask AI') {
            iconName = focused ? 'chatbubble' : 'chatbubble-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          } else {
            iconName = 'help-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: '#8E8E93',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 0.5,
          borderTopColor: '#E5E5EA',
          paddingBottom: Platform.OS === 'ios' ? 20 : 5,
          height: Platform.OS === 'ios' ? 85 : 65,
        },
        headerStyle: {
          backgroundColor: '#FFFFFF',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.1,
          shadowRadius: 3,
          elevation: 3,
        },
        headerTitleStyle: {
          fontWeight: '600',
          fontSize: 18,
        },
      })}
    >
      <Tab.Screen 
        name="Daily Tips" 
        component={DailyTipsScreen}
        options={{ headerTitle: 'Daily Tip' }}
      />
      <Tab.Screen 
        name="Catalog" 
        component={CatalogScreen}
        options={{ headerTitle: 'All Tips' }}
      />
      <Tab.Screen 
        name="Progress" 
        component={ProgressScreen}
        options={{ headerTitle: 'Your Progress' }}
      />
      <Tab.Screen 
        name="Ask AI" 
        component={AskAIScreen}
        options={{ headerTitle: 'Ask Coach' }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{ headerTitle: 'Profile' }}
      />
    </Tab.Navigator>
  );
}