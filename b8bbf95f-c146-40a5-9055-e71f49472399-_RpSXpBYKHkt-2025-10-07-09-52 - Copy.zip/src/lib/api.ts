import { supabaseMCP } from "./supabase-mcp";

// Unified DB access layer using the Vercel proxy only
export const db = {
  async getLessonById(id: string) {
    const res = await supabaseMCP.getLesson(id);
    return res;
  },

  async listLessons(limit = 50) {
    const res = await supabaseMCP.query('lessons', {
      select: 'id,title,category,difficulty,estimated_time,created_at',
      order: { column: 'created_at', direction: 'asc' },
      limit
    });
    return (res?.data || []) as any[];
  },

  async adminListLessons() {
    return await supabaseMCP.getAllLessons();
  },

  async adminGetLesson(id: string) {
    return await supabaseMCP.getLesson(id);
  },

  async adminUpdateLesson(id: string, updates: any) {
    return await supabaseMCP.updateLesson(id, updates);
  },
};
