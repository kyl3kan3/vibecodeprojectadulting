// MCP-style client for auth + database via Vercel AI proxy
// All requests go through the proxy; bearer token (if present) is attached
// Memory-only session management - no local storage persistence

interface SessionCache {
  user: any;
  validatedAt: number;
  token: string;
}

export class SupabaseMCPClient {
  private proxyUrl: string;
  private bypassToken: string;
  private token: string | null = null;
  private sessionCache: SessionCache | null = null;
  private readonly CACHE_DURATION_MS = 5 * 60 * 1000; // 5 minutes

  constructor() {
    this.proxyUrl = process.env.EXPO_PUBLIC_AI_PROXY_URL || '';
    this.bypassToken = process.env.EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS || '';
    
    // Proxy-only setup: All database operations route through the proxy
    // The proxy server has Supabase credentials configured server-side
    if (__DEV__ && !this.proxyUrl) {
      if (__DEV__) console.warn('⚠️ [Supabase] Missing EXPO_PUBLIC_AI_PROXY_URL in .env');
      if (__DEV__) console.warn('  Database operations will fail. Add proxy URL to .env file.');
    }
    
    // Initialize from memory only - no persistent storage
    try {
      const saved = (global as any).__AUTH_TOKEN__ as string | undefined;
      if (saved) this.token = saved;
    } catch {}
  }

  setToken(token: string | null) { 
    this.token = token; 
    (global as any).__AUTH_TOKEN__ = token;
    
    // Clear session cache when token changes
    if (!token || (this.sessionCache?.token !== token)) {
      this.sessionCache = null;
    }
  }

  private headers(extra?: Record<string, string>) {
    const h: Record<string, string> = { 'x-vercel-protection-bypass': this.bypassToken };
    const secret = process.env.EXPO_PUBLIC_PROXY_SECRET || '';
    if (secret) h['x-proxy-secret'] = secret;
    
    // Proxy-only setup: Supabase credentials are configured server-side on the proxy
    // No need to send them from the client
    
    // User auth token
    if (this.token) h['Authorization'] = `Bearer ${this.token}`;
    
    if (extra) Object.assign(h, extra);
    return h;
  }

  async query(table: string, options: {
    select?: string;
    filters?: Array<{ column: string; op: string; value: any }>;
    limit?: number;
    offset?: number;
    order?: { column: string; direction?: 'asc' | 'desc' };
  } = {}) {
    const { select = '*', filters = [], limit, offset, order } = options;
    
    // Use POST request with body (your proxy expects POST for all operations)
    const response = await fetch(`${this.proxyUrl}/api/db/query`, {
      method: 'POST',
      headers: this.headers({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        operation: 'select',
        table,
        select,
        filters,
        limit,
        offset,
        order,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      
      // Handle specific error cases
      if (response.status === 502) {
        throw new Error("Database temporarily unavailable. Please try again in a moment.");
      } else if (response.status === 503) {
        throw new Error("Database service temporarily unavailable. Please try again later.");
      } else if (response.status === 504) {
        throw new Error("Database request timeout. Please try again.");
      } else if (response.status === 429) {
        throw new Error("Too many database requests. Please wait a moment before trying again.");
      }
      
      throw new Error(`Database query failed: ${response.status} ${errorText}`);
    }

    return await response.json();
  }

  async update(table: string, data: any | any[], options: {
    onConflict?: string;
    returning?: 'minimal' | 'representation';
  } = {}) {
    const { onConflict, returning = 'representation' } = options;
    
    const dataArray = Array.isArray(data) ? data : [data];
    
    // Check if data has 'id' field - if so, don't use onConflict
    const hasId = dataArray.some(item => item.id);
    
    // Build the request payload
    const payload: any = {
      operation: 'upsert',
      table,
      data: dataArray,
      values: dataArray,  // Some proxies expect 'values' field
      returning
    };
    
    // Always include onConflict if provided
    // The proxy/Supabase will handle ID-based updates internally
    if (onConflict) {
      payload.onConflict = onConflict;
    }
    
    // Debug logging
    if (__DEV__) {
      if (__DEV__) console.log('📤 [Proxy Request]:', JSON.stringify({
        url: `${this.proxyUrl}/api/db/query`,
        method: 'POST',
        payload: payload,
        hasId: hasId
      }, null, 2));
    }
    
    const response = await fetch(`${this.proxyUrl}/api/db/query`, {
      method: 'POST',
      headers: this.headers({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      
      // Enhanced error logging
      if (__DEV__) {
        if (__DEV__) console.error('❌ [Proxy Response]:', JSON.stringify({
          status: response.status,
          statusText: response.statusText,
          error: errorText,
          table,
          operation: 'upsert'
        }, null, 2));
      }
      
      // Handle specific error cases
      if (response.status === 400) {
        throw new Error(`Bad request: ${errorText}. Check proxy configuration.`);
      } else if (response.status === 502) {
        throw new Error("Database temporarily unavailable. Please try again in a moment.");
      } else if (response.status === 503) {
        throw new Error("Database service temporarily unavailable. Please try again later.");
      } else if (response.status === 504) {
        throw new Error("Database request timeout. Please try again.");
      } else if (response.status === 429) {
        throw new Error("Too many database requests. Please wait a moment before trying again.");
      }
      
      throw new Error(`Database update failed: ${response.status} ${errorText}`);
    }

    return await response.json();
  }

  async delete(table: string, filters: Array<{ column: string; op: string; value: any }>) {
    const response = await fetch(`${this.proxyUrl}/api/db/query`, {
      method: 'POST',
      headers: this.headers({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        operation: 'delete',
        table,
        filters
      })
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      
      // Handle specific error cases
      if (response.status === 502) {
        throw new Error("Database temporarily unavailable. Please try again in a moment.");
      } else if (response.status === 503) {
        throw new Error("Database service temporarily unavailable. Please try again later.");
      } else if (response.status === 504) {
        throw new Error("Database request timeout. Please try again.");
      } else if (response.status === 429) {
        throw new Error("Too many database requests. Please wait a moment before trying again.");
      }
      
      throw new Error(`Database delete failed: ${response.status} ${errorText}`);
    }

    return await response.json();
  }

  // Specific methods for lessons
  async getLesson(id: string) {
    const result = await this.query('lessons', {
      select: '*',
      filters: [{ column: 'id', op: 'eq', value: id }],
      limit: 1
    });
    return result.data[0];
  }

  async updateLesson(id: string, updates: any) {
    return await this.update('lessons', {
      id,
      ...updates,
      updated_at: new Date().toISOString()
    });
  }

  async getAllLessons() {
    const result = await this.query('lessons', {
      select: 'id,title,category,difficulty'
    });
    return result.data;
  }

  async getLessonsByCategory(category: string) {
    const result = await this.query('lessons', {
      select: '*',
      filters: [{ column: 'category', op: 'eq', value: category }]
    });
    return result.data;
  }

  // Auth endpoints via proxy (flexible parsing)
  async authSignIn(email: string, password: string) {
    const res = await fetch(`${this.proxyUrl}/api/auth/sign-in`, {
      method: 'POST',
      headers: this.headers({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ email, password })
    });
    let json: any = null; try { json = await res.json(); } catch {}
    if (!res.ok) throw new Error(json?.error || `Auth sign-in failed: ${res.status}`);

    // Normalize token and user from multiple possible shapes
    const headerToken = res.headers.get('x-session-token');
    const token = json?.token || json?.access_token || json?.session?.token || json?.session?.access_token || headerToken || null;
    const refreshToken = json?.refresh_token || json?.session?.refresh_token || null;
    const user = json?.user || json?.session?.user || json?.data?.session?.user || null;

    if (!token || !user) {
      throw new Error('Missing session token');
    }
    this.setToken(token);
    // Store user data locally for session validation
    (global as any).__AUTH_USER__ = user;
    // Store refresh token if available
    if (refreshToken) {
      (global as any).__REFRESH_TOKEN__ = refreshToken;
      if (__DEV__) console.log('[SupabaseMCP] Refresh token available and stored');
    }
    return { token, user, refreshToken };
  }

  async authSignUp(email: string, password: string, fullName?: string) {
    const res = await fetch(`${this.proxyUrl}/api/auth/sign-up`, {
      method: 'POST',
      headers: this.headers({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ email, password, fullName })
    });
    let json: any = null; try { json = await res.json(); } catch {}
    if (!res.ok) throw new Error(json?.error || `Auth sign-up failed: ${res.status}`);

    const headerToken = res.headers.get('x-session-token');
    const token = json?.token || json?.access_token || json?.session?.token || json?.session?.access_token || headerToken || null;
    const user = json?.user || json?.session?.user || json?.data?.session?.user || null;

    if (token) {
      this.setToken(token);
      // Store user data locally for session validation
      if (user) (global as any).__AUTH_USER__ = user;
    }
    // It is valid for signup to require email confirmation -> user may be null
    return { token: token || null, user: user || null };
  }

  async authSignOut() {
    try {
      await fetch(`${this.proxyUrl}/api/auth/sign-out`, {
        method: 'POST',
        headers: this.headers()
      });
    } finally {
      this.setToken(null);
      // Clear stored user data on sign out
      (global as any).__AUTH_USER__ = null;
    }
    return { ok: true };
  }

  async authRefreshSession() {
    try {
      const refreshToken = (global as any).__REFRESH_TOKEN__;
      
      if (__DEV__) console.log('[SupabaseMCP] Attempting to refresh session token...', {
        hasRefreshToken: !!refreshToken
      });
      
      if (!refreshToken) {
        throw new Error('No refresh token available');
      }
      
      const res = await fetch(`${this.proxyUrl}/api/auth/refresh`, {
        method: 'POST',
        headers: this.headers({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ refresh_token: refreshToken })
      });
      
      let json: any = null; 
      try { json = await res.json(); } catch {}
      
      if (!res.ok) {
        throw new Error(json?.error || `Token refresh failed: ${res.status}`);
      }

      const headerToken = res.headers.get('x-session-token');
      const token = json?.token || json?.access_token || json?.session?.token || json?.session?.access_token || headerToken || null;
      const newRefreshToken = json?.refresh_token || json?.session?.refresh_token || refreshToken;
      const user = json?.user || json?.session?.user || json?.data?.session?.user || null;

      if (token && user) {
        this.setToken(token);
        (global as any).__AUTH_USER__ = user;
        (global as any).__REFRESH_TOKEN__ = newRefreshToken;
        if (__DEV__) console.log('[SupabaseMCP] ✅ Session refreshed successfully');
        return { token, user, refreshToken: newRefreshToken };
      } else {
        throw new Error('Refresh returned invalid session data');
      }
    } catch (error: any) {
      if (__DEV__) console.error('[SupabaseMCP] ❌ Session refresh failed:', error.message);
      throw error;
    }
  }

  private isCacheValid(): boolean {
    if (!this.sessionCache) return false;
    const now = Date.now();
    const isExpired = now - this.sessionCache.validatedAt > this.CACHE_DURATION_MS;
    const tokenMatches = this.sessionCache.token === this.token;
    return !isExpired && tokenMatches;
  }

  // Simplified method - no longer used with current approach but kept for potential future use
  async validateTokenViaQuery(): Promise<boolean> {
    if (!this.token) return false;
    
    try {
      // Simple query to test if token is valid
      await this.query('profiles', { select: 'count', limit: 1 });
      return true;
    } catch (error: any) {
      if (__DEV__) console.log('[SupabaseMCP] validateTokenViaQuery - token validation failed:', error.message);
      return false;
    }
  }

  async authGetSession() {
    if (__DEV__) console.log('[SupabaseMCP] authGetSession called - checking memory state');
    
    if (!this.token) {
      if (__DEV__) console.log('[SupabaseMCP] authGetSession - no token available');
      return null;
    }

    // Check if we have stored user data from sign-in
    const storedUser = (global as any).__AUTH_USER__;
    if (!storedUser) {
      if (__DEV__) console.log('[SupabaseMCP] authGetSession - token exists but no stored user data');
      return null;
    }

    // For now, trust the memory state without additional validation
    // This avoids the database validation chicken-and-egg problem
    const result = { token: this.token, user: storedUser };
    if (__DEV__) console.log('[SupabaseMCP] authGetSession - returning session from memory state');
    return result;
  }
}


// Export singleton instance
export const supabaseMCP = new SupabaseMCPClient();
