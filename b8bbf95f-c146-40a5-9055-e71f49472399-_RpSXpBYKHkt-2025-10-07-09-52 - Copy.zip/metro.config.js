// Learn more https://docs.expo.io/guides/customizing-metro
const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

// iOS deployment optimizations
config.resolver.useWatchman = false;
config.resolver.platforms = ['ios', 'android', 'web'];

// Enable hermes for better performance
config.transformer.hermesCommand = 'hermes';

// Optimization for iOS builds
config.transformer.minifierConfig = {
  mangle: {
    keep_fnames: true,
  },
  output: {
    ascii_only: true,
    quote_keys: true,
    wrap_iife: true,
  },
  sourceMap: {
    includeSources: false,
  },
  toplevel: false,
  warnings: false,
};

module.exports = withNativeWind(config, { input: './global.css' });
