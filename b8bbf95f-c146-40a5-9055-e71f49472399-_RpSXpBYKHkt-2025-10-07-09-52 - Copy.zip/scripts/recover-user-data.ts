/**
 * Data Recovery Script
 * Checks AsyncStorage for user data and attempts recovery
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
  progress: 'project-adulting-progress-store',
  lessons: 'project-adulting-lessons-store',
  auth: 'project-adulting-auth-store',
  tips: 'project-adulting-tips-store',
  ui: 'project-adulting-ui-store',
};

export async function checkStoredData() {
  console.log('🔍 Checking AsyncStorage for user data...\n');
  
  const results: Record<string, any> = {};
  
  for (const [name, key] of Object.entries(STORAGE_KEYS)) {
    try {
      const data = await AsyncStorage.getItem(key);
      if (data) {
        const parsed = JSON.parse(data);
        results[name] = parsed;
        
        // Log key info
        if (name === 'progress') {
          console.log(`✅ PROGRESS DATA FOUND:`);
          console.log(`   - Streak: ${parsed.state?.userProgress?.streak || 0}`);
          console.log(`   - Total XP: ${parsed.state?.totalXP || 0}`);
          console.log(`   - Completed Tips: ${parsed.state?.userProgress?.completedTips?.length || 0}`);
        } else if (name === 'lessons') {
          console.log(`✅ LESSONS DATA FOUND:`);
          console.log(`   - Skills loaded: ${parsed.state?.skills?.length || 0}`);
          console.log(`   - Completed skills: ${parsed.state?.completedSkills?.length || 0}`);
          const progressCount = Object.keys(parsed.state?.skillProgress || {}).length;
          console.log(`   - Skills with progress: ${progressCount}`);
        } else {
          console.log(`✅ ${name.toUpperCase()} DATA FOUND`);
        }
      } else {
        console.log(`❌ ${name.toUpperCase()}: No data found`);
      }
    } catch (error) {
      console.log(`❌ ${name.toUpperCase()}: Error reading - ${error}`);
    }
  }
  
  console.log('\n');
  return results;
}

export async function backupAllData() {
  console.log('💾 Creating backup of all data...\n');
  
  const backup: Record<string, any> = {};
  const timestamp = new Date().toISOString();
  
  for (const [name, key] of Object.entries(STORAGE_KEYS)) {
    try {
      const data = await AsyncStorage.getItem(key);
      if (data) {
        backup[key] = JSON.parse(data);
      }
    } catch (error) {
      console.log(`⚠️  Failed to backup ${name}:`, error);
    }
  }
  
  // Save backup with timestamp
  const backupKey = `backup-${timestamp}`;
  await AsyncStorage.setItem(backupKey, JSON.stringify(backup));
  
  console.log(`✅ Backup saved as: ${backupKey}\n`);
  return backupKey;
}

export async function restoreFromBackup(backupKey: string) {
  console.log(`🔄 Restoring from backup: ${backupKey}...\n`);
  
  try {
    const backupData = await AsyncStorage.getItem(backupKey);
    if (!backupData) {
      console.log('❌ Backup not found');
      return false;
    }
    
    const backup = JSON.parse(backupData);
    
    for (const [key, data] of Object.entries(backup)) {
      await AsyncStorage.setItem(key as string, JSON.stringify(data));
      console.log(`✅ Restored: ${key}`);
    }
    
    console.log('\n✅ Restore complete! Reload the app to see your data.\n');
    return true;
  } catch (error) {
    console.log('❌ Restore failed:', error);
    return false;
  }
}

export async function listBackups() {
  console.log('📋 Available backups:\n');
  
  try {
    const allKeys = await AsyncStorage.getAllKeys();
    const backupKeys = allKeys.filter(key => key.startsWith('backup-'));
    
    if (backupKeys.length === 0) {
      console.log('No backups found\n');
      return [];
    }
    
    for (const key of backupKeys) {
      const timestamp = key.replace('backup-', '');
      console.log(`  - ${timestamp}`);
    }
    
    console.log('\n');
    return backupKeys;
  } catch (error) {
    console.log('❌ Error listing backups:', error);
    return [];
  }
}

// Quick recovery helper
export async function quickRecovery() {
  console.log('🚑 QUICK RECOVERY MODE\n');
  console.log('='.repeat(50) + '\n');
  
  // Step 1: Check current data
  const currentData = await checkStoredData();
  
  // Step 2: Check if progress data exists
  const progressData = currentData.progress?.state;
  
  if (progressData) {
    const streak = progressData.userProgress?.streak || 0;
    const xp = progressData.totalXP || 0;
    const completedTips = progressData.userProgress?.completedTips?.length || 0;
    
    console.log('📊 CURRENT STATE:');
    console.log(`   Streak: ${streak} days`);
    console.log(`   XP: ${xp}`);
    console.log(`   Completed Tips: ${completedTips}\n`);
    
    if (streak === 0 && xp === 0 && completedTips === 0) {
      console.log('⚠️  WARNING: All progress appears to be reset!\n');
      
      // Check for backups
      const backups = await listBackups();
      if (backups.length > 0) {
        console.log('💡 TIP: You have backups available. Use restoreFromBackup() to recover.\n');
      }
    } else {
      console.log('✅ Your data appears to be intact!\n');
    }
  } else {
    console.log('❌ No progress data found in storage\n');
  }
  
  console.log('='.repeat(50) + '\n');
}
