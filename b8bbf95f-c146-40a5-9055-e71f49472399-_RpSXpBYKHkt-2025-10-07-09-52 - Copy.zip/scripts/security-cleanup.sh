#!/bin/bash

# Security Cleanup Script
# Automates the critical security fixes needed after removing exposed secrets

set -e  # Exit on error

echo "🔒 Security Cleanup Script"
echo "=========================="
echo ""

# Step 1: Remove .env from git tracking
echo "Step 1: Removing .env from git tracking..."
if git ls-files .env 2>/dev/null | grep -q .env; then
    git rm --cached .env
    echo "✅ .env removed from git tracking"
else
    echo "✅ .env already not tracked"
fi

# Step 2: Create secure .env template
echo ""
echo "Step 2: Creating secure .env file..."
cat > .env << 'EOF'
# Environment Variables (Secure Configuration)
# Only public values - NO SECRETS!

# Your Vercel proxy URL (public, safe)
EXPO_PUBLIC_AI_PROXY_URL=https://your-vercel-app.vercel.app

# Admin emails
EXPO_PUBLIC_ADMIN_EMAILS=kyl3kan3@gmail.com

# In-App Purchase IDs (from App Store Connect)
EXPO_PUBLIC_IAP_PRODUCT_IDS=com.yourapp.pro.monthly,com.yourapp.pro.yearly
EXPO_PUBLIC_IAP_GROUP_ID=your_group_id

# Account deletion webhook (optional)
# EXPO_PUBLIC_ACCOUNT_DELETION_WEBHOOK_URL=https://your-webhook.com/delete
EOF

echo "✅ Created secure .env template"
echo "⚠️  Please update the values in .env with your actual configuration"

# Step 3: Create .env.example for repository
echo ""
echo "Step 3: Creating .env.example for repository..."
cp .env .env.example
echo "✅ Created .env.example"

# Step 4: Commit changes
echo ""
echo "Step 4: Committing security fixes..."
git add .gitignore src/api/openai.ts src/api/grok.ts src/api/proxy.ts src/lib/supabase-mcp.ts src/api/providers-health.ts .env.example
git status

read -p "Commit these changes? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    git commit -m "🔒 CRITICAL SECURITY FIX: Remove exposed API keys and secrets

- Remove EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY (exposed in app bundle)
- Remove EXPO_PUBLIC_VIBECODE_GROK_API_KEY (exposed in app bundle)  
- Remove EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS (exposed in app bundle)
- Remove EXPO_PUBLIC_PROXY_SECRET (exposed in app bundle)
- Deprecate direct API client functions (openai.ts, grok.ts)
- Update proxy to use user authentication only
- Add .env to .gitignore
- Create .env.example template

BREAKING CHANGE: Vercel proxy must be updated to validate user tokens
instead of app-level secrets. API keys must be rotated."
    
    echo "✅ Changes committed"
    
    # Step 5: Push to main
    echo ""
    read -p "Push to main? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        git push origin main
        echo "✅ Pushed to main"
    fi
else
    echo "⚠️  Skipped commit"
fi

# Summary
echo ""
echo "=========================="
echo "🎯 Next Steps Required:"
echo "=========================="
echo ""
echo "1. UPDATE VERCEL PROXY CODE"
echo "   - Remove dependency on x-proxy-secret and x-vercel-protection-bypass"
echo "   - Validate Supabase user tokens instead"
echo "   - See SECURITY_IMPLEMENTATION_COMPLETE.md for example code"
echo ""
echo "2. ROTATE API KEYS (Old ones were exposed)"
echo "   - OpenAI: https://platform.openai.com/api-keys"
echo "   - Grok: https://console.x.ai/"
echo "   - Update environment variables in Vercel dashboard"
echo ""
echo "3. UPDATE .ENV FILE"
echo "   - Edit .env with your actual proxy URL and settings"
echo "   - Verify no secrets are in the file"
echo ""
echo "4. TEST THE APP"
echo "   - Verify authentication still works"
echo "   - Check AI features function correctly"
echo "   - Monitor Vercel logs for errors"
echo ""
echo "✅ Security cleanup complete!"

