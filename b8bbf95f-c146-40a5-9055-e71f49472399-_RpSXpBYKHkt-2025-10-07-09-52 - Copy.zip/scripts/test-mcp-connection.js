#!/usr/bin/env node

// Test script to verify Supabase MCP connection
const { spawn } = require('child_process');

console.log('🧪 Testing Supabase MCP Connection...\n');

const mcpProcess = spawn('node', [
  './node_modules/@supabase/mcp-server-supabase/dist/transports/stdio.js',
  '--read-only',
  '--project-ref=fhllozktjqvqfedlmhqm'
], {
  env: {
    ...process.env,
    SUPABASE_ACCESS_TOKEN: 'sbp_73b465318fbc8c81d7780d1e8e0c7848c0d681c4'
  },
  stdio: ['pipe', 'pipe', 'pipe']
});

let output = '';
let errorOutput = '';

mcpProcess.stdout.on('data', (data) => {
  output += data.toString();
});

mcpProcess.stderr.on('data', (data) => {
  errorOutput += data.toString();
});

mcpProcess.on('close', (code) => {
  console.log(`Exit code: ${code}`);
  if (output) {
    console.log('Output:', output);
  }
  if (errorOutput) {
    console.log('Error:', errorOutput);
  }
  
  if (code === 0) {
    console.log('✅ MCP server started successfully!');
    console.log('📝 Note: You need to restart Cursor to use MCP tools');
  } else {
    console.log('❌ MCP server failed to start');
  }
});

// Send a test request
setTimeout(() => {
  const testRequest = {
    jsonrpc: "2.0",
    id: 1,
    method: "tools/list"
  };
  
  mcpProcess.stdin.write(JSON.stringify(testRequest) + '\n');
  
  setTimeout(() => {
    mcpProcess.kill();
  }, 2000);
}, 1000);
