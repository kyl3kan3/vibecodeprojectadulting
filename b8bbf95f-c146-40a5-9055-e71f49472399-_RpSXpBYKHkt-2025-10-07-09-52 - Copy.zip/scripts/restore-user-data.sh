#!/bin/bash

# User Data Restoration Script
# Helps restore your progress data after Phase 1 migration

echo "🔄 User Data Restoration Helper"
echo "================================"
echo ""
echo "This script will help you restore your progress data."
echo ""

# Step 1: Reset migration flag
echo "Step 1: Resetting migration flag..."
echo "This will allow the migration to run again and restore your old data."
echo ""

read -p "Reset migration flag? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npm run reset:migration
    echo "✅ Migration flag reset"
    echo ""
    echo "📱 IMPORTANT: Restart your app now!"
    echo "The migration will run automatically and restore:"
    echo "  - Completed skills count"
    echo "  - Skill progress (checkmarks, etc.)"
    echo "  - Total XP"
    echo "  - User profile data"
    echo ""
else
    echo "⚠️  Skipped migration reset"
fi

# Step 2: Check current storage
echo ""
echo "Step 2: Checking current AsyncStorage data..."
echo ""

read -p "Check storage data? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npm run check:storage
fi

echo ""
echo "================================"
echo "✅ Restoration helper complete"
echo ""
echo "Next steps:"
echo "1. Restart your app"
echo "2. Check console for migration logs"
echo "3. Verify your progress is restored"
echo ""
echo "If data is still missing, check console for:"
echo "  🔄 [Migration] Starting data migration..."
echo "  ✅ [Migration] Migrated lessons data: {...}"
echo "  💾 [LessonsStore] Preserved user progress: {...}"

