/**
 * Reset Migration Script
 * Run this to force the data migration to run again
 * 
 * Usage: npx ts-node scripts/reset-migration.ts
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

async function resetMigration() {
  try {
    console.log('🔄 Resetting migration flag...');
    
    await AsyncStorage.removeItem('phase1-migration-complete');
    
    console.log('✅ Migration flag reset!');
    console.log('📱 Restart your app to trigger the migration again.');
    
    // Show what's in storage
    const oldStore = await AsyncStorage.getItem('project-adulting-store');
    if (oldStore) {
      const parsed = JSON.parse(oldStore);
      const state = parsed.state || {};
      console.log('\n📦 Old store data available:');
      console.log('  - Skills:', state.skills?.length || 0);
      console.log('  - Completed:', state.completedSkills?.length || 0);
      console.log('  - Total XP:', state.totalXP || 0);
      console.log('  - User name:', state.userProfile?.name || state.user?.name || 'Not set');
      console.log('  - Streak:', state.userProgress?.streak || state.userProgress?.streakDays || 0);
    } else {
      console.log('\n⚠️  No old store data found');
    }
  } catch (error) {
    console.error('❌ Error resetting migration:', error);
  }
}

resetMigration();

