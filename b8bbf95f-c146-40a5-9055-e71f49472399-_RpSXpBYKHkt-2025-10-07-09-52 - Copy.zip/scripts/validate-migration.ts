/**
 * Migration Validation Script
 * Run this after each major step to ensure app integrity
 */

import * as fs from 'fs';
import * as path from 'path';

interface ValidationResult {
  step: string;
  passed: boolean;
  errors: string[];
  warnings: string[];
}

class MigrationValidator {
  private results: ValidationResult[] = [];
  private srcPath = path.join(__dirname, '..', 'src');

  // Check if TypeScript compiles without errors
  async checkTypeScript(): Promise<ValidationResult> {
    console.log('\n📋 Checking TypeScript...');
    const { execSync } = require('child_process');
    const result: ValidationResult = {
      step: 'TypeScript Check',
      passed: true,
      errors: [],
      warnings: []
    };

    try {
      execSync('npm run typecheck', { stdio: 'pipe' });
      console.log('✅ TypeScript: No errors');
    } catch (error: any) {
      result.passed = false;
      result.errors.push('TypeScript compilation failed');
      result.errors.push(error.stdout?.toString() || error.message);
      console.log('❌ TypeScript: Errors found');
    }

    return result;
  }

  // Check for old unified-store imports
  async checkLegacyImports(): Promise<ValidationResult> {
    console.log('\n📋 Checking for legacy imports...');
    const result: ValidationResult = {
      step: 'Legacy Imports Check',
      passed: true,
      errors: [],
      warnings: []
    };

    const { execSync } = require('child_process');
    
    try {
      const output = execSync(
        `grep -r "from.*unified-store" ${this.srcPath} --exclude-dir=__tests__ --exclude=*.backup.ts || true`,
        { encoding: 'utf-8' }
      );

      if (output.trim()) {
        const files = output.split('\n').filter(Boolean);
        result.warnings.push(`Found ${files.length} files still using unified-store:`);
        files.forEach((file: string) => result.warnings.push(`  - ${file}`));
        console.log(`⚠️  Found ${files.length} legacy imports (may be OK if intentional)`);
      } else {
        console.log('✅ No legacy imports found');
      }
    } catch (error: any) {
      result.errors.push(`Error checking imports: ${error.message}`);
    }

    return result;
  }

  // Verify all new stores exist
  async checkNewStores(): Promise<ValidationResult> {
    console.log('\n📋 Checking new stores...');
    const result: ValidationResult = {
      step: 'New Stores Check',
      passed: true,
      errors: [],
      warnings: []
    };

    const requiredStores = [
      'lessons-store.ts',
      'progress-store.ts',
      'ai-store.ts',
      'ui-store.ts',
      'tips-store.ts',
      'index.ts'
    ];

    const statePath = path.join(this.srcPath, 'state');

    for (const store of requiredStores) {
      const storePath = path.join(statePath, store);
      if (fs.existsSync(storePath)) {
        console.log(`✅ ${store} exists`);
      } else {
        result.passed = false;
        result.errors.push(`Missing store: ${store}`);
        console.log(`❌ ${store} not found`);
      }
    }

    return result;
  }

  // Check store exports
  async checkStoreExports(): Promise<ValidationResult> {
    console.log('\n📋 Checking store exports...');
    const result: ValidationResult = {
      step: 'Store Exports Check',
      passed: true,
      errors: [],
      warnings: []
    };

    const indexPath = path.join(this.srcPath, 'state', 'index.ts');
    
    if (!fs.existsSync(indexPath)) {
      result.passed = false;
      result.errors.push('index.ts not found in src/state/');
      return result;
    }

    const content = fs.readFileSync(indexPath, 'utf-8');
    const requiredExports = [
      'useLessonsStore',
      'useProgressStore',
      'useAIStore',
      'useUIStore',
      'useTipsStore'
    ];

    for (const exportName of requiredExports) {
      if (content.includes(exportName)) {
        console.log(`✅ ${exportName} exported`);
      } else {
        result.errors.push(`Missing export: ${exportName}`);
        console.log(`❌ ${exportName} not exported`);
      }
    }

    return result;
  }

  // Check for circular dependencies
  async checkCircularDeps(): Promise<ValidationResult> {
    console.log('\n📋 Checking for circular dependencies...');
    const result: ValidationResult = {
      step: 'Circular Dependencies Check',
      passed: true,
      errors: [],
      warnings: []
    };

    // This is a simplified check - you might want to use madge or similar tool
    const { execSync } = require('child_process');
    
    try {
      // Check if madge is installed
      execSync('which madge', { stdio: 'pipe' });
      
      const output = execSync(
        `madge --circular ${this.srcPath}`,
        { encoding: 'utf-8' }
      );

      if (output.includes('✖')) {
        result.passed = false;
        result.errors.push('Circular dependencies detected');
        result.errors.push(output);
        console.log('❌ Circular dependencies found');
      } else {
        console.log('✅ No circular dependencies');
      }
    } catch (error: any) {
      result.warnings.push('madge not installed - skipping circular dependency check');
      result.warnings.push('Install with: npm install -g madge');
      console.log('⚠️  Skipping circular dependency check (madge not installed)');
    }

    return result;
  }

  // Validate store structure
  async validateStoreStructure(storeName: string): Promise<ValidationResult> {
    console.log(`\n📋 Validating ${storeName} structure...`);
    const result: ValidationResult = {
      step: `${storeName} Structure Validation`,
      passed: true,
      errors: [],
      warnings: []
    };

    const storePath = path.join(this.srcPath, 'state', `${storeName}.ts`);
    
    if (!fs.existsSync(storePath)) {
      result.passed = false;
      result.errors.push(`${storeName} not found`);
      return result;
    }

    const content = fs.readFileSync(storePath, 'utf-8');

    // Check for required patterns
    const requiredPatterns = [
      { pattern: /import.*zustand/, name: 'Zustand import' },
      { pattern: /interface \w+State/, name: 'State interface' },
      { pattern: /create<\w+>/, name: 'Store creation' },
      { pattern: /persist/, name: 'Persistence middleware' },
    ];

    for (const { pattern, name } of requiredPatterns) {
      if (pattern.test(content)) {
        console.log(`✅ ${name} found`);
      } else {
        result.warnings.push(`${name} not found in ${storeName}`);
        console.log(`⚠️  ${name} not found`);
      }
    }

    return result;
  }

  // Run all validations
  async runAll(): Promise<void> {
    console.log('\n🚀 Starting Migration Validation...\n');
    console.log('='.repeat(50));

    this.results.push(await this.checkTypeScript());
    this.results.push(await this.checkNewStores());
    this.results.push(await this.checkStoreExports());
    this.results.push(await this.checkLegacyImports());
    this.results.push(await this.checkCircularDeps());

    // Validate individual stores if they exist
    const stores = ['lessons-store', 'progress-store', 'ai-store', 'ui-store', 'tips-store'];
    for (const store of stores) {
      const storePath = path.join(this.srcPath, 'state', `${store}.ts`);
      if (fs.existsSync(storePath)) {
        this.results.push(await this.validateStoreStructure(store));
      }
    }

    // Print summary
    this.printSummary();
  }

  private printSummary(): void {
    console.log('\n' + '='.repeat(50));
    console.log('\n📊 Validation Summary:\n');

    const passed = this.results.filter(r => r.passed).length;
    const failed = this.results.filter(r => !r.passed).length;
    const totalWarnings = this.results.reduce((sum, r) => sum + r.warnings.length, 0);
    const totalErrors = this.results.reduce((sum, r) => sum + r.errors.length, 0);

    console.log(`✅ Passed: ${passed}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`⚠️  Warnings: ${totalWarnings}`);
    console.log(`🚨 Errors: ${totalErrors}`);

    if (failed > 0) {
      console.log('\n❌ VALIDATION FAILED - Details:\n');
      this.results
        .filter(r => !r.passed)
        .forEach(r => {
          console.log(`\n${r.step}:`);
          r.errors.forEach(e => console.log(`  ❌ ${e}`));
        });
      process.exit(1);
    }

    if (totalWarnings > 0) {
      console.log('\n⚠️  WARNINGS - Review these:\n');
      this.results.forEach(r => {
        if (r.warnings.length > 0) {
          console.log(`\n${r.step}:`);
          r.warnings.forEach(w => console.log(`  ⚠️  ${w}`));
        }
      });
    }

    if (failed === 0) {
      console.log('\n✅ All validations passed!');
      console.log('\n🎉 Safe to proceed to next migration step\n');
    }
  }
}

// Run validation
const validator = new MigrationValidator();
validator.runAll().catch(error => {
  console.error('\n🚨 Validation script error:', error);
  process.exit(1);
});
