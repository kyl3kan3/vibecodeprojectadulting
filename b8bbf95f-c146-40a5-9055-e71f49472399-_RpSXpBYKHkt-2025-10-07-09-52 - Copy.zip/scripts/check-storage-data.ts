/**
 * Check AsyncStorage Data
 * Debug script to see what's actually stored
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

async function checkStorageData() {
  try {
    console.log('🔍 Checking AsyncStorage data...\n');
    
    // Check all keys
    const allKeys = await AsyncStorage.getAllKeys();
    console.log(`📦 Total keys in storage: ${allKeys.length}`);
    console.log('Keys:', allKeys);
    console.log('');
    
    // Check old unified store
    const oldStore = await AsyncStorage.getItem('project-adulting-store');
    if (oldStore) {
      const parsed = JSON.parse(oldStore);
      const state = parsed.state || {};
      console.log('📚 OLD STORE (project-adulting-store):');
      console.log('  - Skills:', state.skills?.length || 0);
      console.log('  - Completed Skills:', state.completedSkills?.length || 0);
      console.log('  - Total XP:', state.totalXP || 0);
      console.log('  - User name:', state.userProfile?.name || 'Not set');
      console.log('  - Streak:', state.userProgress?.streak || 0);
      console.log('');
    } else {
      console.log('❌ OLD STORE (project-adulting-store): NOT FOUND');
      console.log('');
    }
    
    // Check new lesson store
    const lessonsStore = await AsyncStorage.getItem('project-adulting-lessons-store');
    if (lessonsStore) {
      const parsed = JSON.parse(lessonsStore);
      const state = parsed.state || {};
      console.log('📚 NEW LESSONS STORE:');
      console.log('  - Skills:', state.skills?.length || 0);
      console.log('  - Completed Skills:', state.completedSkills?.length || 0);
      console.log('');
    } else {
      console.log('❌ NEW LESSONS STORE: NOT FOUND');
      console.log('');
    }
    
    // Check new progress store
    const progressStore = await AsyncStorage.getItem('project-adulting-progress-store');
    if (progressStore) {
      const parsed = JSON.parse(progressStore);
      const state = parsed.state || {};
      console.log('📊 NEW PROGRESS STORE:');
      console.log('  - Total XP:', state.totalXP || 0);
      console.log('  - Achievements:', state.achievements?.length || 0);
      console.log('  - Streak:', state.userProgress?.streak || 0);
      console.log('');
    } else {
      console.log('❌ NEW PROGRESS STORE: NOT FOUND');
      console.log('');
    }
    
    // Check migration flag
    const migrationComplete = await AsyncStorage.getItem('phase1-migration-complete');
    console.log('🏁 Migration Status:', migrationComplete === 'true' ? '✅ COMPLETE' : '❌ NOT RUN');
    
  } catch (error) {
    console.error('❌ Error checking storage:', error);
  }
}

checkStorageData();

