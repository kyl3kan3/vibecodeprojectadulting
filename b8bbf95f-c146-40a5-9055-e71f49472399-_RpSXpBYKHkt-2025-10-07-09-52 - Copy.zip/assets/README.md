# Adulting Coach App Assets

## Required Assets for iOS Deployment

### App Icon (icon.png)
- **Size**: 1024x1024px
- **Format**: PNG
- **Design**: Modern app icon featuring a graduation cap or lightbulb symbol
- **Colors**: Warm amber (#F59E0B) and professional slate (#0F172A)
- **Style**: Clean, friendly, trustworthy design for young adults

### Splash Screen (splash.png)
- **Size**: 1536x1024px (landscape) or 1024x1536px (portrait)
- **Format**: PNG
- **Design**: Gradient background in warm amber with central logo
- **Style**: Clean, modern, welcoming design

### Adaptive Icon (adaptive-icon.png)
- **Size**: 1024x1024px
- **Format**: PNG
- **Design**: Core symbol (graduation cap/lightbulb) on transparent background
- **Style**: Minimal design for Android adaptive icons

### Favicon (favicon.png)
- **Size**: 512x512px
- **Format**: PNG
- **Design**: Simplified version of the main app icon

## Notes
- All icons should be clean, modern, and appropriate for young adults (18-30)
- Colors should match the app's amber (#F59E0B) and slate (#0F172A) theme
- Icons should be legible at small sizes
- No text should be included in the icon designs