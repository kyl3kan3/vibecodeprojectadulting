#!/bin/bash

# === Build & Publish to TestFlight (non-interactive) ===
# Prereqs: `npm i -g eas-cli` and you're logged into Expo (`eas login`).
# Uses App Store Connect API key (recommended for CI). Nothing sensitive is committed.

set -euo pipefail

# ---- Fill these in (or export them in your shell profile/CI) ----
export ASC_KEY_ID="YOUR_ASC_KEY_ID"                      # App Store Connect Key ID
export ASC_ISSUER_ID="YOUR_ASC_ISSUER_ID"                # App Store Connect Issuer ID
export ASC_APP_ID="YOUR_ASC_APP_ID"                      # Your App Store Connect App ID (numeric)
export APPLE_TEAM_ID="YOUR_APPLE_TEAM_ID"                # Your Apple Team ID

# Paste your .p8 private key into the multiline var below OR set ASC_API_PRIVATE_KEY in your env.
export ASC_API_PRIVATE_KEY="$(cat <<'EOF'
-----BEGIN PRIVATE KEY-----
# <paste your AuthKey_*.p8 contents here>
-----END PRIVATE KEY-----
EOF
)"

# Write the .p8 key to a local file (ignored by git)
KEY_FILE="AuthKey_${ASC_KEY_ID}.p8"
printf "%s" "$ASC_API_PRIVATE_KEY" > "$KEY_FILE"
chmod 600 "$KEY_FILE"
echo "✅ Wrote ASC key to $KEY_FILE (gitignore this file)."

# 1) Production iOS build (wait until finished)
echo "🚀 Starting production iOS build..."
eas build -p ios --profile production --non-interactive --wait

# 2) Submit the latest finished build to TestFlight
echo "📤 Submitting build to TestFlight..."
eas submit -p ios --latest \
  --non-interactive \
  --apple-team-id "$APPLE_TEAM_ID" \
  --asc-app-id "$ASC_APP_ID" \
  --asc-api-key-path "$KEY_FILE" \
  --asc-api-key-id "$ASC_KEY_ID" \
  --asc-api-key-issuer-id "$ASC_ISSUER_ID"

echo "🎉 Done! Check App Store Connect → TestFlight for processing status."

# Optional cleanup:
# rm -f "$KEY_FILE"
