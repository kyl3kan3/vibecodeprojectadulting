-- Pro Gating Optional Features - Database Schema
-- Add these tables to support subscription verification, analytics, A/B testing, promotions, and referrals

-- =====================================================
-- 1. USER SUBSCRIPTIONS TABLE
-- Stores verified subscription status from Apple/Google
-- =====================================================
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_active BOOLEAN DEFAULT FALSE,
  expires_at TIMESTAMP WITH TIME ZONE,
  product_id TEXT,
  platform TEXT CHECK (platform IN ('ios', 'android', 'web', 'referral')),
  last_verified TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Index for fast subscription lookups
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_id ON user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_active ON user_subscriptions(is_active) WHERE is_active = TRUE;

-- =====================================================
-- 2. ANALYTICS EVENTS TABLE
-- Tracks paywall impressions, conversions, and user behavior
-- =====================================================
CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  event_name TEXT NOT NULL,
  event_properties JSONB DEFAULT '{}'::jsonb,
  session_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for analytics queries
CREATE INDEX IF NOT EXISTS idx_analytics_events_user_id ON analytics_events(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_events_name ON analytics_events(event_name);
CREATE INDEX IF NOT EXISTS idx_analytics_events_created_at ON analytics_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_analytics_events_session ON analytics_events(session_id);

-- =====================================================
-- 3. EXPERIMENTS TABLE
-- A/B testing configuration
-- =====================================================
CREATE TABLE IF NOT EXISTS experiments (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  active BOOLEAN DEFAULT TRUE,
  variants JSONB NOT NULL, -- Array of {name, weight, config}
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 4. EXPERIMENT ASSIGNMENTS TABLE
-- Tracks which variant each user is assigned to
-- =====================================================
CREATE TABLE IF NOT EXISTS experiment_assignments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
  variant TEXT NOT NULL,
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, experiment_id)
);

-- Indexes for experiment lookups
CREATE INDEX IF NOT EXISTS idx_experiment_assignments_user ON experiment_assignments(user_id);
CREATE INDEX IF NOT EXISTS idx_experiment_assignments_experiment ON experiment_assignments(experiment_id);

-- =====================================================
-- 5. EXPERIMENT CONVERSIONS TABLE
-- Tracks conversions for A/B testing analysis
-- =====================================================
CREATE TABLE IF NOT EXISTS experiment_conversions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
  variant TEXT NOT NULL,
  conversion_value NUMERIC DEFAULT 0,
  converted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for conversion analytics
CREATE INDEX IF NOT EXISTS idx_experiment_conversions_experiment ON experiment_conversions(experiment_id);
CREATE INDEX IF NOT EXISTS idx_experiment_conversions_variant ON experiment_conversions(experiment_id, variant);

-- =====================================================
-- 6. REFERRAL CODES TABLE
-- Stores unique referral codes for each user
-- =====================================================
CREATE TABLE IF NOT EXISTS referral_codes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Index for code lookups
CREATE INDEX IF NOT EXISTS idx_referral_codes_code ON referral_codes(code);
CREATE INDEX IF NOT EXISTS idx_referral_codes_user ON referral_codes(user_id);

-- =====================================================
-- 7. REFERRALS TABLE
-- Tracks referral relationships and status
-- =====================================================
CREATE TABLE IF NOT EXISTS referrals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  code_used TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  completed_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(referred_id) -- Each user can only be referred once
);

-- Indexes for referral queries
CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred ON referrals(referred_id);
CREATE INDEX IF NOT EXISTS idx_referrals_status ON referrals(status);

-- =====================================================
-- 8. INSERT DEFAULT EXPERIMENTS
-- Pre-configure A/B tests for free skill counts and AI limits
-- =====================================================
INSERT INTO experiments (id, name, description, active, variants) VALUES
  ('free_skill_count', 'Free Skill Count Test', 'Test different numbers of free starter skills', TRUE, 
   '[
     {"name": "control", "weight": 25, "config": {"count": 3}},
     {"name": "variant_a", "weight": 25, "config": {"count": 5}},
     {"name": "variant_b", "weight": 25, "config": {"count": 2}},
     {"name": "variant_c", "weight": 25, "config": {"count": 10}}
   ]'::jsonb
  ),
  ('ai_message_limit', 'AI Message Limit Test', 'Test different daily AI message limits', TRUE,
   '[
     {"name": "control", "weight": 40, "config": {"limit": 3}},
     {"name": "variant_a", "weight": 30, "config": {"limit": 5}},
     {"name": "variant_b", "weight": 20, "config": {"limit": 1}},
     {"name": "variant_c", "weight": 10, "config": {"limit": 10}}
   ]'::jsonb
  ),
  ('paywall_design', 'Paywall Design Test', 'Test different paywall messaging and design', FALSE,
   '[
     {"name": "control", "weight": 50, "config": {"style": "default"}},
     {"name": "variant_a", "weight": 50, "config": {"style": "social_proof"}}
   ]'::jsonb
  )
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- 9. ROW LEVEL SECURITY (RLS) POLICIES
-- Ensure users can only access their own data
-- =====================================================

-- Enable RLS
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE experiment_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE experiment_conversions ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;

-- User Subscriptions: Users can read their own subscription
CREATE POLICY "Users can view own subscription"
  ON user_subscriptions FOR SELECT
  USING (auth.uid() = user_id);

-- Analytics: Users can insert their own events
CREATE POLICY "Users can insert own analytics"
  ON analytics_events FOR INSERT
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Experiment Assignments: Users can read their own assignments
CREATE POLICY "Users can view own experiments"
  ON experiment_assignments FOR SELECT
  USING (auth.uid() = user_id);

-- Referral Codes: Users can read their own code
CREATE POLICY "Users can view own referral code"
  ON referral_codes FOR SELECT
  USING (auth.uid() = user_id);

-- Referral Codes: Anyone can read codes for validation
CREATE POLICY "Anyone can validate referral codes"
  ON referral_codes FOR SELECT
  USING (TRUE);

-- Referrals: Users can view referrals they made or received
CREATE POLICY "Users can view own referrals"
  ON referrals FOR SELECT
  USING (auth.uid() = referrer_id OR auth.uid() = referred_id);

-- Experiments table: Anyone can read active experiments
CREATE POLICY "Anyone can view active experiments"
  ON experiments FOR SELECT
  USING (active = TRUE);

-- =====================================================
-- 10. HELPER FUNCTIONS
-- =====================================================

-- Function to check if subscription is active and not expired
CREATE OR REPLACE FUNCTION is_subscription_active(p_user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_subscriptions
    WHERE user_id = p_user_id
      AND is_active = TRUE
      AND (expires_at IS NULL OR expires_at > NOW())
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get conversion rate for an experiment
CREATE OR REPLACE FUNCTION get_experiment_conversion_rate(p_experiment_id TEXT, p_variant TEXT)
RETURNS NUMERIC AS $$
DECLARE
  v_assignments INTEGER;
  v_conversions INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_assignments
  FROM experiment_assignments
  WHERE experiment_id = p_experiment_id AND variant = p_variant;
  
  SELECT COUNT(*) INTO v_conversions
  FROM experiment_conversions
  WHERE experiment_id = p_experiment_id AND variant = p_variant;
  
  IF v_assignments = 0 THEN
    RETURN 0;
  END IF;
  
  RETURN (v_conversions::NUMERIC / v_assignments::NUMERIC) * 100;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- MIGRATION COMPLETE
-- =====================================================

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON experiments TO anon, authenticated;
GRANT ALL ON user_subscriptions TO authenticated;
GRANT ALL ON analytics_events TO authenticated;
GRANT ALL ON experiment_assignments TO authenticated;
GRANT ALL ON experiment_conversions TO authenticated;
GRANT ALL ON referral_codes TO authenticated;
GRANT ALL ON referrals TO authenticated;

-- Success message
DO $$
BEGIN
  RAISE NOTICE 'Pro Gating Optional Features Migration Complete!';
  RAISE NOTICE 'Tables created: user_subscriptions, analytics_events, experiments, experiment_assignments, experiment_conversions, referral_codes, referrals';
  RAISE NOTICE 'Default experiments added for A/B testing';
  RAISE NOTICE 'RLS policies enabled for data security';
END $$;
