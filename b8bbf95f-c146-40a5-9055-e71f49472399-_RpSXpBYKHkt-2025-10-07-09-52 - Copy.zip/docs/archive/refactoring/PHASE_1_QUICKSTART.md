# Phase 1 Migration - Quick Start Guide

## 🚀 Getting Started

### 1. Create Branch
```bash
git checkout -b refactor/phase-1-state-consolidation
git commit --allow-empty -m "Checkpoint: Before Phase 1 migration"
```

### 2. Add Validation Script
Add to `package.json` scripts:
```json
"validate:migration": "tsx scripts/validate-migration.ts"
```

---

## 📋 Daily Workflow

**For Each Step:**
1. Make the change
2. Run `npm run typecheck`
3. Test app launches
4. Run `npm run validate:migration`
5. Commit immediately

---

## 🛠️ Helpful Commands

### Progress Check
```bash
# Count remaining unified-store imports
grep -r "from.*unified-store" src/ --exclude-dir=__tests__ | wc -l

# List files still using old store
grep -r "from.*unified-store" src/ --exclude-dir=__tests__
```

### Validation
```bash
npm run typecheck
npm run validate:migration
```

---

## 🚨 Emergency Rollback

### Last Step:
```bash
git revert HEAD
```

### To Checkpoint:
```bash
git log --oneline
git reset --hard <commit-hash>
```

---

## ✅ Final Checklist

Before PR:
- [ ] All components migrated
- [ ] Zero TypeScript errors
- [ ] Validation script passes
- [ ] Full app tested
- [ ] Old store deleted
- [ ] Docs updated

---

**Start:** Follow PHASE_1_MIGRATION_PLAN.md step by step