# Phase 1: State Management Consolidation - Detailed Migration Plan

## Overview
Split the 3,002-line unified-store.ts into 5 focused stores with **incremental steps** and safety checks to prevent app crashes.

---

## Pre-Migration: Safety Preparations

### Step 0: Create Branch & Baseline ✓
```bash
git checkout -b refactor/phase-1-state-consolidation
npm run typecheck  # Ensure clean baseline
git commit --allow-empty -m "Checkpoint: Before Phase 1 migration"
```

---

## Stage 1: Extract Type Definitions (1 hour)

### Step 1: Create Shared Types File
- Extract interfaces from unified-store.ts to `src/state/types.ts`
- Export `DatabaseLesson`, `LessonLoadResult`, etc.
- Import types back into unified-store.ts
- Run typecheck and test app
- Commit: "Extract state types to separate file"

---

## Stage 2: Create New Store Files (Day 1-2)

### Step 2: Lessons Store (`src/state/lessons-store.ts`)
- State: skills, completedSkills, skillProgress, loading states
- Actions: loadSkillsFromDatabase, markSkillCompleted, etc.
- Persist with partialize (cache only necessary data)

### Step 3: Progress Store (`src/state/progress-store.ts`)
- State: userProgress, achievements, dailyChallenges, XP
- Actions: updateUserProgress, addAchievement, etc.
- Integrate with useSupabaseProgress hook

### Step 4: AI Store (`src/state/ai-store.ts`)
- State: learningAnalysis, insights, recommendations, conversations
- Actions: AI service integrations, module suggestions
- Lightweight persistence (don't cache full history)

### Step 5: UI Store (`src/state/ui-store.ts`)
- State: onboarding, modals, navigation state
- Actions: UI state management
- Minimal persistence

### Step 6: Tips Store (`src/state/tips-store.ts`)
- State: tips, dailyTipSchedule, loading
- Actions: loadTips, markComplete, bookmark, rating, photos
- Full persistence

---

## Stage 3: Create Index & Compatibility (Day 2)

### Step 7: Barrel Export (`src/state/index.ts`)
```typescript
export { useLessonsStore } from './lessons-store';
export { useProgressStore } from './progress-store';
export { useAIStore } from './ai-store';
export { useUIStore } from './ui-store';
export { useTipsStore } from './tips-store';

// Compatibility helper
export const useUnifiedStore = () => ({
  ...useLessonsStore(),
  ...useProgressStore(),
  ...useAIStore(),
  ...useUIStore(),
  ...useTipsStore(),
});
```

---

## Stage 4: Component Migration (Day 3-4)

### Step 8-37: Migrate Components ONE AT A TIME
**Process for each component:**
1. Update import to use specific store(s)
2. Run `npm run typecheck`
3. Test component thoroughly
4. Commit immediately
5. If broken, rollback that single commit

**Component List (32 files):**
- SavedTipsScreen → useTipsStore
- DailyTipsScreen → useTipsStore
- AchievementsScreen → useProgressStore
- InteractiveLessonScreen → useLessonsStore
- LessonDetailScreen → useLessonsStore
- LearnScreen → useLessonsStore
- ProgressScreen → useProgressStore
- StatsScreen → useProgressStore + useLessonsStore
- AskAIScreen → useAIStore
- LearningInsightsScreen → useAIStore
- OnboardingScreen → useUIStore
- ProfileScreen → multiple stores
- HomeScreen → multiple stores
- [... remaining 20 components]

---

## Stage 5: Cleanup (Day 5)

### Step 38: Remove Old Store
- Verify ZERO imports of unified-store.ts
- Delete unified-store.ts (keep .backup.ts)
- Update documentation
- Create PR

---

## Safety Features 🛡️

1. **Commit after every step** - Easy rollback
2. **Test after every change** - Catch issues immediately  
3. **One component at a time** - Isolated changes
4. **Validation script** - Automated checks
5. **Compatibility layer** - No breaking changes

---

## Rollback Procedures 🚨

### Single Step:
```bash
git revert HEAD
```

### Multiple Steps:
```bash
git log --oneline  # Find checkpoint
git reset --hard <commit-hash>
```

### Emergency Full Reset:
```bash
git reset --hard origin/main
```

---

## Success Metrics ✅

- [ ] Zero TypeScript errors
- [ ] All 32+ components migrated
- [ ] No file > 600 lines
- [ ] All features working
- [ ] Data persists across restarts
- [ ] No console errors

---

**Next:** Run validation script and begin Step 1
