# Updated Refactoring Plan for Adulting Coach App

## Executive Summary

This updated plan reflects the **current state** of the codebase after recent improvements. Several critical infrastructure pieces have been successfully implemented, including:

✅ **Completed:**
- Comprehensive database services layer (`BaseService`, `UserProgressService`, `UserStreakService`, `ProfileService`, `AnalyticsService`)
- Enhanced error handling with retry logic and custom error types
- Real-time subscription service (polling-based)
- AI-powered substep research feature (replaced 1,584 static URLs)
- Resource cleanup (removed 22 obsolete files, ~3,000 lines)
- Security improvements (removed direct Supabase credentials)

⚠️ **Still Critical:**
- Massive unified store (3,002 lines) needs consolidation
- Multiple state patterns (26 imports across components)
- Type safety improvements needed
- Testing infrastructure missing
- Performance optimization opportunities

---

## Phase 1: State Management Consolidation (UPDATED)
**Priority: CRITICAL | Estimated Time: 4-5 days**

### Current State Analysis:
- ✅ Database services properly separated from store
- ✅ `useSupabaseProgress` hook refactored to use new services
- ❌ `unified-store.ts` still 3,002 lines (monolithic)
- ❌ Multiple store exports (`useAppStore`, `useAdultingStore`, `useGuidesStore`) all pointing to same store
- ❌ 26+ component imports using stores directly
- ❌ Mixed concerns: lessons, tips, progress, UI state, AI modules all in one file

### Refactoring Tasks:

#### 1.1 Create Domain-Specific Store Slices
**Split unified-store.ts into focused stores**

1. **Lessons Store** (`src/state/lessons-store.ts`)
   - Lesson loading and caching
   - Lesson completion tracking
   - Lesson resource management
   - Interactive lesson state
   - **Lines:** ~500-600

2. **Progress Store** (`src/state/progress-store.ts`)
   - Use existing `useSupabaseProgress` hook
   - Daily challenges state
   - Achievements tracking
   - Goals management
   - Integrate with database services
   - **Lines:** ~300-400

3. **AI Features Store** (`src/state/ai-store.ts`)
   - AI learning service state
   - Generated modules
   - Conversation analysis
   - Personalized recommendations
   - **Lines:** ~400-500

4. **UI Store** (`src/state/ui-store.ts`)
   - Onboarding state
   - Subscription modal state
   - Navigation state
   - Theme/appearance settings
   - **Lines:** ~200-300

5. **Tips Store** (`src/state/tips-store.ts`)
   - Daily tips management
   - Saved tips
   - Tip categories
   - Tip scheduling
   - **Lines:** ~300-400

#### 1.2 Implement Store Composition Pattern
**Create unified access without monolithic file**

```typescript
// src/state/index.ts - Clean barrel export
export { useLessonsStore } from './lessons-store';
export { useProgressStore } from './progress-store';
export { useAIStore } from './ai-store';
export { useUIStore } from './ui-store';
export { useTipsStore } from './tips-store';

// Backward compatibility helpers
export const useUnifiedStore = () => ({
  ...useLessonsStore(),
  ...useProgressStore(),
  ...useAIStore(),
  ...useUIStore(),
  ...useTipsStore(),
});
```

#### 1.3 Migration Strategy
**Gradual migration to avoid breaking changes**

1. **Day 1-2: Create new store files**
   - Extract lessons logic → `lessons-store.ts`
   - Extract progress logic → `progress-store.ts`
   - Extract AI logic → `ai-store.ts`
   - Keep unified-store.ts functioning

2. **Day 3: Create UI and Tips stores**
   - Extract UI logic → `ui-store.ts`
   - Extract tips logic → `tips-store.ts`
   - Add barrel exports in `src/state/index.ts`

3. **Day 4: Update components (high priority)**
   - Update screens that use lessons state
   - Update screens that use progress state
   - Test each migration thoroughly

4. **Day 5: Final migration and cleanup**
   - Update remaining components
   - Add compatibility layer
   - Delete old `unified-store.ts` (after full verification)
   - Update imports across codebase

#### 1.4 State Persistence Strategy
**Optimize what gets persisted**

```typescript
// Only persist necessary data
const persistConfig = {
  name: 'lessons-store',
  storage: createJSONStorage(() => AsyncStorage),
  partialize: (state) => ({
    // Only cache lesson metadata, not full content
    cachedLessonIds: state.cachedLessonIds,
    lastSync: state.lastSync,
  }),
};
```

### Files to Create:
- `src/state/lessons-store.ts` (NEW)
- `src/state/progress-store.ts` (NEW)
- `src/state/ai-store.ts` (NEW)
- `src/state/ui-store.ts` (NEW)
- `src/state/tips-store.ts` (NEW)
- `src/state/index.ts` (UPDATED - barrel exports)

### Files to Modify:
- All 26+ components using `unified-store.ts`
- `src/hooks/useSupabaseProgress.ts` (ensure integration)

### Files to Delete:
- `src/state/unified-store.ts` (after migration complete)

### Success Metrics:
- ✅ No store file > 600 lines
- ✅ Zero breaking changes for users
- ✅ 50%+ reduction in re-renders (measured with React DevTools)
- ✅ All tests pass
- ✅ TypeScript compiles with zero errors

---

## Phase 2: Database Service Expansion (UPDATED)
**Priority: MEDIUM | Estimated Time: 2-3 days**

### Current State Analysis:
- ✅ Excellent foundation with `BaseService` class
- ✅ `UserProgressService`, `UserStreakService`, `ProfileService` implemented
- ✅ `AnalyticsService` for insights
- ✅ Comprehensive error handling with `DatabaseError`
- ✅ Retry logic with exponential backoff
- ❌ Missing `LessonService` (lessons still loaded directly in store)
- ❌ No caching layer for lessons
- ❌ Missing batch operations for lesson loading

### Refactoring Tasks:

#### 2.1 Create LessonService
**Centralize lesson data access**

1. **File:** `src/services/database/LessonService.ts`
   - Extends `BaseService`
   - Methods:
     - `getLessonById(id: string)`
     - `getLessonsByCategory(category: string)`
     - `searchLessons(query: string)`
     - `getBatchLessons(ids: string[])`
     - `getLessonProgress(userId: string, lessonId: string)`
     - `markLessonComplete(lessonId: string, rating?: number)`

2. **Caching Strategy**
   - Cache lesson content in memory (5-minute TTL)
   - Cache lesson metadata in AsyncStorage
   - Smart invalidation on updates

3. **Integration Points**
   - Replace direct `supabaseMCP.query()` calls in `lessons-store.ts`
   - Use in `InteractiveLessonScreen.tsx`
   - Use in `LessonDetailScreen.tsx`

#### 2.2 Create ResourceService  
**Manage AI-generated resources**

1. **File:** `src/services/database/ResourceService.ts`
   - Methods:
     - `getResourcesForStep(lessonId: string, stepId: string)`
     - `cacheAIGeneratedResource(lessonId: string, stepId: string, content: any)`
     - `getResourceCache(lessonId: string, stepId: string)`
     - `clearResourceCache()`

#### 2.3 Enhance Existing Services

1. **Update README.md**
   - Add LessonService documentation
   - Add ResourceService documentation
   - Update usage examples
   - Add performance tips specific to lessons

### Files to Create:
- `src/services/database/LessonService.ts` (NEW)
- `src/services/database/ResourceService.ts` (NEW)

### Files to Modify:
- `src/services/database/index.ts` (add exports)
- `src/services/database/README.md` (add documentation)
- `src/state/lessons-store.ts` (use LessonService)

### Success Metrics:
- ✅ All lesson data access goes through LessonService
- ✅ 60%+ reduction in database calls (via caching)
- ✅ Consistent error handling across lesson operations
- ✅ Complete service documentation

---

## Phase 3: Component Architecture Standardization
**Priority: HIGH | Estimated Time: 3-4 days**

### Current State Analysis:
- ✅ Some good components exist (`ChecklistStepCard`, `SubstepResearchModal`)
- ✅ ErrorBoundary implemented
- ❌ Inconsistent prop interfaces across screens
- ❌ No design system or reusable UI components
- ❌ Mixed styling patterns (className vs style)
- ❌ Performance issues (unnecessary re-renders)

### Refactoring Tasks:

#### 3.1 Create Design System Foundation
**Build reusable UI components**

1. **Base Components** (`src/components/ui/`)
   - `Button.tsx` - Primary, secondary, outline variants
   - `Card.tsx` - Container with elevation and padding
   - `Text.tsx` - Typography with semantic variants
   - `Input.tsx` - Form inputs with validation states
   - `LoadingSpinner.tsx` - Consistent loading indicator
   - `EmptyState.tsx` - No data display pattern

2. **Layout Components** (`src/components/layout/`)
   - `Container.tsx` - Content width and safe area
   - `Stack.tsx` - Vertical/horizontal spacing
   - `Screen.tsx` - Base screen wrapper with header

#### 3.2 Optimize Existing Components

1. **ChecklistStepCard.tsx**
   - Add React.memo for performance
   - Use useCallback for event handlers
   - Implement proper prop memoization

2. **SubstepResearchModal.tsx**
   - Add skeleton loading state
   - Implement error retry UI
   - Optimize modal animations

#### 3.3 Screen Standardization

1. **Create BaseScreen wrapper**
   ```typescript
   // src/components/BaseScreen.tsx
   interface BaseScreenProps {
     title?: string;
     loading?: boolean;
     error?: string;
     onRetry?: () => void;
     children: React.ReactNode;
   }
   ```

2. **Update screens to use BaseScreen**
   - `InteractiveLessonScreen.tsx`
   - `LessonDetailScreen.tsx`
   - `ProgressScreen.tsx`

### Files to Create:
- `src/components/ui/Button.tsx` (NEW)
- `src/components/ui/Card.tsx` (NEW)
- `src/components/ui/Text.tsx` (NEW)
- `src/components/ui/Input.tsx` (NEW)
- `src/components/ui/LoadingSpinner.tsx` (NEW)
- `src/components/ui/EmptyState.tsx` (NEW)
- `src/components/layout/Container.tsx` (NEW)
- `src/components/layout/Stack.tsx` (NEW)
- `src/components/layout/Screen.tsx` (NEW)
- `src/components/BaseScreen.tsx` (NEW)

### Files to Modify:
- `src/components/lessons/ChecklistStepCard.tsx` (optimize)
- `src/components/SubstepResearchModal.tsx` (optimize)
- `src/screens/InteractiveLessonScreen.tsx` (use BaseScreen)
- `src/screens/ProgressScreen.tsx` (use BaseScreen)

### Success Metrics:
- ✅ 30%+ reduction in component code duplication
- ✅ Consistent UI patterns across all screens
- ✅ 40%+ improvement in render performance
- ✅ Complete component documentation

---

## Phase 4: Type System Enhancement
**Priority: HIGH | Estimated Time: 2 days**

### Current State Analysis:
- ✅ Good type definitions in `src/types/app.ts` and `src/types/adulting.ts`
- ✅ Database types in `src/types/db.ts`
- ❌ No runtime validation (no Zod schemas)
- ❌ Type inconsistencies between database and app layer
- ❌ Missing API response types

### Refactoring Tasks:

#### 4.1 Add Runtime Validation
**Install and configure Zod**

1. **Create Schema Validators** (`src/schemas/`)
   - `lessonSchemas.ts` - Lesson data validation
   - `progressSchemas.ts` - Progress data validation
   - `userSchemas.ts` - User data validation
   - `apiSchemas.ts` - API response validation

2. **Integrate with Services**
   - Add validation in LessonService
   - Add validation in UserProgressService
   - Validate all API responses

#### 4.2 Standardize Type Patterns

1. **Create Utility Types** (`src/types/utils.ts`)
   ```typescript
   export type AsyncResult<T> = {
     data: T | null;
     error: Error | null;
     loading: boolean;
   };
   
   export type PaginatedResponse<T> = {
     data: T[];
     page: number;
     pageSize: number;
     total: number;
     hasMore: boolean;
   };
   ```

2. **Update Existing Types**
   - Ensure consistency between DB and app types
   - Add JSDoc comments to all types
   - Export types properly from index files

### Files to Create:
- `src/schemas/lessonSchemas.ts` (NEW)
- `src/schemas/progressSchemas.ts` (NEW)
- `src/schemas/userSchemas.ts` (NEW)
- `src/schemas/apiSchemas.ts` (NEW)
- `src/types/utils.ts` (NEW)

### Files to Modify:
- `src/services/database/LessonService.ts` (add validation)
- `src/services/database/UserProgressService.ts` (add validation)
- `src/types/app.ts` (add JSDoc)
- `src/types/adulting.ts` (add JSDoc)

### Success Metrics:
- ✅ Runtime validation for all API data
- ✅ Zero TypeScript errors
- ✅ 100% type coverage
- ✅ Complete type documentation

---

## Phase 5: Testing Infrastructure
**Priority: MEDIUM | Estimated Time: 3 days**

### Current State Analysis:
- ❌ No test files found
- ❌ No Jest configuration
- ❌ No testing utilities

### Refactoring Tasks:

#### 5.1 Set Up Testing Framework

1. **Configure Jest**
   - Create `jest.config.js`
   - Add React Native Testing Library
   - Configure test environment

2. **Create Test Utilities** (`src/utils/testUtils.ts`)
   - Mock stores
   - Mock database services
   - Mock navigation
   - Render helpers

#### 5.2 Write Critical Tests

1. **Service Tests** (`src/services/database/__tests__/`)
   - Test BaseService retry logic
   - Test UserProgressService operations
   - Test LessonService caching
   - Test error handling

2. **Component Tests** (`src/components/__tests__/`)
   - Test ChecklistStepCard rendering
   - Test SubstepResearchModal interactions
   - Test UI component library

3. **Hook Tests** (`src/hooks/__tests__/`)
   - Test useSupabaseProgress
   - Test custom hooks

### Files to Create:
- `jest.config.js` (NEW)
- `src/utils/testUtils.ts` (NEW)
- `src/services/database/__tests__/*.test.ts` (NEW - multiple files)
- `src/components/__tests__/*.test.tsx` (NEW - multiple files)
- `src/hooks/__tests__/*.test.ts` (NEW - multiple files)

### Success Metrics:
- ✅ 70%+ test coverage for services
- ✅ 60%+ test coverage for components
- ✅ All critical paths tested
- ✅ CI/CD integration ready

---

## Phase 6: Performance Optimization
**Priority: MEDIUM | Estimated Time: 2-3 days**

### Current State Analysis:
- ❌ No memoization in components
- ❌ No virtualization for long lists
- ❌ No image optimization
- ❌ Large store causing re-renders

### Refactoring Tasks:

#### 6.1 Component Optimization

1. **Add Memoization**
   - Wrap expensive components with React.memo
   - Use useMemo for expensive calculations
   - Use useCallback for event handlers

2. **Implement Virtualization**
   - Add FlatList to lesson lists
   - Optimize checklist rendering
   - Add pagination for progress history

#### 6.2 Asset Optimization

1. **Image Optimization**
   - Implement lazy loading
   - Add progressive image loading
   - Optimize icon usage

2. **Bundle Optimization**
   - Analyze bundle size
   - Implement code splitting
   - Remove unused dependencies

### Files to Modify:
- All screen components (add memoization)
- `src/components/lessons/ChecklistStepCard.tsx` (optimize)
- `src/screens/ProgressScreen.tsx` (add virtualization)

### Success Metrics:
- ✅ 50%+ reduction in render time
- ✅ 30%+ smaller bundle size
- ✅ Smooth 60fps scrolling
- ✅ < 100ms screen transition time

---

## Implementation Timeline

### Week 1 (Critical Foundation)
- **Days 1-3:** Phase 1 (State Management) - Store splitting
- **Days 4-5:** Phase 1 (State Management) - Component migration

### Week 2 (Services & Components)
- **Days 1-2:** Phase 2 (Database Services) - LessonService, ResourceService
- **Days 3-5:** Phase 3 (Component Architecture) - Design system

### Week 3 (Quality & Performance)
- **Days 1-2:** Phase 4 (Type System) - Zod validation
- **Days 3-5:** Phase 5 (Testing) - Test infrastructure

### Week 4 (Optimization & Polish)
- **Days 1-3:** Phase 6 (Performance) - Optimization
- **Days 4-5:** Integration testing and bug fixes

**Total Estimated Time:** 4 weeks

---

## Success Metrics (Overall)

### Code Quality:
- ✅ No file > 600 lines
- ✅ 70%+ test coverage
- ✅ Zero TypeScript errors
- ✅ Zero console warnings in production

### Performance:
- ✅ 50%+ faster app launch time
- ✅ 40%+ reduction in re-renders
- ✅ 30%+ smaller bundle size
- ✅ < 100ms API response caching

### Developer Experience:
- ✅ Clear separation of concerns
- ✅ Comprehensive documentation
- ✅ Easy to add new features
- ✅ Fast test execution

---

## Assumptions

1. **Database services are working well** - The existing `BaseService`, `UserProgressService`, etc., are solid and should be kept
2. **AI substep research feature is complete** - No further work needed on resource generation
3. **Backward compatibility is critical** - Users should not experience any breaking changes
4. **Incremental migration** - We can split the work into phases and deploy incrementally
5. **Testing can be added gradually** - Start with critical paths, expand coverage over time
6. **Performance gains are measurable** - We'll use React DevTools Profiler and bundle analyzer to validate improvements
7. **Design system will follow Apple HIG** - As specified in the coding specifications
8. **Zustand + AsyncStorage will remain** - No changes to state management technology, just organization
9. **Supabase MCP proxy continues working** - All database access through existing proxy pattern
10. **Phase 1 is highest priority** - The 3,002-line store is the biggest blocker to maintainability

---

## Database Services (Already Implemented) ✅

### Current Implementation Status:

The app already has a **comprehensive database services layer** that follows best practices:

#### 1. **BaseService** - Foundation Class
- ✅ Automatic retry logic with exponential backoff
- ✅ Circuit breaker pattern for resilience
- ✅ User-friendly error handling
- ✅ Performance monitoring with slow query detection
- ✅ Health check capabilities
- ✅ Transaction-like operations support
- ✅ Pagination helpers
- ✅ Optimistic update utilities

#### 2. **UserProgressService** - Progress Tracking
- ✅ Mark tips as complete with ratings and notes
- ✅ Get progress history with filtering
- ✅ Progress statistics and analytics
- ✅ Batch completion operations
- ✅ Update and delete progress entries
- ✅ Category-based progress tracking

#### 3. **UserStreakService** - Streak Management
- ✅ Track daily activity streaks
- ✅ Calculate current and longest streaks
- ✅ Update streaks after completions
- ✅ Reset streak functionality
- ✅ Streak statistics and insights
- ✅ Historical streak data

#### 4. **ProfileService** - User Profiles
- ✅ Create and update user profiles
- ✅ Avatar upload and management
- ✅ Profile with statistics aggregation
- ✅ Username uniqueness validation
- ✅ Profile retrieval and caching

#### 5. **AnalyticsService** - Insights & Analytics
- ✅ Comprehensive progress insights
- ✅ Completion rate analysis (daily, weekly, monthly)
- ✅ Streak insights and trends
- ✅ Time-based analysis (best days, times)
- ✅ Category completion statistics
- ✅ Goal suggestions and projections
- ✅ Performance metrics tracking

#### 6. **RealtimeService** - Live Updates
- ✅ Real-time progress subscriptions
- ✅ Real-time streak updates
- ✅ Real-time profile synchronization
- ✅ Polling-based implementation (fallback from WebSockets)
- ✅ Automatic reconnection handling
- ✅ Multiple subscription management

#### 7. **Error Handling System**
- ✅ Custom `DatabaseError` class with error codes
- ✅ User-friendly error messages
- ✅ Retryable vs non-retryable error classification
- ✅ Error timestamp tracking
- ✅ Supabase error translation
- ✅ Network, auth, validation, and permission error handling

#### 8. **Enhanced useSupabaseProgress Hook**
- ✅ Integrates all database services
- ✅ Real-time updates with optimistic UI
- ✅ Comprehensive error handling
- ✅ Loading states management
- ✅ Progress statistics
- ✅ Streak management
- ✅ Export functionality
- ✅ Batch operations support

### Architecture Benefits:
- **Consistent API** - All services follow the same patterns
- **Error Resilience** - Automatic retry, circuit breaker, graceful degradation
- **Performance** - Caching, optimistic updates, slow query detection
- **Real-time** - Live updates for progress, streaks, and profiles
- **Type Safety** - Full TypeScript support with `DatabaseResult<T>` pattern
- **Testability** - Services are easily mockable and testable
- **Documentation** - Comprehensive README with usage examples

### What Still Needs to Be Done:
- ❌ **LessonService** - Centralize lesson data access (Phase 2)
- ❌ **ResourceService** - Manage AI-generated resource caching (Phase 2)
- ❌ **Integration** - Connect new LessonService to stores (Phase 1 & 2)
- ❌ **Testing** - Add comprehensive tests for all services (Phase 5)

---

## Notes

- This plan prioritizes maintaining functionality while improving code quality
- Each phase should be completed and tested before moving to the next
- Consider user impact when implementing changes
- Maintain backward compatibility where possible
- Document all changes and decisions made during refactoring
- The database services layer is a solid foundation - build on it, don't replace it

---

**Last Updated:** September 30, 2025  
**Version:** 2.0  
**Status:** Ready for Implementation  
**Next Step:** Begin Phase 1 - State Management Consolidation
