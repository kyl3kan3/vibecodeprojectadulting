# Phase 2: Database Service Expansion - Detailed Plan

## Overview
Create LessonService and ResourceService to centralize lesson data access with caching, following the excellent patterns established in existing database services.

---

## Current State ✅

**Existing Services (Working Well):**
- ✅ BaseService - Foundation with retry, caching, error handling
- ✅ UserProgressService - Progress tracking
- ✅ UserStreakService - Streak management
- ✅ ProfileService - User profiles
- ✅ AnalyticsService - Insights & analytics
- ✅ RealtimeService - Live updates

**What's Missing:**
- ❌ LessonService - Lessons loaded directly in unified-store.ts
- ❌ ResourceService - No caching for AI-generated resources
- ❌ No caching layer for lesson content
- ❌ Direct supabaseMCP calls scattered in store

---

## Phase 2 Tasks (Incremental Steps)

### Step 1: Create LessonService Shell (30 min)
- [ ] Create `src/services/database/LessonService.ts`
- [ ] Extend BaseService
- [ ] Define interface and basic structure
- [ ] Add to `index.ts` exports
- [ ] Commit: "Create LessonService shell"

### Step 2: Add Core Lesson Methods (1 hour)
- [ ] `getAllLessons()` - Load all lessons with caching
- [ ] `getLessonById(id)` - Get single lesson
- [ ] `getLessonsByCategory(category)` - Filter by category
- [ ] Add in-memory cache with 5-minute TTL
- [ ] Commit: "Add core LessonService methods"

### Step 3: Add Lesson Conversion Logic (1 hour)
- [ ] Move `convertDatabaseLessonToLifeSkill` to service
- [ ] Handle stepResources properly
- [ ] Add error handling for conversion failures
- [ ] Commit: "Add lesson conversion to LessonService"

### Step 4: Add Advanced Methods (45 min)
- [ ] `searchLessons(query)` - Text search
- [ ] `getBatchLessons(ids[])` - Bulk loading
- [ ] `refreshLesson(id)` - Force reload
- [ ] Commit: "Add advanced LessonService methods"

### Step 5: Create ResourceService (1 hour)
- [ ] Create `src/services/database/ResourceService.ts`
- [ ] Methods for AI resource caching
- [ ] `getResourcesForStep(lessonId, stepId)`
- [ ] `cacheAIGeneratedResource()`
- [ ] Commit: "Create ResourceService"

### Step 6: Integrate LessonService into Store (1 hour)
- [ ] Update `unified-store.ts` to use LessonService
- [ ] Replace `supabaseMCP.query()` calls
- [ ] Test lesson loading still works
- [ ] Commit: "Integrate LessonService into store"

### Step 7: Update Documentation (30 min)
- [ ] Add LessonService docs to README.md
- [ ] Add ResourceService docs
- [ ] Update usage examples
- [ ] Commit: "Update database services documentation"

### Step 8: Testing & Validation (1 hour)
- [ ] Test all lesson operations
- [ ] Verify caching works
- [ ] Check error handling
- [ ] Measure performance improvements
- [ ] Commit: "Phase 2 complete - testing validated"

---

## Estimated Time: 2-3 days
## Current Status: Starting Step 1
