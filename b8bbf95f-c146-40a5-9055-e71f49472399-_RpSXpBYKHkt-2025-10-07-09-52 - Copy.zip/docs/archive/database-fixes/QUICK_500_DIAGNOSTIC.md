# 🔧 Quick 500 Error Diagnostic

## Can't Find Detailed Logs? Answer These Questions:

### Question 1: What is your Next.js version?
Check your Vercel project's `package.json` for:
```json
"next": "13.x.x" or "14.x.x" or "15.x.x"
```

### Question 2: What is your file structure?

**Option A: Pages Router (Old)**
```
/pages/api/db/query.ts
```

**Option B: App Router (New)**
```
/app/api/db/query/route.ts
```

### Question 3: What code did you add?

Send me a screenshot or copy of the SELECT handler you added.

---

## Most Common Issues Based on Setup

### If Using App Router (Next.js 13+)

**Problem:** Using wrong function signature

**Wrong:**
```typescript
// ❌ This is for Pages Router
export default async function handler(req, res) {
  const body = req.body;
  // ...
}
```

**Correct:**
```typescript
// ✅ App Router syntax
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const body = await req.json();
  // ...
  return NextResponse.json({ data });
}
```

### If Using Pages Router (Next.js 12 or older)

**Problem:** Wrong imports or syntax

**Correct:**
```typescript
import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const body = req.body;
  // ...
  return res.status(200).json({ data });
}
```

---

## Quick Test: Can You Access This URL?

Try opening in your browser:
```
https://vercel-multi-ai-proxy.vercel.app/api/db/query
```

**What do you see?**
- "Method not allowed" or "405" → Good! Function exists but needs POST
- "404 Not Found" → File path is wrong
- Blank/timeout → Server is crashing

---

## Emergency Rollback

If you need the app working NOW while we debug:

1. Go to Vercel dashboard
2. Go to Deployments
3. Find the PREVIOUS deployment (before your changes)
4. Click "..." menu → "Promote to Production"
5. This will restore the working version

Then we can fix the issue in a new deployment.

---

## Send Me One of These:

**Option 1 (Best):** Full error from Vercel logs
```
Copy and paste the entire error message here
```

**Option 2:** Your file structure
```
Is it:
A) /pages/api/db/query.ts
B) /app/api/db/query/route.ts
```

**Option 3:** Your Next.js version
```
What version of Next.js? (check package.json)
```

**Option 4:** The code you added
```
Copy and paste the SELECT handler you added
```

With any of these, I can give you the exact fix! 🚀
