# 🔑 Get Your Supabase Credentials

## ❌ **Current Problem**

You're getting **400 Bad Request** errors because **Supabase credentials are missing**!

The app is trying to use a Vercel proxy for database operations, but that proxy is designed for AI operations, not database operations.

---

## ✅ **Solution: Add Direct Supabase Access**

You need to add your Supabase URL and anon key to the `.env` file.

---

## 📝 **Step-by-Step Instructions**

### **Step 1: Go to Supabase Dashboard**

1. Open your browser
2. Go to: **https://supabase.com/dashboard**
3. Sign in to your account
4. Click on your **project** (the one where you ran the migration)

### **Step 2: Get Your Credentials**

1. In your project dashboard, click **Settings** (⚙️ icon in left sidebar)
2. Click **API** in the settings menu
3. You'll see two important values:

   **Project URL:**
   ```
   https://xxxxxxxxxxxxx.supabase.co
   ```
   
   **anon public key:**
   ```
   eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZi...
   ```

### **Step 3: Add to .env File**

1. Open your project in your code editor
2. Open the `.env` file (in the root directory)
3. Add these two lines:

```bash
EXPO_PUBLIC_SUPABASE_URL=https://xxxxxxxxxxxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Replace** the values with YOUR actual credentials from Step 2!

### **Step 4: Restart Your App**

```bash
# Stop the dev server (Ctrl+C)
npx expo start --clear
```

Then force close and reopen your app.

---

## 🎯 **What Your .env Should Look Like**

```bash
# Environment Variables (Secure Configuration)

# Your Vercel proxy URL (for AI operations)
EXPO_PUBLIC_AI_PROXY_URL=https://vercel-multi-ai-proxy.vercel.app

# Supabase Configuration (for database operations)
EXPO_PUBLIC_SUPABASE_URL=https://xxxxxxxxxxxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOi...

# Admin emails
EXPO_PUBLIC_ADMIN_EMAILS=kyl3kan3@gmail.com

# Other settings...
```

---

## 🔒 **Security: Is the Anon Key Safe?**

**YES!** The anon key is safe to use in your React Native app:

✅ **It's designed to be public** - Called "anon" (anonymous) for a reason  
✅ **Row Level Security (RLS) protects your data** - Users can only access their own data  
✅ **Can be safely committed to repos** - It's not a secret  
✅ **Scoped by RLS policies** - Can't access data without proper authentication  

**However:** Don't share your **service_role** key (that one IS secret!)

---

## 🎊 **After Adding Credentials**

Once you add the credentials and restart:

✅ **Direct Supabase connection** (no more proxy errors)  
✅ **Cloud sync works** (saves to database)  
✅ **No more 400 errors** (proper authentication)  
✅ **Fast and reliable** (direct connection)  

---

## 🐛 **Troubleshooting**

### **Still getting 400 errors?**
- Double-check you copied the ENTIRE anon key (it's very long!)
- Make sure there are no extra spaces or quotes
- Verify the URL starts with `https://` and ends with `.supabase.co`

### **Can't find the credentials?**
1. Make sure you're signed into the right Supabase account
2. Make sure you're in the correct project
3. Settings → API should show the values

### **Don't have a Supabase project?**
1. Go to https://supabase.com
2. Click "Start your project"
3. Create a new project (takes ~2 minutes)
4. Then follow steps above to get credentials

---

## 📸 **Visual Guide**

**Where to find credentials:**

```
Supabase Dashboard
├── [Your Project Name]
    ├── Settings ⚙️
        ├── API
            ├── Project URL → Copy this!
            └── Project API keys
                └── anon public → Copy this!
```

---

## ✅ **Quick Checklist**

- [ ] Go to Supabase Dashboard
- [ ] Click Settings → API
- [ ] Copy Project URL
- [ ] Copy anon public key
- [ ] Paste both into `.env` file
- [ ] Restart dev server with `--clear` flag
- [ ] Force close and reopen app
- [ ] Test completing a lesson step
- [ ] Should work! 🎉

---

**Once you add these credentials, the 400 errors will disappear!** 🚀
