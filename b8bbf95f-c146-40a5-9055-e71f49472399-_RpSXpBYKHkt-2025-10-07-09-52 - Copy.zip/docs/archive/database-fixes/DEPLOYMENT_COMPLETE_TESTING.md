# ✅ Deployment Complete - Testing Checklist

## 🎉 Congratulations!

Your Vercel proxy has been deployed with:
- ✅ SELECT operation handler (fixes 405 errors)
- ✅ UPSERT operation with onConflict support (fixes duplicate key errors)
- ✅ Storage endpoints (upload/download via signed URLs)

Your React Native app already has:
- ✅ Updated database client (`src/lib/supabase-mcp.ts`)
- ✅ Cloud storage service (`src/api/cloud-storage.ts`)
- ✅ Example components (`src/examples/CloudStorageExample.tsx`)

---

## 📋 Testing Checklist

### Test 1: Verify Lessons Load (Critical)

**What to test:**
- Open your React Native app
- App should load lessons from database
- No more "405 Method Not Allowed" errors

**Expected Result:**
```
✅ [LessonsStore] Loaded 132 lessons from database
```

**If it fails:**
- Check Vercel deployment logs
- Verify SELECT handler was added correctly
- Check environment variables are set (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

---

### Test 2: Test User Authentication

**What to test:**
- Sign in to your app
- Check that JWT token is stored
- Verify user session persists

**Expected Result:**
- Sign in succeeds
- User profile loads
- No authentication errors

---

### Test 3: Test Lesson Progress Sync (When Re-enabled)

**What to test:**
- Complete a lesson step
- Check if progress syncs to cloud

**Current Status:**
- ⚠️ Still disabled in `src/state/lessons-store.ts` (lines 198-211)
- Will work once you re-enable after confirming SELECT works

**To re-enable:**
1. Verify lessons load successfully (Test 1 passes)
2. Open `src/state/lessons-store.ts`
3. Uncomment the sync methods (lines 198-211)
4. Replace with actual implementation from `src/services/database/LessonProgressService.ts`

---

### Test 4: Test Cloud Storage (Optional - New Feature)

**What to test:**
- Upload a photo using the cloud storage service
- Get download URL
- Display the photo

**How to test:**
```typescript
import { uploadFromUri, getFileUrl } from '../api/cloud-storage';

// Upload
const result = await uploadFromUri(imageUri, {
  bucket: 'user-content',
  path: `users/${userId}/photos/test.jpg`,
  contentType: 'image/jpeg',
});

console.log('Upload result:', result);

// Get URL
const url = await getFileUrl('user-content', result.path, 300);
console.log('Download URL:', url);
```

**If storage fails:**
- Check Vercel logs for storage endpoint errors
- Verify storage buckets exist in Supabase
- Verify storage policies are set

---

## 🔍 Quick Verification Commands

### Test Proxy SELECT Endpoint

```bash
# Replace with your actual values
export PROXY_URL="https://vercel-multi-ai-proxy.vercel.app"
export JWT_TOKEN="your-jwt-token-here"

# Test SELECT operation
curl -X POST "$PROXY_URL/api/db/query" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "select",
    "table": "lessons",
    "select": "*",
    "limit": 5
  }'

# Expected: Returns JSON with lessons array
```

### Test Proxy UPSERT Endpoint

```bash
# Test UPSERT with onConflict
curl -X POST "$PROXY_URL/api/db/query" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "your-user-id",
      "skill_id": "test-skill",
      "completed": false,
      "completed_steps": [],
      "step_results": {}
    }],
    "onConflict": "user_id,skill_id"
  }'

# Expected: Returns JSON with upserted data
# No duplicate key errors
```

### Test Storage Upload URL

```bash
curl -X POST "$PROXY_URL/api/storage/upload-url" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "bucket": "user-content",
    "path": "test.jpg",
    "contentType": "image/jpeg"
  }'

# Expected: Returns { uploadUrl, method, headers }
```

---

## 🐛 Common Issues & Solutions

### Issue: Still getting 405 errors

**Cause:** SELECT handler not deployed or incorrect

**Solution:**
1. Check Vercel deployment logs
2. Verify the SELECT handler is in your `/api/db/query` file
3. Redeploy if needed

---

### Issue: Getting 401 Unauthorized

**Cause:** JWT token invalid or not sent

**Solution:**
1. Sign out and sign in again to get fresh token
2. Check that token is being sent in Authorization header
3. Verify token with: `console.log((global as any).__AUTH_TOKEN__)`

---

### Issue: Getting 400 Bad Request

**Cause:** Invalid request data or missing parameters

**Solution:**
1. Check Vercel logs for specific error message
2. Verify request body has all required fields
3. Check that environment variables are set in Vercel

---

### Issue: Lessons not loading

**Cause:** Database query failing or no lessons in database

**Solution:**
1. Check Vercel logs for errors
2. Verify lessons exist in Supabase: `select count(*) from lessons`
3. Check that SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are correct

---

### Issue: Storage uploads fail with 404

**Cause:** Storage endpoints not deployed

**Solution:**
1. Verify files exist in Vercel project:
   - `/api/storage/upload-url.ts`
   - `/api/storage/download-url.ts`
   - `/api/storage/delete.ts`
2. Redeploy Vercel project
3. Check deployment logs

---

## 📊 What Should Work Now

| Feature | Status | Test Method |
|---------|--------|-------------|
| Load Lessons | ✅ Should work | Open app, check console |
| User Auth | ✅ Should work | Sign in/out |
| Lesson Progress (local) | ✅ Works | Complete a lesson |
| Lesson Progress (cloud) | ⏳ Disabled | Re-enable after testing |
| Cloud Storage | ✅ Ready | Use cloud-storage.ts API |

---

## 🎯 Next Steps

### Immediate (Today)

1. ✅ Test that lessons load in your app
2. ✅ Verify no 405 errors in console
3. ✅ Test user authentication works

### Short Term (This Week)

1. ⏳ Re-enable cloud sync for lesson progress
2. ⏳ Test cloud sync thoroughly
3. ⏳ Integrate cloud storage into screens

### Medium Term (Next Week)

1. 🔜 Add profile photo upload
2. 🔜 Add achievement share cards
3. 🔜 Add progress photos to lessons

---

## 📞 Need Help?

If you encounter any issues:

1. **Check Vercel Logs**
   - Go to Vercel dashboard
   - Click on your deployment
   - View Runtime Logs

2. **Check React Native Console**
   - Look for error messages
   - Check network requests in dev tools

3. **Review Documentation**
   - `FIX_405_ERROR.md` - SELECT handler fix
   - `VERCEL_PROXY_CHANGES.md` - Database operations
   - `VERCEL_STORAGE_ENDPOINTS.md` - Storage setup
   - `README_IMPLEMENTATION.md` - Complete guide

---

## ✨ Success Indicators

You'll know everything is working when:

- ✅ App loads lessons without errors
- ✅ Console shows: "[LessonsStore] Loaded X lessons from database"
- ✅ No 405, 400, or 401 errors in console
- ✅ User can sign in and see their progress
- ✅ Lesson completion works (saves locally)

---

**Status**: 🟢 Deployment Complete  
**Next Action**: Test your app and verify lessons load  
**Priority**: Verify Test 1 (Load Lessons) first

---

Congratulations on completing the deployment! 🎉

Your app now has a production-ready, secure cloud infrastructure with:
- Database sync via proxy
- File storage via signed URLs
- Zero credentials in the app
- Full documentation

Test it out and let me know how it goes! 🚀
