# 📍 Exact Location to Add SELECT Handler

## Your Current Proxy Code Probably Looks Like This:

```typescript
export default async function handler(req: any, res: any) {
  // ... auth verification code ...

  if (req.method === 'POST') {
    const { operation, table, data: requestData, filters } = req.body;

    try {
      // ❌ MISSING: SELECT operation handler
      
      if (operation === 'upsert') {
        // Your existing upsert code...
      }

      if (operation === 'insert') {
        // Your existing insert code...
      }

      // etc...
    } catch (error) {
      // error handling
    }
  }
}
```

---

## Add SELECT Handler RIGHT HERE:

```typescript
export default async function handler(req: any, res: any) {
  // ... auth verification code ...

  if (req.method === 'POST') {
    const { 
      operation, 
      table, 
      data: requestData, 
      filters,
      select,        // ← Add these parameters
      limit,         // ← Add these parameters
      offset,        // ← Add these parameters
      order          // ← Add these parameters
    } = req.body;

    try {
      // ✅ ADD THIS ENTIRE BLOCK (30 lines)
      // ============================================
      if (operation === 'select') {
        let query = supabase.from(table).select(select || '*');
        
        // Apply filters
        if (filters && Array.isArray(filters)) {
          filters.forEach(filter => {
            const { column, op, value } = filter;
            if (op === 'eq') query = query.eq(column, value);
            else if (op === 'neq') query = query.neq(column, value);
            else if (op === 'gt') query = query.gt(column, value);
            else if (op === 'gte') query = query.gte(column, value);
            else if (op === 'lt') query = query.lt(column, value);
            else if (op === 'lte') query = query.lte(column, value);
          });
        }
        
        if (limit) query = query.limit(limit);
        if (offset) query = query.range(offset, offset + (limit || 10) - 1);
        if (order) {
          query = query.order(order.column, { 
            ascending: order.direction === 'asc' 
          });
        }
        
        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        return res.status(200).json({ data, error: null });
      }
      // ============================================
      // ✅ END OF NEW CODE
      
      // Your existing operations (keep these)
      if (operation === 'upsert') {
        // Your existing upsert code...
      }

      if (operation === 'insert') {
        // Your existing insert code...
      }

      // etc...
    } catch (error) {
      // error handling
    }
  }
}
```

---

## Visual Diagram

```
┌─────────────────────────────────────────────────────────────┐
│  if (req.method === 'POST') {                               │
│    const { operation, table, ... } = req.body;             │
│    try {                                                     │
│                                                              │
│      ┌────────────────────────────────────────────────┐    │
│      │  ✅ INSERT THIS CODE HERE                      │    │
│      │  if (operation === 'select') { ... }           │    │
│      └────────────────────────────────────────────────┘    │
│                                                              │
│      if (operation === 'upsert') {                          │
│        // existing code                                     │
│      }                                                       │
│                                                              │
│      if (operation === 'insert') {                          │
│        // existing code                                     │
│      }                                                       │
│    }                                                         │
│  }                                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## What This Code Does

1. **Checks for SELECT operation**: `if (operation === 'select')`
2. **Builds Supabase query**: `supabase.from(table).select(select)`
3. **Applies filters**: Loops through filters array and applies each one
4. **Applies limit**: Limits number of results
5. **Applies offset**: For pagination
6. **Applies ordering**: Sorts results
7. **Returns data**: Sends back to React Native app

---

## Example Request/Response

**React Native sends:**
```json
POST /api/db/query
{
  "operation": "select",
  "table": "lessons",
  "select": "*",
  "limit": 200,
  "order": {
    "column": "created_at",
    "direction": "asc"
  }
}
```

**Proxy returns:**
```json
{
  "data": [
    { "id": "1", "title": "Lesson 1", ... },
    { "id": "2", "title": "Lesson 2", ... },
    ...
  ],
  "error": null
}
```

---

## Deployment

```bash
# In your Vercel proxy project directory
vercel deploy

# Or if using git
git add api/db/query.ts
git commit -m "Add SELECT operation handler"
git push
# Vercel auto-deploys
```

---

## Verification

After deploying, check your React Native app:

**Before (Error):**
```
❌ [LessonsStore] Exception loading lessons: 
   Error: Database query failed: 405
```

**After (Success):**
```
✅ [LessonsStore] Loaded 132 lessons from database
```

---

## Still Not Working?

If you still get errors after deploying:

1. Check Vercel logs for any deployment errors
2. Verify the code was added in the right place
3. Make sure `supabase` client is initialized at the top of the file
4. Check that environment variables are set (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

---

**That's it!** Add this code block, deploy, and your app will work immediately. 🚀
