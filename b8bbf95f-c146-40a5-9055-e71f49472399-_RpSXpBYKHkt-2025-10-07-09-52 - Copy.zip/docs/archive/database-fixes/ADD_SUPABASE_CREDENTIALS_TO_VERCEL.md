# 🎯 Quick Fix: Add Supabase Credentials to Vercel

## What You Need to Do

Add **2 environment variables** to your Vercel project, then **redeploy**.

---

## Step 1: Get Service Role Key from Supabase

```
https://supabase.com/dashboard
  → Click your project (fhllozktjqvqfedlmhqm)
  → Settings (⚙️ icon)
  → API
  → Scroll to "Project API keys"
  → Find "service_role" (secret key)
  → Click "Reveal"
  → Copy the entire key
```

---

## Step 2: Add Variables to Vercel

```
https://vercel.com/dashboard
  → vercel-multi-ai-proxy
  → Settings
  → Environment Variables
  → Add New
```

### Variable 1:
```
Key:    SUPABASE_URL
Value:  https://fhllozktjqvqfedlmhqm.supabase.co

Environments: ✓ Production ✓ Preview ✓ Development

Click "Save"
```

### Variable 2:
```
Key:    SUPABASE_SERVICE_ROLE_KEY
Value:  [paste the long key from Supabase - starts with eyJ...]

Environments: ✓ Production ✓ Preview ✓ Development

Click "Save"
```

---

## Step 3: Redeploy

**Critical:** Variables only work after redeployment!

```
Vercel Dashboard
  → vercel-multi-ai-proxy
  → Deployments tab
  → Click "..." on latest deployment
  → Click "Redeploy"
  → Wait 1-2 minutes
```

---

## Verify It Works

### Check Vercel Logs:
```
✅ Should see: POST 200 /api/db/query
❌ No more: 401 from fhllozktjqvqfedlmhqm.supabase.co
```

### Check Your App:
```
✅ Lessons load successfully
✅ Tips load successfully
✅ No errors in console
```

---

## Why This Is Needed

Your proxy code (`/app/api/db/query/route.ts`) has:

```typescript
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);
```

Without these environment variables, the proxy can't connect to Supabase!

---

## Security Note

✅ **Correct:** Service role key in Vercel (server-side)  
❌ **Wrong:** Service role key in React Native app or committed to git

The key should **only** exist on your Vercel server.

---

## Common Mistakes

1. ❌ Using "anon" key instead of "service_role" key
2. ❌ Forgetting to redeploy after adding variables
3. ❌ Not checking all three environments (Prod, Preview, Dev)
4. ❌ Typo in variable names

---

**That's it!** Add the two variables, redeploy, and you're done. 🚀
