# ⚠️ Cloud Sync Temporarily Disabled - Proxy Issue

## Current Status: DISABLED ❌

Cloud sync has been **temporarily disabled** due to a limitation with the Vercel proxy's upsert implementation.

---

## The Problem

The Vercel proxy at `https://vercel-multi-ai-proxy.vercel.app` does not properly handle **upsert operations** with UNIQUE constraints.

### Error Encountered:
```
duplicate key value violates unique constraint "user_lesson_progress_user_id_skill_id_key"
```

### What's Happening:

1. **Table has UNIQUE constraint** on `(user_id, skill_id)`
2. **Proxy always uses `upsert` operation** (not separate INSERT/UPDATE)
3. **`onConflict` parameter not working** - Proxy doesn't translate it to PostgreSQL's `ON CONFLICT` clause
4. **Result**: Trying to sync existing progress fails with duplicate key error

---

## Technical Details

### Proxy Request Format:
```json
{
  "operation": "upsert",
  "table": "user_lesson_progress",
  "data": [{
    "user_id": "uuid",
    "skill_id": "skill-123",
    "completed": false,
    "completed_steps": [],
    ...
  }],
  "onConflict": "user_id,skill_id",
  "returning": "representation"
}
```

###Proxy Behavior:
- Receives `onConflict` parameter
- **Does NOT apply it** to the Supabase upsert
- Attempts regular INSERT
- Fails if record exists (violates UNIQUE constraint)

### Expected Behavior:
```sql
INSERT INTO user_lesson_progress (...)
VALUES (...)
ON CONFLICT (user_id, skill_id) 
DO UPDATE SET ...
```

### Actual Behavior:
```sql
INSERT INTO user_lesson_progress (...)
VALUES (...)
-- No ON CONFLICT clause
-- Fails with duplicate key error
```

---

## Solutions Attempted

### ❌ Attempt 1: Use `onConflict` Parameter
- **Result**: Proxy ignores it, duplicate key errors

### ❌ Attempt 2: Fetch-First with ID
- **Result**: Proxy still treats as upsert, same error

### ❌ Attempt 3: Delete-Then-Insert
- **Result**: Race conditions, timing issues

### ❌ Attempt 4: Separate UPDATE/INSERT Logic
- **Result**: Proxy only has `upsert` operation, no separate UPDATE

---

## What Needs to Happen

### Option 1: Fix Proxy Server-Side (RECOMMENDED)

The Vercel proxy needs to be updated to properly handle the `onConflict` parameter:

```typescript
// In proxy server code
if (operation === 'upsert' && onConflict) {
  // Use Supabase's upsert with onConflict
  return supabase
    .from(table)
    .upsert(data, { 
      onConflict: onConflict,
      returning: returning 
    });
}
```

**Files to modify on proxy:**
- `/api/db/query` endpoint handler
- Need to parse `onConflict` parameter
- Pass it to Supabase's `.upsert()` method

### Option 2: Add Separate UPDATE Operation

Add a new `update` operation type to the proxy:

```typescript
// In proxy
if (operation === 'update') {
  // Use Supabase's update (not upsert)
  return supabase
    .from(table)
    .update(data)
    .eq('id', data.id);
}
```

Then update client:
```typescript
// In supabase-mcp.ts
async update(table, data, options) {
  if (data.id) {
    // Has ID, use UPDATE operation
    payload.operation = 'update';
  } else {
    // No ID, use UPSERT operation
    payload.operation = 'upsert';
    payload.onConflict = options.onConflict;
  }
}
```

### Option 3: Use Direct Supabase Connection

Add Supabase credentials to `.env` and bypass proxy for database operations:

```bash
# .env
EXPO_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
```

Then use `@supabase/supabase-js` client directly instead of proxy.

---

## Current Workaround

**Cloud sync is disabled** to prevent error spam. The app works perfectly with **local storage only** (AsyncStorage):

✅ Progress saves locally  
✅ Persists across app restarts  
✅ No errors  
❌ No cloud backup  
❌ No cross-device sync  

---

## Re-enabling Cloud Sync

Once the proxy is fixed, re-enable sync by uncommenting the methods in:
- `src/state/lessons-store.ts` lines 196-286

The implementation is complete and ready - it just needs a working proxy.

---

## Testing Proxy Fix

After proxy is updated, test with:

```bash
# 1. First sync (INSERT)
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user",
      "skill_id": "test-skill",
      "completed": false
    }],
    "onConflict": "user_id,skill_id"
  }'

# 2. Second sync (UPDATE - same data)
# Should succeed, not error
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user",
      "skill_id": "test-skill",
      "completed": true
    }],
    "onConflict": "user_id,skill_id"
  }'
```

Expected: Both requests succeed, second one updates the first record.

---

## Contact

For proxy fixes, contact the maintainer of:
- **Proxy URL**: `https://vercel-multi-ai-proxy.vercel.app`
- **Required**: Support for `onConflict` parameter in upsert operations
- **Database**: Supabase with PostgreSQL `ON CONFLICT` clause

---

**Status**: ⚠️ Awaiting Proxy Fix  
**Impact**: Cloud sync unavailable, local storage works fine  
**Priority**: Medium (app functional without cloud sync)  
**Date**: October 3, 2025
