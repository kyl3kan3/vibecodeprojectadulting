# 🔧 Fix Cloud Sync Error

## Error You're Seeing
```
[Database] getAllProgress failed (attempt 3/3): Database query failed: 403 
{"error":"Table not allowed","table":"public.user_lesson_progress"}
```

## What This Means
The Supabase table `user_lesson_progress` either:
1. Doesn't exist yet, OR
2. Exists but has incorrect permissions

## ✅ How to Fix (5 Minutes)

### **Step 1: Open Supabase Dashboard**
1. Go to: https://supabase.com/dashboard
2. Select your project
3. Click **SQL Editor** in the left sidebar

### **Step 2: Run the Fix Script**
1. Click **New Query**
2. Copy the ENTIRE contents of: `scripts/fix-cloud-sync.sql`
3. Paste into the SQL editor
4. Click **RUN** (or press Cmd/Ctrl + Enter)

### **Step 3: Verify Success**
You should see:
```
✅ Table created successfully!
✅ Row count: 0
✅ Policies listed (4 policies)
```

### **Step 4: Restart Your App**
1. Force close the app completely
2. Reopen the app
3. The error should be GONE! ✨

---

## 🎯 What the Script Does

1. **Drops old table** (if exists) - Fresh start
2. **Creates new table** - With all correct columns
3. **Enables RLS** - Security enabled
4. **Creates policies** - Users can only see their own data
5. **Adds indexes** - Makes queries fast
6. **Creates trigger** - Auto-updates timestamps
7. **Verifies success** - Shows you it worked

---

## ✨ After Running Migration

### **What Changes:**
- ✅ Error disappears completely
- ✅ Progress syncs to cloud automatically
- ✅ Console shows: `☁️ Synced: [lesson-name]`
- ✅ Progress loads on login
- ✅ Data backed up in Supabase

### **What Stays the Same:**
- ✅ Local progress still works
- ✅ App doesn't crash if sync fails
- ✅ Offline progress saved locally

---

## 🔍 Alternative: Manual Setup

If the script doesn't work, you can also:

### **Option A: Use Original Migration**
- Copy entire contents of `supabase-lesson-progress-migration.sql`
- Paste in SQL Editor
- Run it

### **Option B: Check Existing Table**
If table already exists, check permissions:

```sql
-- Check if table exists
SELECT * FROM public.user_lesson_progress LIMIT 1;

-- Check RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE tablename = 'user_lesson_progress';

-- Check policies exist
SELECT policyname, cmd 
FROM pg_policies 
WHERE tablename = 'user_lesson_progress';
```

If RLS shows `false`, run:
```sql
ALTER TABLE public.user_lesson_progress ENABLE ROW LEVEL SECURITY;
```

---

## 🐛 Still Getting Errors?

### **If "handle_updated_at function not found":**
This is OK! The trigger is optional. The table will still work.

### **If "permission denied":**
Make sure you're logged into Supabase with the project owner account.

### **If "relation already exists":**
The table exists but has wrong permissions. Run this:
```sql
-- Fix permissions
ALTER TABLE public.user_lesson_progress ENABLE ROW LEVEL SECURITY;

-- Re-create policies (drops old ones first)
DROP POLICY IF EXISTS "Users can view own lesson progress" ON public.user_lesson_progress;
CREATE POLICY "Users can view own lesson progress" 
  ON public.user_lesson_progress FOR SELECT 
  USING (auth.uid() = user_id);
```

---

## 📊 Verify It's Working

After migration, in your app:

1. **Complete a lesson step**
2. **Check console** - Should see: `☁️ Synced: lesson-name`
3. **Go to Supabase Dashboard** → Table Editor → `user_lesson_progress`
4. **Should see your progress row!**

---

## 💡 Why This Error Happened

The cloud sync code was implemented and working, but:
- The database table didn't exist yet
- Supabase returned "403 Table not allowed"
- The app handled it gracefully (no crash!)
- But showed the warning in console

After running the migration:
- Table exists
- Permissions correct
- Syncing works perfectly
- No more errors! 🎉

---

## 🚀 Ready to Fix?

1. Open Supabase SQL Editor
2. Run `scripts/fix-cloud-sync.sql`
3. Restart app
4. Done! ✨

**Questions?** The error is expected and easily fixed with the migration!
