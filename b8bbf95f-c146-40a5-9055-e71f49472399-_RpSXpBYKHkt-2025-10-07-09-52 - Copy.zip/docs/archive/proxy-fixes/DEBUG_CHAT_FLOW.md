# Debug Chat Flow - Enhanced Logging

## What I Fixed

1. **URL Construction Bug** - Fixed the proxy URL to correctly form `https://vercel-multi-ai-proxy.vercel.app/api/ai`
2. **Added Comprehensive Logging** - Added debug logs throughout the entire call chain

## Expected Console Output

When you send a chat message like "Hello", you should see these logs **in this exact order**:

```
[CoachScreen] sendMessage called with text: Hello
[CoachScreen] Entering try block - about to make AI call
[CoachScreen] About to call getCoachAIResponse with 2 messages
[chat-service] getCoachAIResponse called with options: { model: 'gpt-4o-mini', temperature: 0.2, maxTokens: 700 }
[chat-service] Normalized to 2 messages, calling getOpenAITextResponse...
[chat-service] getOpenAITextResponse called, normalizing messages...
[chat-service] Calling proxyChat with provider: openai, model: gpt-4o-mini
[Proxy] proxyChat called with: {
  provider: 'openai',
  task: 'chat',
  model: 'gpt-4o-mini',
  hasMessages: true,
  messageCount: 2,
  hasPrompt: false
}
[Proxy] JWT from provider: eyJhbGciOiJIUzI1Ni... (truncated)
[Proxy] Sending request to: https://vercel-multi-ai-proxy.vercel.app/api/ai
[Proxy] Request body: {
  "provider": "openai",
  "task": "chat",
  "model": "gpt-4o-mini",
  "messages": [...],
  "temperature": 0.2,
  "max_tokens": 700
}
[Proxy] Response received: { ... }
[chat-service] proxyChat returned data
[CoachScreen] Got response: { content: "...", usage: {...} }
```

## Troubleshooting Based on Logs

### Scenario 1: No Logs at All
**Symptom:** You don't see ANY of the above logs when pressing send

**Possible Causes:**
1. The send button isn't working
2. Text input is empty
3. Already loading (isLoading = true)
4. Subscription limit reached (free users > 3 messages)

**Check:**
- Make sure you typed something in the input
- Make sure you're not already loading (look for loading indicator)
- Check if you hit the subscription limit

### Scenario 2: Logs Stop at CoachScreen
**Symptom:** You see `[CoachScreen]` logs but nothing from `[chat-service]`

**Possible Causes:**
1. Function not imported correctly
2. Exception thrown before reaching chat-service

**Check:**
- Look for error messages in console
- Check if there's a red error screen

### Scenario 3: Logs Stop at chat-service
**Symptom:** You see `[chat-service]` logs but nothing from `[Proxy]`

**Possible Causes:**
1. proxyChat not imported correctly
2. Exception in message normalization

**Check:**
- Look for TypeScript errors
- Check the error message in the chat

### Scenario 4: Logs Stop at "Calling proxyChat"
**Symptom:** You see "Calling proxyChat" but never see `[Proxy] proxyChat called`

**Possible Causes:**
1. proxy.ts not being executed
2. __DEV__ is false (shouldn't happen in development)

**This is the most likely scenario if you're not seeing proxy logs!**

### Scenario 5: "JWT from provider: null"
**Symptom:** You see `[Proxy] JWT from provider: null` or `[Proxy] No authTokenProvider set`

**Possible Causes:**
1. Not logged in
2. Auth token provider not set up in App.tsx
3. Session expired

**Fix:**
- Log out and log back in
- Restart the app completely

### Scenario 6: "Network request failed"
**Symptom:** You see all logs up to "Sending request to" then error

**Possible Causes:**
1. Device offline
2. Vercel proxy not accessible
3. URL still malformed (should be fixed now)

**Fix:**
- Check internet connection
- Try accessing `https://vercel-multi-ai-proxy.vercel.app/` in a browser
- Verify the URL in logs is correct (has `/api/ai` at the end)

### Scenario 7: Gets Response But Shows Error
**Symptom:** You see all logs including "Response received" but chat shows error

**Possible Causes:**
1. Response format unexpected
2. Content extraction failed
3. Error in parsing response

**Check:**
- Look at the response object in logs
- Check if it has `choices[0].message.content`

## Testing Steps

1. **Open the app** in Vibecode
2. **Go to Coach tab** (bottom navigation)
3. **Type "test" in the input**
4. **Press send**
5. **Watch the console carefully** - scroll through all the logs
6. **Find where the logs stop** - that's where the problem is
7. **Take a screenshot of the console logs**
8. **Report back with:**
   - Which logs you see
   - Where the logs stop
   - Any error messages

## Quick Tests

### Test 1: Is sendMessage Being Called?
Look for: `[CoachScreen] sendMessage called`
- ✅ YES → Go to Test 2
- ❌ NO → Button isn't working or input is empty

### Test 2: Is getCoachAIResponse Being Called?
Look for: `[chat-service] getCoachAIResponse called`
- ✅ YES → Go to Test 3
- ❌ NO → Error in CoachScreen before reaching chat-service

### Test 3: Is proxyChat Being Called?
Look for: `[Proxy] proxyChat called`
- ✅ YES → Go to Test 4
- ❌ NO → Error in chat-service or proxy import issue

### Test 4: Is JWT Token Present?
Look for: `[Proxy] JWT from provider: eyJ...`
- ✅ YES → Go to Test 5
- ❌ NO (shows "null") → Not logged in or auth issue

### Test 5: Is Network Request Made?
Look for: `[Proxy] Sending request to: https://vercel-multi-ai-proxy.vercel.app/api/ai`
- ✅ YES (URL looks correct) → Go to Test 6
- ❌ NO or URL is wrong → Proxy configuration issue

### Test 6: Is Response Received?
Look for: `[Proxy] Response received:`
- ✅ YES → Success! Check if response shows in chat
- ❌ NO → Network issue, Vercel proxy down, or timeout

## Files Modified

- `src/api/proxy.ts` - Fixed URL construction (line 113)
- `src/screens/CoachScreen.tsx` - Added logging at lines 107-110, 152, 176-178
- `src/api/chat-service.ts` - Added logging in getCoachAIResponse and getOpenAITextResponse

## What Should Happen

After sending "test", you should:
1. See all the above logs in order
2. See the AI response appear in the chat
3. See "Thinking..." indicator briefly
4. See a response like "Hello! How can I help you with adulting today?"

## Common Issues - Already Fixed

✅ URL construction bug (vercel.appapi/ai → vercel.app/api/ai)  
✅ Missing debug logs (added comprehensive logging)  
⏳ ProxySessionMonitor warning (harmless, can ignore)  

## Next Steps

Run the test and share:
1. **Screenshot of console logs** when you send a message
2. **Where the logs stop** (which test failed)
3. **Any error messages** in the console or in the chat

This will help me pinpoint exactly where the issue is!
