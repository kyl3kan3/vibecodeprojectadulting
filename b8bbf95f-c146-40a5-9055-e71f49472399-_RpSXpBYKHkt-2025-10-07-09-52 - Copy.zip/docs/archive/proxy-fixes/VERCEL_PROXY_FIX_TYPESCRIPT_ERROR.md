# 🔧 Fix TypeScript Error in Vercel Proxy

## Error

```
Type error: Type '"exact" | "planned" | "estimated" | null' is not assignable to type '"exact" | "planned" | "estimated" | undefined'.
Type 'null' is not assignable to type '"exact" | "planned" | "estimated" | undefined'.
```

**Line 161:** `count: count || null` is causing the error.

---

## Quick Fix

### Option 1: Use `undefined` instead of `null` (Recommended)

Change this line:

```typescript
// ❌ WRONG
let q: any = supabase.from(table).select(select || "*", { head: !!head, count: count || null });
```

To:

```typescript
// ✅ CORRECT
let q: any = supabase.from(table).select(select || "*", { head: !!head, count });
```

Or if you need a default:

```typescript
// ✅ ALSO CORRECT
let q: any = supabase.from(table).select(select || "*", { head: !!head, count: count || undefined });
```

---

## Option 2: Conditional Options Object

Even better approach:

```typescript
// Build options object conditionally
const selectOptions: any = {};
if (head) selectOptions.head = true;
if (count) selectOptions.count = count;

let q = supabase.from(table).select(select || "*", selectOptions);
```

---

## Complete Fixed SELECT Handler

Replace your entire SELECT operation handler with this corrected version:

```typescript
if (operation === 'select') {
  // Build select options
  const selectOptions: any = {};
  if (head) selectOptions.head = true;
  if (count) selectOptions.count = count; // 'exact' | 'planned' | 'estimated'
  
  let query = supabase.from(table).select(select || '*', selectOptions);
  
  // Apply filters
  if (filters && Array.isArray(filters)) {
    filters.forEach(filter => {
      const { column, op, value } = filter;
      if (op === 'eq') query = query.eq(column, value);
      else if (op === 'neq') query = query.neq(column, value);
      else if (op === 'gt') query = query.gt(column, value);
      else if (op === 'gte') query = query.gte(column, value);
      else if (op === 'lt') query = query.lt(column, value);
      else if (op === 'lte') query = query.lte(column, value);
      else if (op === 'like') query = query.like(column, value);
      else if (op === 'ilike') query = query.ilike(column, value);
      else if (op === 'in') {
        const inValue = Array.isArray(value) ? value : [value];
        query = query.in(column, inValue);
      }
    });
  }
  
  // Apply limit
  if (limit) {
    query = query.limit(limit);
  }
  
  // Apply offset/range
  if (offset !== undefined && limit) {
    query = query.range(offset, offset + limit - 1);
  }
  
  // Apply ordering
  if (order && order.column) {
    query = query.order(order.column, { 
      ascending: order.direction === 'asc' || order.direction !== 'desc'
    });
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Select error:', error);
    return res.status(400).json({ error: error.message });
  }
  
  return res.status(200).json({ data, error: null });
}
```

---

## Even Simpler Version (If You Don't Need `head` or `count`)

If your app doesn't use the `head` or `count` parameters, use this minimal version:

```typescript
if (operation === 'select') {
  let query = supabase.from(table).select(select || '*');
  
  // Apply filters
  if (filters && Array.isArray(filters)) {
    filters.forEach(filter => {
      const { column, op, value } = filter;
      if (op === 'eq') query = query.eq(column, value);
      else if (op === 'neq') query = query.neq(column, value);
      else if (op === 'gt') query = query.gt(column, value);
      else if (op === 'gte') query = query.gte(column, value);
      else if (op === 'lt') query = query.lt(column, value);
      else if (op === 'lte') query = query.lte(column, value);
    });
  }
  
  if (limit) query = query.limit(limit);
  if (offset !== undefined && limit) {
    query = query.range(offset, offset + limit - 1);
  }
  if (order?.column) {
    query = query.order(order.column, { 
      ascending: order.direction === 'asc' 
    });
  }
  
  const { data, error } = await query;
  if (error) {
    console.error('Select error:', error);
    return res.status(400).json({ error: error.message });
  }
  
  return res.status(200).json({ data, error: null });
}
```

---

## Why This Happened

TypeScript is strict about types:
- ✅ `undefined` is allowed
- ❌ `null` is not allowed for this parameter
- The `count` parameter expects: `'exact' | 'planned' | 'estimated' | undefined`

---

## Quick Fix Steps

1. Find line 161 in your `app/api/db/query/route.ts`
2. Replace with the simpler version above (without `head` and `count`)
3. Save and deploy again

---

## Test After Deployment

```bash
# Should work now
vercel deploy
```

Your React Native app will immediately load lessons successfully! ✅

---

**Status**: TypeScript compilation error  
**Fix Time**: 30 seconds (replace code)  
**Next**: Deploy again and test
