# ✅ Correct Code for App Router (Next.js 13+)

## Your File: `/app/api/db/query/route.ts`

Replace the entire contents with this:

```typescript
import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  try {
    // Parse request body
    const body = await req.json();
    
    // Verify JWT authentication
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized - missing token' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Invalid or expired token' },
        { status: 401 }
      );
    }

    // Extract request parameters
    const { 
      operation, 
      table, 
      select, 
      filters, 
      limit, 
      offset, 
      order,
      data: requestData,
      onConflict,
      ignoreDuplicates
    } = body;

    // ===== SELECT OPERATION =====
    if (operation === 'select') {
      let query = supabase.from(table).select(select || '*');
      
      // Apply filters
      if (filters && Array.isArray(filters)) {
        filters.forEach((filter: any) => {
          const { column, op, value } = filter;
          if (op === 'eq') query = query.eq(column, value);
          else if (op === 'neq') query = query.neq(column, value);
          else if (op === 'gt') query = query.gt(column, value);
          else if (op === 'gte') query = query.gte(column, value);
          else if (op === 'lt') query = query.lt(column, value);
          else if (op === 'lte') query = query.lte(column, value);
          else if (op === 'like') query = query.like(column, value);
          else if (op === 'ilike') query = query.ilike(column, value);
          else if (op === 'in') {
            const inValue = Array.isArray(value) ? value : [value];
            query = query.in(column, inValue);
          }
        });
      }
      
      // Apply limit
      if (limit) {
        query = query.limit(limit);
      }
      
      // Apply offset/pagination
      if (offset !== undefined && limit) {
        query = query.range(offset, offset + limit - 1);
      }
      
      // Apply ordering
      if (order?.column) {
        query = query.order(order.column, { 
          ascending: order.direction === 'asc' 
        });
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Select error:', error);
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      
      return NextResponse.json({ data, error: null });
    }

    // ===== UPSERT OPERATION =====
    if (operation === 'upsert') {
      const upsertOptions: any = {};
      
      if (onConflict) {
        upsertOptions.onConflict = onConflict;
      }
      
      if (ignoreDuplicates !== undefined) {
        upsertOptions.ignoreDuplicates = ignoreDuplicates;
      }
      
      const { data, error } = await supabase
        .from(table)
        .upsert(requestData, upsertOptions);
      
      if (error) {
        console.error('Upsert error:', error);
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      
      return NextResponse.json({ data, error: null });
    }

    // ===== INSERT OPERATION =====
    if (operation === 'insert') {
      const { data, error } = await supabase
        .from(table)
        .insert(requestData);
      
      if (error) {
        console.error('Insert error:', error);
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      
      return NextResponse.json({ data, error: null });
    }

    // ===== UPDATE OPERATION =====
    if (operation === 'update') {
      let query = supabase.from(table).update(requestData);
      
      // Apply filters
      if (filters && Array.isArray(filters)) {
        filters.forEach((filter: any) => {
          const { column, op, value } = filter;
          if (op === 'eq') query = query.eq(column, value);
          else if (op === 'neq') query = query.neq(column, value);
          else if (op === 'gt') query = query.gt(column, value);
          else if (op === 'gte') query = query.gte(column, value);
          else if (op === 'lt') query = query.lt(column, value);
          else if (op === 'lte') query = query.lte(column, value);
        });
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Update error:', error);
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      
      return NextResponse.json({ data, error: null });
    }

    // ===== DELETE OPERATION =====
    if (operation === 'delete') {
      let query = supabase.from(table).delete();
      
      // Apply filters
      if (filters && Array.isArray(filters)) {
        filters.forEach((filter: any) => {
          const { column, op, value } = filter;
          if (op === 'eq') query = query.eq(column, value);
          else if (op === 'neq') query = query.neq(column, value);
        });
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Delete error:', error);
        return NextResponse.json(
          { error: error.message },
          { status: 400 }
        );
      }
      
      return NextResponse.json({ data, error: null });
    }

    // Invalid operation
    return NextResponse.json(
      { error: 'Invalid operation' },
      { status: 400 }
    );

  } catch (error: any) {
    console.error('Handler error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
```

---

## Key Differences for App Router

### 1. Function Export
```typescript
// ❌ Pages Router (OLD - causes 500)
export default async function handler(req, res) { ... }

// ✅ App Router (NEW - correct)
export async function POST(req: NextRequest) { ... }
```

### 2. Request Body
```typescript
// ❌ Pages Router
const body = req.body;

// ✅ App Router
const body = await req.json();
```

### 3. Headers
```typescript
// ❌ Pages Router
const authHeader = req.headers.authorization;

// ✅ App Router
const authHeader = req.headers.get('authorization');
```

### 4. Response
```typescript
// ❌ Pages Router
return res.status(200).json({ data });

// ✅ App Router
return NextResponse.json({ data });
```

---

## Deploy Steps

1. **Copy the code above**
2. **Replace entire contents** of `/app/api/db/query/route.ts`
3. **Commit and push** (or deploy via Vercel dashboard)
4. **Wait for deployment** (1-2 minutes)
5. **Test your app** - should work now!

---

## Verification

After deploying, you should see in Vercel logs:
```
✅ POST 200 /api/db/query
```

And in your React Native app console:
```
✅ [LessonsStore] Loaded 132 lessons from database
```

---

**This will fix the 500 error!** Deploy this and test. 🚀
