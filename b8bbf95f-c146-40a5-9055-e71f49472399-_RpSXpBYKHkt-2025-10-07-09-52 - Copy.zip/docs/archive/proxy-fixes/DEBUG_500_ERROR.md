# 🔍 Debug 500 Internal Server Error

## What 500 Means

**500 Internal Server Error** = There's a bug in your Vercel proxy code that's causing it to crash.

---

## How to Find the Error

### Step 1: Check Vercel Runtime Logs

1. Go to **https://vercel.com/dashboard**
2. Click on your **vercel-multi-ai-proxy** project
3. Click on the **latest deployment**
4. Go to **"Functions"** tab or **"Runtime Logs"** tab
5. Look for error messages with timestamps matching your request

### Step 2: Look for These Common Errors

#### Error Type 1: Syntax Error
```
SyntaxError: Unexpected token
```
**Cause:** Missing bracket, comma, or semicolon  
**Fix:** Check the code you just added for syntax errors

#### Error Type 2: ReferenceError
```
ReferenceError: supabase is not defined
```
**Cause:** Variable used but not imported/defined  
**Fix:** Make sure Supabase client is initialized at top of file

#### Error Type 3: TypeError
```
TypeError: Cannot read property 'from' of undefined
```
**Cause:** Trying to call method on undefined variable  
**Fix:** Check that all variables are properly initialized

#### Error Type 4: Environment Variable Missing
```
Error: Invalid Supabase URL
```
**Cause:** SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not set  
**Fix:** Check Vercel environment variables

---

## Common Mistakes When Adding SELECT Handler

### Mistake 1: Missing Supabase Import

**Wrong:**
```typescript
export default async function handler(req, res) {
  // ❌ supabase not defined
  let query = supabase.from(table).select(select);
}
```

**Correct:**
```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req, res) {
  // ✅ supabase is defined
  let query = supabase.from(table).select(select);
}
```

### Mistake 2: Missing Error Handling

**Wrong:**
```typescript
if (operation === 'select') {
  let query = supabase.from(table).select(select);
  const { data, error } = await query;
  return res.status(200).json({ data }); // ❌ Doesn't handle error
}
```

**Correct:**
```typescript
if (operation === 'select') {
  let query = supabase.from(table).select(select);
  const { data, error } = await query;
  
  if (error) {
    console.error('Select error:', error);
    return res.status(400).json({ error: error.message });
  }
  
  return res.status(200).json({ data, error: null });
}
```

### Mistake 3: Accessing Undefined Properties

**Wrong:**
```typescript
// ❌ order might be undefined
query = query.order(order.column, { ascending: order.direction === 'asc' });
```

**Correct:**
```typescript
// ✅ Check if order exists first
if (order?.column) {
  query = query.order(order.column, { ascending: order.direction === 'asc' });
}
```

### Mistake 4: Wrong Method Signature

**Wrong:**
```typescript
// ❌ Next.js 13+ App Router uses different signature
export default async function handler(req, res) {
  // This works in Pages Router, not App Router
}
```

**Correct for App Router:**
```typescript
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const body = await req.json();
  // ... your code
  return NextResponse.json({ data, error: null });
}
```

---

## Quick Fix: Verify Your Code Structure

Your `/api/db/query/route.ts` (or `/api/db/query.ts`) should look like this:

```typescript
import { createClient } from '@supabase/supabase-js';
import { NextRequest, NextResponse } from 'next/server';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  try {
    // Get body
    const body = await req.json();
    
    // Verify JWT
    const authHeader = req.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { operation, table, select, filters, limit, offset, order } = body;

    // SELECT operation
    if (operation === 'select') {
      let query = supabase.from(table).select(select || '*');
      
      // Apply filters
      if (filters && Array.isArray(filters)) {
        filters.forEach(filter => {
          const { column, op, value } = filter;
          if (op === 'eq') query = query.eq(column, value);
          else if (op === 'neq') query = query.neq(column, value);
          else if (op === 'gt') query = query.gt(column, value);
          else if (op === 'gte') query = query.gte(column, value);
          else if (op === 'lt') query = query.lt(column, value);
          else if (op === 'lte') query = query.lte(column, value);
        });
      }
      
      if (limit) query = query.limit(limit);
      if (offset !== undefined && limit) {
        query = query.range(offset, offset + limit - 1);
      }
      if (order?.column) {
        query = query.order(order.column, { 
          ascending: order.direction === 'asc' 
        });
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Select error:', error);
        return NextResponse.json({ error: error.message }, { status: 400 });
      }
      
      return NextResponse.json({ data, error: null });
    }

    // UPSERT operation
    if (operation === 'upsert') {
      const { data: requestData, onConflict } = body;
      const upsertOptions: any = {};
      if (onConflict) upsertOptions.onConflict = onConflict;
      
      const { data, error } = await supabase
        .from(table)
        .upsert(requestData, upsertOptions);
      
      if (error) {
        console.error('Upsert error:', error);
        return NextResponse.json({ error: error.message }, { status: 400 });
      }
      
      return NextResponse.json({ data, error: null });
    }

    return NextResponse.json({ error: 'Invalid operation' }, { status: 400 });

  } catch (error: any) {
    console.error('Handler error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

---

## Checklist

Before asking for help, verify:

- [ ] Supabase client is imported and initialized at top of file
- [ ] Environment variables are set in Vercel (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
- [ ] All variables are defined before use (check for `undefined`)
- [ ] Proper error handling with try/catch
- [ ] Correct method signature for your Next.js version (Pages Router vs App Router)
- [ ] No syntax errors (missing brackets, commas, etc.)

---

## What to Send Me

To help debug, please provide:

1. **Error message from Vercel logs** (exact text)
2. **Line number** where error occurs
3. **Stack trace** (if available)
4. **Your Next.js version** (check package.json)
5. **Your project structure** (Pages Router or App Router?)

---

**Let's get this fixed!** Share the Vercel error logs and I'll provide the exact fix. 🔧
