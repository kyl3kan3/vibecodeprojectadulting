# 🔧 PROXY FIX REQUIRED - Server-Side Changes Needed

## Current Situation

**Cloud sync is DISABLED** because your Vercel proxy cannot properly handle upsert operations with UNIQUE constraints.

The proxy is at: `https://vercel-multi-ai-proxy.vercel.app`

---

## The Problem

When the client sends an upsert request with `onConflict` parameter, the proxy does NOT properly pass this to Supabase's `.upsert()` method, causing duplicate key errors.

### What's Happening:

**Client sends:**
```json
POST /api/db/query
{
  "operation": "upsert",
  "table": "user_lesson_progress",
  "data": [{
    "user_id": "uuid",
    "skill_id": "skill-123",
    "completed": false,
    ...
  }],
  "onConflict": "user_id,skill_id"
}
```

**Proxy does:** ❌ WRONG
```typescript
// Proxy ignores onConflict parameter
await supabase
  .from('user_lesson_progress')
  .upsert(data)  // No onConflict passed!
```

**Result:** Duplicate key error on second sync

---

## What Needs to Be Fixed (Server-Side)

### Location: Vercel Proxy `/api/db/query` Endpoint

You need to update the proxy's database query handler to properly handle the `onConflict` parameter.

### Fix 1: Handle onConflict in Upsert Operations

**File**: `/api/db/query` (or wherever your proxy handles database operations)

**Current code (BROKEN)**:
```typescript
if (operation === 'upsert') {
  const { data, error } = await supabase
    .from(table)
    .upsert(data);  // ❌ Missing onConflict
    
  return res.json({ data, error });
}
```

**Fixed code**:
```typescript
if (operation === 'upsert') {
  const { onConflict, data: requestData } = req.body;
  
  // Build upsert options
  const upsertOptions: any = {};
  
  if (onConflict) {
    upsertOptions.onConflict = onConflict;  // ✅ Pass it through
  }
  
  const { data, error } = await supabase
    .from(table)
    .upsert(requestData, upsertOptions);  // ✅ Include options
    
  return res.json({ data, error });
}
```

### Fix 2: Support ignoreDuplicates Option (Alternative)

If the above doesn't work, you can use `ignoreDuplicates` option:

```typescript
if (operation === 'upsert') {
  const { onConflict, ignoreDuplicates, data: requestData } = req.body;
  
  const upsertOptions: any = {
    ignoreDuplicates: ignoreDuplicates || false
  };
  
  if (onConflict) {
    upsertOptions.onConflict = onConflict;
  }
  
  const { data, error } = await supabase
    .from(table)
    .upsert(requestData, upsertOptions);
    
  return res.json({ data, error });
}
```

---

## Testing the Fix

After deploying the proxy fix, test with:

```bash
# Test 1: First upsert (INSERT)
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user-id",
      "skill_id": "test-skill-id",
      "completed": false,
      "completed_steps": [],
      "step_results": {}
    }],
    "onConflict": "user_id,skill_id"
  }'

# Should return 200 with data

# Test 2: Second upsert (UPDATE - same user_id and skill_id)
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user-id",
      "skill_id": "test-skill-id",
      "completed": true,
      "completed_steps": ["step1"],
      "step_results": {}
    }],
    "onConflict": "user_id,skill_id"
  }'

# Should return 200 with updated data
# Should NOT return duplicate key error
```

**Expected**: Both requests succeed, second one updates the first record.

---

## Alternative: Add Separate UPDATE Operation

If you can't fix the upsert, add a separate `update` operation:

```typescript
if (operation === 'update') {
  const { data: requestData, filters } = req.body;
  
  let query = supabase.from(table).update(requestData);
  
  // Apply filters
  filters.forEach(filter => {
    query = query.eq(filter.column, filter.value);
  });
  
  const { data, error } = await query;
  return res.json({ data, error });
}
```

Then update client to use:
- `operation: 'update'` when record exists (with filters)
- `operation: 'upsert'` only for new records

---

## Once Proxy is Fixed

After the proxy is updated and deployed:

1. **Re-enable cloud sync** in the React Native app:
   - Uncomment sync methods in `src/state/lessons-store.ts`
   - The implementation is already there, just disabled

2. **Test in app**:
   - Sign in
   - Complete lesson steps
   - Should see: "✅ Synced successfully"
   - No duplicate key errors

3. **Verify in Supabase**:
   - Check `user_lesson_progress` table
   - Should see records updating (not duplicating)

---

## Reference Documentation

- Supabase `.upsert()` docs: https://supabase.com/docs/reference/javascript/upsert
- Key parameter: `onConflict` - specifies which columns to check for conflicts
- Format: Single column name string or comma-separated for composite keys

### Example from Supabase docs:

```typescript
// Single column conflict
await supabase
  .from('cities')
  .upsert({ name: 'Chicago' }, { onConflict: 'name' })

// Composite key conflict
await supabase
  .from('user_progress')
  .upsert(
    { user_id: '123', lesson_id: 'abc', completed: true },
    { onConflict: 'user_id,lesson_id' }  // ← This is what's missing
  )
```

---

## Summary

**What you need to change**: Update your Vercel proxy's `/api/db/query` endpoint to properly pass the `onConflict` parameter to Supabase's `.upsert()` method.

**Where**: Server-side code at `https://vercel-multi-ai-proxy.vercel.app`

**Why**: Without this, the proxy cannot handle updates to existing records that have UNIQUE constraints.

**Result**: Once fixed, cloud sync will work perfectly through your proxy with full security.

---

**Status**: ⚠️ Waiting for proxy server-side fix  
**App Status**: ✅ Fully functional with local storage (no errors)  
**Cloud Sync**: ❌ Disabled until proxy is fixed
