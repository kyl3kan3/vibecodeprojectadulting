# 🔧 Fix for 405 Method Not Allowed Error

## Problem

You're getting **405 errors** when loading lessons because:

1. The React Native app is sending **POST** requests with `operation: 'select'`
2. Your Vercel proxy's `/api/db/query` endpoint doesn't handle the **SELECT** operation

## Error Message

```
[LessonsStore] Exception loading lessons: Error: Database query failed: 405
```

## Solution

Add support for the **SELECT** operation in your Vercel proxy's `/api/db/query` endpoint.

---

## Quick Fix (Add to Your Proxy)

Open your `/api/db/query` endpoint and add this **SELECT operation handler** inside the `POST` method handler:

```typescript
// Handle POST requests
if (req.method === 'POST') {
  const { 
    operation, 
    table, 
    data: requestData, 
    filters, 
    onConflict, 
    ignoreDuplicates, 
    returning,
    select,        // ← Add these
    limit,         // ← Add these
    offset,        // ← Add these
    order          // ← Add these
  } = req.body;

  try {
    // ✅ ADD THIS: SELECT OPERATION HANDLER
    if (operation === 'select') {
      let query = supabase.from(table).select(select || '*');
      
      // Apply filters
      if (filters && Array.isArray(filters)) {
        filters.forEach(filter => {
          const { column, op, value } = filter;
          if (op === 'eq') query = query.eq(column, value);
          else if (op === 'neq') query = query.neq(column, value);
          else if (op === 'gt') query = query.gt(column, value);
          else if (op === 'gte') query = query.gte(column, value);
          else if (op === 'lt') query = query.lt(column, value);
          else if (op === 'lte') query = query.lte(column, value);
          else if (op === 'like') query = query.like(column, value);
          else if (op === 'ilike') query = query.ilike(column, value);
          else if (op === 'in') query = query.in(column, Array.isArray(value) ? value : [value]);
        });
      }
      
      // Apply limit
      if (limit) {
        query = query.limit(limit);
      }
      
      // Apply offset/pagination
      if (offset !== undefined) {
        const end = offset + (limit || 10) - 1;
        query = query.range(offset, end);
      }
      
      // Apply ordering
      if (order) {
        query = query.order(order.column, { 
          ascending: order.direction === 'asc' 
        });
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Select error:', error);
        return res.status(400).json({ error: error.message });
      }
      
      return res.status(200).json({ data, error: null });
    }

    // Your existing UPSERT operation handler goes here...
    if (operation === 'upsert') {
      // ... existing code
    }

    // Your existing INSERT, UPDATE, DELETE handlers...
    
  } catch (error: any) {
    console.error('Database operation error:', error);
    return res.status(500).json({ error: error.message });
  }
}
```

---

## What This Does

The React Native app sends requests like this:

```json
POST /api/db/query
{
  "operation": "select",
  "table": "lessons",
  "select": "*",
  "order": {
    "column": "created_at",
    "direction": "asc"
  },
  "limit": 200
}
```

Your proxy needs to handle this `operation: 'select'` and convert it to a Supabase query.

---

## Testing

After deploying this fix, test from your React Native app. The error should be gone and lessons should load successfully.

You can also test with curl:

```bash
curl -X POST https://your-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "select",
    "table": "lessons",
    "select": "*",
    "limit": 10
  }'

# Should return:
# {
#   "data": [...lessons...],
#   "error": null
# }
```

---

## Why This Happened

1. Previous documentation showed GET support (older pattern)
2. Current implementation uses POST for all operations (newer pattern)
3. Proxy was missing the SELECT operation handler for POST

---

## Related Files Updated

- ✅ **src/lib/supabase-mcp.ts** - Already uses POST for queries
- ✅ **VERCEL_PROXY_CHANGES.md** - Updated with SELECT handler
- ✅ **FIX_405_ERROR.md** - This file (quick reference)

---

## Priority

**HIGH** - App cannot load lessons without this fix. Deploy ASAP!

Once deployed, the app will work immediately - no changes needed on React Native side.

---

**Status**: ⚠️ Waiting for proxy deployment  
**Impact**: 🔴 Critical (app cannot load lessons)  
**Fix Time**: ~2 minutes to add code + deploy
