# 🔧 Fix 401 "Invalid Proxy Secret" Error

## Problem

Your app is getting **401 Unauthorized** errors with message "Invalid proxy secret".

**Root Cause:** Your Vercel proxy is checking for `x-proxy-secret` header, but:
- It's not set in your React Native app's `.env` file
- Or the value doesn't match what the proxy expects

---

## Quick Fix - Option 1: Make Proxy Secret Optional (Recommended)

Since you already have JWT authentication, the proxy secret might be redundant.

### Update Your Vercel Proxy

Find where your proxy checks the secret and make it optional:

**Current (Causing 401):**
```typescript
// In your /api/db/query route
export default async function handler(req, res) {
  // ❌ This rejects requests without the secret
  const proxySecret = req.headers['x-proxy-secret'];
  if (proxySecret !== process.env.PROXY_SECRET) {
    return res.status(401).json({ error: 'Invalid proxy secret' });
  }
  
  // ... rest of code
}
```

**Fixed (Makes it optional):**
```typescript
// In your /api/db/query route
export default async function handler(req, res) {
  // ✅ Only check secret if it's configured
  const proxySecret = req.headers['x-proxy-secret'];
  const expectedSecret = process.env.PROXY_SECRET;
  
  // Only validate if secret is configured on server
  if (expectedSecret && proxySecret !== expectedSecret) {
    return res.status(401).json({ error: 'Invalid proxy secret' });
  }
  
  // ... rest of code
}
```

Or even simpler - just remove the check entirely since you have JWT auth:

```typescript
// In your /api/db/query route
export default async function handler(req, res) {
  // JWT authentication (already have this)
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const token = authHeader.substring(7);
  const { data: { user }, error: authError } = await supabase.auth.getUser(token);
  
  if (authError || !user) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  
  // ✅ No proxy secret check needed - JWT is enough!
  
  // ... rest of code
}
```

**Deploy this change to Vercel.**

---

## Quick Fix - Option 2: Add Proxy Secret to React Native App

If you want to keep the proxy secret check, add it to your `.env` file:

### Step 1: Get the Secret from Vercel

1. Go to your Vercel project settings
2. Go to Environment Variables
3. Find `PROXY_SECRET` value
4. Copy it

### Step 2: Add to React Native `.env`

```bash
# In /home/user/workspace/.env
EXPO_PUBLIC_PROXY_SECRET=your-secret-value-here
```

### Step 3: Restart Dev Server

```bash
# Kill and restart the dev server to load new env variable
# The Vibecode system will auto-restart
```

---

## Recommended Approach

**I recommend Option 1** (make secret optional or remove it) because:

1. ✅ You already have JWT authentication (more secure)
2. ✅ Proxy secret adds complexity without much benefit
3. ✅ JWT verifies user identity, proxy secret just verifies request source
4. ✅ One less secret to manage

JWT authentication is **sufficient and secure** for your use case. The proxy secret was probably added as an extra layer, but it's not necessary when you have proper JWT auth.

---

## Testing After Fix

### If Using Option 1 (Remove/Make Optional)

1. Deploy the updated proxy to Vercel
2. Restart your React Native app
3. Should work immediately - no 401 errors

### If Using Option 2 (Add Secret)

1. Add secret to `.env` file
2. Restart dev server
3. Should work immediately - no 401 errors

---

## Verification

After deploying the fix, check your app console:

**Before (Error):**
```
❌ Database query failed: 401 Invalid proxy secret
❌ [LessonsStore] Exception loading lessons: 401 error
```

**After (Success):**
```
✅ [LessonsStore] Loaded 132 lessons from database
```

---

## Why This Is Better Than Proxy Secret

| Security Layer | Purpose | Your Setup |
|----------------|---------|------------|
| **JWT Authentication** | Verifies user identity | ✅ You have this |
| **Proxy Secret** | Verifies request source | ⚠️ Optional/Redundant |

**JWT is cryptographically signed and expires**, making it far more secure than a static shared secret.

The proxy secret was useful when you didn't have JWT, but now that you do, it's redundant.

---

## Complete Handler Example (No Proxy Secret)

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req, res) {
  // Only JWT authentication needed
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized - missing token' });
  }

  const token = authHeader.substring(7);
  const { data: { user }, error: authError } = await supabase.auth.getUser(token);
  
  if (authError || !user) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // ✅ User is authenticated via JWT - proceed with operation
  
  if (req.method === 'POST') {
    const { operation, table, select, filters, limit, offset, order } = req.body;

    try {
      if (operation === 'select') {
        let query = supabase.from(table).select(select || '*');
        
        // Apply filters, limit, order...
        // (your existing code)
        
        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        return res.status(200).json({ data, error: null });
      }
      
      // ... other operations
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  }
  
  return res.status(405).json({ error: 'Method not allowed' });
}
```

---

## Summary

**Problem:** 401 errors due to missing/invalid proxy secret

**Best Solution:** Remove proxy secret check (JWT is enough)

**Alternative:** Add secret to `.env` if you want to keep the check

**Recommendation:** Use JWT-only authentication (simpler, more secure)

---

**Next Step:** Deploy the fix (Option 1 recommended) and test your app!
