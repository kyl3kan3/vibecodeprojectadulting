# ✅ Complete Fix for 401 Errors

## Issue 1: Vercel Proxy Missing Supabase Credentials

Your Vercel proxy is trying to call Supabase but doesn't have the credentials.

### Fix: Add Environment Variables to Vercel

**Step 1: Get Supabase Credentials**

1. Go to https://supabase.com/dashboard
2. Click on your project (fhllozktjqvqfedlmhqm)
3. Go to **Settings** → **API**
4. Copy these two values:
   - **Project URL**: `https://fhllozktjqvqfedlmhqm.supabase.co`
   - **service_role key** (secret key, NOT anon key)

**Step 2: Add to Vercel**

1. Go to https://vercel.com/dashboard
2. Click **vercel-multi-ai-proxy** project
3. Go to **Settings** → **Environment Variables**
4. Click **Add New**
5. Add these TWO variables:

```
Name: SUPABASE_URL
Value: https://fhllozktjqvqfedlmhqm.supabase.co
Environment: Production, Preview, Development (select all)
```

```
Name: SUPABASE_SERVICE_ROLE_KEY
Value: [paste your service role key here]
Environment: Production, Preview, Development (select all)
```

**Step 3: Redeploy**

After adding variables, you MUST redeploy:
- Go to **Deployments** tab
- Click **"..."** on latest deployment
- Click **Redeploy**
- Or push a new commit to trigger deployment

---

## Issue 2: JWT Expired in React Native App

User's JWT token has expired and needs to sign in again.

### Fix: Sign Out and Sign In Again

**Option A: Manual (Quick Test)**

1. In your app, go to settings/profile
2. Click "Sign Out"
3. Sign in again with your credentials
4. Fresh JWT token will be issued

**Option B: Auto-Refresh (Add Token Refresh)**

If you want automatic token refresh, I can add that to your auth flow.

### Why JWT Expires

JWT tokens typically expire after:
- 1 hour (default for most systems)
- 24 hours (if configured for longer sessions)

This is normal security behavior. Once expired, you need a fresh token.

---

## Testing After Fixes

### Test 1: Verify Vercel Has Credentials

After adding environment variables and redeploying:

```bash
# Check if proxy can connect to Supabase
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "select",
    "table": "lessons",
    "select": "id,title",
    "limit": 1
  }'

# Should return lessons data (not 401)
```

### Test 2: Verify App Works

1. Sign out of your app
2. Sign in again (get fresh JWT)
3. App should load lessons successfully
4. No 401 errors in console or Vercel logs

---

## Expected Results

**Before Fixes:**
- ❌ Vercel logs: 401 from Supabase (no credentials)
- ❌ App console: JWT expired (token too old)
- ❌ App: Can't load data

**After Fixes:**
- ✅ Vercel logs: 200 from Supabase (credentials set)
- ✅ App console: No JWT errors (fresh token)
- ✅ App: Loads lessons successfully

---

## Priority Order

**Do this NOW (Critical):**
1. Add `SUPABASE_URL` to Vercel environment variables
2. Add `SUPABASE_SERVICE_ROLE_KEY` to Vercel environment variables
3. Redeploy Vercel project
4. Sign out and sign in again in your app

**Do this LATER (Optional):**
- Add automatic token refresh to avoid manual sign-in

---

## How to Find Service Role Key

If you can't find the service role key:

1. Go to https://supabase.com/dashboard
2. Click your project
3. Click **Settings** (gear icon in sidebar)
4. Click **API** in the settings menu
5. Scroll down to **Project API keys**
6. You'll see:
   - `anon` key (public) ← DON'T use this
   - `service_role` key (secret) ← USE THIS ONE
7. Click **Reveal** next to service_role
8. Copy the entire key (it's very long)

**Warning:** The service_role key is SECRET. Don't commit it to git or share it publicly!

---

## Security Note

The service_role key:
- ✅ Should ONLY be on your Vercel server (server-side)
- ❌ Should NEVER be in your React Native app
- ❌ Should NEVER be in git/public repos

Your current setup is correct: Key lives on Vercel, app talks to Vercel proxy, proxy talks to Supabase.

---

## Summary

**Problem 1:** Vercel proxy can't authenticate with Supabase
**Solution:** Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to Vercel env vars

**Problem 2:** User's JWT token expired
**Solution:** Sign out and sign in again to get fresh token

Both are easy fixes! Do Problem 1 first (Vercel env vars), then Problem 2 (sign in again).

---

**Status after fixes:**
- 🟢 Vercel can connect to Supabase
- 🟢 App has fresh JWT token
- 🟢 Everything works end-to-end

Let me know once you've added the Vercel environment variables! 🚀
