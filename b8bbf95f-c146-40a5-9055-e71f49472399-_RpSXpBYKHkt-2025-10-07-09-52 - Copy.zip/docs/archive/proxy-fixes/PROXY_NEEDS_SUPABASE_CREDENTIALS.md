# 🔧 Fix 400 Bad Request - Proxy Needs Supabase Credentials!

## 🎯 **The Real Problem**

Your **Vercel proxy needs your Supabase credentials** to work!

### **How the Proxy Works:**
```
Your App → Vercel Proxy → Supabase Database
```

The proxy is a **middleman** that:
1. Takes your database requests
2. Forwards them to YOUR Supabase project
3. Returns the results back to you

**But the proxy doesn't know WHERE your Supabase project is!**

That's why you're getting 400 errors - the proxy needs:
- ✅ Your Supabase URL (where to send requests)
- ✅ Your Supabase anon key (how to authenticate)

---

## ✅ **The Solution**

You still use the proxy, but you need to add Supabase credentials to `.env` so the proxy knows where to connect!

### **Step 1: Get Supabase Credentials**

1. Go to: https://supabase.com/dashboard
2. Click your project
3. Click **Settings** → **API**
4. Copy these two values:
   - **Project URL**: `https://xxxxx.supabase.co`
   - **anon public key**: `eyJhbGci...` (long string)

### **Step 2: Add to .env**

Open your `.env` file and replace:

```bash
EXPO_PUBLIC_SUPABASE_URL=YOUR_SUPABASE_PROJECT_URL
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

With your actual values:

```bash
EXPO_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### **Step 3: Update the Proxy Client**

The proxy needs to send these credentials with each request.

### **Step 4: Restart**

```bash
npx expo start --clear
```

Force close and reopen your app.

---

## 📊 **Request Flow After Fix**

```
1. App creates database request
2. App adds Supabase URL + anon key to request headers
3. Vercel proxy receives request
4. Proxy forwards to YOUR Supabase project
5. Supabase processes request
6. Response comes back through proxy to app
```

---

## 🔒 **Why This is Safe**

The anon key is **designed to be public**:
- ✅ Can be used in client apps
- ✅ Protected by Row Level Security
- ✅ Users can only access their own data
- ✅ Safe to put in environment variables

---

## ✨ **After Adding Credentials**

- ✅ Proxy knows where to send requests (your Supabase URL)
- ✅ Proxy knows how to authenticate (your anon key)
- ✅ Database operations work through proxy
- ✅ **No more 400 errors!**

---

## 🎯 **Quick Summary**

**The proxy is NOT connecting to Supabase because it doesn't have your credentials!**

Add these to `.env`:
```bash
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-long-anon-key-here
```

Restart, and it will work! 🎉
