# 🔍 Debug 401 Errors from Supabase Direct Calls

## What You're Seeing

```
401 error from:
- fhllozktjqvqfedlmhqm.supabase.co/rest/v1/profiles  
- fhllozktjqvqfedlmhqm.supabase.co/rest/v1/lessons
```

## Where Are These Coming From?

These are **Supabase direct REST API calls**, which means either:

### Option 1: React Native App Making Direct Calls
Some code is bypassing the proxy and calling Supabase directly.

### Option 2: Vercel Proxy Making the Calls (Most Likely)
Your Vercel proxy is calling Supabase with invalid credentials.

---

## Question: Where Do You See These Errors?

**Please tell me:**

### A) In React Native console/logs?
If yes → React Native app is calling Supabase directly (we need to fix client)

### B) In Vercel runtime logs?
If yes → Vercel proxy is calling Supabase with wrong credentials (we need to fix proxy)

---

## If Answer is B (Vercel Logs) - Most Likely

The Vercel proxy needs Supabase environment variables set:

### Check Vercel Environment Variables

1. Go to https://vercel.com/dashboard
2. Click on **vercel-multi-ai-proxy** project
3. Go to **Settings** → **Environment Variables**
4. Check if these exist:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`

### If Missing or Wrong

You need to add them:

```
SUPABASE_URL=https://fhllozktjqvqfedlmhqm.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
```

**Where to find these:**
1. Go to https://supabase.com/dashboard
2. Click your project
3. Go to **Settings** → **API**
4. Copy:
   - **Project URL** → `SUPABASE_URL`
   - **service_role** key (NOT anon key!) → `SUPABASE_SERVICE_ROLE_KEY`

### After Adding Variables

1. **Redeploy** your Vercel project (variables only apply after redeploy)
2. Test again

---

## If Answer is A (React Native Logs)

Then React Native is somehow calling Supabase directly.

### Quick Fix: Remove Direct Supabase Client

Delete or rename the direct supabase client:

```bash
# In your React Native project
mv src/lib/supabase.ts src/lib/supabase.ts.backup
```

This will force everything through the proxy.

---

## Most Likely Scenario

Based on the error, I believe:

1. ✅ React Native is calling your proxy correctly
2. ✅ Proxy is receiving the request
3. ❌ Proxy is trying to call Supabase but doesn't have credentials
4. ❌ Supabase returns 401 "unauthorized"

**Solution:** Set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in Vercel environment variables.

---

## How to Verify

### Test 1: Check if Proxy Has Credentials

Look at the top of your `/app/api/db/query/route.ts`:

```typescript
const supabase = createClient(
  process.env.SUPABASE_URL!,      // ← Is this set in Vercel?
  process.env.SUPABASE_SERVICE_ROLE_KEY!  // ← Is this set in Vercel?
);
```

If these aren't set in Vercel, the proxy can't connect to Supabase!

### Test 2: Check Vercel Deployment Logs

When you deployed, did you see any warnings about missing environment variables?

---

## Action Plan

**Step 1:** Tell me where you see the 401 errors (React Native or Vercel logs?)

**Step 2:** Check if Vercel has Supabase environment variables set

**Step 3:** If missing, add them and redeploy

**Step 4:** Test again

---

Let me know which scenario this is and I'll give you the exact fix! 🚀
