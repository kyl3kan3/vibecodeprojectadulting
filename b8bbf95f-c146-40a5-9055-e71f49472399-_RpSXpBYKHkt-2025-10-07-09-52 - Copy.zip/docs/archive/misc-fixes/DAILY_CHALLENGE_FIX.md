# Daily Challenge Fix

## Problem
The daily challenge/achievement on the HomeScreen was only showing up sometimes. Users would see it appear and disappear inconsistently.

## Root Causes

### 1. Missing Persistence (FIXED)
**File:** `src/state/progress-store.ts` (line 530)

The `todaysChallenge` and `dailyChallenges` were NOT included in the Zustand persistence configuration. This meant:
- ❌ Challenge would be lost on app restart
- ❌ Challenge would be lost when navigating between screens
- ✅ Challenge would only exist in memory during the current session

**Fix:** Added both fields to the `partialize` configuration:
```typescript
partialize: (state) => ({
  // ... other fields ...
  todaysChallenge: state.todaysChallenge,
  dailyChallenges: state.dailyChallenges,
}),
```

### 2. Screen Focus Detection (FIXED)
**File:** `src/screens/HomeScreen.tsx` (line 78)

The challenge generation was only running when the component mounted (via `useEffect`). This meant:
- ❌ If user stayed on a different tab overnight, challenge wouldn't update
- ❌ If React didn't remount the component, old challenge would persist
- ✅ Challenge only regenerated on fresh mount

**Fix:** Changed from `useEffect` to `useFocusEffect` to run every time the screen comes into focus:
```typescript
useFocusEffect(
  React.useCallback(() => {
    updateStreak();
    generateTodaysChallenge();
  }, [updateStreak, generateTodaysChallenge])
);
```

## How It Works Now

### Daily Challenge Generation Logic
**File:** `src/state/progress-store.ts` (generateTodaysChallenge)

1. Checks if `todaysChallenge` exists and matches today's date
2. If yes → Keeps existing challenge (don't regenerate)
3. If no → Generates new challenge with:
   - Unique ID with timestamp
   - Today's date string
   - Title, description, category
   - Time estimate and XP reward
   - `isCompleted: false` flag

### When Challenge Updates

The challenge will now automatically update:
- ✅ **On app restart** - Persisted challenge is loaded
- ✅ **On date change** - Old challenge is replaced with new one
- ✅ **On screen focus** - Checks if challenge needs regeneration
- ✅ **On tab switch** - HomeScreen re-checks on focus
- ✅ **After app background** - Re-validates on return

### Display Logic
**File:** `src/screens/HomeScreen.tsx` (line 365)

Challenge is displayed only if:
```typescript
{todaysChallengeData && (
  // ... render challenge card ...
)}
```

Where `todaysChallengeData` comes from:
```typescript
const todaysChallengeData = useMemo(() => {
  return getTodaysChallenge();
}, [getTodaysChallenge]);
```

## Testing

### Before Fix
1. Open app → See challenge ✅
2. Close app → Challenge lost ❌
3. Reopen app → No challenge ❌
4. Navigate away and back → Sometimes shows ⚠️

### After Fix
1. Open app → See challenge ✅
2. Close app → Challenge persisted ✅
3. Reopen app → Same challenge (if same day) ✅
4. Navigate away and back → Challenge still there ✅
5. Open app next day → New challenge ✅

## Files Modified
1. `src/state/progress-store.ts` - Added persistence for challenges
2. `src/screens/HomeScreen.tsx` - Changed to useFocusEffect

## Additional Notes

### Challenge Completion
When user taps "COMPLETE" (line 391-410):
- Updates `todaysChallenge.isCompleted = true`
- Adds XP reward to user's totalXP
- Challenge card hides the button but remains visible

### Future Enhancements
- Vary challenge types based on user progress
- Add challenge streaks (complete N days in a row)
- Sync completed challenges to cloud database
- Add challenge categories matching user preferences
- Randomize challenge content instead of static "Complete 3 tasks"
