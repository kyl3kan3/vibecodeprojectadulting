# Terminology Consistency Fix: "Lessons" → "Skills"

## Problem
The app was inconsistently using both "lessons" and "skills" to refer to the same thing:
- UI showed: "Learn Skills", "Skill Detail"  
- But also showed: "Loading lessons...", "No Lessons Available", "Start Lesson"
- Backend: `lessons` database table, `LifeSkill` type, `LessonsStore`

This was confusing for users and developers.

## Solution
Made all **user-facing text** consistently use "Skills" terminology, while keeping backend names as-is (no breaking changes).

### Reasoning
- **"Skills"** is more outcome-focused and motivating for users
- Emphasizes what users will **gain** rather than what they'll **do**
- Backend can stay as "lessons" since it's technically accurate (instructional content)
- No database migrations or type refactoring needed

## Changes Made

### 1. LearnScreen (`src/screens/LearnScreen.tsx`)
- ✅ "Learn Skills" (already correct)
- ❌ "Loading lessons..." → ✅ "Loading skills..."
- ❌ "No Lessons Available" → ✅ "No Skills Available"
- ❌ "Lessons are being loaded" → ✅ "Skills are being loaded"
- ❌ "No lessons match your filters" → ✅ "No skills match your filters"

### 2. SkillDetailScreen (`src/screens/SkillDetailScreen.tsx`)
- ❌ "This lesson has been removed" → ✅ "This skill has been removed"
- ❌ "You can find this lesson" → ✅ "You can find this skill"
- ❌ accessibilityLabel="Refresh lesson data" → ✅ "Refresh skill data"
- ❌ "Start Lesson" button → ✅ "Start Skill"

### 3. CatalogScreen (`src/screens/CatalogScreen.tsx`)
- ❌ "Start Lesson" → ✅ "Start Skill"

### 4. ProgressSyncScreen (`src/screens/ProgressSyncScreen.tsx`)
- ❌ "lesson progress records" → ✅ "skill progress records"
- ❌ "Total Lessons: X" → ✅ "Total Skills: X"
- ❌ "Lesson Records: X" → ✅ "Skill Records: X"
- ❌ "complete steps or lessons" → ✅ "complete steps or skills"

## What Stayed the Same (Backend)

### Database
- ✅ Table name: `lessons` (no migration needed)
- ✅ Database type: `DatabaseLesson` (internal)

### Code/Types
- ✅ Type: `LifeSkill` (makes sense - it's a life skill)
- ✅ Store: `LessonsStore` (internal name)
- ✅ Function names: `loadSkillsFromDatabase()`, `lessonProgressService` (internal)
- ✅ Component: `InteractiveLessonScreen` (internal)

### Why This Works
The backend accurately reflects what the data **is** (lessons/instructional content), while the UI focuses on what users **get** (skills/abilities). This is a common pattern in education apps:
- **Duolingo**: Backend has "lessons", UI shows "Learn [Language]"
- **Khan Academy**: Backend has "lessons", UI shows "Skills"
- **LinkedIn Learning**: Backend has "courses", UI shows "Skills you'll gain"

## User Experience Impact

### Before Fix 🔴
User sees:
1. "Learn Skills" (tab label)
2. "Loading lessons..." (loading state)
3. "No Lessons Available" (empty state)
4. Clicks skill → "Start Lesson" (button)

**Confusing!** Are they learning skills or lessons?

### After Fix ✅
User sees:
1. "Learn Skills" (tab label)
2. "Loading skills..." (loading state)
3. "No Skills Available" (empty state)
4. Clicks skill → "Start Skill" (button)

**Consistent!** Everything is about building skills.

## Testing Checklist
- [ ] LearnScreen shows "Loading skills..." when loading
- [ ] LearnScreen shows "No Skills Available" when empty
- [ ] SkillDetailScreen shows "Start Skill" button
- [ ] SkillDetailScreen shows "skill" in saved/removed alerts
- [ ] CatalogScreen shows "Start Skill" button
- [ ] ProgressSyncScreen uses "skill" in all text
- [ ] No crashes or TypeScript errors

## Future Considerations

If you want to rename backend code for consistency, here's the migration path:

### Phase 1: Database (requires migration)
1. Rename `lessons` table → `skills`
2. Update all queries to reference new table name
3. Run migration script for existing data

### Phase 2: Types (requires refactoring)
1. Rename `DatabaseLesson` → `DatabaseSkill`
2. Keep `LifeSkill` (already correct)
3. Update all imports

### Phase 3: Stores/Services (requires refactoring)
1. Rename `LessonsStore` → `SkillsStore`
2. Rename `lessonProgressService` → `skillProgressService`
3. Update all references

**Recommendation:** Don't do this unless absolutely necessary. The current hybrid approach works well and avoids breaking changes.
