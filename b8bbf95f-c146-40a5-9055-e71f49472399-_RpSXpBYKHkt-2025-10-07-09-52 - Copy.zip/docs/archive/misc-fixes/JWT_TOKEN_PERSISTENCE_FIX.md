# JWT Token Persistence Fix

## Problem
App was getting stuck on "Loading..." screen after restart with errors:
- "[Database] saveProgress failed (attempt 3/3)"
- "❌ [Proxy Response]: {"

## Root Cause
JWT tokens were being persisted and restored correctly, but they were expired. When the app tried to make database calls with expired tokens, the requests failed, causing the loading process to hang or error.

## Solution Implemented

### 1. Automatic Token Refresh on App Restart
**File:** `src/contexts/AuthContext.tsx` (lines 126-155)

When restoring a session from persistent storage:
- First attempts to refresh the JWT token using the refresh token
- If refresh succeeds, uses the new token
- If refresh fails, falls back to stored token (will fail on first API call and force re-login)
- Updates auth store with the refreshed token

```typescript
// Try to refresh the token first to ensure it's valid
const refreshResult = await supabaseMCP.authRefreshSession();
if (refreshResult?.token && refreshResult?.user) {
  activeToken = refreshResult.token;
  activeUser = refreshResult.user;
  authStore.setAuth(activeToken, activeUser, true, refreshResult.refreshToken);
}
```

### 2. Loading Timeout Protection
**File:** `src/contexts/AuthContext.tsx` (lines 88-92, 252)

Added a 10-second timeout to prevent infinite loading:
- If session restoration takes longer than 10 seconds, force `loading=false`
- Ensures users can always get past the loading screen
- Timeout is properly cleared in the finally block

### 3. Lightweight Session Restoration  
**File:** `src/contexts/AuthContext.tsx` (lines 197-221)

Removed heavy data loading from initial auth restoration:
- ❌ **Before:** Loaded skills, tips, and progress during login (could hang if DB calls fail)
- ✅ **After:** Only loads user profile during restoration
- Skills/tips will be loaded on-demand when screens need them

### 4. Error Resilience
All errors during session restoration are caught and logged without breaking the flow:
- Token refresh errors → Falls back to stored token
- Profile load errors → Session still restored, profile loaded later
- Auth errors → User shown login screen

## Files Modified
- `src/contexts/AuthContext.tsx` - Token refresh + lightweight restoration
- `src/state/auth-store.ts` - Already had persistence working correctly
- `src/lib/supabase-mcp.ts` - Already had `authRefreshSession()` method

## Testing Steps
1. Sign in with "Remember Me" enabled
2. Close and restart the app
3. Should see "Loading..." briefly (< 2 seconds)
4. Should automatically log in with refreshed token
5. If token can't be refreshed, should show login screen

## Current State
- ✅ Token persistence working
- ✅ Token refresh on app restart  
- ✅ Loading timeout protection
- ✅ Lightweight session restoration
- ⚠️ Skills/tips will load on-demand (first screen access might be slower)

## Next Steps (Optional)
1. Add preloading of skills/tips after successful login (in background)
2. Add loading indicators to individual screens
3. Implement token refresh before expiry (proactive refresh)
4. Add retry logic for failed database calls
