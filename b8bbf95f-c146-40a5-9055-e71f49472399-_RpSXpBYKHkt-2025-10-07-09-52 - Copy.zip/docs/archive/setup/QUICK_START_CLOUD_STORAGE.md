# 🚀 Quick Start: Cloud Storage

## For React Native App (Already Done ✅)

### Import the service
```typescript
import {
  uploadFromUri,
  getFileUrl,
  deleteFile,
  generateUserFilePath,
} from '../api/cloud-storage';
```

### Upload a photo
```typescript
const userId = (global as any).__AUTH_USER__?.id;
const filePath = generateUserFilePath(userId, 'photos', 'jpg');

const result = await uploadFromUri(imageUri, {
  bucket: 'user-content',
  path: filePath,
  contentType: 'image/jpeg',
});

if (result.success) {
  console.log('Uploaded to:', result.path);
}
```

### Get download URL
```typescript
const url = await getFileUrl('user-content', filePath, 300);
// url expires in 300 seconds (5 minutes)
```

### Display image
```typescript
<Image source={{ uri: url }} style={{ width: 200, height: 200 }} />
```

### Delete file
```typescript
await deleteFile('user-content', filePath);
```

---

## For Vercel Proxy (You Need To Do)

### 1. Create these 4 files in your Vercel project:

```
your-vercel-project/
└── api/
    └── storage/
        ├── upload-url.ts      ← Copy from VERCEL_STORAGE_ENDPOINTS.md
        ├── download-url.ts    ← Copy from VERCEL_STORAGE_ENDPOINTS.md
        ├── delete.ts          ← Copy from VERCEL_STORAGE_ENDPOINTS.md
        └── list.ts            ← Copy from VERCEL_STORAGE_ENDPOINTS.md (optional)
```

### 2. Set environment variables in Vercel:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### 3. Deploy to Vercel
```bash
vercel deploy
```

### 4. Test with curl:
```bash
# Get your JWT token first (from app after sign-in)
export JWT_TOKEN="your-jwt-token-here"

# Test upload URL
curl -X POST https://your-proxy.vercel.app/api/storage/upload-url \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "bucket": "user-content",
    "path": "test.jpg",
    "contentType": "image/jpeg"
  }'

# Should return:
# {
#   "uploadUrl": "https://...signed-url...",
#   "method": "PUT",
#   "headers": { ... }
# }
```

---

## For Supabase (You Need To Do)

### 1. Create storage buckets

In Supabase Dashboard → Storage → New Bucket:

- **Bucket name**: `user-content`
- **Public**: No (private)
- Click "Create bucket"

Repeat for:
- `avatars` (private)
- `achievements` (public, optional)

### 2. Set storage policies

Go to Storage → Policies → New Policy

**For user-content bucket:**

```sql
-- Allow users to upload to their own folder
CREATE POLICY "Users can upload own files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'user-content' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to read their own files
CREATE POLICY "Users can read own files"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'user-content' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow users to delete their own files
CREATE POLICY "Users can delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'user-content' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);
```

---

## Testing Flow

### Test 1: Upload from React Native
```typescript
// In your app
import { uploadFromUri } from '../api/cloud-storage';

const testUpload = async () => {
  const result = await uploadFromUri(imageUri, {
    bucket: 'user-content',
    path: 'users/test-user/photos/test.jpg',
    contentType: 'image/jpeg',
  });
  
  console.log('Result:', result);
  // Should log: { success: true, path: '...' }
};
```

### Test 2: Get download URL
```typescript
import { getFileUrl } from '../api/cloud-storage';

const testDownload = async () => {
  const url = await getFileUrl(
    'user-content',
    'users/test-user/photos/test.jpg',
    300
  );
  
  console.log('Download URL:', url);
  // Should log a signed URL
};
```

### Test 3: Display image
```typescript
const [imageUrl, setImageUrl] = useState<string | null>(null);

useEffect(() => {
  getFileUrl('user-content', filePath, 300).then(setImageUrl);
}, [filePath]);

return imageUrl ? (
  <Image source={{ uri: imageUrl }} style={{ width: 200, height: 200 }} />
) : (
  <Text>Loading...</Text>
);
```

---

## Common Issues

### Issue: "Failed to get upload URL: 401"
**Solution**: Check that your JWT token is valid and being sent correctly.

### Issue: "Failed to get upload URL: 500"
**Solution**: Check Vercel environment variables are set correctly.

### Issue: "Upload failed: 403"
**Solution**: Check Supabase storage policies allow the operation.

### Issue: Image not displaying
**Solution**: 
1. Check the download URL is valid (curl it)
2. Check the URL has not expired (default 5 minutes)
3. Refresh the URL if needed: `await getFileUrl(...)`

### Issue: "Missing required fields"
**Solution**: Ensure all required parameters are provided:
- `bucket` - Must match Supabase bucket name
- `path` - File path in bucket
- `contentType` - MIME type (e.g., "image/jpeg")

---

## File Naming Best Practices

### User-specific files
```typescript
`users/${userId}/${category}/${timestamp}-${random}.${ext}`

Example:
"users/123e4567/photos/1696348800000-abc123.jpg"
```

### Profile photos (always same name, use upsert)
```typescript
`users/${userId}/avatars/profile.jpg`

// Always overwrites previous profile photo
```

### Achievement cards (unique names)
```typescript
`users/${userId}/achievements/${achievementId}-${timestamp}.jpg`
```

### Helper function
```typescript
import { generateUserFilePath } from '../api/cloud-storage';

const path = generateUserFilePath(userId, 'photos', 'jpg');
// Returns: "users/{userId}/photos/{timestamp}-{random}.jpg"
```

---

## Next Steps

1. ✅ React Native service created (`src/api/cloud-storage.ts`)
2. ⏳ Deploy Vercel endpoints (see `VERCEL_STORAGE_ENDPOINTS.md`)
3. ⏳ Create Supabase storage buckets
4. ⏳ Set storage policies
5. ⏳ Test with curl commands
6. ⏳ Test from React Native app
7. ⏳ Integrate into existing screens (Profile, Achievements, etc.)

---

## Documentation Files

- 📘 **VERCEL_STORAGE_ENDPOINTS.md** - Complete proxy implementation
- 📗 **CLOUD_STORAGE_SUMMARY.md** - Comprehensive overview
- 📙 **QUICK_START_CLOUD_STORAGE.md** - This file (quick reference)
- 📕 **VERCEL_PROXY_CHANGES.md** - Database upsert fix

---

**Ready to use!** Just deploy the Vercel endpoints and you are good to go. 🚀
