# Pro Tier Architecture

## Overview

The Adulting Coach app implements a freemium model where subscription status is determined **entirely by Apple's StoreKit**. The subscription service we've built syncs this status to the database for analytics and tracking purposes only.

---

## 🎯 Source of Truth

**StoreKit is the ONLY source of truth for subscription status.**

The Pro/Free tier is determined by:
```typescript
// In src/services/storekit/index.ts
export async function getActive() {
  const active = !!useUIStore.getState().isPro;
  return { active };
}
```

Which is set by StoreKit's purchase listeners in:
```typescript
// Line 56-63 in src/services/storekit/index.ts
purchaseUpdatedListener(async (purchase) => {
  await RNIap.finishTransaction({ purchase, isConsumable: false });
  useUIStore.getState().setIsPro(true);
})
```

---

## 🔄 How It Works

### 1. **App Launch** (App.tsx)
```typescript
// Lines 119-126
const { storekit } = await import("./src/services/storekit");
const res = await storekit.getActive();
useUIStore.getState().setIsPro(!!res?.active);
```

### 2. **User Authentication** (AuthContext.tsx)
```typescript
// Lines 437-438
const { active } = await storekit.getActive();
store.setIsPro(active);
```

### 3. **Purchase Flow** (PaywallScreen.tsx + StoreKit)
```typescript
// User taps subscribe button
await storekit.purchase(productId);

// StoreKit purchase listener fires
purchaseUpdatedListener() → setIsPro(true)
```

### 4. **Restore Purchases** (PaywallScreen.tsx)
```typescript
const state = await storekit.restore();
if (state === "restored") {
  setIsPro(true);
}
```

---

## 📊 Subscription Service Role

The subscription service (`src/services/subscriptions/subscription-service.ts`) **does NOT control Pro status**. It only:

1. **Syncs StoreKit status to database** for analytics
2. **Records purchase history** for tracking
3. **Enables analytics queries** (conversion rates, etc.)

### Key Functions:

#### `syncSubscriptionStatus(userId)`
- **Reads** from StoreKit (source of truth)
- **Writes** to Supabase database (for tracking)
- **Never overrides** StoreKit status

```typescript
// Get status from StoreKit
const { active: storekitActive } = await storekit.getActive();

// Sync to database (for analytics only)
await updateSubscriptionStatus(userId, {
  isActive: storekitActive, // Database matches StoreKit
  platform: 'ios'
});
```

#### `verifyAndUpdateSubscription(userId)`
- **Records** purchase to database after StoreKit completes
- **Does NOT call** `setIsPro()` (StoreKit already did)
- Used for database tracking only

---

## 🎨 Free vs Pro Features

### Free Tier
- **24+ skills** (first 3 starter skills per category)
- **3 AI messages per day** (resets at midnight)
- **All daily tips** accessible
- **Can unlock 1 Pro skill free** (one-time promotion)

### Pro Tier
- **All 100+ skills** unlocked
- **Unlimited AI messages**
- **All features** accessible
- **No limits**

### Determined By:
```typescript
// In any component
const isPro = useUIStore((state) => state.isPro);

// Or
const { isPro } = useUIStore();

if (isPro) {
  // Show Pro features
} else {
  // Show paywall or free limits
}
```

---

## 🔧 Implementation Details

### 1. **StoreKit handles all purchases**
- Located in `src/services/storekit/index.ts`
- Uses `react-native-iap` library
- Configured with product IDs from `process.env.EXPO_PUBLIC_IAP_PRODUCT_IDS`
- Automatically sets `isPro` on successful purchase

### 2. **UI Store persists Pro status**
- Located in `src/state/ui-store.ts`
- Persisted to AsyncStorage via Zustand middleware
- Accessed throughout app via `useUIStore` hooks

### 3. **Subscription Service syncs to database**
- Located in `src/services/subscriptions/subscription-service.ts`
- Reads from StoreKit
- Writes to Supabase `user_subscriptions` table
- Enables analytics queries

---

## 📝 Integration Points

### Where Pro Status is Checked:

1. **App.tsx** - Initial check on launch
2. **AuthContext.tsx** - Check after user loads
3. **PaywallScreen.tsx** - Purchase/restore flows
4. **SubscriptionSheet.tsx** - Alternative purchase UI
5. **LessonsStore.ts** - Skill unlock logic (`isSkillUnlocked()`)
6. **UIStore.ts** - AI message limits (`canSendAI()`)
7. **ProgressStore.ts** - AI usage tracking

### Where Pro Paywall is Shown:

1. **Locked skills** - When user taps a Pro skill
2. **AI chat limit** - When free user hits 3 messages/day
3. **Settings menu** - "Manage Subscription" option
4. **Profile screen** - Upgrade to Pro banner (if free)

---

## 🚀 How to Test

### Test Pro Subscription:
1. **Admin emails auto-granted Pro** (see `AuthContext.tsx` line 432-434)
2. **Sandbox Apple ID** for testing purchases
3. **Manual toggle** (for testing only):
   ```typescript
   useUIStore.getState().setIsPro(true); // Test Pro features
   useUIStore.getState().setIsPro(false); // Test Free features
   ```

### Test Free Tier:
1. Sign in with non-admin email
2. Don't purchase subscription
3. Should see:
   - First 3 skills per category unlocked (~24 total)
   - 3 AI messages per day limit
   - Lock icons on Pro skills
   - Paywall when tapping Pro skills

---

## ⚠️ Important Notes

### DO NOT:
- Override StoreKit status in subscription service
- Manually set `isPro` outside of StoreKit flows
- Change StoreKit implementation (already working)
- Make database the source of truth (Apple requires StoreKit)

### DO:
- Always check StoreKit for current subscription status
- Sync status to database for analytics
- Use `useUIStore` hooks to access Pro status
- Keep StoreKit as single source of truth

---

## 🔐 Admin Overrides

Admins automatically get Pro status regardless of subscription:

```typescript
// In AuthContext.tsx
const ADMIN_EMAILS = process.env.EXPO_PUBLIC_ADMIN_EMAILS
  .split(/[\,\s]+/)
  .map(e => e.trim().toLowerCase());

if (isAdminEmail(user.email)) {
  store.setIsAdmin(true);
  store.setIsPro(true); // Admin always has Pro
}
```

---

## 📈 Future Enhancements

### Server-Side Receipt Verification:
Currently, the app trusts device for subscription status. For production, implement:

1. **Apple receipt verification** - Verify receipts with Apple servers
2. **Server-side validation** - Add Supabase RPC function `verify_subscription`
3. **Expiration handling** - Auto-downgrade when subscription expires
4. **Fraud prevention** - Detect jailbroken devices, tampered receipts

This is already scaffolded in `verifySubscriptionWithServer()` but marked as TODO.

---

## Summary

**StoreKit controls everything. Subscription service just tracks it.**

- ✅ StoreKit = Source of truth
- ✅ Database = Analytics/tracking
- ✅ No conflicts between systems
- ✅ Apple guidelines compliant
- ✅ Admin overrides work
- ✅ Free tier generous (24+ skills)
- ✅ Pro tier unlimited

The architecture ensures Apple's StoreKit remains authoritative while enabling robust analytics and promotional features through the database layer.
