# Data Loss Investigation

## What Happened

Your progress (streak, XP, completed tips) was reset to 0.

## Why It Happened

The `resetUserData()` function was called, which resets all progress. This happens automatically in these scenarios:

### Automatic Sign-Out Triggers

1. **Security validation failure** (line 307 in AuthContext.tsx)
2. **Session validation failure** (line 322)  
3. **Session validation error** (line 329)
4. **Periodic security cleanup** (line 374)

Any of these can trigger `signOut()` → which calls `resetUserData()` → **erases all progress**.

## How To Check If Your Data Still Exists

I've created a **Data Recovery Screen** for you:

### Option 1: Navigate in App
1. Go to Profile
2. Scroll to Developer/Debug section
3. Tap "Data Recovery"
4. Tap "Check Storage"

### Option 2: Add Manual Navigation
Add this button somewhere in your ProfileScreen:

```typescript
<Pressable
  onPress={() => navigation.navigate('DataRecovery')}
  className="bg-red-500 p-4 rounded-xl"
>
  <Text className="text-white font-semibold text-center">
    Check Data Recovery
  </Text>
</Pressable>
```

## What The Recovery Screen Does

1. **Checks AsyncStorage** for your data
2. **Shows you**:
   - If data exists
   - Your streak value
   - Your XP
   - Number of completed tips
3. **Tells you if data was reset** (all values = 0)

## Possible Outcomes

### ✅ Good News: Data exists but not showing
- The data is still in AsyncStorage
- Just not loaded into the app state
- **Fix**: Restart the app

### ❌ Bad News: Data was wiped
- All values show as 0 in storage
- This means `resetUserData()` was called
- **Cause**: Automatic sign-out occurred

## Why Automatic Sign-Out Might Have Occurred

### Most Likely Causes:

1. **Session validation failed** (after app was inactive for 24+ hours)
2. **Security check failed** (suspicious activity detected)
3. **Auth token expired**
4. **Network error** during session refresh

### Recent Code Changes That Could Trigger This:

- We modified cloud sync code
- Changed how `onConflict` parameter is sent
- This might have caused auth validation to fail
- Failed validation → auto sign-out → data wipe

## Prevention

### Short Term: Comment Out Auto Sign-Out

In `AuthContext.tsx`, you can temporarily disable auto sign-out on validation errors:

```typescript
// Line 329 - Comment this out:
// await signOut();

// Replace with:
if (__DEV__) console.warn('[AuthContext] Would sign out, but disabled for debugging');
```

### Long Term: Don't Wipe Data on Sign-Out

**The Problem**: `signOut()` should clear auth data, NOT user progress.

**The Fix**: Remove this line from `signOut()` function (line 581):

```typescript
// REMOVE THIS:
try { useProgressStore.getState().resetUserData(); } catch {}
```

User progress should persist even after sign-out, so they don't lose everything if accidentally signed out.

## Next Steps

1. **Run Data Recovery Screen** to see if data exists
2. **If data exists**: Restart app
3. **If data was wiped**: Unfortunately lost (unless you have a device backup)
4. **Prevent future loss**: Remove `resetUserData()` call from `signOut()`

## Files Involved

- `src/contexts/AuthContext.tsx` - Sign out logic
- `src/state/progress-store.ts` - Progress data store
- `src/screens/DataRecoveryScreen.tsx` - New recovery tool (just created)
- `src/navigation/AppNavigator.tsx` - Added recovery screen to nav

---

**Created**: $(date)
**Issue**: Progress/streak reset to 0
**Status**: Investigation in progress
