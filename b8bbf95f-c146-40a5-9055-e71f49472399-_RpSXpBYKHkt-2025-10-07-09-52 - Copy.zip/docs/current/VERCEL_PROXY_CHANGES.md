# 🔧 Vercel Proxy Changes Required

## File to Modify

Your Vercel proxy's database query handler endpoint, likely:
- `/api/db/query.ts` or
- `/api/db/query.js` or  
- `/pages/api/db/query.ts`

## Current Code (What You Have Now - BROKEN)

```typescript
// This is what's causing the duplicate key errors
if (operation === 'upsert') {
  const { data, error } = await supabase
    .from(table)
    .upsert(data);  // ❌ Missing onConflict parameter
    
  return res.status(200).json({ data, error });
}
```

## Updated Code (What It Should Be - FIXED)

```typescript
if (operation === 'upsert') {
  const { data: requestData, onConflict, ignoreDuplicates } = req.body;
  
  // Build upsert options object
  const upsertOptions: any = {};
  
  // Pass through onConflict parameter (e.g., "user_id,skill_id")
  if (onConflict) {
    upsertOptions.onConflict = onConflict;
  }
  
  // Optionally support ignoreDuplicates
  if (ignoreDuplicates !== undefined) {
    upsertOptions.ignoreDuplicates = ignoreDuplicates;
  }
  
  // Pass options as second parameter to upsert
  const { data, error } = await supabase
    .from(table)
    .upsert(requestData, upsertOptions);  // ✅ Now includes options
    
  return res.status(200).json({ data, error });
}
```

## Complete Example (Full Handler Function)

Here's a complete example of what your `/api/db/query` endpoint should look like:

```typescript
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client with your service role key
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req: any, res: any) {
  // Verify authentication token
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.substring(7);
  
  // Verify the JWT token with Supabase
  const { data: { user }, error: authError } = await supabase.auth.getUser(token);
  if (authError || !user) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  // Handle GET requests (SELECT operations)
  if (req.method === 'GET') {
    const { table, select = '*', limit, offset, order } = req.query;
    
    let query = supabase.from(table).select(select);
    
    // Apply filters from query params
    Object.keys(req.query).forEach(key => {
      if (!['table', 'select', 'limit', 'offset', 'order'].includes(key)) {
        const [column, operator] = key.split('.');
        const value = req.query[key];
        
        if (operator === 'eq') query = query.eq(column, value);
        else if (operator === 'neq') query = query.neq(column, value);
        else if (operator === 'gt') query = query.gt(column, value);
        else if (operator === 'gte') query = query.gte(column, value);
        else if (operator === 'lt') query = query.lt(column, value);
        else if (operator === 'lte') query = query.lte(column, value);
        else if (operator === 'like') query = query.like(column, value);
        else if (operator === 'ilike') query = query.ilike(column, value);
        else if (operator === 'in') query = query.in(column, value.split(','));
      }
    });
    
    if (limit) query = query.limit(parseInt(limit));
    if (offset) query = query.range(parseInt(offset), parseInt(offset) + parseInt(limit || 10));
    if (order) {
      const [column, direction] = order.split('.');
      query = query.order(column, { ascending: direction === 'asc' });
    }
    
    const { data, error } = await query;
    
    if (error) {
      return res.status(400).json({ error: error.message });
    }
    
    return res.status(200).json({ data, error: null });
  }

  // Handle POST requests (SELECT, INSERT, UPSERT, UPDATE, DELETE operations)
  if (req.method === 'POST') {
    const { operation, table, data: requestData, filters, onConflict, ignoreDuplicates, returning, select, limit, offset, order } = req.body;

    try {
      // ✅ SELECT OPERATION (for POST-based queries)
      if (operation === 'select') {
        let query = supabase.from(table).select(select || '*');
        
        // Apply filters
        if (filters && Array.isArray(filters)) {
          filters.forEach(filter => {
            const { column, op, value } = filter;
            if (op === 'eq') query = query.eq(column, value);
            else if (op === 'neq') query = query.neq(column, value);
            else if (op === 'gt') query = query.gt(column, value);
            else if (op === 'gte') query = query.gte(column, value);
            else if (op === 'lt') query = query.lt(column, value);
            else if (op === 'lte') query = query.lte(column, value);
            else if (op === 'like') query = query.like(column, value);
            else if (op === 'ilike') query = query.ilike(column, value);
            else if (op === 'in') query = query.in(column, Array.isArray(value) ? value : [value]);
          });
        }
        
        if (limit) query = query.limit(limit);
        if (offset) query = query.range(offset, offset + (limit || 10) - 1);
        if (order) {
          query = query.order(order.column, { ascending: order.direction === 'asc' });
        }
        
        const { data, error } = await query;
        
        if (error) {
          return res.status(400).json({ error: error.message });
        }
        
        return res.status(200).json({ data, error: null });
      }

      // ✅ UPSERT OPERATION (THIS IS THE FIX)
      if (operation === 'upsert') {
        const upsertOptions: any = {};
        
        // Pass through onConflict parameter
        if (onConflict) {
          upsertOptions.onConflict = onConflict;
        }
        
        // Pass through ignoreDuplicates parameter
        if (ignoreDuplicates !== undefined) {
          upsertOptions.ignoreDuplicates = ignoreDuplicates;
        }
        
        // Pass through returning preference
        if (returning) {
          // 'minimal' or 'representation'
          // Note: Supabase uses different methods for this
        }
        
        const { data, error } = await supabase
          .from(table)
          .upsert(requestData, upsertOptions);  // ✅ Fixed!
        
        if (error) {
          console.error('Upsert error:', error);
          return res.status(400).json({ error: error.message });
        }
        
        return res.status(200).json({ data, error: null });
      }

      // INSERT OPERATION
      if (operation === 'insert') {
        const { data, error } = await supabase
          .from(table)
          .insert(requestData);
        
        if (error) {
          return res.status(400).json({ error: error.message });
        }
        
        return res.status(200).json({ data, error: null });
      }

      // UPDATE OPERATION
      if (operation === 'update') {
        let query = supabase.from(table).update(requestData);
        
        // Apply filters
        if (filters && Array.isArray(filters)) {
          filters.forEach(filter => {
            const { column, op, value } = filter;
            if (op === 'eq') query = query.eq(column, value);
            else if (op === 'neq') query = query.neq(column, value);
            else if (op === 'gt') query = query.gt(column, value);
            else if (op === 'gte') query = query.gte(column, value);
            else if (op === 'lt') query = query.lt(column, value);
            else if (op === 'lte') query = query.lte(column, value);
          });
        }
        
        const { data, error } = await query;
        
        if (error) {
          return res.status(400).json({ error: error.message });
        }
        
        return res.status(200).json({ data, error: null });
      }

      // DELETE OPERATION
      if (operation === 'delete') {
        let query = supabase.from(table).delete();
        
        // Apply filters
        if (filters && Array.isArray(filters)) {
          filters.forEach(filter => {
            const { column, op, value } = filter;
            if (op === 'eq') query = query.eq(column, value);
            else if (op === 'neq') query = query.neq(column, value);
          });
        }
        
        const { data, error } = await query;
        
        if (error) {
          return res.status(400).json({ error: error.message });
        }
        
        return res.status(200).json({ data, error: null });
      }

      return res.status(400).json({ error: 'Invalid operation' });
    } catch (error: any) {
      console.error('Database operation error:', error);
      return res.status(500).json({ error: error.message });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
```

## Key Changes Summary

### 1. Extract `onConflict` from request body
```typescript
const { data: requestData, onConflict, ignoreDuplicates } = req.body;
```

### 2. Build options object
```typescript
const upsertOptions: any = {};
if (onConflict) {
  upsertOptions.onConflict = onConflict;
}
```

### 3. Pass options to upsert
```typescript
await supabase
  .from(table)
  .upsert(requestData, upsertOptions);  // ✅ Second parameter
```

## What the Client Sends

Your React Native app will send requests like this:

```json
POST /api/db/query
Content-Type: application/json
Authorization: Bearer <JWT_TOKEN>

{
  "operation": "upsert",
  "table": "user_lesson_progress",
  "data": [{
    "user_id": "123e4567-e89b-12d3-a456-426614174000",
    "skill_id": "how-to-create-a-budget",
    "completed": false,
    "completed_steps": ["step1"],
    "step_results": {},
    "started_at": "2025-10-03T12:00:00.000Z"
  }],
  "onConflict": "user_id,skill_id"
}
```

**The `onConflict: "user_id,skill_id"` tells Supabase**: "If a record with this user_id AND skill_id already exists, UPDATE it instead of throwing an error."

## Testing After Deployment

After deploying your changes, test with curl:

```bash
# Test 1: First upsert (creates new record)
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user-123",
      "skill_id": "test-skill-abc",
      "completed": false,
      "completed_steps": [],
      "step_results": {}
    }],
    "onConflict": "user_id,skill_id"
  }'

# Expected: 200 OK with data returned

# Test 2: Second upsert with same user_id and skill_id (updates existing)
curl -X POST https://vercel-multi-ai-proxy.vercel.app/api/db/query \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "operation": "upsert",
    "table": "user_lesson_progress",
    "data": [{
      "user_id": "test-user-123",
      "skill_id": "test-skill-abc",
      "completed": true,
      "completed_steps": ["step1", "step2"],
      "step_results": {}
    }],
    "onConflict": "user_id,skill_id"
  }'

# Expected: 200 OK with updated data
# Should NOT get duplicate key error
```

## Environment Variables

Make sure your Vercel project has these environment variables set:

```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

## After Deployment

Once you've deployed these changes:

1. Test with the curl commands above
2. Let me know it's deployed
3. I'll re-enable cloud sync in your React Native app
4. Cloud sync will work perfectly! ✅

## Reference

- Supabase `.upsert()` docs: https://supabase.com/docs/reference/javascript/upsert
- Key insight: The `onConflict` parameter specifies which columns to check for conflicts
- Format: `"column_name"` for single column, `"col1,col2"` for composite keys

---

**That's it!** Just add the `onConflict` parameter handling and everything will work. The React Native app is already sending it correctly - the proxy just needs to pass it through to Supabase.
