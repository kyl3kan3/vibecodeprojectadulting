# Automatic App Version Sync

**Date:** October 6, 2025  
**Feature:** App version now automatically syncs from app.json/package.json

---

## Problem

The app version was hardcoded in the ProfileScreen:
```typescript
{
  id: 'about',
  title: 'About Adulting Coach',
  subtitle: 'Version 1.0.0',  // ❌ Hardcoded
  icon: 'information-circle-outline',
}
```

**Issues:**
- Had to manually update version in 2 places (app.json + ProfileScreen)
- Easy to forget when releasing new versions
- Version could be out of sync between backend and frontend

---

## Solution

Created a utility to automatically read version from `app.json`:

### 1. Created `app-version.ts` utility

**File:** `src/utils/app-version.ts`

**Functions:**

#### `getAppVersion()`
Returns the app version from expo config:
```typescript
getAppVersion() // Returns: "1.0.0"
```

Sources (in priority order):
1. `Constants.expoConfig.version` (app.json)
2. `Constants.manifest.version` (fallback)
3. `"1.0.0"` (ultimate fallback)

#### `getBuildNumber()`
Returns the build number:
```typescript
getBuildNumber() // Returns: "13"
```

Sources:
- iOS: `Constants.expoConfig.ios.buildNumber`
- Android: `Constants.expoConfig.android.versionCode`

#### `getFullVersionString()`
Returns version with build number:
```typescript
getFullVersionString() // Returns: "1.0.0 (13)"
```

#### `getVersionInfo()`
Returns complete version information:
```typescript
getVersionInfo()
// Returns:
// {
//   version: "1.0.0",
//   buildNumber: "13",
//   fullVersion: "1.0.0 (13)",
//   platform: "iOS",
//   expoVersion: "53.0.0"
// }
```

---

### 2. Updated ProfileScreen

**File:** `src/screens/ProfileScreen.tsx`

**Before:**
```typescript
const menuItems = [
  {
    id: 'about',
    title: 'About Adulting Coach',
    subtitle: 'Version 1.0.0',  // ❌ Hardcoded
    icon: 'information-circle-outline',
  },
  // ...
];
```

**After:**
```typescript
import { getFullVersionString } from '../utils/app-version';

// Menu items factory function
const getMenuItems = () => [
  {
    id: 'about',
    title: 'About Adulting Coach',
    subtitle: `Version ${getFullVersionString()}`,  // ✅ Dynamic
    icon: 'information-circle-outline',
  },
  // ...
];

export default function ProfileScreen() {
  // Get menu items with dynamic version
  const menuItems = React.useMemo(() => getMenuItems(), []);
  // ...
}
```

**Changes:**
- Converted `menuItems` to a factory function
- Uses `getFullVersionString()` to inject dynamic version
- Wrapped in `useMemo` for performance
- Now shows: "Version 1.0.0 (13)"

---

## How It Works

### Version Source Hierarchy

```
app.json (expo.version)
       ↓
Constants.expoConfig.version
       ↓
app-version.ts utility
       ↓
ProfileScreen
       ↓
Displayed to user: "Version 1.0.0 (13)"
```

### When Version Updates

**Old Process:**
1. Update `app.json` → `"version": "1.0.1"`
2. Update `ProfileScreen.tsx` → `'Version 1.0.1'`
3. Update `ios/buildNumber` → `"14"`
4. Build and release

**New Process:**
1. Update `app.json` → `"version": "1.0.1"`
2. Update `ios/buildNumber` → `"14"`
3. Build and release ✅

Version automatically syncs everywhere!

---

## Version Configuration

### app.json
```json
{
  "expo": {
    "version": "1.0.0",
    "ios": {
      "buildNumber": "13"
    },
    "android": {
      "versionCode": 13
    }
  }
}
```

### package.json
```json
{
  "version": "1.0.0"
}
```

**Note:** The utility reads from `app.json` (via expo config), not `package.json`. Keep them in sync manually or use a script.

---

## Usage Examples

### Display version in any component

```typescript
import { getAppVersion, getFullVersionString } from '../utils/app-version';

// Simple version
const version = getAppVersion();
console.log(version); // "1.0.0"

// Version with build number
const fullVersion = getFullVersionString();
console.log(fullVersion); // "1.0.0 (13)"

// In JSX
<Text>App Version: {getFullVersionString()}</Text>
```

### Display in About screen

```typescript
import { getVersionInfo } from '../utils/app-version';

function AboutScreen() {
  const versionInfo = getVersionInfo();
  
  return (
    <View>
      <Text>Version: {versionInfo.version}</Text>
      <Text>Build: {versionInfo.buildNumber}</Text>
      <Text>Platform: {versionInfo.platform}</Text>
      <Text>Expo SDK: {versionInfo.expoVersion}</Text>
    </View>
  );
}
```

### Send version in bug reports

```typescript
import { getVersionInfo } from '../utils/app-version';

async function sendBugReport(message: string) {
  const versionInfo = getVersionInfo();
  
  await fetch('https://api.example.com/bugs', {
    method: 'POST',
    body: JSON.stringify({
      message,
      version: versionInfo.fullVersion,
      platform: versionInfo.platform,
      expoVersion: versionInfo.expoVersion,
    }),
  });
}
```

---

## Benefits

### ✅ Single Source of Truth
- Version defined once in `app.json`
- Automatically propagates everywhere
- No manual updates needed

### ✅ Prevents Sync Issues
- Frontend always matches backend
- Build number included automatically
- No version mismatches

### ✅ Better Debug Info
- Full version string: "1.0.0 (13)"
- Platform information
- Expo SDK version
- Useful for bug reports

### ✅ Easy to Use
- Simple utility functions
- Works anywhere in the app
- TypeScript typed

---

## Testing

### Manual Test
1. Check ProfileScreen → "About Adulting Coach"
2. Should show: "Version 1.0.0 (13)"
3. Update `app.json` → `"version": "1.0.1"`
4. Reload app
5. Should show: "Version 1.0.1 (13)"

### Update Version Test
```bash
# Update version in app.json
sed -i 's/"version": "1.0.0"/"version": "1.0.1"/' app.json

# Update iOS build number
sed -i 's/"buildNumber": "13"/"buildNumber": "14"/' app.json

# Restart dev server
bun start

# Check app - should show "Version 1.0.1 (14)"
```

---

## Future Enhancements

### 1. Sync package.json and app.json
Create a script to keep them in sync:
```bash
# scripts/sync-version.sh
#!/bin/bash
VERSION=$(jq -r '.version' package.json)
jq ".expo.version = \"$VERSION\"" app.json > app.json.tmp
mv app.json.tmp app.json
```

### 2. Auto-increment build number
```typescript
// scripts/increment-build.ts
import fs from 'fs';
const appJson = JSON.parse(fs.readFileSync('app.json', 'utf8'));
appJson.expo.ios.buildNumber = String(Number(appJson.expo.ios.buildNumber) + 1);
fs.writeFileSync('app.json', JSON.stringify(appJson, null, 2));
```

### 3. Version change detection
```typescript
// Detect when version changes
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAppVersion } from './utils/app-version';

async function checkVersionChange() {
  const currentVersion = getAppVersion();
  const lastVersion = await AsyncStorage.getItem('lastAppVersion');
  
  if (lastVersion && lastVersion !== currentVersion) {
    // Show "What's New" modal
    showWhatsNewModal(currentVersion);
  }
  
  await AsyncStorage.setItem('lastAppVersion', currentVersion);
}
```

### 4. Server-side version check
```typescript
// Check if app version is outdated
async function checkForUpdate() {
  const currentVersion = getAppVersion();
  const response = await fetch('https://api.example.com/version');
  const { latestVersion, minimumVersion } = await response.json();
  
  if (currentVersion < minimumVersion) {
    // Force update required
    showForceUpdateModal();
  } else if (currentVersion < latestVersion) {
    // Optional update available
    showOptionalUpdateModal();
  }
}
```

---

## Files Modified

1. `src/utils/app-version.ts` (NEW) - Version utility
2. `src/screens/ProfileScreen.tsx` - Uses dynamic version
3. `docs/current/AUTO_VERSION_SYNC.md` - This document

---

## Status

✅ **Version automatically syncs from app.json**  
✅ **Shows full version with build number**  
✅ **Works in ProfileScreen**  
✅ **Reusable utility for other components**  
✅ **TypeScript typed**  
✅ **Handles fallbacks gracefully**

---

## Summary

The app version is now automatically synced from `app.json` to the ProfileScreen using the `app-version.ts` utility. 

**Before:** Had to update version in 2 places manually  
**After:** Update once in `app.json`, automatically syncs everywhere

**Display Format:** "Version 1.0.0 (13)" (version + build number)

This eliminates version sync issues and makes releases easier! 🚀
