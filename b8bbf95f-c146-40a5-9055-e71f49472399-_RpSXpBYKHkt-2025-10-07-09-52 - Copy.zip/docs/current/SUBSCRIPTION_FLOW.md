# Subscription Flow Diagram

## 🔄 How Pro Status is Determined

```
┌─────────────────────────────────────────────────────────────┐
│                       APP LAUNCH                             │
│                                                              │
│  1. App.tsx initializes                                     │
│  2. StoreKit.init() called                                  │
│  3. Check: storekit.getActive()                             │
│     └──> Returns: { active: isPro }                         │
│  4. Set: useUIStore.setIsPro(active)                        │
│                                                              │
└─────────────────┬────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│                   USER AUTHENTICATION                        │
│                                                              │
│  1. User signs in (AuthContext)                             │
│  2. Check if admin email                                    │
│     ├─ YES → setIsPro(true) + setIsAdmin(true)             │
│     └─ NO  → Check StoreKit                                 │
│          └──> storekit.getActive()                          │
│               └──> setIsPro(active)                         │
│                                                              │
└─────────────────┬────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│              FREE USER TAPS LOCKED SKILL                     │
│                                                              │
│  1. User taps Pro skill                                     │
│  2. Check: isPro = useUIStore(s => s.isPro)                 │
│  3. If false → Show PaywallScreen                           │
│                                                              │
└─────────────────┬────────────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────────┐
│                    PURCHASE FLOW                             │
│                                                              │
│  1. User selects subscription plan                          │
│  2. Call: storekit.purchase(productId)                      │
│  3. Apple StoreKit handles payment                          │
│  4. Purchase listener fires:                                │
│     ├─ finishTransaction()                                  │
│     └─ setIsPro(true) ✅                                    │
│  5. [Optional] Sync to database:                            │
│     └─ subscriptionService.sync(userId)                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘

## 📊 Data Flow

```
┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│              │         │              │         │              │
│   StoreKit   │────────>│   UI Store   │────────>│  Components  │
│  (Apple IAP) │ setIsPro│  (Zustand)   │  isPro  │  (React)     │
│              │         │              │         │              │
└──────┬───────┘         └──────┬───────┘         └──────────────┘
       │                        │
       │ Syncs to database      │
       │ (analytics only)       │
       ▼                        │
┌──────────────┐                │
│              │                │
│  Supabase    │<───────────────┘
│  Database    │    Reads for
│              │    analytics
└──────────────┘
```

## 🎯 Source of Truth Hierarchy

1. **StoreKit** (Apple IAP) - ONLY SOURCE OF TRUTH
2. **UI Store** (Zustand) - Mirrors StoreKit status
3. **Supabase DB** - Analytics/tracking only, NOT authoritative

## 🔐 Access Control Logic

### Skill Unlocking (LessonsStore.ts)

```typescript
isSkillUnlocked(skillId: string): boolean {
  const isPro = useUIStore.getState().isPro;
  
  if (isPro) {
    return true; // Pro users: all skills unlocked ✅
  }
  
  // Free users: Check if it's a starter skill
  const skill = skills.find(s => s.id === skillId);
  if (skill?.difficulty === 'starter') {
    return true; // Starter skills always free ✅
  }
  
  return false; // Lock Pro skills 🔒
}
```

### AI Message Limits (UIStore.ts)

```typescript
canSendAI(): { ok: boolean; reason?: string } {
  const isPro = useUIStore.getState().isPro;
  
  if (isPro) {
    return { ok: true }; // Unlimited for Pro ✅
  }
  
  const remaining = progressStore.getAiRemaining();
  
  if (remaining <= 0) {
    return { ok: false, reason: 'limit' }; // 3/day limit 🔒
  }
  
  return { ok: true };
}
```

## 🧪 Testing Pro Features

### Option 1: Admin Email
```typescript
// Add your email to .env
EXPO_PUBLIC_ADMIN_EMAILS="your-email@example.com"

// Sign in → Auto-granted Pro ✅
```

### Option 2: Manual Toggle (Dev Only)
```typescript
// In any screen (dev mode)
useUIStore.getState().setIsPro(true); // Test Pro
useUIStore.getState().setIsPro(false); // Test Free
```

### Option 3: Sandbox Purchase
```typescript
// Use Apple Sandbox tester account
// Purchase flows through real StoreKit
// No actual charges
```

## 🚫 Anti-Patterns (DO NOT DO)

```typescript
// ❌ BAD: Setting isPro outside StoreKit
useUIStore.getState().setIsPro(true); // Only StoreKit should do this

// ❌ BAD: Reading from database for Pro status
const isPro = await supabase.from('subscriptions').select('is_active');

// ❌ BAD: Overriding StoreKit in subscription service
if (serverStatus.isActive) {
  useUIStore.getState().setIsPro(true); // NO! StoreKit is boss
}

// ✅ GOOD: Reading from UI Store
const isPro = useUIStore(s => s.isPro);

// ✅ GOOD: Letting StoreKit handle it
await storekit.purchase(productId); // StoreKit sets isPro automatically

// ✅ GOOD: Syncing to database (analytics)
await subscriptionService.sync(userId); // Just records, doesn't change isPro
```

## 📱 User Experience Flow

```
Free User Journey:
1. Opens app → See 24 starter skills unlocked
2. Browse catalog → See lock icons on Pro skills
3. Tap Pro skill → Paywall appears
4. Purchase Pro → StoreKit processes
5. Success! → isPro = true
6. All skills unlocked ✅

Pro User Journey:
1. Opens app → StoreKit checks subscription
2. Active subscription → isPro = true
3. All features unlocked
4. No limits, no paywalls ✅
```

## 🔄 Subscription States

```
┌─────────────┐
│   Free      │ isPro = false
│   User      │ 24 skills, 3 AI msgs/day
└──────┬──────┘
       │
       │ Purchase
       ▼
┌─────────────┐
│   Pro       │ isPro = true
│   User      │ All skills, unlimited AI
└──────┬──────┘
       │
       │ Subscription expires
       │ (StoreKit detects)
       ▼
┌─────────────┐
│   Free      │ isPro = false
│   User      │ Back to free limits
└─────────────┘
```

## 🎯 Key Takeaways

1. **StoreKit is king** - It controls everything
2. **Database is a mirror** - For analytics only
3. **UI Store bridges them** - Persisted subscription state
4. **No manual overrides** - Let StoreKit handle Pro status
5. **Admin emails bypass** - For testing and support
6. **Free tier is generous** - 24 skills + 3 AI msgs/day

This architecture ensures compliance with Apple guidelines while enabling robust analytics and promotional features! 🚀
