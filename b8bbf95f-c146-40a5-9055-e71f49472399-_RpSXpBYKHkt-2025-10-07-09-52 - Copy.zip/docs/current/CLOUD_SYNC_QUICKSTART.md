# 🚀 Quick Start: Cloud Sync Setup

## Step 1: Run Database Migration (5 minutes)

1. Open https://supabase.com/dashboard/project/YOUR_PROJECT_ID/sql
2. Click "+ New Query"
3. Open `supabase-lesson-progress-migration.sql` in this project
4. Copy entire file contents
5. Paste into Supabase SQL Editor
6. Click "Run" button
7. ✅ Should see "Success. No rows returned"

## Step 2: Test It Works (2 minutes)

1. **Sign in to your app**
2. **Open any lesson** and complete a step (check a checklist item)
3. **Check console** - Look for:
   ```
   ☁️ [LessonsStore] Synced progress to cloud: {skillId}
   ✅ [LessonProgressService] Saved progress for skill: {skillId}
   ```
4. **Check Supabase Dashboard**:
   - Go to Table Editor → `user_lesson_progress`
   - You should see a new row with your progress!

## Step 3: Test Cross-Device Sync (3 minutes)

1. **Complete progress on Device A** (or simulator)
2. **Sign out**
3. **Sign in on Device B** (or different simulator/web)
4. **Check console** for:
   ```
   ✅ [AuthContext] Loaded lesson progress from cloud
   ☁️ [LessonsStore] Loaded N progress records from cloud
   ```
5. **Open lessons** - Progress should be there! 🎉

## That's It!

Your app now has:
- ✅ Automatic cloud backup
- ✅ Cross-device sync
- ✅ No data loss on app deletion

## Troubleshooting

**If sync isn't working:**
1. Check you ran the migration (Step 1)
2. Verify user is logged in (check AuthContext user state)
3. Check console for error messages
4. Verify internet connection

**Common Issues:**
- "Table doesn't exist" → Run migration
- "Permission denied" → Check RLS policies (should be auto-created by migration)
- "No sync happening" → Check console for errors, verify user is authenticated

---

Need help? Check `CLOUD_SYNC_IMPLEMENTATION.md` for full details.
