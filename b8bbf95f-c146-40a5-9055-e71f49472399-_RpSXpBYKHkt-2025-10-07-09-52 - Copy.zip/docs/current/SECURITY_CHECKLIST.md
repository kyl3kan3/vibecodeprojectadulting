# 🔒 Security Cleanup Checklist

## Immediate Actions (Critical)

### ✅ Code Changes (Completed)
- [x] Removed `EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY` from code
- [x] Removed `EXPO_PUBLIC_VIBECODE_GROK_API_KEY` from code
- [x] Removed `EXPO_PUBLIC_VERCEL_PROTECTION_BYPASS` from code
- [x] Removed `EXPO_PUBLIC_PROXY_SECRET` from code
- [x] Added `.env` to `.gitignore`
- [x] Deprecated insecure API client functions
- [x] Updated proxy to use user authentication
- [x] **Updated proxy.ts to send real user Supabase tokens**
- [x] **Created .env.example with safe public variables**

### ⏳ Configuration Changes (Next Steps)

**Step 1: Run Security Cleanup Script**
```bash
chmod +x scripts/security-cleanup.sh
./scripts/security-cleanup.sh
```

**Step 2: Update Vercel Environment Variables**

Go to: Vercel Dashboard → Your Project → Settings → Environment Variables

Add these (if not already there):
```
OPENAI_API_KEY=sk-proj-... (GET NEW KEY!)
GROK_API_KEY=xai-... (GET NEW KEY!)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=eyJ...
```

**Step 3: Update Vercel Proxy Code**

Your Vercel `/api/ai` route needs to validate user tokens:

```typescript
import { createClient } from '@supabase/supabase-js';

export default async function handler(req, res) {
  // Get user token
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const userToken = authHeader.substring(7);
  
  // Validate with Supabase
  const supabase = createClient(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_KEY!
  );
  
  const { data: { user }, error } = await supabase.auth.getUser(userToken);
  
  if (error || !user) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  
  // User authenticated! Process AI request...
  // Use process.env.OPENAI_API_KEY or GROK_API_KEY (server-side)
}
```

**Step 4: Rotate Compromised API Keys**

- [ ] Generate new OpenAI key: https://platform.openai.com/api-keys
- [ ] Generate new Grok key: https://console.x.ai/
- [ ] Update Vercel environment variables
- [ ] Delete old exposed keys

**Step 5: Clean Git History (Optional but Recommended)**

The old `.env` is in git history. To completely remove:

```bash
# Option A: BFG Repo Cleaner (recommended)
# Download from https://rtyley.github.io/bfg-repo-cleaner/
java -jar bfg.jar --delete-files .env
git reflog expire --expire=now --all && git gc --prune=now --aggressive

# Option B: git filter-branch
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch .env" \
  --prune-empty --tag-name-filter cat -- --all
```

⚠️ **Warning:** These rewrite git history. Coordinate with team if applicable.

## Verification Steps

### After Implementation:

- [ ] Run: `git ls-files .env` → Should return nothing
- [ ] Run: `grep -r "EXPO_PUBLIC_.*API_KEY" src/` → Should find nothing
- [ ] Check `.env` file → Only has `EXPO_PUBLIC_` prefixed public values
- [ ] Test app → Authentication works
- [ ] Test AI features → Proxy calls work
- [ ] Check Vercel logs → No 401 errors
- [ ] Verify API keys → Old keys deleted, new keys working

## Security Score

**Before:** ⚠️ 4/10 (Critical vulnerabilities)  
**After:** ✅ 8/10 (Secure architecture)

## Quick Reference

**What's safe in .env:**
- ✅ `EXPO_PUBLIC_AI_PROXY_URL` - Your Vercel URL
- ✅ `EXPO_PUBLIC_ADMIN_EMAILS` - Admin emails
- ✅ `EXPO_PUBLIC_IAP_*` - App Store product IDs

**What goes ONLY on Vercel:**
- 🔒 `OPENAI_API_KEY`
- 🔒 `GROK_API_KEY`
- 🔒 `SUPABASE_SERVICE_KEY`
- 🔒 Any other secrets

**Remember:** Anything with `EXPO_PUBLIC_` prefix is **embedded in your app** and publicly visible!

