# Pro Tier Quick Reference Card 🎯

## 🔑 Key Facts

| Aspect | Details |
|--------|---------|
| **Source of Truth** | Apple StoreKit (IAP) |
| **Local State** | `useUIStore.getState().isPro` |
| **Database Role** | Analytics/tracking only |
| **Free Skills** | 24+ (first 3 per category) |
| **Free AI** | 3 messages/day |
| **Pro Skills** | All 100+ unlocked |
| **Pro AI** | Unlimited messages |

---

## 📍 Where to Check Pro Status

```typescript
// Option 1: Hook (preferred in components)
const isPro = useUIStore(s => s.isPro);

// Option 2: Direct access (utils/services)
const isPro = useUIStore.getState().isPro;

// Option 3: Multiple selectors
const { isPro, isAdmin } = useUIStore();
```

---

## 🔄 Purchase Flow

```typescript
// 1. User taps "Subscribe"
await storekit.purchase(productId);

// 2. StoreKit handles payment
// 3. Purchase listener fires automatically
// 4. isPro set to true ✅

// 5. (Optional) Sync to database
await subscriptionService.sync(userId);
```

---

## 🧪 Testing Quick Commands

```typescript
// Toggle Pro status (dev only)
useUIStore.getState().setIsPro(true);  // Test Pro
useUIStore.getState().setIsPro(false); // Test Free

// Check current status
console.log('Pro?', useUIStore.getState().isPro);

// Get StoreKit products
const products = await storekit.getProducts();
console.log('Products:', products);
```

---

## 🚦 Access Control Examples

### Check if skill is unlocked:
```typescript
const { isSkillUnlocked } = useLessonsStore();
const unlocked = isSkillUnlocked(skillId);

if (!unlocked) {
  navigation.navigate('Paywall');
}
```

### Check if can send AI message:
```typescript
const canSend = useUIStore(s => s.canSendAI());

if (!canSend.ok) {
  Alert.alert('Limit Reached', 'Upgrade to Pro for unlimited AI');
}
```

### Show Pro badge:
```typescript
const isPro = useUIStore(s => s.isPro);

{isPro && <Text className="text-emerald-400">PRO</Text>}
```

---

## 📂 Key Files

| File | Purpose |
|------|---------|
| `src/services/storekit/index.ts` | StoreKit implementation |
| `src/services/subscriptions/subscription-service.ts` | Database sync |
| `src/state/ui-store.ts` | isPro state |
| `src/state/lessons-store.ts` | Skill locking logic |
| `src/screens/PaywallScreen.tsx` | Purchase UI |
| `src/contexts/AuthContext.tsx` | Initial Pro check |
| `App.tsx` | Launch-time Pro check |

---

## ⚡ Common Tasks

### Add Pro-only feature:
```typescript
const isPro = useUIStore(s => s.isPro);

if (!isPro) {
  return (
    <Pressable onPress={() => navigation.navigate('Paywall')}>
      <Text>Unlock Pro to access this feature</Text>
    </Pressable>
  );
}

return <ProFeatureComponent />;
```

### Track paywall impression:
```typescript
import { analytics } from '../services/analytics/analytics-service';

useEffect(() => {
  analytics.paywall.shown('skill_detail', skillId);
}, []);
```

### Check if user is admin:
```typescript
const isAdmin = useUIStore(s => s.isAdmin);

// Admins always have Pro
if (isAdmin) {
  // Show admin-only features
}
```

---

## 🚫 Common Mistakes

```typescript
// ❌ DON'T: Override StoreKit
useUIStore.getState().setIsPro(true); // Only StoreKit should do this

// ❌ DON'T: Read from database
const isPro = await db.query('subscriptions');

// ❌ DON'T: Async check in render
const [isPro, setIsPro] = useState(false);
useEffect(() => {
  storekit.getActive().then(res => setIsPro(res.active));
}, []); // Just use useUIStore!

// ✅ DO: Use the store
const isPro = useUIStore(s => s.isPro);
```

---

## 🎯 Feature Comparison

| Feature | Free | Pro |
|---------|------|-----|
| Starter Skills (24+) | ✅ | ✅ |
| Pro Skills (76+) | 🔒 | ✅ |
| AI Messages | 3/day | ∞ |
| Daily Tips | ✅ | ✅ |
| Achievements | ✅ | ✅ |
| Progress Tracking | ✅ | ✅ |
| Learning Paths | ✅ | ✅ |
| Free Trial Skill | 1 skill | N/A |
| Referral Rewards | ✅ | ✅ |

---

## 🔧 Environment Variables

```bash
# Admin emails (auto-granted Pro)
EXPO_PUBLIC_ADMIN_EMAILS="email1@example.com,email2@example.com"

# IAP Product IDs
EXPO_PUBLIC_IAP_PRODUCT_IDS="monthly_pro,annual_pro"
```

---

## 📞 Support Scenarios

### User can't restore purchase:
```typescript
// Have them try restore flow
const state = await storekit.restore();

if (state === 'restored') {
  // Success! ✅
} else {
  // Check Apple subscriptions
  await storekit.openManageSubscriptions();
}
```

### User claims they have Pro but it's not working:
```typescript
// Check local state
console.log('isPro:', useUIStore.getState().isPro);

// Check StoreKit
const { active } = await storekit.getActive();
console.log('StoreKit active:', active);

// Check database (analytics only)
const dbStatus = await subscriptionService.getStatus(userId);
console.log('DB status:', dbStatus);

// Try syncing
await subscriptionService.sync(userId);
```

### Admin wants to grant Pro manually:
```typescript
// Add their email to EXPO_PUBLIC_ADMIN_EMAILS
// Or manually toggle (dev only):
useUIStore.getState().setIsPro(true);
```

---

## 💡 Pro Tips

1. **Always use hooks in components** - `useUIStore(s => s.isPro)`
2. **StoreKit handles everything** - Don't override manually
3. **Database is optional** - App works fine without analytics
4. **Admin emails bypass** - Great for testing/support
5. **Free tier is generous** - 24 skills keeps users engaged
6. **Paywall is key** - Make it compelling but not annoying

---

## 🎓 Learning Resources

- **Architecture:** `docs/current/PRO_TIER_ARCHITECTURE.md`
- **Flow Diagrams:** `docs/current/SUBSCRIPTION_FLOW.md`
- **Complete Guide:** `docs/current/STOREKIT_INTEGRATION_COMPLETE.md`
- **Implementation:** `docs/current/PRO_GATING_IMPLEMENTATION.md`
- **Optional Features:** `docs/current/PRO_GATING_OPTIONAL_FEATURES_COMPLETE.md`

---

## ✅ Checklist

- [x] StoreKit handles purchases
- [x] isPro stored in UI Store
- [x] Free tier: 24 skills + 3 AI/day
- [x] Pro tier: unlimited everything
- [x] Admin emails bypass
- [x] Database syncs for analytics
- [x] No conflicts between systems
- [x] Apple guidelines compliant
- [x] Well documented

**Status: 100% Complete! 🚀**
