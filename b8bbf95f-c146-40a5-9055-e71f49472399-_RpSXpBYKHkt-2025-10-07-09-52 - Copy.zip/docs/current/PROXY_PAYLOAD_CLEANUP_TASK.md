# Proxy Payload Cleanup Task

## Current State
`src/lib/supabase-mcp.ts` (line ~120) sends both `data` AND `values` fields:

```typescript
const payload: any = {
  operation: 'upsert',
  table,
  data: dataArray,
  values: dataArray,  // Duplicate - added to support legacy proxy
  returning
};
```

## Why Both Fields Exist
During the cloud sync upsert fix, we encountered an error:
```
"Missing 'values' for upsert"
```

This suggested the Vercel proxy was expecting `values` instead of `data`. We added both fields to be safe.

## Testing Required

### Step 1: Check Proxy Implementation
Look at your Vercel proxy code (`/api/db/query.ts`) and find the upsert handler:

```typescript
if (operation === 'upsert') {
  const { data: requestData, onConflict } = req.body;  // Does it use 'data'?
  // OR
  const { values: requestData, onConflict } = req.body;  // Or 'values'?
  
  // ...
}
```

### Step 2: Test With Only `data` Field

**Option A: Test in development**
1. Comment out `values: dataArray` line in `src/lib/supabase-mcp.ts`
2. Reload app
3. Complete a lesson step
4. Check if progress saves without error

**Option B: Check proxy logs**
1. Add logging to your Vercel proxy
2. See what field it actually reads from `req.body`

### Step 3: Decision

**If proxy uses `data`:**
- ✅ Remove `values: dataArray` line (line ~121)
- Cleaner code, no duplication

**If proxy uses `values`:**
- ✅ Remove `data: dataArray` line (line ~120)
- Keep `values` as the correct field

**If proxy can handle both:**
- ⚠️ Keep both (safe but redundant)
- Document why we keep both

## Recommended Action

1. **Check the proxy code first** (look at deployed Vercel function)
2. **If proxy correctly uses `data`** → Remove `values` field
3. **If proxy needs `values`** → Remove `data` field and update documentation

## Files to Modify

If removing `values`:
- `src/lib/supabase-mcp.ts` line ~121

If removing `data`:
- `src/lib/supabase-mcp.ts` line ~120

## Risk Level
🟡 **Medium** - Could break cloud sync if proxy expects specific field

## Testing Checklist
- [ ] Check Vercel proxy source code
- [ ] Test with only one field in dev
- [ ] Verify lesson progress saves
- [ ] Verify tip progress saves  
- [ ] Verify streak updates
- [ ] Check console for upsert errors

---

**Status**: ⏸️ Awaiting testing  
**Action Required**: Check Vercel proxy implementation  
**Blocked By**: Need to verify proxy field expectations
