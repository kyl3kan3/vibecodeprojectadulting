# Pro Gating Review
## Date: October 4, 2025

### Summary
Review of the current Pro subscription gating implementation across the app, including what's gated, how it works, and recommendations.

---

## Current Gating Status

### ✅ What's Implemented

#### **1. Pro State Management**
**Location**: `src/state/ui-store.ts`

**State Variables:**
- `isPro: boolean` - Whether user has Pro subscription
- `isAdmin: boolean` - Admin access flag
- `freeLimits` - Free tier limits configuration
  - `aiMonthly: 30` - Monthly AI message limit
  - `aiCooldownMin: 30` - Cooldown between messages (minutes)
  - `unlockedSkillIds: []` - Free skills (currently empty)

**Storage**: Persisted in AsyncStorage as part of ui-store

#### **2. Subscription Service**
**Location**: `src/services/storekit/index.ts`

**Features:**
- iOS In-App Purchase integration via `react-native-iap`
- Purchase flow: `purchase()` → sets `isPro: true`
- Restore purchases: `restore()` → checks previous purchases
- Product fetching from App Store Connect
- Manages subscription lifecycle

**Configuration:**
- Product IDs from: `process.env.EXPO_PUBLIC_IAP_PRODUCT_IDS`
- Subscription managed via Apple's subscription system

#### **3. AI Feature Gating** ⚠️ NEEDS REVIEW

**Location**: `src/screens/AskAIScreen.tsx`, `src/state/progress-store.ts`

**Free Tier Limits:**
```typescript
const AI_MONTHLY_LIMIT = 30; // messages per month
const AI_COOLDOWN_MINUTES = 30; // wait time between messages
const freeLimit = 3; // displayed in UI (conflicts with 30?)
```

**⚠️ ISSUE: Conflicting Limits**
- Code shows `AI_MONTHLY_LIMIT = 30`
- UI displays `freeLimit = 3`
- UI banner: "Free plan: 3/month • 1 per day"
- **Which is correct?**

**How It Works:**
```typescript
// Before sending message
if (!isPro) {
  const gate = useUIStore.getState().canSendAI?.();
  if (gate && gate.ok === false) {
    if (gate.reason === "cooldown") {
      // Show cooldown message
      return;
    }
    // Redirect to subscription
    navigation.navigate("SubscriptionSheet");
    return;
  }
}

// After successful message
if (!isPro) { 
  incrementAIUsage(); 
}
```

**Tracking:**
- `aiUsage: number` - Messages sent this month
- `aiLastUsedAt: string` - Last message timestamp
- Resets monthly automatically
- Cooldown: 30 minutes between messages

#### **4. Skill/Lesson Gating** ⚠️ CURRENTLY BROKEN

**Location**: `src/screens/SkillDetailScreen.tsx`, `src/state/lessons-store.ts`

**How It Should Work:**
```typescript
const isPro = useUIStore(s => s.isPro);
const canAccessSkill = useLessonsStore(s => s.isSkillUnlocked(skillId));
const canAccess = isPro || canAccessSkill;

// isSkillUnlocked logic:
isSkillUnlocked: (skillId: string): boolean => {
  // Only returns true if skill is completed OR has progress
  return get().completedSkills.includes(skillId) || !!get().skillProgress[skillId];
}
```

**⚠️ MAJOR ISSUE: No Free Skills**
- `freeLimits.unlockedSkillIds: []` - Empty array!
- `isSkillUnlocked()` only unlocks if already started/completed
- **Result: ALL skills are locked for free users**
- Users can't start ANY lessons without Pro

**Expected Behavior:**
- Some skills should be free (e.g., first 3-5 skills per category)
- Free skills should be in `freeLimits.unlockedSkillIds`
- Pro users get all skills

**Locked Screen Behavior:**
```typescript
if (!canAccess) {
  return (
    <View>
      <Text>Preview Locked Skill</Text>
      <Pressable onPress={() => navigation.navigate('SubscriptionSheet')}>
        <Text>Upgrade to Pro</Text>
      </Pressable>
    </View>
  );
}
```

#### **5. Tips/Catalog Gating**

**Location**: `src/screens/CatalogScreen.tsx`

**Implementation:**
```typescript
const canAccess = isPro || (canAccessTip ? canAccessTip(tip.id) : false);
const locked = !canAccess;

// Visual indicators
{locked && (
  <View className="absolute inset-0 z-10 bg-black/5" />
)}
{locked && (
  <Ionicons name="lock-closed" size={14} color="#6B7280" />
  <Text>Pro</Text>
)}
```

**canAccessTip Implementation:**
```typescript
// From ui-store.ts
canAccessTip: (tipId: string) => {
  // All tips accessible by default
  return true;
}
```

**⚠️ ISSUE: Not Actually Gated**
- Function always returns `true`
- All tips are free despite lock UI

---

## Issues Found

### 🔴 Critical Issues

#### **1. No Free Skills Available**
**Problem:** `freeLimits.unlockedSkillIds` is empty array
**Impact:** Free users cannot start ANY lessons
**Severity:** CRITICAL - Blocks all free users from core functionality

**Fix Required:**
1. Define which skills/lessons should be free
2. Populate `freeLimits.unlockedSkillIds` with free skill IDs
3. OR change unlock logic to allow first N skills per category
4. Update `isSkillUnlocked()` to check this array

**Suggested Free Content:**
- First 3-5 skills in each category
- All "starter" difficulty lessons
- Specific "intro" lessons to showcase app

#### **2. Conflicting AI Limits**
**Problem:** Code says 30/month, UI says 3/month
**Impact:** User confusion, incorrect limit enforcement
**Severity:** HIGH - Affects user expectations

**Which is Correct?**
- `AI_MONTHLY_LIMIT = 30` (in code)
- `freeLimit = 3` (in UI)
- Banner: "3/month • 1 per day"

**Fix Required:**
- Clarify business requirement: What's the actual limit?
- Update code OR UI to match
- Consider: 3 per month with 1 per day max is very restrictive

### 🟡 Medium Issues

#### **3. Tips Not Actually Gated**
**Problem:** `canAccessTip()` always returns `true`
**Impact:** Pro upsell doesn't work for tips
**Severity:** MEDIUM - Lost revenue opportunity

**Fix Required:**
- Implement actual tip gating logic
- Define free vs Pro tips
- OR remove gating UI if all tips should be free

#### **4. No Server-Side Validation**
**Problem:** Pro status only stored locally in AsyncStorage
**Impact:** Users can manually edit storage to get Pro features
**Severity:** MEDIUM - Revenue loss potential

**Current Code:**
```typescript
async getActive() {
  // Local entitlement flag for this build; 
  // replace with server check in production
  const active = !!useUIStore.getState().isPro;
  return { active };
}
```

**Fix Required:**
- Implement server-side subscription verification
- Validate receipts with Apple/Google servers
- Use Supabase to store verified subscription status
- Check server status before granting access

### 🟢 Minor Issues

#### **5. Hardcoded Admin Email**
**Problem:** Admin check uses hardcoded email
```typescript
const isAdmin = user?.email?.toLowerCase() === 'kyl3kan3@gmail.com';
```
**Impact:** Not scalable for multiple admins
**Severity:** LOW - Works but not ideal

**Fix Required:**
- Add `is_admin` field to profiles table
- Check database instead of hardcoded email

#### **6. canSendAI Always Returns OK**
**Problem:** Simplified implementation
```typescript
canSendAI: () => {
  // Simplified - full implementation would check AI usage limits
  return { ok: true };
}
```
**Impact:** Doesn't actually enforce limits
**Severity:** LOW - AskAIScreen has its own checks

---

## How Gating Currently Works

### AI Messages (Working, but conflicting limits)
```
Free User Flow:
1. User types message
2. Check: isPro? → No
3. Check: canSendAI()? → Always returns true (bug)
4. Check: cooldown active? → If yes, show wait message
5. Check: monthly limit reached? → If yes, redirect to paywall
6. Send message
7. Increment usage counter
8. Set last used timestamp

Pro User Flow:
1. User types message
2. Check: isPro? → Yes
3. Send message (no limits, no tracking)
```

### Lessons/Skills (Currently broken)
```
Free User Flow:
1. User taps lesson
2. Check: isPro? → No
3. Check: isSkillUnlocked(skillId)? → Always false (empty unlocked array)
4. Show locked preview screen
5. Offer upgrade to Pro

Pro User Flow:
1. User taps lesson
2. Check: isPro? → Yes
3. Show full lesson content
```

### Tips (Not actually gated)
```
All Users:
1. User taps tip
2. Check: isPro || canAccessTip()? → Always true
3. Show full tip content
4. Lock UI displays but doesn't enforce
```

---

## Recommendations

### Immediate Fixes (Critical)

#### **1. Define and Implement Free Skills**
**Option A: First N Skills Per Category**
```typescript
// In lessons-store.ts
isSkillUnlocked: (skillId: string): boolean => {
  const state = get();
  const skill = state.skills.find(s => s.id === skillId);
  
  // Pro users get everything
  if (useUIStore.getState().isPro) return true;
  
  // Skill already started or completed
  if (state.completedSkills.includes(skillId) || !!state.skillProgress[skillId]) {
    return true;
  }
  
  // Check if skill is in free unlocked list
  const freeSkills = useUIStore.getState().freeLimits.unlockedSkillIds;
  if (freeSkills.includes(skillId)) return true;
  
  // Free tier: Unlock first 3 "starter" difficulty per category
  if (skill?.difficulty === 'starter') {
    const categorySkills = state.skills
      .filter(s => s.category === skill.category && s.difficulty === 'starter')
      .sort((a, b) => a.order - b.order);
    const skillIndex = categorySkills.findIndex(s => s.id === skillId);
    return skillIndex < 3; // First 3 starter skills free
  }
  
  return false;
}
```

**Option B: Specific Free Skills List**
```typescript
// In ui-store.ts initial state
freeLimits: {
  aiMonthly: 30,
  aiCooldownMin: 30,
  unlockedSkillIds: [
    'budgeting-basics',
    'credit-score-101',
    'resume-writing',
    'meal-planning-intro',
    'apartment-hunting',
    // ... add 10-15 intro skills
  ]
}
```

#### **2. Clarify and Fix AI Limits**
**Recommended: Be Clear and Generous**
```typescript
// Option 1: Simple daily limit
const AI_DAILY_LIMIT = 3;
const AI_COOLDOWN_MINUTES = 0; // No cooldown

// Option 2: Monthly with daily cap
const AI_MONTHLY_LIMIT = 30;
const AI_DAILY_LIMIT = 3;
const AI_COOLDOWN_MINUTES = 0;

// Option 3: Very restrictive (current)
const AI_MONTHLY_LIMIT = 3;
const AI_COOLDOWN_MINUTES = 1440; // 24 hours = 1 per day
```

**Update UI to match:**
```typescript
// In AskAIScreen.tsx
<Text>Free plan: {AI_DAILY_LIMIT}/day • {AI_MONTHLY_LIMIT}/month</Text>
```

### Medium Priority

#### **3. Implement Server-Side Verification**
```typescript
// In storekit/index.ts
async getActive() {
  try {
    // 1. Get local state
    const localPro = !!useUIStore.getState().isPro;
    
    // 2. Verify with server (Supabase)
    const { data, error } = await supabaseMCP.query('user_subscriptions', {
      select: 'is_active, expires_at',
      filter: { user_id: getCurrentUserId() },
      single: true
    });
    
    if (error || !data) return { active: localPro };
    
    // 3. Check if subscription is active and not expired
    const serverPro = data.is_active && new Date(data.expires_at) > new Date();
    
    // 4. Update local state if mismatch
    if (serverPro !== localPro) {
      useUIStore.getState().setIsPro(serverPro);
    }
    
    return { active: serverPro };
  } catch {
    // Fallback to local state
    return { active: !!useUIStore.getState().isPro };
  }
}
```

#### **4. Decide on Tips Gating**
**Option A: Keep All Tips Free** (Recommended for user engagement)
```typescript
// Remove gating UI from CatalogScreen
// All tips accessible to drive engagement
```

**Option B: Gate Advanced Tips**
```typescript
canAccessTip: (tipId: string) => {
  const state = get();
  if (state.isPro) return true;
  
  // Free tier gets first 50 tips
  const tip = getTipById(tipId);
  return tip && tip.order <= 50;
}
```

### Low Priority

#### **5. Admin Management**
```sql
-- Add to profiles table
ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT false;
```

```typescript
// In AuthContext or middleware
const checkAdminStatus = async (userId: string) => {
  const { data } = await supabase
    .from('profiles')
    .select('is_admin')
    .eq('id', userId)
    .single();
  
  useUIStore.getState().setIsAdmin(data?.is_admin || false);
}
```

---

## Testing Checklist

### Free User Testing
- [ ] Can access free skills (3-5 starter skills per category)
- [ ] Cannot access locked skills (shows paywall)
- [ ] Can send N AI messages per day/month
- [ ] Gets cooldown message if applicable
- [ ] Sees "Upgrade to Pro" prompts in right places
- [ ] Lock icons display correctly on gated content

### Pro User Testing
- [ ] Can access ALL skills immediately
- [ ] Can send unlimited AI messages
- [ ] No cooldowns or limits enforced
- [ ] "Pro" badge displays correctly
- [ ] No paywall interruptions

### Subscription Flow Testing
- [ ] Can purchase Pro subscription
- [ ] Pro features unlock immediately after purchase
- [ ] Can restore previous purchases
- [ ] Subscription status persists across app restarts
- [ ] Can manage subscription through iOS settings

### Edge Cases
- [ ] What happens if subscription expires?
- [ ] What if user downgrades from Pro to Free?
- [ ] Do completed lessons stay accessible after downgrade?
- [ ] Can user complete partially-started lessons after downgrade?

---

## Summary

**Critical Issues:**
1. 🔴 No free skills defined - ALL lessons locked for free users
2. 🔴 Conflicting AI limits (30 vs 3 messages)

**Works Correctly:**
- ✅ In-App Purchase integration
- ✅ Pro status persistence
- ✅ UI displays lock icons and Pro badges
- ✅ Paywall navigation flow

**Needs Implementation:**
- Server-side subscription verification
- Clear definition of free vs Pro content
- Consistent limit enforcement
- Admin management system

**Recommendation:**
1. **Immediately**: Define 3-5 free starter skills per category
2. **Immediately**: Clarify AI message limits (recommend 3/day or 30/month)
3. **Soon**: Implement server-side verification
4. **Eventually**: Decide on tips gating strategy
