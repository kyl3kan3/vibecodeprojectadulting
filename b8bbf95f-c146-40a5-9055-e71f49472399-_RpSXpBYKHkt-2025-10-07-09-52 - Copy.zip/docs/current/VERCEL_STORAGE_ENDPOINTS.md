# 📦 Vercel Storage Proxy Endpoints

Complete implementation for the storage proxy endpoints that your React Native app will use.

## Files to Create in Your Vercel Project

Create these three files in your Vercel project's `/api/storage/` directory:

---

## 1. `/api/storage/upload-url.ts`

Generates a signed upload URL for the client to use.

```typescript
import { createClient } from '@supabase/supabase-js';
import type { VercelRequest, VercelResponse } from '@vercel/node';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Extract request parameters
    const { bucket, path, contentType, upsert = true } = req.body;

    if (!bucket || !path || !contentType) {
      return res.status(400).json({ 
        error: 'Missing required fields: bucket, path, contentType' 
      });
    }

    // Create signed upload URL
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUploadUrl(path, {
        upsert,
      });

    if (error) {
      console.error('Failed to create signed upload URL:', error);
      return res.status(500).json({ error: error.message });
    }

    if (!data?.signedUrl) {
      return res.status(500).json({ error: 'No signed URL returned' });
    }

    // Return the signed URL and headers for the client to use
    return res.status(200).json({
      uploadUrl: data.signedUrl,
      method: 'PUT', // Supabase signed uploads use PUT
      headers: {
        'Content-Type': contentType,
        'x-upsert': upsert ? 'true' : 'false',
      },
      path: data.path,
      token: data.token,
    });
  } catch (error: any) {
    console.error('Upload URL generation error:', error);
    return res.status(500).json({ error: error.message });
  }
}
```

---

## 2. `/api/storage/download-url.ts`

Generates a signed download URL for the client to use.

```typescript
import { createClient } from '@supabase/supabase-js';
import type { VercelRequest, VercelResponse } from '@vercel/node';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow GET
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Extract query parameters
    const { bucket, path, expiresIn = '300' } = req.query;

    if (!bucket || !path) {
      return res.status(400).json({ 
        error: 'Missing required parameters: bucket, path' 
      });
    }

    const expiresInSeconds = parseInt(expiresIn as string, 10);
    if (isNaN(expiresInSeconds) || expiresInSeconds < 1 || expiresInSeconds > 3600) {
      return res.status(400).json({ 
        error: 'expiresIn must be between 1 and 3600 seconds' 
      });
    }

    // Create signed download URL
    const { data, error } = await supabase.storage
      .from(bucket as string)
      .createSignedUrl(path as string, expiresInSeconds);

    if (error) {
      console.error('Failed to create signed download URL:', error);
      return res.status(500).json({ error: error.message });
    }

    if (!data?.signedUrl) {
      return res.status(500).json({ error: 'No signed URL returned' });
    }

    // Calculate expiration timestamp
    const expiresAt = new Date(Date.now() + expiresInSeconds * 1000).toISOString();

    return res.status(200).json({
      url: data.signedUrl,
      expiresAt,
      expiresIn: expiresInSeconds,
    });
  } catch (error: any) {
    console.error('Download URL generation error:', error);
    return res.status(500).json({ error: error.message });
  }
}
```

---

## 3. `/api/storage/delete.ts`

Deletes a file from storage.

```typescript
import { createClient } from '@supabase/supabase-js';
import type { VercelRequest, VercelResponse } from '@vercel/node';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Extract request parameters
    const { bucket, path } = req.body;

    if (!bucket || !path) {
      return res.status(400).json({ 
        error: 'Missing required fields: bucket, path' 
      });
    }

    // Delete the file
    const { data, error } = await supabase.storage
      .from(bucket)
      .remove([path]);

    if (error) {
      console.error('Failed to delete file:', error);
      return res.status(500).json({ error: error.message });
    }

    return res.status(200).json({
      success: true,
      deleted: data,
    });
  } catch (error: any) {
    console.error('Delete error:', error);
    return res.status(500).json({ error: error.message });
  }
}
```

---

## 4. `/api/storage/list.ts` (Optional - for browsing files)

Lists files in a storage bucket path.

```typescript
import { createClient } from '@supabase/supabase-js';
import type { VercelRequest, VercelResponse } from '@vercel/node';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Only allow GET
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const token = authHeader.substring(7);
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Extract query parameters
    const { bucket, path, limit = '100', offset = '0', sortBy } = req.query;

    if (!bucket || !path) {
      return res.status(400).json({ 
        error: 'Missing required parameters: bucket, path' 
      });
    }

    // List files
    const options: any = {
      limit: parseInt(limit as string, 10),
      offset: parseInt(offset as string, 10),
    };

    if (sortBy) {
      try {
        options.sortBy = JSON.parse(sortBy as string);
      } catch (e) {
        return res.status(400).json({ error: 'Invalid sortBy JSON' });
      }
    }

    const { data, error } = await supabase.storage
      .from(bucket as string)
      .list(path as string, options);

    if (error) {
      console.error('Failed to list files:', error);
      return res.status(500).json({ error: error.message });
    }

    return res.status(200).json({
      files: data || [],
      count: data?.length || 0,
    });
  } catch (error: any) {
    console.error('List error:', error);
    return res.status(500).json({ error: error.message });
  }
}
```

---

## Environment Variables Required

Add these to your Vercel project settings:

```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
```

---

## Supabase Storage Setup

### 1. Create Storage Buckets

In your Supabase dashboard, go to **Storage** and create these buckets:

```sql
-- Bucket for user-uploaded content
CREATE BUCKET user-content WITH (public = false);

-- Bucket for profile avatars (can be public or private)
CREATE BUCKET avatars WITH (public = false);

-- Bucket for achievement badges (can be public)
CREATE BUCKET achievements WITH (public = true);
```

### 2. Set Storage Policies

For private user content:

```sql
-- Allow authenticated users to upload to their own folder
CREATE POLICY "Users can upload own files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'user-content' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Allow authenticated users to read their own files
CREATE POLICY "Users can read own files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'user-content' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Allow authenticated users to delete their own files
CREATE POLICY "Users can delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'user-content' AND (storage.foldername(name))[1] = auth.uid()::text);
```

---

## How It Works

### Upload Flow

1. **App requests signed URL** from proxy:
   ```typescript
   const result = await uploadFromUri(
     localFileUri,
     {
       bucket: 'user-content',
       path: `users/${userId}/photos/${Date.now()}.jpg`,
       contentType: 'image/jpeg',
       upsert: true,
     }
   );
   ```

2. **Proxy generates signed URL** using Supabase Storage
3. **App uploads directly to Supabase** using signed URL (secure, no keys exposed)
4. **File is stored** in Supabase Storage

### Download Flow

1. **App requests signed URL** from proxy:
   ```typescript
   const url = await getFileUrl('user-content', 'users/123/photos/image.jpg', 300);
   ```

2. **Proxy generates signed URL** with 5-minute expiration
3. **App uses URL** in `<Image source={{ uri: url }} />`
4. **URL expires** after 5 minutes (security)

---

## Testing

Test upload:

```bash
# 1. Get upload URL
curl -X POST https://your-proxy.vercel.app/api/storage/upload-url \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "bucket": "user-content",
    "path": "users/test-user/photos/test.jpg",
    "contentType": "image/jpeg",
    "upsert": true
  }'

# Response:
# {
#   "uploadUrl": "https://xxx.supabase.co/storage/v1/object/upload/...",
#   "method": "PUT",
#   "headers": { "Content-Type": "image/jpeg", ... },
#   "path": "users/test-user/photos/test.jpg"
# }

# 2. Upload file to signed URL
curl -X PUT "SIGNED_URL_FROM_STEP_1" \
  -H "Content-Type: image/jpeg" \
  --data-binary @test-image.jpg
```

Test download:

```bash
curl -X GET "https://your-proxy.vercel.app/api/storage/download-url?bucket=user-content&path=users/test-user/photos/test.jpg&expiresIn=300" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"

# Response:
# {
#   "url": "https://xxx.supabase.co/storage/v1/object/sign/...",
#   "expiresAt": "2025-10-03T12:05:00.000Z",
#   "expiresIn": 300
# }
```

---

## Security Features

✅ **No keys in app** - All Supabase credentials stay on the server  
✅ **Signed URLs** - Time-limited, secure access to storage  
✅ **JWT auth** - All requests require valid user authentication  
✅ **User isolation** - Users can only access their own files via policies  
✅ **Expiring URLs** - Download links expire after specified time  

---

## Usage in React Native

See the created `src/api/cloud-storage.ts` file for ready-to-use functions:

```typescript
import { uploadFromUri, getFileUrl } from '../api/cloud-storage';

// Upload example
const result = await uploadFromUri(
  imageUri,
  {
    bucket: 'user-content',
    path: generateUserFilePath(userId, 'photos', 'jpg'),
    contentType: 'image/jpeg',
  }
);

// Download example
const url = await getFileUrl('user-content', result.path);
<Image source={{ uri: url }} style={{ width: 200, height: 200 }} />
```

---

**Complete! Your storage system is now secure and matches your database proxy pattern.** 🎉
