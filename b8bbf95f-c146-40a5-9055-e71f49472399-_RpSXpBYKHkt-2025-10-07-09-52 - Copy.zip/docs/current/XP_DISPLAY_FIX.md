# XP Display Mismatch Fix

**Date:** October 6, 2025  
**Issue:** XP values didn't match between progress bar and stats card

---

## Problem

The HomeScreen displayed two different XP values:
- **Progress bar:** 170/300 XP (current level progress)
- **Total XP card:** 470 points earned (lifetime total)

This was confusing because they showed different metrics.

---

## Root Cause

**File:** `src/screens/HomeScreen.tsx`

```typescript
// Line 143-150: Calculate XP values
const totalXPValue = completedSkills.reduce((sum, skillId) => {
  const skill = skills.find(s => s.id === skillId);
  return sum + (skill?.xpReward || 0);
}, 0);

const xpProgress = (totalXPValue % 300) / 300;
const currentLevelXP = totalXPValue % 300;  // 470 % 300 = 170
const nextLevelXP = 300;

// Line 236: Progress bar (CORRECT)
<Text>{currentLevelXP}/{nextLevelXP} XP</Text>  // Shows 170/300 ✅

// Line 270: Total XP card (INCORRECT)
<Text>{totalXPValue}</Text>  // Shows 470 ❌
```

The progress bar correctly showed **current level progress** (170 XP toward next level), but the Total XP card showed **lifetime total** (470 XP), causing the mismatch.

---

## Solution

Changed the "TOTAL XP" card to show "CURRENT XP" with current level progress instead of lifetime total.

**Before:**
```typescript
<View className="bg-purple-500 rounded-3xl p-5 flex-1">
  <Text className="text-purple-100 text-xs font-bold mb-2">TOTAL XP</Text>
  <Text className="text-white text-3xl font-black">{totalXPValue}</Text>
  <Text className="text-purple-200 text-xs font-medium">points earned</Text>
</View>
```

**After:**
```typescript
<View className="bg-purple-500 rounded-3xl p-5 flex-1">
  <Text className="text-purple-100 text-xs font-bold mb-2">CURRENT XP</Text>
  <Text className="text-white text-3xl font-black">{currentLevelXP}</Text>
  <Text className="text-purple-200 text-xs font-medium">toward level {userLevel + 1}</Text>
</View>
```

---

## Result

Now both displays show the **same XP value** (170):
- ✅ **Progress bar:** 170/300 XP
- ✅ **Current XP card:** 170 (toward level 2)

Both now represent **current progress toward next level**, not lifetime total.

---

## Why This Makes Sense

**Leveling System:**
- Users earn XP from completing skills
- Every 300 XP = new level
- Progress bar shows: "How close am I to next level?"
- Current XP card shows: "How much XP toward next level?"

**Example:**
- User has earned 470 XP total
- They are Level 2 (0-299 XP = Level 1, 300-599 = Level 2)
- Current level progress: 470 - 300 = 170 XP
- Need 300 XP per level, so: 170/300 toward Level 3

**Display:**
- Progress bar: 170/300 XP ✅
- Current XP card: 170 toward level 3 ✅
- Level badge: LVL 2 ✅

All three metrics now align correctly!

---

## Alternative Approach (Not Used)

If we wanted to show **lifetime total XP**, we could:
1. Keep "TOTAL XP: 470 points earned"
2. Change progress bar to show "LEVEL 2" instead of "170/300 XP"

But the current approach (showing current level progress) is more gamified and motivating.

---

## Files Modified

- `src/screens/HomeScreen.tsx` (lines 269-271)

---

## Testing

To verify the fix:
1. Complete some skills to earn XP
2. Check HomeScreen
3. Verify progress bar XP matches Current XP card
4. Both should show XP toward next level (totalXP % 300)

Example scenarios:
- 150 total XP → Shows 150/300 (Level 1)
- 350 total XP → Shows 50/300 (Level 2, because 350 % 300 = 50)
- 650 total XP → Shows 50/300 (Level 3, because 650 % 300 = 50)

---

## Status

✅ **Fixed** - XP values now match between progress bar and stats card
