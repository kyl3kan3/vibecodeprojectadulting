# AI Chat Debugging Guide

## Problem
Chat isn't making calls to Vercel proxy - you don't see requests in Vercel logs.

## Debug Steps

### 1. Check Console Logs

When you send a chat message, you should see these logs in your React Native console:

```
[Proxy] proxyChat called with: {
  provider: 'openai',
  task: 'chat',
  model: 'gpt-4o-mini',
  hasMessages: true,
  messageCount: 3
}

[Proxy] JWT from provider: eyJhbGciOiJIUzI1NiI...

[Proxy] Sending request to: https://vercel-multi-ai-proxy.vercel.app/api/ai

[Proxy] Request body: {
  "provider": "openai",
  "task": "chat",
  "model": "gpt-4o-mini",
  "messages": [...],
  "temperature": 0.2,
  "max_tokens": 700
}

[Proxy] Response received: { ... }
```

### 2. If You DON'T See These Logs

The function isn't being called. Check:

**A. Are you logged in?**
- Chat requires authentication
- Check if you're signed in to the app
- Try logging out and back in

**B. Is the chat screen loading?**
- Go to Coach tab
- Type a message
- Press send
- Watch the console

**C. Check for errors**
Look for error messages like:
- "Not signed in. Please log in to use AI features."
- "Proxy error 401"
- "Missing EXPO_PUBLIC_AI_PROXY_URL"

### 3. If You See Logs But No Vercel Request

**A. Check the URL**
The log should show:
```
[Proxy] Sending request to: https://vercel-multi-ai-proxy.vercel.app/api/ai
```

Is this the correct URL? Check `.env`:
```bash
EXPO_PUBLIC_AI_PROXY_URL=https://vercel-multi-ai-proxy.vercel.app
```

**B. Check JWT Token**
The log should show:
```
[Proxy] JWT from provider: eyJhbGciOiJ...
```

If it shows:
```
[Proxy] No authTokenProvider set
```
Or:
```
[Proxy] JWT from provider: null
```

Then auth isn't working. Restart the app to ensure `App.tsx` runs the auth setup.

**C. Check Network**
- Is the device online?
- Can you reach the proxy URL in a browser?
- Try: https://vercel-multi-ai-proxy.vercel.app/

### 4. If Request is Made But Fails

**A. Check Error Response**
Look for:
```
[Proxy] Response received: { error: "..." }
```

Common errors:
- `401 Unauthorized` - JWT token is invalid
- `400 Bad Request` - Invalid payload
- `500 Internal Server Error` - Proxy issue
- `502/503/504` - Proxy down or timeout

**B. Check Vercel Logs**
Go to:
1. https://vercel.com/dashboard
2. Your proxy project
3. "Logs" tab
4. Filter by "/api/ai"

Look for:
- Request received
- Error messages
- Response sent

### 5. Manual Test

Add this to a screen to test directly:

```typescript
import { proxyChat } from '@/api/proxy';

const testChat = async () => {
  try {
    console.log('Starting test...');
    const result = await proxyChat({
      provider: "openai",
      messages: [{ role: "user", content: "test" }],
      model: "gpt-4o-mini"
    });
    console.log('Success!', result);
    Alert.alert('Success', JSON.stringify(result));
  } catch (error: any) {
    console.error('Error:', error);
    Alert.alert('Error', error.message);
  }
};

// Add a button:
<Pressable onPress={testChat}>
  <Text>Test Chat</Text>
</Pressable>
```

### 6. Check CoachScreen

The chat call happens in `src/screens/CoachScreen.tsx` around line 200-210.

Look for:
```typescript
let response = await getCoachAIResponse(aiMessages, { 
  provider: 'openai', 
  model: 'gpt-4o-mini', 
  temperature: 0.2, 
  maxTokens: 700 
});
```

Make sure:
- Function isn't commented out
- No early returns before this
- No try-catch silencing errors

### 7. Common Issues

**Issue: "No authTokenProvider set"**
**Fix:** Restart the app. The provider is set in `App.tsx` useEffect.

**Issue: "JWT from provider: null"**
**Fix:** Log in to the app first. Chat requires authentication.

**Issue: "Proxy error 404"**
**Fix:** Check the URL in `.env` - make sure it's correct.

**Issue: "Network request failed"**
**Fix:** 
- Check internet connection
- Check Vercel proxy is deployed
- Try in a browser: https://vercel-multi-ai-proxy.vercel.app/

**Issue: Logs show request but Vercel shows nothing**
**Fix:** 
- Check you're looking at the right Vercel project
- Check the timeframe in Vercel logs
- Refresh Vercel logs page

## Quick Checklist

- [ ] I'm logged into the app
- [ ] Console shows `[Proxy] proxyChat called`
- [ ] Console shows JWT token (not null)
- [ ] Console shows request to correct URL
- [ ] .env has correct EXPO_PUBLIC_AI_PROXY_URL
- [ ] Vercel proxy is deployed and online
- [ ] Device has internet connection

## Still Not Working?

1. **Restart the app completely** (not just refresh)
2. **Check you're testing in dev mode** (logs only show in dev)
3. **Try the manual test** (step 5 above)
4. **Check Vercel deployment status**
5. **Verify proxy has /api/ai endpoint**

## Expected Flow

```
1. User types message in Coach screen
2. User presses send
3. CoachScreen calls getCoachAIResponse()
4. chat-service.ts calls proxyChat()
5. proxy.ts logs: "proxyChat called"
6. proxy.ts gets JWT token
7. proxy.ts logs: "JWT from provider"
8. proxy.ts logs: "Sending request to"
9. proxy.ts makes POST to Vercel
10. Vercel receives request (shows in logs)
11. Vercel forwards to OpenAI
12. OpenAI responds
13. Vercel responds to app
14. proxy.ts logs: "Response received"
15. User sees AI response
```

If any step fails, check logs at that step!
