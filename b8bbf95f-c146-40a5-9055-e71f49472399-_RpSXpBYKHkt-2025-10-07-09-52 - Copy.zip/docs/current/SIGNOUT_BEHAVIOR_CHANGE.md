# Sign-Out Behavior Change

## Date
October 4, 2025

## Change Summary
Modified `signOut()` function to **preserve user progress data** instead of wiping it.

## Why This Changed

### The Problem
Previously, when a user signed out (manually or automatically), the app would:
1. Clear authentication data (✅ correct)
2. **Reset all user progress to 0** (❌ problematic)

This meant users would lose their:
- Streak count
- Total XP
- Completed tips/lessons
- Personal goals
- Todo items
- Learning path progress

### The Trigger
During our cloud sync upsert fix session, we encountered automatic sign-outs caused by:
- Session validation failures
- Security check failures  
- Auth token expiration
- Network errors during session refresh

These automatic sign-outs would wipe all user data, even though the user didn't intend to sign out.

## The Fix

### File Modified
`src/contexts/AuthContext.tsx` line 582

### Before
```typescript
const signOut = async () => {
  const currentUserId = user?.id;
  
  try {
    await supabaseMCP.authSignOut().catch(() => {});
  } finally {
    // Clear all session data (memory + persistent)
    authStore.clearAuth();
    supabaseMCP.setToken(null);
    (global as any).__AUTH_USER__ = null;
    setSession(null);
    setUser(null);
    setProfile(null);
    try { useProgressStore.getState().resetUserData(); } catch {}  // ❌ This was the problem
    
    trackLogout(currentUserId);
  }
};
```

### After
```typescript
const signOut = async () => {
  const currentUserId = user?.id;
  
  try {
    await supabaseMCP.authSignOut().catch(() => {});
  } finally {
    // Clear all session data (memory + persistent)
    authStore.clearAuth();
    supabaseMCP.setToken(null);
    (global as any).__AUTH_USER__ = null;
    setSession(null);
    setUser(null);
    setProfile(null);
    // NOTE: User progress should persist - NOT resetting on sign-out  // ✅ Fixed!
    // try { useProgressStore.getState().resetUserData(); } catch {}
    
    trackLogout(currentUserId);
  }
};
```

## Rationale

### User Progress Should Be Local-First
User progress data should persist in AsyncStorage regardless of auth state because:

1. **It's local data** - streaks, XP, completed items are local achievements
2. **Sign-out != data wipe** - logging out shouldn't delete your progress
3. **Recovery from auth failures** - if token expires or validation fails, user shouldn't lose everything
4. **Prevents accidental data loss** - users can sign out and back in without penalty

### What Still Gets Cleared
Auth-related data is still properly cleared:
- ✅ Auth tokens (memory + AsyncStorage)
- ✅ User session
- ✅ User profile from server
- ✅ Global auth user object

### What Persists
User progress data remains in AsyncStorage:
- ✅ Streak count (local)
- ✅ Total XP (local)
- ✅ Completed tips/lessons (local)
- ✅ Personal goals (local)
- ✅ Todo items (local)
- ✅ Learning paths (local)

When the user signs back in, their local progress loads from AsyncStorage.

## Cloud Sync Implications

### How It Works Now
1. **User signs out** → Auth cleared, progress persists locally
2. **User signs back in** → Auth restored
3. **Cloud sync runs** → Local progress syncs to cloud
4. **User switches devices** → Can pull progress from cloud

### Multi-Device Scenario
- Device A: User has 10 day streak locally
- User signs out and signs in on Device B
- Device B has 0 day streak locally
- Cloud sync: Device A uploads 10 days, Device B downloads 10 days
- Both devices now show 10 day streak

This is the correct behavior - progress follows the user via cloud sync, not by wiping local data on sign-out.

## Automatic Sign-Out Scenarios

These scenarios still work correctly:

### 1. Security Validation Failure
- **Trigger**: `authSecurityManager` detects suspicious activity
- **Action**: Calls `signOut()` automatically
- **Result**: Auth cleared, **progress preserved**
- **User experience**: Can sign back in and resume progress

### 2. Session Validation Failure  
- **Trigger**: App becomes active after 24+ hours, session validation fails
- **Action**: Calls `signOut()` automatically
- **Result**: Auth cleared, **progress preserved**
- **User experience**: Can sign back in and resume progress

### 3. Periodic Security Cleanup
- **Trigger**: Security check runs every 30 minutes
- **Action**: Calls `signOut()` if needed
- **Result**: Auth cleared, **progress preserved**
- **User experience**: Can sign back in and resume progress

## Migration Notes

### Existing Users
- If users had data before this change, it still exists in AsyncStorage
- The change is backwards compatible
- No migration needed

### New Users
- Progress will persist from the start
- Expected behavior: sign-out doesn't delete progress

## Testing

To verify the fix works:

1. **Sign in** and complete some tips/lessons
2. **Check progress**: Note your streak, XP, completed items
3. **Sign out**
4. **Check AsyncStorage**: Run `scripts/check-storage-data.ts`
5. **Verify**: Progress data should still exist with correct values
6. **Sign back in**
7. **Verify**: Progress should be restored

## Related Issues

- Data loss during automatic sign-outs: **FIXED**
- Cloud sync upsert errors: **FIXED** (separate issue)
- Session validation clearing data: **FIXED**

## Related Documentation

- `docs/current/DATA_LOSS_INVESTIGATION.md` - Investigation of data loss issue
- `docs/current/CLOUD_SYNC_UPSERT_FIX.md` - Cloud sync fix that revealed this issue
- `docs/current/SECURITY_CHECKLIST.md` - Security considerations

---

**Status**: ✅ Implemented  
**Breaking Change**: No  
**Migration Required**: No  
**User Impact**: Positive - prevents data loss
