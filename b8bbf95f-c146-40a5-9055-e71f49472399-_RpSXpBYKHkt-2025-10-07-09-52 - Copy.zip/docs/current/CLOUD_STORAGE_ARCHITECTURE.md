# 🏗️ Cloud Storage Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         REACT NATIVE APP (Client)                       │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────┐    │
│  │  src/api/cloud-storage.ts                                       │    │
│  │  • uploadFromUri()                                              │    │
│  │  • getFileUrl()                                                 │    │
│  │  • deleteFile()                                                 │    │
│  │  • listFiles()                                                  │    │
│  └────────────────────────────────────────────────────────────────┘    │
│                                 │                                        │
│                                 │ HTTPS + JWT Token                     │
│                                 ▼                                        │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│                      VERCEL PROXY (Your Server)                         │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────┐    │
│  │  /api/storage/upload-url.ts                                     │    │
│  │  1. Verify JWT token                                            │    │
│  │  2. Generate signed upload URL                                  │    │
│  │  3. Return { uploadUrl, method, headers }                       │    │
│  └────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────┐    │
│  │  /api/storage/download-url.ts                                   │    │
│  │  1. Verify JWT token                                            │    │
│  │  2. Generate signed download URL (expires in 5 min)             │    │
│  │  3. Return { url, expiresAt }                                   │    │
│  └────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  ┌────────────────────────────────────────────────────────────────┐    │
│  │  /api/storage/delete.ts                                         │    │
│  │  1. Verify JWT token                                            │    │
│  │  2. Delete file from storage                                    │    │
│  │  3. Return { success }                                          │    │
│  └────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  🔒 SERVER-SIDE ONLY:                                                   │
│     • SUPABASE_URL                                                      │
│     • SUPABASE_SERVICE_ROLE_KEY                                         │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
                                 │
                                 │ Supabase Admin API
                                 │ (Service Role Key)
                                 ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                         SUPABASE STORAGE                                │
│                                                                           │
│  📦 Buckets:                                                            │
│     ├─ user-content (private)                                          │
│     │   └─ users/                                                       │
│     │       └─ {user_id}/                                               │
│     │           ├─ photos/                                              │
│     │           ├─ documents/                                           │
│     │           └─ achievements/                                        │
│     │                                                                    │
│     ├─ avatars (private)                                               │
│     │   └─ users/                                                       │
│     │       └─ {user_id}/                                               │
│     │           └─ profile.jpg                                          │
│     │                                                                    │
│     └─ achievements (public, optional)                                 │
│         └─ badges/                                                      │
│                                                                           │
│  🔒 Storage Policies:                                                   │
│     • Users can only access files in /users/{their_id}/                │
│     • Enforced at database level                                       │
│     • No unauthorized access possible                                   │
│                                                                           │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 📊 Upload Flow Diagram

```
┌─────────────┐
│   User      │
│  Picks      │
│  Image      │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 1: Request Signed URL                                  │
│                                                               │
│ App → Proxy:                                                 │
│   POST /api/storage/upload-url                              │
│   Headers: { Authorization: "Bearer {JWT}" }                │
│   Body: {                                                    │
│     bucket: "user-content",                                 │
│     path: "users/123/photos/1234567890.jpg",               │
│     contentType: "image/jpeg"                               │
│   }                                                          │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Proxy Verifies & Generates                          │
│                                                               │
│ 1. Verify JWT token ✓                                       │
│ 2. Call Supabase Storage API                                │
│ 3. Get signed upload URL                                    │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 3: Proxy Returns Signed URL                            │
│                                                               │
│ Proxy → App:                                                 │
│   {                                                          │
│     uploadUrl: "https://xxx.supabase.co/storage/.../sign",  │
│     method: "PUT",                                           │
│     headers: { "Content-Type": "image/jpeg" }               │
│   }                                                          │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 4: App Uploads File                                    │
│                                                               │
│ App → Supabase:                                              │
│   PUT {uploadUrl}                                            │
│   Body: [binary file data]                                  │
│                                                               │
│ ✅ No credentials needed!                                   │
│ ✅ Signed URL is temporary (1 hour)                         │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 5: File Stored                                         │
│                                                               │
│ Supabase Storage:                                            │
│   user-content/                                              │
│   └─ users/123/photos/1234567890.jpg ✓                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 📊 Download Flow Diagram

```
┌─────────────┐
│   User      │
│  Wants to   │
│  View Image │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 1: Request Signed URL                                  │
│                                                               │
│ App → Proxy:                                                 │
│   GET /api/storage/download-url                             │
│   Query: ?bucket=user-content&path=users/123/...&expiresIn=300│
│   Headers: { Authorization: "Bearer {JWT}" }                │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 2: Proxy Verifies & Generates                          │
│                                                               │
│ 1. Verify JWT token ✓                                       │
│ 2. Call Supabase Storage API                                │
│ 3. Get signed download URL (5-min expiry)                   │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 3: Proxy Returns Signed URL                            │
│                                                               │
│ Proxy → App:                                                 │
│   {                                                          │
│     url: "https://xxx.supabase.co/storage/.../sign?token=...",│
│     expiresAt: "2025-10-03T12:05:00.000Z"                   │
│   }                                                          │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 4: App Uses URL                                        │
│                                                               │
│ <Image source={{ uri: url }} />                             │
│                                                               │
│ ✅ No credentials needed!                                   │
│ ✅ URL expires after 5 minutes                              │
│ ✅ Must request new URL after expiry                        │
└─────────────────────────────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────────────────────────┐
│ Step 5: Image Loaded                                        │
│                                                               │
│ User sees image in app ✓                                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔒 Security Model

```
┌─────────────────────────────────────────────────────────────┐
│                    Security Layers                           │
└─────────────────────────────────────────────────────────────┘

Layer 1: JWT Authentication
├─ All requests require valid JWT token
├─ Token verified by proxy before any operation
└─ Invalid token = 401 Unauthorized

Layer 2: User Isolation (Storage Policies)
├─ Users can only access /users/{their_id}/**
├─ Enforced at Supabase level
└─ Cannot access other users' files

Layer 3: Signed URLs
├─ Temporary access only (1 hour upload, 5 min download)
├─ URLs expire automatically
└─ Must request new URL after expiration

Layer 4: Server-Side Credentials
├─ Supabase keys only on Vercel proxy (server)
├─ React Native app never sees credentials
└─ Safe even if app is decompiled

Layer 5: Content Type Validation
├─ Proxy validates content types
├─ Prevents malicious uploads
└─ MIME type enforcement
```

---

## 📈 Data Flow Comparison

### ❌ Insecure (Credentials in App)
```
App has Supabase key → Direct upload → Storage
   └─ Problem: Anyone can decompile app and steal key
```

### ✅ Secure (Signed URLs via Proxy)
```
App → Proxy (verifies JWT) → Signed URL → App → Upload → Storage
   └─ Solution: No keys in app, temporary URLs, user isolation
```

---

## 🎯 Why This Architecture?

### Benefits

1. **Security**
   - No Supabase credentials in React Native app
   - Even if app is decompiled, no keys to steal
   - User isolation enforced server-side

2. **Scalability**
   - Direct uploads to Supabase (not through proxy)
   - Proxy only generates URLs (lightweight)
   - Bandwidth efficient

3. **Flexibility**
   - Easy to add virus scanning
   - Easy to add file size limits
   - Easy to add custom validation
   - All logic in one place (proxy)

4. **Cost Effective**
   - Signed URLs expire automatically
   - No permanent public URLs
   - Storage policies prevent abuse

5. **Matches Your Pattern**
   - Same as database proxy pattern
   - Consistent architecture
   - Easy to understand and maintain

---

## 📚 File Organization

```
workspace/
├── src/
│   ├── api/
│   │   ├── cloud-storage.ts              ← Client service
│   │   ├── chat-service.ts
│   │   └── openai.ts
│   │
│   └── examples/
│       └── CloudStorageExample.tsx       ← Usage examples
│
├── VERCEL_STORAGE_ENDPOINTS.md           ← Proxy implementation
├── CLOUD_STORAGE_SUMMARY.md              ← Comprehensive guide
├── QUICK_START_CLOUD_STORAGE.md          ← Quick reference
├── CLOUD_STORAGE_ARCHITECTURE.md         ← This file (diagrams)
└── VERCEL_PROXY_CHANGES.md               ← Database upsert fix
```

---

**Next**: Deploy Vercel endpoints and start using cloud storage! 🚀
