# Documentation Structure

This directory contains all project documentation organized for easy navigation.

## Directory Structure

```
docs/
├── current/          # Active, current documentation
│   ├── REFACTORING_FINAL_SUMMARY.md
│   ├── CLOUD_STORAGE_ARCHITECTURE.md
│   ├── CLOUD_STORAGE_SUMMARY.md
│   ├── CLOUD_SYNC_QUICKSTART.md
│   ├── CLOUD_SYNC_RESTORED.md
│   ├── AI-SUBSTEP-RESEARCH-FEATURE.md
│   ├── AI_CHAT_DEBUG_GUIDE.md
│   ├── SECURITY_CHECKLIST.md
│   ├── VERCEL_STORAGE_ENDPOINTS.md
│   └── VERCEL_PROXY_CHANGES.md
│
└── archive/          # Historical documentation (for reference)
    ├── refactoring/      # Refactoring phase documentation (18 files)
    ├── cloud-sync/       # Cloud sync iteration docs (8 files)
    ├── proxy-fixes/      # Proxy/Vercel troubleshooting (16 files)
    ├── database-fixes/   # Database and deployment fixes (10 files)
    ├── misc-fixes/       # Individual feature fixes (8 files)
    └── setup/            # Setup and onboarding guides (3 files)
```

## Current Documentation

### Architecture & Implementation
- **REFACTORING_FINAL_SUMMARY.md** - Complete refactoring history and achievements
- **CLOUD_STORAGE_ARCHITECTURE.md** - Cloud storage system architecture
- **CLOUD_STORAGE_SUMMARY.md** - Cloud storage implementation details
- **AI-SUBSTEP-RESEARCH-FEATURE.md** - AI-powered substep research feature

### Setup & Configuration
- **CLOUD_SYNC_QUICKSTART.md** - Quick start guide for cloud sync setup
- **VERCEL_PROXY_CHANGES.md** - Required Vercel proxy configuration changes
- **VERCEL_STORAGE_ENDPOINTS.md** - API endpoint reference

### Troubleshooting & Security
- **AI_CHAT_DEBUG_GUIDE.md** - Debugging guide for AI chat issues
- **SECURITY_CHECKLIST.md** - Security best practices and checklist
- **CLOUD_SYNC_RESTORED.md** - Cloud sync restoration and status

### Recent Fixes (October 2025)
- **CLOUD_SYNC_UPSERT_FIX.md** - Fixed upsert operations to include onConflict parameter
- **DATA_LOSS_INVESTIGATION.md** - Investigation and prevention of data loss on sign-out
- **SIGNOUT_BEHAVIOR_CHANGE.md** - Why user progress now persists across sign-outs
- **SESSION_SUMMARY_OCT_4_2025.md** - Complete session summary of cloud sync fixes
- **PROXY_PAYLOAD_CLEANUP_TASK.md** - Optional cleanup task for proxy payload

## Archive Documentation

The `archive/` directory contains historical documentation from development iterations. These files are kept for reference but represent completed work or superseded approaches.

### When to Use Archive Docs
- Understanding historical context of decisions
- Debugging similar issues encountered in the past
- Learning from previous implementation attempts
- Reference for what was tried and why it didn't work

### Archive Categories

**refactoring/** - All 6 phases of the comprehensive refactoring project
- Phase plans, progress tracking, and completion summaries
- Migration status and quickstart guides

**cloud-sync/** - Iterative cloud sync implementation attempts
- Various approaches tried (disabled, proxy-enabled, fetch-first, etc.)
- Troubleshooting duplicate key errors and upsert issues

**proxy-fixes/** - Proxy and Vercel troubleshooting documentation
- 401, 405, 500 error debugging
- Gateway vs direct provider implementations
- TypeScript errors and configuration issues

**database-fixes/** - Database operation and deployment fixes
- Duplicate key error resolution
- Supabase credential setup
- Deployment testing checklists

**misc-fixes/** - Individual feature fixes
- Daily challenge, JWT persistence, terminology consistency
- Data loss reports and recovery plans
- Security implementation

**setup/** - Initial setup and quickstart guides
- Superseded by current documentation in `docs/current/`

## Maintenance

### Adding New Documentation
1. Create new docs in `docs/current/` for active documentation
2. Use clear, descriptive filenames
3. Update this README with links to new docs

### Archiving Documentation
When a feature is complete or an approach is superseded:
1. Move the doc from `current/` to appropriate `archive/` subdirectory
2. Update this README to remove the link
3. Consider consolidating into a summary doc if useful

### Cleaning Up
Periodically review `archive/` for docs that can be:
- Consolidated into summary documents
- Removed if no longer relevant (keep in git history)
- Moved to a project wiki or external documentation

## Project Context

This documentation structure was created after completing a comprehensive 6-phase refactoring project that transformed the codebase. The archive contains ~63 historical troubleshooting docs from iterative development, while current docs (10 files) represent active, relevant documentation.

**Original state:** 73 markdown files in project root  
**Current state:** 1 file in root (ReadMeKen.md), organized structure in docs/

---

**Last Updated:** October 4, 2025  
**Documentation Files:** 78 total (15 current, 63 archived)
